# ctmGP — box / anchor decomposition R wrappers.
#
# Two distinct decompositions of the non-dominated region:
#   box_decompose()    — region tiling for visualization / volume partitioning.
#                        NOT consumed by the EHVI engine.
#   anchor_decompose() — Yang-2019 anchor-box decomposition.  Each anchor box
#                        admits the per-box HVI formula
#                        ∏_m (u_m - max(y_m, l_m)).  This is what the EHVI
#                        engine's per-leaf moment dispatcher actually consumes.

#' Region-tiling box decomposition (visualization / volume partition).
#'
#' Partitions the non-dominated region into axis-aligned hyperboxes whose
#' total volume equals the dominated hypervolume "negative space".  This is
#' useful for plotting and for sanity checks but is **NOT** the decomposition
#' that the EHVI engine consumes — see [anchor_decompose()] for that.
#'
#' Supports T = 2 and T = 3.  T >= 4 not implemented (current scope).
#'
#' @param pareto_set matrix of non-dominated points, rows = points, cols = objectives.
#'   Must already be Pareto-filtered; call [pareto_front()] first if unsure.
#' @param ref_point length-T numeric; must componentwise-dominate every row of
#'   `pareto_set`.  If `NULL`, derived via [ctmgp_default_ref_point()].
#' @return list with
#'   - `lower`: T × n_boxes matrix; column k = lower corner of box k
#'   - `upper`: T × n_boxes matrix; column k = upper corner of box k
#'   - `n_boxes`: integer scalar
#'   - `ref_point`: the resolved reference point
#' @export
box_decompose <- function(pareto_set, ref_point = NULL) {
  if (!is.matrix(pareto_set)) pareto_set <- as.matrix(pareto_set)
  storage.mode(pareto_set) <- "double"
  if (is.null(ref_point)) ref_point <- ctmgp_default_ref_point(pareto_set)
  ref_point <- as.numeric(ref_point)
  res <- ctmgp_box_decompose_cpp(pareto_set, ref_point)
  res$n_boxes   <- ncol(res$lower)
  res$ref_point <- ref_point
  res
}

#' Yang-2019 anchor-box decomposition (T = 2 or T = 3).
#'
#' Returns the anchor boxes consumed by the EHVI engine's per-leaf moment
#' dispatcher.  For each box `k` and any non-PF-dominated `y` inside it,
#' \eqn{HVI(y, PF, ref) = \prod_m (\text{upper}[m, k] - \max(y_m, \text{lower}[m, k]))}.
#'
#' T = 2 uses the Hupkens-Yang triangular enumeration → (n+1)(n+2)/2 boxes.
#' T = 3 uses slab construction over z-sorted PF (paper-scale O(n³) worst case).
#' T ≥ 4 not implemented (current paper scope).
#'
#' @param pareto_set non-dominated front, rows = points (use [pareto_front()]
#'   first if not already filtered).
#' @param ref_point length-T numeric.  Must componentwise STRICTLY dominate
#'   every row of `pareto_set`.  If `NULL`, derived via
#'   [ctmgp_default_ref_point()].
#' @return list with
#'   - `lower`: T × n_boxes matrix
#'   - `upper`: T × n_boxes matrix (also serves as the anchor of each box)
#'   - `n_boxes`: integer scalar
#'   - `ref_point`: the resolved reference point
#' @export
anchor_decompose <- function(pareto_set, ref_point = NULL) {
  if (!is.matrix(pareto_set)) pareto_set <- as.matrix(pareto_set)
  storage.mode(pareto_set) <- "double"
  if (is.null(ref_point)) ref_point <- ctmgp_default_ref_point(pareto_set)
  ref_point <- as.numeric(ref_point)
  res <- ctmgp_anchor_decompose_cpp(pareto_set, ref_point)
  res$n_boxes   <- ncol(res$lower)
  res$ref_point <- ref_point
  res
}
