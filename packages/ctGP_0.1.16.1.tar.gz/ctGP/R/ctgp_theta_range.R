.ctgp_theta_range_eps <- function() {
  1e-6
}

.ctgp_sanitize_theta_range <- function(theta_range,
                                       arg_name = "theta_range",
                                       warn = TRUE,
                                       eps = .ctgp_theta_range_eps()) {
  if (is.null(theta_range)) {
    return(NULL)
  }

  theta_range_raw <- as.numeric(theta_range)
  if (length(theta_range_raw) != 2L || any(!is.finite(theta_range_raw))) {
    stop(arg_name, " must be a finite numeric vector of length 2.")
  }

  lower <- theta_range_raw[1L]
  upper <- theta_range_raw[2L]
  if (lower < 0 || upper > pi) {
    stop(arg_name, " must satisfy 0 <= lower < upper <= pi.")
  }

  sanitized <- FALSE
  if (lower == 0) {
    lower <- eps
    sanitized <- TRUE
  }
  if (upper == pi) {
    upper <- pi - eps
    sanitized <- TRUE
  }

  if (!(lower > 0 && lower < upper && upper < pi)) {
    stop(
      arg_name,
      " must satisfy 0 <= lower < upper <= pi, and the sanitized interval must lie strictly inside (0, pi)."
    )
  }

  out <- c(lower, upper)
  attr(out, "requested") <- theta_range_raw
  attr(out, "sanitized") <- sanitized
  attr(out, "theta_eps") <- eps

  if (sanitized && isTRUE(warn)) {
    warning(
      arg_name,
      " reached the closed spherical-angle boundary. The high-level wrapper sanitized it to the open interval (",
      format(out[1L], digits = 7),
      ", ",
      format(out[2L], digits = 7),
      ") before calling the C++ backend.",
      call. = FALSE
    )
  }

  out
}

.ctgp_expand_fi_range <- function(range, d, arg_name = "range") {
  if (is.null(range)) {
    return(NULL)
  }
  range <- as.numeric(range)
  if (length(range) == 2L) {
    range <- c(rep(range[1L], d), rep(range[2L], d))
  }
  if (length(range) != 2L * d || any(!is.finite(range))) {
    stop(arg_name, " must have length 2 or 2 * input dimension.")
  }
  lower <- range[seq_len(d)]
  upper <- range[d + seq_len(d)]
  if (any(lower >= upper)) {
    stop(arg_name, " must satisfy lower < upper elementwise.")
  }
  range
}


.ctgp_theta_range_use_closed_bounds <- function(kernel_mode = NULL) {
  if (is.null(kernel_mode)) {
    kernel_mode <- .ctgp_hidden_option_chr(
      'ctGP.internal.debug.optimizer_mode',
      fallback = 'ctGP.internal.pso_kernel_mode',
      default = 'qpso'
    )
  }
  kernel_mode <- as.character(kernel_mode[[1L]])
  kernel_mode %in% c('globpso_exact', 'qpso_exact')
}

.ctgp_validate_theta_range_closed <- function(theta_range,
                                              arg_name = 'theta_range') {
  if (is.null(theta_range)) {
    return(NULL)
  }

  theta_range_raw <- as.numeric(theta_range)
  if (length(theta_range_raw) != 2L || any(!is.finite(theta_range_raw))) {
    stop(arg_name, ' must be a finite numeric vector of length 2.')
  }

  lower <- theta_range_raw[1L]
  upper <- theta_range_raw[2L]
  if (!(0 <= lower && lower < upper && upper <= pi)) {
    stop(arg_name, ' must satisfy 0 <= lower < upper <= pi.')
  }

  out <- c(lower, upper)
  attr(out, 'requested') <- theta_range_raw
  attr(out, 'sanitized') <- FALSE
  out
}

.ctgp_prepare_theta_range_current <- function(theta_range,
                                              arg_name = 'theta_range',
                                              warn = TRUE,
                                              eps = .ctgp_theta_range_eps(),
                                              kernel_mode = NULL) {
  if (.ctgp_theta_range_use_closed_bounds(kernel_mode)) {
    return(.ctgp_validate_theta_range_closed(theta_range, arg_name = arg_name))
  }
  .ctgp_sanitize_theta_range(theta_range, arg_name = arg_name, warn = warn, eps = eps)
}
