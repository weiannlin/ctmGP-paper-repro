#ifndef CTGP_GLOBAL_CORE_H
#define CTGP_GLOBAL_CORE_H

#include <RcppArmadillo.h>
#include <string>
#include <vector>

#include "objective_base.h"
#include "gp_model.h"

struct ctgp_global_gp_fit_result {
  arma::vec fi;
  arma::vec lower;
  arma::vec upper;
  arma::vec init;
  double objective;
  int n_eval;
  bool converged;
  bool success;
  double h_nugget;
  int objective_mode;
  std::string message;

  ctgp_global_gp_fit_result()
    : objective(arma::datum::inf),
      n_eval(0),
      converged(false),
      success(false),
      h_nugget(0.0),
      objective_mode(GP_OBJECTIVE_STABLE),
      message("") {}
};

struct ctgp_bcd_state {
  arma::mat H_base;
  arma::mat H_effective;
  arma::mat H_inv;
  arma::vec mu;
  arma::mat tau_cov_base;
  arma::mat tau_cov_effective;
  arma::mat tau_corr;
  arma::mat y_matrix;
  arma::mat y_matrix_observed;
  arma::umat missing_mask;
  arma::mat level_fi;
  double h_nugget;
  double t_nugget;
  double rcond_h;
  double rcond_t;
  double neg_lik;
  double scale_divisor;
  int mc_samples;
  bool used_monte_carlo;
  bool success;
  std::string regime;
  std::string message;

  ctgp_bcd_state()
    : h_nugget(0.0),
      t_nugget(0.0),
      rcond_h(NA_REAL),
      rcond_t(NA_REAL),
      neg_lik(arma::datum::inf),
      scale_divisor(NA_REAL),
      mc_samples(0),
      used_monte_carlo(false),
      success(false),
      regime("common"),
      message("") {}
};

double ctgp_compute_nugget_tb(const arma::mat& mat, double condition_target = 1e8);
arma::mat ctgp_cov2cor_sym(const arma::mat& cov);
Rcpp::List ctgp_default_global_bounds(const arma::mat& design);

class ctgp_global_gp_objective : public objective_base {
private:
  std::vector<arma::mat> design_list_;
  std::vector<arma::vec> y_list_;
  bool nugget_provided_;
  double nugget_value_;
  bool use_openmp_;
  int num_threads_;
  int objective_mode_;

public:
  ctgp_global_gp_objective(
      const std::vector<arma::mat>& design_list,
      const std::vector<arma::vec>& y_list,
      bool nugget_provided,
      double nugget_value,
      bool use_openmp,
      int num_threads,
      int objective_mode
  );

  double eval(const arma::vec& par) override;
};

class ctgp_bcd_objective : public objective_base {
private:
  arma::mat design_;
  arma::mat y_matrix_;
  arma::mat tau_cov_current_;
  bool nugget_provided_;
  double nugget_value_;

public:
  ctgp_bcd_objective(
      const arma::mat& design,
      const arma::mat& y_matrix,
      const arma::mat& tau_cov_current,
      bool nugget_provided,
      double nugget_value
  );

  double eval(const arma::vec& fi) override;
};

ctgp_global_gp_fit_result ctgp_global_gp_fit_core(
    const arma::mat& coerce_data,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode = GP_OBJECTIVE_LEGACY_EXACT
);

ctgp_bcd_state ctgp_bcd_update_given_fi(
    const arma::vec& fi,
    const arma::mat& design,
    const arma::mat& y_matrix,
    bool nugget_provided,
    double nugget_value
);

ctgp_bcd_state ctgp_bcd_union_update_given_fi(
    const arma::vec& fi,
    const arma::mat& coerce_data,
    const arma::mat& union_design,
    const std::vector<int>& level_ids,
    const std::vector<arma::uvec>& group_union_index,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    int union_mcmc_samples,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode = GP_OBJECTIVE_LEGACY_EXACT
);

Rcpp::List ctgp_bcd_loop_core(
    const std::string& regime,
    const arma::mat& coerce_data,
    const arma::mat& design,
    const arma::mat& y_matrix,
    const arma::mat& union_design,
    const std::vector<int>& level_ids,
    const std::vector<arma::uvec>& group_union_index,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    bool init_provided,
    int bcd_loops,
    double bcd_tol,
    int union_mcmc_samples,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode = GP_OBJECTIVE_LEGACY_EXACT
);

Rcpp::List ctgp_bcd_common_loop_core(
    const arma::mat& coerce_data,
    const arma::mat& design,
    const arma::mat& y_matrix,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    bool init_provided,
    int bcd_loops,
    double bcd_tol,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode = GP_OBJECTIVE_LEGACY_EXACT
);

#endif
