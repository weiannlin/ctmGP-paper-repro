.ctgp_gpreg_resolve_optimizer_control <- function(optimizer_control) {
  defaults <- list(
    swarm_size = 64L,
    max_iter = 200L,
    c1 = 2.05,
    c2 = 2.05,
    w = 0.7,
    tol = 1e-6,
    use_openmp = TRUE,
    num_threads = 0L,
    seed = NULL
  )

  if (is.null(optimizer_control)) {
    optimizer_control <- list()
  }
  if (!is.list(optimizer_control)) {
    stop("optimizer_control must be a list.")
  }

  unknown <- setdiff(names(optimizer_control), names(defaults))
  if (length(unknown) > 0L) {
    stop("Unknown entries in optimizer_control: ", paste(unknown, collapse = ", "), ".")
  }

  control <- defaults
  if (length(optimizer_control) > 0L) {
    control[names(optimizer_control)] <- optimizer_control
  }

  control$swarm_size <- as.integer(control$swarm_size)
  control$max_iter <- as.integer(control$max_iter)
  control$c1 <- as.numeric(control$c1)
  control$c2 <- as.numeric(control$c2)
  control$w <- as.numeric(control$w)
  control$tol <- as.numeric(control$tol)
  control$use_openmp <- isTRUE(control$use_openmp)
  control$num_threads <- as.integer(control$num_threads)
  if (!is.null(control$seed)) {
    control$seed <- as.integer(control$seed)
  }

  if (length(control$swarm_size) != 1L || is.na(control$swarm_size) || control$swarm_size < 1L) stop("optimizer_control$swarm_size must be a positive integer scalar.")
  if (length(control$max_iter) != 1L || is.na(control$max_iter) || control$max_iter < 1L) stop("optimizer_control$max_iter must be a positive integer scalar.")
  if (length(control$c1) != 1L || !is.finite(control$c1)) stop("optimizer_control$c1 must be a finite numeric scalar.")
  if (length(control$c2) != 1L || !is.finite(control$c2)) stop("optimizer_control$c2 must be a finite numeric scalar.")
  if (length(control$w) != 1L || !is.finite(control$w)) stop("optimizer_control$w must be a finite numeric scalar.")
  if (length(control$tol) != 1L || !is.finite(control$tol) || control$tol < 0) stop("optimizer_control$tol must be a finite nonnegative numeric scalar.")
  if (length(control$num_threads) != 1L || is.na(control$num_threads)) stop("optimizer_control$num_threads must be an integer scalar.")
  if (!is.null(control$seed) && (length(control$seed) != 1L || is.na(control$seed))) stop("optimizer_control$seed must be NULL or an integer scalar.")

  control
}

.ctgp_gpreg_collect_omp_info <- function(control) {
  compiled <- tryCatch(isTRUE(ctgp_openmp_enabled_cpp()), error = function(e) FALSE)
  runtime_max <- tryCatch(as.integer(ctgp_openmp_max_threads_cpp()), error = function(e) NA_integer_)

  list(
    compiled = compiled,
    use_openmp = control$use_openmp,
    num_threads_requested = control$num_threads,
    num_threads_runtime_max = runtime_max
  )
}

.ctgp_gpreg_make_data_names <- function(data) {
  d <- ncol(data) - 1L
  if (d < 1L) stop("data must contain at least one input column and one response column.")

  raw_names <- colnames(data)
  default_names <- c(paste0("x", seq_len(d)), "y")

  if (is.null(raw_names)) {
    final_names <- default_names
  } else {
    raw_names <- as.character(raw_names)
    if (length(raw_names) < d + 1L) raw_names <- c(raw_names, rep("", d + 1L - length(raw_names)))
    raw_names <- raw_names[seq_len(d + 1L)]
    use_names <- ifelse(!is.na(raw_names) & nzchar(raw_names), raw_names, default_names)
    final_names <- make.names(use_names, unique = TRUE)
  }

  list(x = final_names[seq_len(d)], y = final_names[d + 1L])
}

.ctgp_gpreg_prepare_mean_data <- function(data) {
  d <- ncol(data) - 1L
  name_info <- .ctgp_gpreg_make_data_names(data)
  x_df <- as.data.frame(data[, seq_len(d), drop = FALSE])
  names(x_df) <- name_info$x
  y_vec <- data[, d + 1L]
  mean_df <- x_df
  mean_df$y <- y_vec
  if (!identical(name_info$y, "y")) mean_df[[name_info$y]] <- y_vec
  list(data = mean_df, x_colnames_used = name_info$x, y_colname_used = name_info$y)
}

.ctgp_gpreg_normalize_formula <- function(mean_formula, env = parent.frame()) {
  fml <- if (inherits(mean_formula, "formula")) mean_formula else stats::as.formula(mean_formula, env = env)
  environment(fml) <- env
  fml
}

.ctgp_gpreg_validate_f_matrix <- function(f_matrix, n, context = "f_matrix") {
  f_matrix <- as.matrix(f_matrix)
  storage.mode(f_matrix) <- "double"
  if (nrow(f_matrix) != n) stop(context, " must have the same number of rows as the training data.")
  if (ncol(f_matrix) < 1L) stop(context, " must have at least one column.")
  if (any(!is.finite(f_matrix))) stop(context, " must contain only finite numeric values.")
  if (qr(f_matrix)$rank < ncol(f_matrix)) stop(context, " is rank deficient. Please remove linearly dependent columns.")
  if (is.null(colnames(f_matrix))) colnames(f_matrix) <- paste0("term", seq_len(ncol(f_matrix)))
  f_matrix
}

.ctgp_gpreg_build_formula_f_matrix <- function(formula_obj, mean_data, n) {
  trm <- stats::terms(formula_obj, data = mean_data)
  if (attr(trm, "response") > 0L) trm <- stats::delete.response(trm)
  rhs_formula <- stats::formula(trm)
  environment(rhs_formula) <- environment(formula_obj)
  mf <- stats::model.frame(rhs_formula, data = mean_data, na.action = stats::na.fail)
  f_matrix_use <- stats::model.matrix(rhs_formula, data = mf)
  f_matrix_use <- .ctgp_gpreg_validate_f_matrix(f_matrix_use, n, context = "Mean design matrix generated from mean_formula")
  list(f_matrix = f_matrix_use, rhs_formula = rhs_formula, mean_formula_chr = paste(deparse(rhs_formula), collapse = ""))
}

.ctgp_gpreg_prepare_fit_mean <- function(data, f_matrix = NULL, mean_formula = NULL, formula_env = parent.frame()) {
  n <- nrow(data)
  mean_data_info <- .ctgp_gpreg_prepare_mean_data(data)
  mean_data <- mean_data_info$data
  x_colnames_used <- mean_data_info$x_colnames_used

  if (!is.null(f_matrix) && !is.null(mean_formula)) stop("At most one of f_matrix and mean_formula can be supplied.")

  if (is.null(f_matrix) && is.null(mean_formula)) {
    f_matrix_use <- matrix(1, nrow = n, ncol = 1L)
    colnames(f_matrix_use) <- "(Intercept)"
    return(list(f_matrix = f_matrix_use, mean_source = "default", mean_structure = "formula: ~1", mean_formula = "~1", mean_terms = colnames(f_matrix_use), x_colnames_used = x_colnames_used))
  }

  if (!is.null(mean_formula)) {
    formula_obj <- .ctgp_gpreg_normalize_formula(mean_formula, env = formula_env)
    formula_info <- .ctgp_gpreg_build_formula_f_matrix(formula_obj, mean_data, n)
    return(list(f_matrix = formula_info$f_matrix, mean_source = "formula", mean_structure = paste0("formula: ", formula_info$mean_formula_chr), mean_formula = formula_info$mean_formula_chr, mean_terms = colnames(formula_info$f_matrix), x_colnames_used = x_colnames_used))
  }

  f_matrix_use <- .ctgp_gpreg_validate_f_matrix(f_matrix, n, context = "f_matrix")
  list(f_matrix = f_matrix_use, mean_source = "f_matrix", mean_structure = paste0("custom f_matrix (", ncol(f_matrix_use), " terms)"), mean_formula = NULL, mean_terms = colnames(f_matrix_use), x_colnames_used = x_colnames_used)
}

.ctgp_gpreg_default_nugget_spec <- function(y) {
  y_var <- stats::var(as.numeric(y))
  if (!is.finite(y_var) || y_var <= 0) y_var <- 1
  lower <- max(1e-8 * y_var, 1e-12)
  upper <- max(y_var, lower * 1e4)
  init <- sqrt(lower * upper)
  list(lower = lower, upper = upper, init = init)
}

fit_gp_regression <- function(data,
                              init_param = NULL,
                              range = NULL,
                              nugget_init = NULL,
                              nugget_range = NULL,
                              f_matrix = NULL,
                              mean_formula = NULL,
                              normalization = "none",
                              normalize_response = FALSE,
                              optimizer_control = list()) {
  data <- as.matrix(data)
  if (ncol(data) < 2L) stop("data must have at least one input column and one response column.")
  storage.mode(data) <- "double"
  d <- ncol(data) - 1L
  normalization <- .ctgp_resolve_normalization_method(normalization)

  input_normalizer <- NULL
  response_normalizer <- NULL
  data_fit <- data
  if (!identical(normalization, "none")) {
    x_norm <- .ctgp_normalize_training_matrix(data[, seq_len(d), drop = FALSE], normalization = normalization)
    data_fit[, seq_len(d)] <- as.matrix(x_norm$x)
    input_normalizer <- x_norm$normalizer
  }
  if (isTRUE(normalize_response) && !identical(normalization, "none")) {
    y_norm <- .ctgp_normalize_response_vector(data_fit[, d + 1L], normalization = normalization)
    data_fit[, d + 1L] <- y_norm$y
    response_normalizer <- y_norm$normalizer
  }

  if (!is.null(init_param)) {
    init_param <- as.numeric(init_param)
    if (length(init_param) != d) stop("init_param must have length equal to the number of input variables.")
  }
  range_requested <- if (is.null(range)) NULL else as.numeric(range)

  if (!is.null(range)) {
    range <- .ctgp_expand_fi_range(range, d = d, arg_name = "range")
  }

  y <- data[, d + 1L]
  nugget_defaults <- .ctgp_gpreg_default_nugget_spec(y)

  if (is.null(nugget_range)) {
    nugget_range <- c(nugget_defaults$lower, nugget_defaults$upper)
  } else {
    nugget_range <- as.numeric(nugget_range)
    if (length(nugget_range) != 2L || any(!is.finite(nugget_range)) || nugget_range[1] <= 0 || nugget_range[2] <= nugget_range[1]) {
      stop("nugget_range must be a numeric vector of length 2 satisfying 0 < lower < upper.")
    }
  }

  if (is.null(nugget_init)) {
    nugget_init <- nugget_defaults$init
  } else {
    nugget_init <- as.numeric(nugget_init)
    if (length(nugget_init) != 1L || !is.finite(nugget_init) || nugget_init <= 0) {
      stop("nugget_init must be NULL or a positive finite numeric scalar.")
    }
  }
  if (nugget_init < nugget_range[1] || nugget_init > nugget_range[2]) {
    stop("nugget_init must lie within nugget_range.")
  }

  mean_info <- .ctgp_gpreg_prepare_fit_mean(data = data_fit, f_matrix = f_matrix, mean_formula = mean_formula, formula_env = parent.frame())
  control <- .ctgp_gpreg_resolve_optimizer_control(optimizer_control)
  kernel_mode <- .ctgp_resolve_pso_kernel_mode()

  t_start <- proc.time()

  seed_cpp <- if (is.null(control$seed)) -1L else control$seed
  if (identical(kernel_mode, 'globpso_exact') && !is.null(control$seed)) {
    set.seed(control$seed)
    seed_cpp <- -1L
  }

  fit <- fit_gp_regression_cpp(
    data = data_fit,
    init_param = init_param,
    range = range,
    nugget_init = nugget_init,
    nugget_range = nugget_range,
    f_matrix = mean_info$f_matrix,
    swarm_size = control$swarm_size,
    max_iter = control$max_iter,
    c1 = control$c1,
    c2 = control$c2,
    w = control$w,
    tol = control$tol,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    seed = seed_cpp
  )

  elapsed <- proc.time() - t_start

  if (!is.null(fit$f_matrix)) {
    fit$f_matrix <- as.matrix(fit$f_matrix)
    colnames(fit$f_matrix) <- mean_info$mean_terms
  }
  if (!is.null(fit$beta_vec)) {
    fit$beta_vec <- as.matrix(fit$beta_vec)
    rownames(fit$beta_vec) <- mean_info$mean_terms
  }

  fit$timing <- list(
    elapsed = unname(elapsed["elapsed"]),
    user_self = unname(elapsed["user.self"]),
    sys_self = unname(elapsed["sys.self"])
  )
  fit$optimizer_control <- control
  fit$optimizer_mode <- kernel_mode
  fit$omp <- .ctgp_gpreg_collect_omp_info(control)
  fit$range_requested <- range_requested
  fit$range_used <- if (!is.null(fit$lower) && !is.null(fit$upper)) c(as.numeric(fit$lower), as.numeric(fit$upper)) else range
  fit$seed_requested <- control$seed
  fit$seed_cpp_used <- seed_cpp
  fit$r_seed_set_before_cpp <- identical(kernel_mode, "globpso_exact") && !is.null(control$seed)
  fit$mean_source <- mean_info$mean_source
  fit$mean_structure <- mean_info$mean_structure
  fit$mean_formula <- mean_info$mean_formula
  fit$mean_terms <- mean_info$mean_terms
  fit$x_colnames_used <- mean_info$x_colnames_used
  fit$noise_model <- "estimated_nugget"
  fit$data_type_supported <- c("noise-free", "noisy")
  fit$normalization <- normalization
  fit$normalize_response <- isTRUE(normalize_response)
  fit$input_normalizer <- input_normalizer
  fit$response_normalizer <- response_normalizer
  fit$training_data_original <- data

  class(fit) <- c("gp_regression_fit", class(fit))
  fit$diagnostics <- ctgp_diagnostics(fit)
  fit
}
