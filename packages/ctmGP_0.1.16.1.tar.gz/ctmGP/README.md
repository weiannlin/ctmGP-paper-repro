# ctmGP

`ctmGP` extends the [ctGP] category-tree Gaussian-process family with a
multi-output ("m") variant and an end-to-end multi-objective Bayesian
optimization (MOBO) acquisition stack.  It is the package backing the
ctmGP paper *"Multi-Objective Bayesian Optimization of CPU Cooling
Design with Mixed Variables Using a Category Tree Multivariate Gaussian
Process"*.

ctmGP imports ctGP.  The single-output GP / QQGP / ctGP machinery
comes from the parent package, and ctmGP layers the multi-output
extensions on top, so shared bug fixes propagate without re-installing
ctmGP.

[ctGP]: https://github.com/weiannlin/ctGP

## What's in ctmGP

- **Multi-output adapters** via long-format stacking with a response-
  indicator categorical factor (paper §2.2): `fit_qqigp`, `fit_ctmgp`,
  `fit_qqmgp`, plus matching `predict_*` returning a canonical
  `(mu, Sigma, block_indices)` triple.
- **Unified C++ EHVI acquisition engine** via Yang-2019 anchor box
  decomposition (T = 2 + T = 3) with per-block dispatch to the cheapest
  valid moment kernel; checked against `GPareto::EHI_2d` and against
  brute-force Monte Carlo estimates.
- **Closed-form EIM acquisition** (Zhan-Cheng-Liu 2017).
- **IGD+ metric** (Ishibuchi 2015) implemented in OpenMP-parallel C++.
- **`bo_loop()` BO driver** supporting single-configuration and
  categorical-batch selection strategies, with per-(config, seed)
  incremental CSV output, full per-point logging (pred mean / sd /
  error, RMSE, HV, IGD+, wall + CPU times across fit / predict / acq /
  total), and parallel worker dispatch (PSOCK on Windows, fork on Unix).

## Installation

ctGP must be installed first (ctmGP `Imports:` it):

```r
install.packages("/path/to/ctGP_0.1.16.1.tar.gz",  repos = NULL, type = "source")
install.packages("/path/to/ctmGP_0.1.16.1.tar.gz", repos = NULL, type = "source")
```

Required: R ≥ 4.1, Rcpp ≥ 1.0.14, RcppArmadillo, ctGP (>= 0.1.16.1),
C++17 toolchain.  On macOS arm64 the build wires up libomp for OpenMP
parallelism.

## Quick start: one BO run on VLMOP2

```r
library(ctmGP)

# Paper §4.1 VLMOP2 closed form
vlmop2 <- function(df) {
  s_minus <- (df$x1 - 1/sqrt(2))^2 + (df$x2 - 1/sqrt(2))^2
  s_plus  <- (df$x1 + 1/sqrt(2))^2 + (df$x2 + 1/sqrt(2))^2
  cbind(y1 = ifelse(df$z == "c1", 1.00 - exp(-s_minus), 1.25 - exp(-s_minus)),
        y2 = ifelse(df$z == "c1", 1.00 - exp(-s_plus),  0.75 - exp(-s_plus)))
}

set.seed(1)
init <- data.frame(
  x1 = c(runif(5, -2, 2), runif(5, -2, 2)),
  x2 = c(runif(5, -2, 2), runif(5, -2, 2)),
  z  = c(rep("c1", 5),    rep("c2", 5)),
  stringsAsFactors = FALSE
)
init <- cbind(init, vlmop2(init))

out <- bo_loop(
  objective_fn = vlmop2,
  init_data    = init,
  x_cols       = c("x1", "x2"),
  w_cols       = "z",
  y_cols       = c("y1", "y2"),
  x_bounds     = list(x1 = c(-2, 2), x2 = c(-2, 2)),
  w_levels     = list(z = c("c1", "c2")),
  surrogate    = "ctmgp",
  acquisition  = "ehvi",
  strategy     = "categorical_batch",
  budget       = 10L
)
out$total_wall_sec
tail(out$history)
```

## Three surrogates × two acquisitions × two strategies

The acquisition layer does not depend on the surrogate.  Speed
differences come from the predictive Σ structure each surrogate emits,
not from algorithmic substitutions.

|         | Σ structure            | Engine path                          |
|---------|------------------------|--------------------------------------|
| `qqigp` | diagonal               | per-output 1-D closed form           |
| `ctmgp` | block-diagonal (tree)  | per-leaf 1-D / diag / dense MC       |
| `qqmgp` | dense T × T            | dense MC over the joint Gaussian     |

Pair with `acquisition = "ehvi"` for joint-Σ-aware acquisition or
`"eim"` for marginal-only closed form.  Both are exported.

## Reproducing the paper experiments

The scripts and data for the synthetic studies of the paper are
distributed in the separate reproduction package that accompanies the
manuscript, not inside this package.

## Recent changes

- 0.1.16.1 is a version bump aligned with ctGP 0.1.16.1 and ctmfGP
  0.1.16.1.  ctmGP itself has no behavioural change in this version;
  the ctGP 0.1.16.1 patch (eigen-based MC sampler factor for
  rank-deficient predictive Σ in BO loops) propagates automatically
  through the import of ctGP.
- 0.1.16.0 removed the copy of the parent's source that ctmGP used to
  carry.  There are no behavioural changes; the APIs and outputs are the
  same, and the validation set of 480 cases passes identically.
- 0.1.15.0 added the unified EHVI acquisition stack and the end-to-end
  MOBO workflow, and fixed a bug in the inherited C++ predict path (the
  full-Σ branch was returning a zero-diagonal covariance).
