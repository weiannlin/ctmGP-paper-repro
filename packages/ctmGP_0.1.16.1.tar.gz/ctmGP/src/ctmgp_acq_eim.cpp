// ctmGP — Expected Improvement Matrix (EIM) acquisition.
//
// Reference: Zhan, Cheng & Liu (2017); Manson, Chamberlain & Bourne (2021).
// Used in the AoAS paper alongside EHVI as the second multi-objective
// acquisition baseline.
//
// Per-output expected improvement vs every Pareto-front point j:
//   EI_l^j(w) = (y_l^j - μ_l(w)) Φ(z_l^j) + σ_l(w) φ(z_l^j)
//   where z_l^j = (y_l^j - μ_l(w)) / σ_l(w).
// Combined across objectives for each j:
//   norm_j(w) = sqrt(Σ_l (EI_l^j(w))²)
// EIM = min over j:
//   EIM(w) = min_j norm_j(w)
//
// EIM consumes only MARGINAL predictive (μ_l, σ_l) per output — it does NOT
// use cross-output covariance.  This is by design: EIM treats objectives
// independently and is therefore the natural pair for QQiGP-like surrogates;
// EHVI is the natural pair for joint surrogates (ctmGP / QQmGP).

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <cmath>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif

using namespace Rcpp;

namespace {

inline double norm_pdf(double z) {
  static const double inv_sqrt_2pi = 0.3989422804014327;
  return inv_sqrt_2pi * std::exp(-0.5 * z * z);
}
inline double norm_cdf(double z) {
  return 0.5 * std::erfc(-z * 0.7071067811865475);  // 1/sqrt(2)
}

}  // namespace

//' EIM (Expected Improvement Matrix) acquisition (per Zhan et al. 2017).
//'
//' Computes EIM per candidate.  Higher EIM = more attractive candidate.
//' Closed-form; no MC required.  Only consumes per-objective marginal
//' (μ, σ) — does not use cross-output covariance.
//'
//' For a candidate with marginals (μ_l(w), σ_l(w)) and current Pareto
//' front {(y_1^j, ..., y_T^j)}_{j=1..n_pf}:
//'   EI_l^j(w) = (y_l^j - μ_l(w)) Φ(z_l^j) + σ_l(w) φ(z_l^j),
//'              z_l^j = (y_l^j - μ_l(w)) / σ_l(w)
//'   EIM(w)    = min_j sqrt(Σ_l (EI_l^j(w))²)
//'
//' Edge case: if any σ_l(w) = 0, the per-output EI degenerates to
//'   max(y_l^j - μ_l(w), 0).
//'
//' @param mu_per_cand T × n_cand matrix of predictive means.
//' @param sigma_marginal_per_cand T × n_cand matrix of per-output predictive
//'   standard deviations (NOT covariance).  Must be non-negative.
//' @param pareto_set n_pf × T matrix of current non-dominated outcomes.
//' @return numeric vector of EIM values, length n_cand.
// [[Rcpp::export]]
arma::vec ctmgp_eim_engine_cpp(const arma::mat& mu_per_cand,
                                 const arma::mat& sigma_marginal_per_cand,
                                 const arma::mat& pareto_set) {
  const arma::uword t_dim = mu_per_cand.n_rows;
  const arma::uword n_cand = mu_per_cand.n_cols;
  if (sigma_marginal_per_cand.n_rows != t_dim ||
      sigma_marginal_per_cand.n_cols != n_cand) {
    Rcpp::stop("sigma_marginal_per_cand shape must equal mu_per_cand shape "
               "(T × n_cand).");
  }
  if (pareto_set.n_cols != t_dim) {
    Rcpp::stop("ncol(pareto_set) must equal nrow(mu_per_cand) (T).");
  }
  const arma::uword n_pf = pareto_set.n_rows;
  if (n_pf == 0) Rcpp::stop("pareto_set is empty.");

  arma::vec out(n_cand);

#ifdef _OPENMP
  #pragma omp parallel for schedule(static)
#endif
  for (arma::sword c = 0; c < static_cast<arma::sword>(n_cand); ++c) {
    double best = std::numeric_limits<double>::infinity();
    for (arma::uword j = 0; j < n_pf; ++j) {
      double sq_sum = 0.0;
      for (arma::uword l = 0; l < t_dim; ++l) {
        const double mu_l    = mu_per_cand(l, c);
        const double sigma_l = sigma_marginal_per_cand(l, c);
        const double pf_lj   = pareto_set(j, l);
        double ei;
        if (sigma_l <= 0.0) {
          // Degenerate Gaussian → EI is the deterministic improvement
          ei = std::max(pf_lj - mu_l, 0.0);
        } else {
          const double diff = pf_lj - mu_l;
          const double z    = diff / sigma_l;
          ei = diff * norm_cdf(z) + sigma_l * norm_pdf(z);
        }
        sq_sum += ei * ei;
      }
      const double norm_j = std::sqrt(sq_sum);
      if (norm_j < best) best = norm_j;
    }
    out[c] = best;
  }
  return out;
}
