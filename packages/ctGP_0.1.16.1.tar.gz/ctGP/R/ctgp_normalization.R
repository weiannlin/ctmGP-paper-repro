.ctgp_resolve_normalization_method <- function(normalization) {
  if (is.null(normalization)) normalization <- "none"
  normalization <- as.character(normalization[[1L]])
  if (!normalization %in% c("none", "min_max", "standardize")) {
    stop("normalization must be one of 'none', 'min_max', or 'standardize'.")
  }
  normalization
}

#' Build a column-wise normalizer
#'
#' Builds a reusable column-wise normalization specification for numeric data.
#' The normalizer can later be applied to new data or inverted back to the
#' original scale.
#'
#' @param x Numeric matrix or data frame.
#' @param method One of `"none"`, `"min_max"`, or `"standardize"`.
#'
#' @return A list describing the normalization transform.
#' @export
ctgp_build_normalizer <- function(x, method = c("none", "min_max", "standardize")) {
  method <- .ctgp_resolve_normalization_method(method)
  x <- as.matrix(x)
  storage.mode(x) <- "double"
  spec <- ctgp_build_normalizer_cpp(x, method)
  spec$colnames <- colnames(x)
  class(spec) <- c("ctgp_normalizer", "list")
  spec
}

#' Apply a column-wise normalizer
#'
#' @param x Numeric matrix or data frame.
#' @param normalizer A normalizer returned by [ctgp_build_normalizer()].
#'
#' @return Normalized data with the same shape as `x`.
#' @export
ctgp_apply_normalizer <- function(x, normalizer) {
  x_mat <- as.matrix(x)
  storage.mode(x_mat) <- "double"
  out <- ctgp_apply_normalizer_cpp(x_mat, normalizer)
  colnames(out) <- colnames(x_mat)
  if (is.data.frame(x)) out <- as.data.frame(out, stringsAsFactors = FALSE, check.names = FALSE)
  out
}

#' Invert a column-wise normalizer
#'
#' @param x Numeric matrix or data frame on the normalized scale.
#' @param normalizer A normalizer returned by [ctgp_build_normalizer()].
#'
#' @return Data transformed back to the original scale.
#' @export
ctgp_inverse_normalizer <- function(x, normalizer) {
  x_mat <- as.matrix(x)
  storage.mode(x_mat) <- "double"
  out <- ctgp_inverse_normalizer_cpp(x_mat, normalizer)
  colnames(out) <- colnames(x_mat)
  if (is.data.frame(x)) out <- as.data.frame(out, stringsAsFactors = FALSE, check.names = FALSE)
  out
}

.ctgp_inverse_variance <- function(x, normalizer) {
  x_mat <- as.matrix(x)
  storage.mode(x_mat) <- "double"
  out <- ctgp_inverse_variance_cpp(x_mat, normalizer)
  colnames(out) <- colnames(x_mat)
  out
}

.ctgp_normalize_training_matrix <- function(x, normalization = "none") {
  method <- .ctgp_resolve_normalization_method(normalization)
  normalizer <- ctgp_build_normalizer(x, method = method)
  list(x = ctgp_apply_normalizer(x, normalizer), normalizer = normalizer)
}

.ctgp_normalize_response_vector <- function(y, normalization = "none") {
  method <- .ctgp_resolve_normalization_method(normalization)
  y_mat <- matrix(as.numeric(y), ncol = 1L)
  normalizer <- ctgp_build_normalizer(y_mat, method = method)
  y_norm <- as.numeric(ctgp_apply_normalizer(y_mat, normalizer)[, 1L])
  list(y = y_norm, normalizer = normalizer)
}

.ctgp_inverse_prediction_scale <- function(pred, response_normalizer) {
  if (is.null(response_normalizer)) return(pred)
  if (!is.null(pred$pred_mean)) {
    pred$pred_mean <- as.numeric(ctgp_inverse_normalizer(matrix(pred$pred_mean, ncol = 1L), response_normalizer)[, 1L])
  }
  if (!is.null(pred$pred_var)) {
    pred$pred_var <- as.numeric(.ctgp_inverse_variance(matrix(pred$pred_var, ncol = 1L), response_normalizer)[, 1L])
  }
  if (!is.null(pred$pred_sigma_sq)) {
    scale_sq <- as.numeric(response_normalizer$scale)^2
    pred$pred_sigma_sq <- as.matrix(pred$pred_sigma_sq) * scale_sq
  }
  pred
}

.ctgp_apply_prepared_normalization <- function(prepped,
                                              normalization = "none",
                                              normalize_response = FALSE) {
  normalization <- .ctgp_resolve_normalization_method(normalization)
  if (identical(normalization, "none")) {
    prepped$normalization <- "none"
    prepped$normalize_response <- FALSE
    prepped$input_normalizer <- NULL
    prepped$response_normalizer <- NULL
    return(prepped)
  }

  cont_norm <- .ctgp_normalize_training_matrix(prepped$continuous_data, normalization = normalization)
  cont_df <- as.data.frame(cont_norm$x, stringsAsFactors = FALSE, check.names = FALSE)
  names(cont_df) <- names(prepped$continuous_data)

  response_normalizer <- NULL
  y_vec <- as.numeric(prepped$y)
  if (isTRUE(normalize_response)) {
    y_norm <- .ctgp_normalize_response_vector(y_vec, normalization = normalization)
    y_vec <- y_norm$y
    response_normalizer <- y_norm$normalizer
  }

  qual_df <- prepped$qualitative_data
  data_reordered <- cbind(cont_df, qual_df, data.frame(y = y_vec, check.names = FALSE))
  names(data_reordered)[ncol(data_reordered)] <- prepped$response_name
  coerce_data <- coerce_fun(data_reordered, cont_df, include_sub_cate = TRUE)
  colnames(coerce_data) <- c(names(cont_df), "c.T", "Y")

  prepped$data <- data_reordered
  prepped$design <- as.matrix(cont_df)
  prepped$continuous_data <- cont_df
  prepped$y <- y_vec
  prepped$coerce_data <- coerce_data
  prepped$combined_id <- coerce_data[, "c.T"]
  prepped$combined_key <- attr(coerce_data, "level_key")
  prepped$normalization <- normalization
  prepped$normalize_response <- isTRUE(normalize_response)
  prepped$input_normalizer <- cont_norm$normalizer
  prepped$response_normalizer <- response_normalizer
  prepped
}

.ctgp_apply_fit_input_normalizer <- function(x_matrix, fit) {
  if (is.null(fit$input_normalizer)) return(as.matrix(x_matrix))
  out <- ctgp_apply_normalizer(as.matrix(x_matrix), fit$input_normalizer)
  as.matrix(out)
}
