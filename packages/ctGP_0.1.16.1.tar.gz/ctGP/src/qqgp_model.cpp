#include "qqgp_model.h"
#include "ctgp_rcpp_utils.h"
#include <cmath>
#include <limits>
#include <algorithm>

#ifdef _OPENMP
  #include <omp.h>
#endif

// ----------------------------------------------------
// H matrix for continuous variables
// H_ij = exp( - sum_k 10^{fi_k} (x_ik - x_jk)^2 )
// ----------------------------------------------------
arma::mat qqgp_build_h_matrix(
    const arma::mat& design,
    const arma::vec& fi
) {
  int n = design.n_rows;
  int d = design.n_cols;

  arma::vec theta = arma::exp(fi * std::log(10.0));
  arma::mat H(n, n, arma::fill::eye);

  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = design(i, k) - design(j, k);
        s += theta(k) * diff * diff;
      }
      double val = std::exp(-s);
      H(i, j) = val;
      H(j, i) = val;
    }
  }

  return H;
}

// ----------------------------------------------------
// T matrix via sphere decomposition
// theta length must be choose(level_num, 2)
// ----------------------------------------------------
arma::mat qqgp_build_t_matrix(
    const arma::vec& theta,
    int level_num
) {
  arma::mat L(level_num, level_num, arma::fill::zeros);
  L(0, 0) = 1.0;

  if (level_num == 1) {
    return L * L.t();
  }

  arma::mat lower_temp(level_num, level_num, arma::fill::zeros);
  lower_temp(arma::trimatl_ind(size(lower_temp), -1)) = theta;

  for (int r = 1; r < level_num; ++r) {
    L(r, 0) = std::cos(lower_temp(r, 0));

    for (int s = 1; s <= r; ++s) {
      double prod_sin = 1.0;
      for (int k = 0; k < s; ++k) {
        prod_sin *= std::sin(lower_temp(r, k));
      }

      if (s < r) {
        L(r, s) = prod_sin * std::cos(lower_temp(r, s));
      } else {
        L(r, s) = prod_sin;
      }
    }
  }

  return L * L.t();
}

// ----------------------------------------------------
// R matrix = H .* T(level_i, level_j)
// level_index is expected to be 1, 2, ..., level_num
// ----------------------------------------------------
arma::mat qqgp_build_r_matrix(
    const arma::mat& h_matrix,
    const arma::mat& t_matrix,
    const arma::uvec& level_index
) {
  int n = h_matrix.n_rows;
  arma::mat R(n, n, arma::fill::zeros);

  int level_num = t_matrix.n_rows;

  for (int i = 0; i < n; ++i) {
    unsigned int li = level_index(i);
    if (li < 1 || li > (unsigned int)level_num) {
      Rcpp::stop("level_index contains values outside 1, ..., level_num.");
    }

    for (int j = 0; j < n; ++j) {
      unsigned int lj = level_index(j);
      if (lj < 1 || lj > (unsigned int)level_num) {
        Rcpp::stop("level_index contains values outside 1, ..., level_num.");
      }

      R(i, j) = h_matrix(i, j) * t_matrix(li - 1, lj - 1);
    }
  }

  return R;
}

// ----------------------------------------------------
// 預設 treatment-style F matrix:
// first column = intercept
// columns 2..level_num = dummies for levels 2..level_num
// ----------------------------------------------------
arma::mat qqgp_build_f_matrix(
    const arma::uvec& level_index,
    int level_num
) {
  int n = level_index.n_elem;
  arma::mat F(n, level_num, arma::fill::zeros);

  F.col(0).ones();

  for (int i = 0; i < n; ++i) {
    unsigned int li = level_index(i);
    if (li < 1 || li > (unsigned int)level_num) {
      Rcpp::stop("level_index contains values outside 1, ..., level_num.");
    }
    if (li >= 2) {
      F(i, li - 1) = 1.0;
    }
  }

  return F;
}

// ----------------------------------------------------
// default bounds
// ----------------------------------------------------
Rcpp::List qqgp_default_bounds(
    const arma::mat& design,
    int level_num,
    double theta_low,
    double theta_upp
) {
  int n = design.n_rows;
  int d = design.n_cols;

  double max_sum_sqdiff = 0.0;
  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = design(i, k) - design(j, k);
        s += diff * diff;
      }
      if (s > max_sum_sqdiff) {
        max_sum_sqdiff = s;
      }
    }
  }

  if (max_sum_sqdiff <= 0.0) {
    max_sum_sqdiff = 1.0;
  }

  double upp = std::log10(-std::log(0.1) / max_sum_sqdiff);
  double low = std::log10(-std::log(0.9) / max_sum_sqdiff);

  arma::vec fi_lower(d); fi_lower.fill(low);
  arma::vec fi_upper(d); fi_upper.fill(upp);

  int theta_dim = level_num * (level_num - 1) / 2;
  arma::vec lower(d + theta_dim, arma::fill::zeros);
  arma::vec upper(d + theta_dim, arma::fill::zeros);

  lower.subvec(0, d - 1) = fi_lower;
  upper.subvec(0, d - 1) = fi_upper;

  if (theta_dim > 0) {
    lower.subvec(d, d + theta_dim - 1).fill(theta_low);
    upper.subvec(d, d + theta_dim - 1).fill(theta_upp);
  }

  return Rcpp::List::create(
    Rcpp::Named("fi_lower") = fi_lower,
    Rcpp::Named("fi_upper") = fi_upper,
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper
  );
}

// ----------------------------------------------------
// common core for QQGP profile fit
// ----------------------------------------------------
namespace {

int qqgp_resolve_objective_mode_int(int objective_mode) {
  if (objective_mode == QQGP_OBJECTIVE_LEGACY_EXACT) {
    return QQGP_OBJECTIVE_LEGACY_EXACT;
  }
  return QQGP_OBJECTIVE_STABLE;
}

void qqgp_copy_lower_to_upper_in_place(arma::mat& M) {
  const int nr = static_cast<int>(M.n_rows);
  const int nc = static_cast<int>(M.n_cols);
  if (nr != nc) return;
  for (int row = 0; row < nr; ++row) {
    for (int col = row; col < nc; ++col) {
      M(row, col) = M(col, row);
    }
  }
}

static qqgp_profile_result qqgp_profile_fit_core_stable(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::mat& t_matrix,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided
) {
  qqgp_profile_result out;
  out.objective_mode = QQGP_OBJECTIVE_STABLE;

  const int n = static_cast<int>(design.n_rows);
  if ((int)f_matrix.n_rows != n || (int)f_matrix.n_cols < 1) {
    return out;
  }

  arma::mat h_matrix = qqgp_build_h_matrix(design, fi);
  arma::mat r_matrix = qqgp_build_r_matrix(h_matrix, t_matrix, level_index);
  arma::mat R_work = r_matrix;

  double effective_nugget = 0.0;
  double rc = arma::rcond(r_matrix);
  out.raw_rcond = rc;
  bool bad_rcond = (!std::isfinite(rc) || rc <= 1e-6);

  if (!nugget_provided) {
    if (bad_rcond) {
      effective_nugget = compute_nugget_from_eigen(r_matrix, 1e10);
      if (effective_nugget > 0.0) {
        R_work.diag() += effective_nugget;
      }
    }
  } else {
    if (nugget == 0.0) {
      effective_nugget = 0.0;
    } else if (nugget > 0.0) {
      if (bad_rcond) {
        effective_nugget = nugget;
        R_work.diag() += effective_nugget;
      }
    }
  }
  out.nugget_added = (effective_nugget > 0.0);

  arma::mat L;
  bool chol_ok = arma::chol(L, R_work, "lower");
  if (!chol_ok) {
    return out;
  }

  arma::mat r_inv_f = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), f_matrix)
  );

  arma::vec r_invy = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), y)
  );

  arma::mat ft_r_inv_f = f_matrix.t() * r_inv_f;
  ft_r_inv_f = 0.5 * (ft_r_inv_f + ft_r_inv_f.t());

  arma::vec rhs = f_matrix.t() * r_invy;
  arma::vec beta_vec;
  bool beta_ok = arma::solve(beta_vec, ft_r_inv_f, rhs, arma::solve_opts::likely_sympd);
  if (!beta_ok || beta_vec.n_elem != f_matrix.n_cols || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;
  arma::vec alpha_vec = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), resid)
  );

  double sigma_sq = arma::dot(resid, alpha_vec) / static_cast<double>(n);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  double logdet_r = 2.0 * arma::sum(arma::log(L.diag()));
  double neg_log_lik = static_cast<double>(n) * std::log(sigma_sq) + logdet_r;

  arma::mat I = arma::eye<arma::mat>(n, n);
  arma::mat r_inv = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), I)
  );

  out.h_matrix = h_matrix;
  out.t_matrix = t_matrix;
  out.r_matrix = R_work;
  out.r_inv = r_inv;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.sigma_sq = sigma_sq;
  out.neg_log_lik = neg_log_lik;
  out.effective_nugget = effective_nugget;
  out.success = true;

  return out;
}

static qqgp_profile_result qqgp_profile_fit_core_legacy_exact(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::mat& t_matrix,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided
) {
  qqgp_profile_result out;
  out.objective_mode = QQGP_OBJECTIVE_LEGACY_EXACT;

  const int n = static_cast<int>(design.n_rows);
  if ((int)f_matrix.n_rows != n || (int)f_matrix.n_cols < 1) {
    return out;
  }

  arma::mat h_matrix = qqgp_build_h_matrix(design, fi);
  arma::mat r_matrix = qqgp_build_r_matrix(h_matrix, t_matrix, level_index);
  arma::mat R_work = r_matrix;

  double rc = arma::rcond(r_matrix);
  out.raw_rcond = rc;
  bool bad_rcond = (!std::isfinite(rc) || rc <= 1e-6);

  double effective_nugget = 0.0;
  if (bad_rcond) {
    effective_nugget = 1e-10;
    R_work.diag() += effective_nugget;
  }
  out.nugget_added = (effective_nugget > 0.0);

  arma::mat L;
  bool chol_ok = arma::chol(L, R_work, "lower");
  if (!chol_ok) {
    return out;
  }

  arma::mat r_inv;
  bool rinv_ok = arma::inv_sympd(r_inv, R_work);
  if (!rinv_ok || !r_inv.is_finite()) {
    return out;
  }

  arma::mat to_be_inv = f_matrix.t() * r_inv * f_matrix;
  qqgp_copy_lower_to_upper_in_place(to_be_inv);

  arma::mat to_be_inv_inv;
  bool inv_ok = arma::inv_sympd(to_be_inv_inv, to_be_inv);
  if (!inv_ok || !to_be_inv_inv.is_finite()) {
    return out;
  }

  arma::vec rhs = f_matrix.t() * r_inv * y;
  arma::vec beta_vec = to_be_inv_inv * rhs;
  if (!beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;
  arma::vec alpha_vec = r_inv * resid;
  if (!alpha_vec.is_finite()) {
    return out;
  }

  double sigma_sq = arma::as_scalar((resid.t() * r_inv * resid) / static_cast<double>(n));
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  double det_r = arma::det(R_work);
  double neg_log_lik = static_cast<double>(n) * std::log(sigma_sq) + std::log(det_r);

  out.h_matrix = h_matrix;
  out.t_matrix = t_matrix;
  out.r_matrix = R_work;
  out.r_inv = r_inv;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.sigma_sq = sigma_sq;
  out.neg_log_lik = neg_log_lik;
  out.effective_nugget = effective_nugget;
  out.success = true;

  return out;
}

static qqgp_profile_result qqgp_profile_fit_core(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::mat& t_matrix,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided,
    int objective_mode
) {
  if (qqgp_resolve_objective_mode_int(objective_mode) == QQGP_OBJECTIVE_LEGACY_EXACT) {
    return qqgp_profile_fit_core_legacy_exact(
      design, level_index, y, t_matrix, fi, f_matrix, nugget, nugget_provided
    );
  }
  return qqgp_profile_fit_core_stable(
    design, level_index, y, t_matrix, fi, f_matrix, nugget, nugget_provided
  );
}

} // anonymous namespace

// ----------------------------------------------------
// profile fit: theta estimated jointly
// ----------------------------------------------------
qqgp_profile_result qqgp_profile_fit(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::vec& theta,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided,
    int objective_mode
) {
  int level_num = arma::max(level_index);
  arma::mat t_matrix = qqgp_build_t_matrix(theta, level_num);

  return qqgp_profile_fit_core(
    design,
    level_index,
    y,
    t_matrix,
    fi,
    f_matrix,
    nugget,
    nugget_provided,
    objective_mode
  );
}

// ----------------------------------------------------
// profile fit: T matrix fixed
// ----------------------------------------------------
qqgp_profile_result qqgp_profile_fit_fixed_t(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& t_matrix,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided,
    int objective_mode
) {
  return qqgp_profile_fit_core(
    design,
    level_index,
    y,
    t_matrix,
    fi,
    f_matrix,
    nugget,
    nugget_provided,
    objective_mode
  );
}

// ----------------------------------------------------
// objective
// ----------------------------------------------------
double qqgp_likelihood_objective::eval(const arma::vec& par) {
  int d = design_.n_cols;

  qqgp_profile_result fit;

  if (!fixed_t_) {
    arma::vec fi = par.subvec(0, d - 1);

    int theta_dim = level_num_ * (level_num_ - 1) / 2;
    arma::vec theta(theta_dim, arma::fill::zeros);

    if (theta_dim > 0) {
      theta = par.subvec(d, d + theta_dim - 1);
    }

    fit = qqgp_profile_fit(
      design_,
      level_index_,
      y_,
      fi,
      theta,
      f_matrix_,
      nugget_,
      nugget_provided_,
      objective_mode_
    );
  } else {
    arma::vec fi = par.subvec(0, d - 1);

    fit = qqgp_profile_fit_fixed_t(
      design_,
      level_index_,
      y_,
      fi,
      fixed_t_matrix_,
      f_matrix_,
      nugget_,
      nugget_provided_,
      objective_mode_
    );
  }

  if (!fit.success) {
    return arma::datum::inf;
  }
  if (std::isnan(fit.neg_log_lik)) {
    return arma::datum::inf;
  }
  return fit.neg_log_lik;
}

namespace {

int qqgp_effective_num_threads(bool use_openmp, int requested, int n_tasks) {
  int tasks = std::max(1, n_tasks);
#ifdef _OPENMP
  if (!use_openmp) {
    return 1;
  }
  int max_threads = omp_get_max_threads();
  int out = (requested > 0) ? requested : max_threads;
  out = std::max(1, std::min(out, max_threads));
  out = std::min(out, tasks);
  return std::max(1, out);
#else
  (void)use_openmp;
  (void)requested;
  (void)tasks;
  return 1;
#endif
}

arma::mat qqgp_cross_corr_matrix(
    const arma::mat& Xnew,
    const arma::uvec& new_level_index,
    const arma::mat& Xtrain,
    const arma::uvec& level_index,
    const arma::mat& t_matrix,
    const arma::vec& theta,
    bool use_openmp,
    int num_threads
) {
  int m = Xnew.n_rows;
  int n = Xtrain.n_rows;
  int d = Xtrain.n_cols;
  int level_num = t_matrix.n_rows;

  arma::mat R(m, n, arma::fill::zeros);
  int n_threads = qqgp_effective_num_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    unsigned int li = new_level_index(i);
    if (li < 1 || li > (unsigned int)level_num) {
      continue;
    }
    for (int j = 0; j < n; ++j) {
      unsigned int lj = level_index(j);
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = Xnew(i, k) - Xtrain(j, k);
        s += theta(k) * diff * diff;
      }
      double hval = std::exp(-s);
      double tval = t_matrix(li - 1, lj - 1);
      R(i, j) = hval * tval;
    }
  }

  return R;
}

arma::mat qqgp_self_corr_matrix(
    const arma::mat& Xnew,
    const arma::uvec& new_level_index,
    const arma::mat& t_matrix,
    const arma::vec& theta,
    bool use_nugget,
    double effective_nugget,
    bool use_openmp,
    int num_threads
) {
  int m = Xnew.n_rows;
  int d = Xnew.n_cols;
  arma::mat SXX(m, m, arma::fill::zeros);
  int n_threads = qqgp_effective_num_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    unsigned int li = new_level_index(i);
    SXX(i, i) = t_matrix(li - 1, li - 1) + ((use_nugget && effective_nugget > 0.0) ? effective_nugget : 0.0);
    for (int j = i + 1; j < m; ++j) {
      unsigned int lj = new_level_index(j);
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = Xnew(i, k) - Xnew(j, k);
        s += theta(k) * diff * diff;
      }
      double hval = std::exp(-s);
      double tval = t_matrix(li - 1, lj - 1);
      double val = hval * tval;
      SXX(i, j) = val;
      SXX(j, i) = val;
    }
  }
  return SXX;
}

} // anonymous namespace

namespace {

static qqgp_profile_result qqgp_profile_fit_exact_nugget(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& t_matrix,
    const arma::mat& f_matrix,
    double nugget
) {
  qqgp_profile_result out;

  if (!std::isfinite(nugget) || nugget < 0.0) {
    return out;
  }

  arma::mat h_matrix = qqgp_build_h_matrix(design, fi);
  arma::mat r_matrix = qqgp_build_r_matrix(h_matrix, t_matrix, level_index);
  arma::mat R_work = 0.5 * (r_matrix + r_matrix.t());
  if (nugget > 0.0) {
    R_work.diag() += nugget;
  }

  arma::mat L;
  bool chol_ok = arma::chol(L, R_work, "lower");
  if (!chol_ok) {
    return out;
  }

  arma::mat r_inv_f = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), f_matrix)
  );

  arma::vec r_invy = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), y)
  );

  arma::mat ft_r_inv_f = f_matrix.t() * r_inv_f;
  ft_r_inv_f = 0.5 * (ft_r_inv_f + ft_r_inv_f.t());

  arma::vec rhs = f_matrix.t() * r_invy;
  arma::vec beta_vec;
  bool beta_ok = arma::solve(beta_vec, ft_r_inv_f, rhs, arma::solve_opts::likely_sympd);
  if (!beta_ok || beta_vec.n_elem != f_matrix.n_cols || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;
  arma::vec alpha_vec = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), resid)
  );

  double sigma_sq = arma::dot(resid, alpha_vec) / static_cast<double>(design.n_rows);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  out.h_matrix = h_matrix;
  out.t_matrix = t_matrix;
  out.r_matrix = R_work;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.sigma_sq = sigma_sq;
  out.neg_log_lik = static_cast<double>(design.n_rows) * std::log(sigma_sq) + 2.0 * arma::sum(arma::log(L.diag()));
  out.effective_nugget = nugget;
  out.success = true;

  return out;
}

} // anonymous namespace

// ----------------------------------------------------
// prediction
//
// new_point format:
// columns 1..conti_dim = continuous inputs
// last column         = categorical level index (1..level_num)
//
// generic mean 時需由 R wrapper 傳入對應新資料的 f_pred_matrix。
// ----------------------------------------------------
Rcpp::List qqgp_predict_from_fit(
    const Rcpp::List& model,
    SEXP new_point_sexp,
    const arma::mat& f_pred_matrix,
    bool indep,
    bool use_nugget,
    bool use_openmp,
    int num_threads,
    int block_size,
    bool has_nugget_override,
    double nugget_override,
    bool use_universal_variance
) {
  arma::mat data = Rcpp::as<arma::mat>(model["data"]);
  arma::vec fi = Rcpp::as<arma::vec>(model["fi"]);
  arma::mat t_matrix = Rcpp::as<arma::mat>(model["t_matrix"]);
  arma::mat f_matrix_train = Rcpp::as<arma::mat>(model["f_matrix"]);

  int d = data.n_cols - 2;
  arma::mat design = data.cols(0, d - 1);
  arma::uvec level_index = arma::conv_to<arma::uvec>::from(data.col(d));
  arma::vec y = data.col(d + 1);

  bool is_regression = contains_element_named(model, "log10_nugget");

  arma::mat l_matrix;
  arma::vec alpha_vec;
  arma::vec beta_vec;
  double sigma_sq = arma::datum::nan;
  double effective_nugget = 0.0;

  if (is_regression) {
    l_matrix = Rcpp::as<arma::mat>(model["l_matrix"]);
    alpha_vec = Rcpp::as<arma::vec>(model["alpha_vec"]);
    beta_vec = Rcpp::as<arma::vec>(model["beta_vec"]);
    sigma_sq = Rcpp::as<double>(model["sigma_sq"]);
    if (contains_element_named(model, "effective_nugget")) {
      effective_nugget = Rcpp::as<double>(model["effective_nugget"]);
    }
  } else {
    if (has_nugget_override) {
      qqgp_profile_result refit = qqgp_profile_fit_exact_nugget(
        design, level_index, y, fi, t_matrix, f_matrix_train, nugget_override
      );
      if (!refit.success) {
        Rcpp::stop(
          "Deterministic QQGP prediction failed while rebuilding the conditioning system with the requested nugget value."
        );
      }
      l_matrix = refit.l_matrix;
      alpha_vec = refit.alpha_vec;
      beta_vec = refit.beta_vec;
      sigma_sq = refit.sigma_sq;
      effective_nugget = refit.effective_nugget;
    } else if (!use_nugget) {
      qqgp_profile_result refit = qqgp_profile_fit_exact_nugget(
        design, level_index, y, fi, t_matrix, f_matrix_train, 0.0
      );
      if (!refit.success) {
        Rcpp::stop(
          "Deterministic QQGP prediction with use_nugget = FALSE failed because the no-nugget conditioning system is numerically unstable. Try prediction_control = list(use_nugget = TRUE)."
        );
      }
      l_matrix = refit.l_matrix;
      alpha_vec = refit.alpha_vec;
      beta_vec = refit.beta_vec;
      sigma_sq = refit.sigma_sq;
      effective_nugget = 0.0;
    } else {
      l_matrix = Rcpp::as<arma::mat>(model["l_matrix"]);
      alpha_vec = Rcpp::as<arma::vec>(model["alpha_vec"]);
      beta_vec = Rcpp::as<arma::vec>(model["beta_vec"]);
      sigma_sq = Rcpp::as<double>(model["sigma_sq"]);
      if (contains_element_named(model, "effective_nugget")) {
        effective_nugget = Rcpp::as<double>(model["effective_nugget"]);
      }
    }
  }

  arma::mat new_point;
  if (sexp_is_matrix(new_point_sexp)) {
    new_point = Rcpp::as<arma::mat>(new_point_sexp);
  } else {
    arma::vec v = Rcpp::as<arma::vec>(new_point_sexp);
    new_point = v.t();
  }

  if ((int)new_point.n_cols != d + 1) {
    Rcpp::stop("new_point must contain conti_dim continuous columns plus one categorical level column.");
  }
  if (!new_point.is_finite()) {
    Rcpp::stop("new_point must contain only finite numeric values.");
  }

  arma::mat np = new_point.cols(0, d - 1);
  arma::uvec new_level_index = arma::conv_to<arma::uvec>::from(new_point.col(d));
  int m = np.n_rows;
  int level_num = t_matrix.n_rows;

  for (int i = 0; i < m; ++i) {
    if (new_level_index(i) < 1 || new_level_index(i) > (unsigned int)level_num) {
      Rcpp::stop("new_point contains categorical level outside 1, ..., level_num.");
    }
  }

  if ((int)f_pred_matrix.n_rows != m) {
    Rcpp::stop("f_pred_matrix must have the same number of rows as newdata.");
  }
  if ((int)f_pred_matrix.n_cols != (int)f_matrix_train.n_cols) {
    Rcpp::stop("f_pred_matrix must have the same number of columns as the training f_matrix.");
  }
  if (!f_pred_matrix.is_finite()) {
    Rcpp::stop("f_pred_matrix must contain only finite numeric values.");
  }

  arma::vec theta = arma::exp(fi * std::log(10.0));

  arma::mat r_inv_f;
  arma::mat ft_r_inv_f_inv;
  if (use_universal_variance) {
    r_inv_f = arma::solve(
      arma::trimatu(l_matrix.t()),
      arma::solve(arma::trimatl(l_matrix), f_matrix_train)
    );

    arma::mat ft_r_inv_f = f_matrix_train.t() * r_inv_f;
    ft_r_inv_f = 0.5 * (ft_r_inv_f + ft_r_inv_f.t());

    bool m_ok = arma::inv_sympd(ft_r_inv_f_inv, ft_r_inv_f);
    if (!m_ok) {
      m_ok = arma::solve(ft_r_inv_f_inv, ft_r_inv_f, arma::eye<arma::mat>(ft_r_inv_f.n_rows, ft_r_inv_f.n_cols));
    }
    if (!m_ok || !ft_r_inv_f_inv.is_finite()) {
      if (!use_nugget && !is_regression && !has_nugget_override) {
        Rcpp::stop(
          "Deterministic QQGP prediction with use_nugget = FALSE failed because the no-nugget conditioning system is numerically unstable. Try prediction_control = list(use_nugget = TRUE)."
        );
      }
      Rcpp::stop("QQGP prediction failed because (F' R^{-1} F) is singular or ill-conditioned.");
    }
  }

  arma::vec y_predict(m, arma::fill::zeros);
  arma::vec pred_var;
  arma::mat pred_sigma_sq;

  if (indep) {
    int b = (block_size > 0) ? block_size : std::max(64, std::min(1024, m));
    int n_blocks = (m + b - 1) / b;
    int block_threads = qqgp_effective_num_threads(use_openmp, num_threads, n_blocks);
#ifndef _OPENMP
    (void)block_threads;
#endif
    pred_var.set_size(m);
    pred_var.zeros();

#ifdef _OPENMP
#pragma omp parallel for if(block_threads > 1) schedule(dynamic) num_threads(block_threads)
#endif
    for (int bi = 0; bi < n_blocks; ++bi) {
      int start = bi * b;
      int end = std::min(start + b - 1, m - 1);
      arma::mat np_block = np.rows(start, end);
      arma::uvec level_block = new_level_index.subvec(start, end);
      arma::mat F_block = f_pred_matrix.rows(start, end);

      arma::mat r_block = qqgp_cross_corr_matrix(np_block, level_block, design, level_index, t_matrix, theta, false, 1);
      arma::mat Ublock = arma::solve(arma::trimatl(l_matrix), r_block.t());

      arma::vec diag_a = arma::sum(arma::square(Ublock), 0).t();
      arma::vec diag_b(diag_a.n_elem, arma::fill::zeros);
      if (use_universal_variance) {
        arma::mat rr_inv_f = r_block * r_inv_f;
        arma::mat t_block = F_block - rr_inv_f;
        arma::mat TM = t_block * ft_r_inv_f_inv;
        diag_b = arma::sum(TM % t_block, 1);
      }
      arma::vec mean_block = F_block * beta_vec + r_block * alpha_vec;
      arma::vec base_var(level_block.n_elem, arma::fill::zeros);
      for (arma::uword i = 0; i < level_block.n_elem; ++i) {
        base_var(i) = t_matrix(level_block(i) - 1, level_block(i) - 1) + ((use_nugget && effective_nugget > 0.0) ? effective_nugget : 0.0);
      }
      arma::vec var_block = sigma_sq * (base_var - diag_a + diag_b);

      for (arma::uword i = 0; i < var_block.n_elem; ++i) {
        if (!std::isfinite(var_block(i))) {
          if (!use_nugget && !is_regression && !has_nugget_override) {
            Rcpp::stop(
              "QQGP prediction variance became numerically unstable. "
              "Try prediction_control = list(use_nugget = TRUE)."
            );
          } else {
            Rcpp::stop("QQGP prediction variance became numerically unstable.");
          }
        }
        var_block(i) = std::max(0.0, var_block(i));
      }

      for (int i = start; i <= end; ++i) {
        int li = i - start;
        y_predict(i) = mean_block(li);
        pred_var(i) = var_block(li);
      }
    }
  } else {
    arma::mat r_matrix = qqgp_cross_corr_matrix(np, new_level_index, design, level_index, t_matrix, theta, use_openmp, num_threads);
    arma::mat U = arma::solve(arma::trimatl(l_matrix), r_matrix.t());
    // BUGFIX (2026-04-24): the previous code declared `arma::mat t_matrix;`
    // here, shadowing the outer categorical correlation matrix `t_matrix`
    // that the qqgp_self_corr_matrix / qqgp_cross_corr_matrix calls below
    // require.  The local matrix was being assigned the universal-kriging
    // mean-residual `f_pred_matrix - r_matrix * r_inv_f` and then mistakenly
    // passed in place of the categorical T, making predictive variance
    // (full-Σ path) collapse to zero.  Rename the locals.
    arma::mat f_pred_resid;
    arma::mat f_pred_resid_m;
    if (use_universal_variance) {
      arma::mat rr_inv_f = r_matrix * r_inv_f;
      f_pred_resid = f_pred_matrix - rr_inv_f;
      f_pred_resid_m = f_pred_resid * ft_r_inv_f_inv;
    }

    y_predict = f_pred_matrix * beta_vec + r_matrix * alpha_vec;

    int b = (block_size > 0) ? block_size : std::max(64, std::min(256, m));
    int n_blocks = (m + b - 1) / b;
    int block_threads = qqgp_effective_num_threads(use_openmp, num_threads, n_blocks);
#ifndef _OPENMP
    (void)block_threads;
#endif

    pred_sigma_sq.set_size(m, m);
    pred_sigma_sq.zeros();

#ifdef _OPENMP
#pragma omp parallel for if(block_threads > 1) schedule(dynamic) num_threads(block_threads)
#endif
    for (int bi = 0; bi < n_blocks; ++bi) {
      int i_start = bi * b;
      int i_end = std::min(i_start + b - 1, m - 1);

      arma::mat Xi = np.rows(i_start, i_end);
      arma::uvec Li = new_level_index.subvec(i_start, i_end);
      arma::mat Ui = U.cols(i_start, i_end);
      arma::mat Ti;
      arma::mat t_i_m;
      if (use_universal_variance) {
        Ti = f_pred_resid.rows(i_start, i_end);
        t_i_m = f_pred_resid_m.rows(i_start, i_end);
      }

      for (int bj = bi; bj < n_blocks; ++bj) {
        int j_start = bj * b;
        int j_end = std::min(j_start + b - 1, m - 1);

        arma::mat Xj = np.rows(j_start, j_end);
        arma::uvec Lj = new_level_index.subvec(j_start, j_end);
        arma::mat Uj = U.cols(j_start, j_end);
        arma::mat Tj;
        if (use_universal_variance) {
          Tj = f_pred_resid.rows(j_start, j_end);
        }

        arma::mat Sblock;
        if (bi == bj) {
          Sblock = qqgp_self_corr_matrix(Xi, Li, t_matrix, theta, use_nugget, effective_nugget, false, 1);
        } else {
          Sblock = qqgp_cross_corr_matrix(Xi, Li, Xj, Lj, t_matrix, theta, false, 1);
        }

        arma::mat Ablock = Ui.t() * Uj;
        arma::mat Cblock;
        if (use_universal_variance) {
          arma::mat Bblock = t_i_m * Tj.t();
          Cblock = sigma_sq * (Sblock - Ablock + Bblock);
        } else {
          Cblock = sigma_sq * (Sblock - Ablock);
        }

        if (bi == bj) {
          Cblock = 0.5 * (Cblock + Cblock.t());
          for (arma::uword k = 0; k < Cblock.n_rows; ++k) {
            Cblock(k, k) = std::max(0.0, Cblock(k, k));
          }
          pred_sigma_sq.submat(i_start, i_start, i_end, i_end) = Cblock;
        } else {
          pred_sigma_sq.submat(i_start, j_start, i_end, j_end) = Cblock;
          pred_sigma_sq.submat(j_start, i_start, j_end, i_end) = Cblock.t();
        }
      }
    }

    if (!pred_sigma_sq.is_finite()) {
      if (!use_nugget && !is_regression && !has_nugget_override) {
        Rcpp::stop(
          "QQGP prediction covariance became numerically unstable. "
          "Try prediction_control = list(use_nugget = TRUE)."
        );
      } else {
        Rcpp::stop("QQGP prediction covariance became numerically unstable.");
      }
    }
  }

  if (indep) {
    return Rcpp::List::create(
      Rcpp::Named("pred_mean") = y_predict,
      Rcpp::Named("pred_var") = pred_var
    );
  }

  return Rcpp::List::create(
    Rcpp::Named("pred_mean") = y_predict,
    Rcpp::Named("pred_sigma_sq") = pred_sigma_sq
  );
}
