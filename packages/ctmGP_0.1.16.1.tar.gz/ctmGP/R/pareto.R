# ctmGP — R wrappers for Pareto-front and hypervolume C++ kernels.

#' Non-dominated (Pareto-efficient) mask.
#'
#' Returns a logical vector of length nrow(Y), TRUE where the row is non-
#' dominated under the minimisation convention.  A row p dominates q iff
#' (p <= q componentwise) AND (p != q).
#'
#' @param Y numeric matrix; rows = points, cols = objectives.
#' @return logical vector of length nrow(Y).
#' @export
pareto_mask <- function(Y) {
  if (!is.matrix(Y)) Y <- as.matrix(Y)
  storage.mode(Y) <- "double"
  as.logical(ctmgp_pareto_filter_cpp(Y))
}

#' Extract the Pareto front from Y.
#'
#' Returns the SET of distinct non-dominated points (deduplicated by exact row
#' equality).  This deduplication matters for downstream algorithms like the
#' Yang-2019 anchor decomposition that require a strictly monotone front; with
#' identical y rows present, the strict-dominance test keeps all duplicates and
#' breaks the anchor monotonicity assumption.
#'
#' @param Y numeric matrix.
#' @return matrix of distinct non-dominated rows (order matches first
#'   occurrence in Y).
#' @export
pareto_front <- function(Y) {
  if (!is.matrix(Y)) Y <- as.matrix(Y)
  storage.mode(Y) <- "double"
  pf <- ctmgp_pareto_extract_cpp(Y)
  # Deduplicate exact-duplicate rows (a Pareto FRONT is a set; identical rows
  # are mutually non-dominated by the strict-domination rule but downstream
  # consumers expect uniqueness).
  if (nrow(pf) > 1L) {
    keys <- apply(pf, 1, function(r) paste(r, collapse = "||"))
    keep <- !duplicated(keys)
    pf <- pf[keep, , drop = FALSE]
  }
  pf
}

#' Default reference point from a non-dominated front.
#'
#' Used as the auto-default by `acq_ehvi()`, `box_decompose()`,
#' `anchor_decompose()`, `hypervolume()`, and `bo_loop()` when the caller
#' doesn't supply an explicit `ref_point`.  The rule is
#'
#'   ref[l] = max(PF[, l]) + margin × max(max(PF[, l]) - min(PF[, l]), eps)
#'
#' so that degenerate (zero-range) PF dimensions still get a strict cushion
#' above `max(PF)` instead of `ref == max(PF)` (which would break the EHVI
#' anchor decomposition's "ref strictly dominates PF" requirement).
#'
#' @param PF non-empty `n × T` numeric matrix.
#' @param margin fractional cushion (default 0.1, matching the paper's
#'   informal default).
#' @param eps absolute floor for the per-dim cushion (default 1e-12) so
#'   degenerate dims are still strictly cushioned.
#' @return length-T numeric vector.
#' @export
ctmgp_default_ref_point <- function(PF, margin = 0.1, eps = 1e-12) {
  if (!is.matrix(PF)) PF <- as.matrix(PF)
  if (nrow(PF) == 0L) stop("ctmgp_default_ref_point: PF must be non-empty.")
  col_max <- apply(PF, 2, max); col_min <- apply(PF, 2, min)
  col_max + margin * pmax(col_max - col_min, eps)
}

#' Hypervolume (exact T=2 sort-and-sweep; T=3 via HSO; T≥4 not implemented).
#'
#' @param PF matrix of non-dominated points (one row per point).  If Y may
#'   contain dominated points, pre-filter via [pareto_front()].
#' @param ref numeric reference point.  Must be dominated by every point in PF
#'   (i.e. ref[l] > max(PF[,l]) under minimisation).  If `NULL`, derived via
#'   [ctmgp_default_ref_point()].
#' @return scalar hypervolume.  0 if PF is empty.
#' @export
hypervolume <- function(PF, ref = NULL) {
  if (!is.matrix(PF)) PF <- as.matrix(PF)
  storage.mode(PF) <- "double"
  if (nrow(PF) == 0L) return(0.0)
  T <- ncol(PF)
  if (is.null(ref)) ref <- ctmgp_default_ref_point(PF)
  ref <- as.numeric(ref)
  if (length(ref) != T) stop("ref must have length ncol(PF)")
  if (T == 2L) return(ctmgp_hv_2d_cpp(PF, ref))
  if (T == 3L) return(ctmgp_hv_3d_cpp(PF, ref))
  stop("hypervolume(): T >= 4 not yet implemented (paper scope is T <= 3).")
}

#' HV contribution of a single candidate point to the current Pareto front.
#'
#' @param y numeric vector of length T.
#' @param PF matrix of Pareto-front points.
#' @param ref reference point.
#' @return scalar >= 0.
#' @export
hv_contribution <- function(y, PF, ref) {
  y <- as.numeric(y); PF <- as.matrix(PF); ref <- as.numeric(ref)
  storage.mode(PF) <- "double"
  if (length(y) == 2L) return(ctmgp_hv_contrib_2d_cpp(y, PF, ref))
  if (length(y) == 3L) return(ctmgp_hv_contrib_3d_cpp(y, PF, ref))
  stop("hv_contribution(): T >= 4 not yet implemented (paper scope is T <= 3).")
}
