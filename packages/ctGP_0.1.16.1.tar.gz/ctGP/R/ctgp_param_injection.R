
`%||%` <- function(x, y) if (is.null(x)) y else x

# Internal helper: rebuild a GP fit from supplied parameters without optimization.
.ctgp_rebuild_gp_from_template <- function(template_fit, fi, nugget = NULL) {
  if (is.null(template_fit) || !inherits(template_fit, "gp_fit")) {
    stop("template_fit must be a gp_fit object.")
  }
  fi <- as.numeric(fi)
  if (length(fi) != length(template_fit$fi)) {
    stop("fi has incompatible length for the supplied gp_fit template.")
  }
  nugget_use <- if (is.null(nugget)) template_fit$nugget %||% NULL else as.numeric(nugget)
  objective_mode <- as.character(template_fit$search_objective_mode %||% template_fit$objective_mode %||% getOption("ctGP.internal.debug.gp_search_mode", getOption("ctGP.internal.gp_objective_mode", "legacy_exact")))
  objective_mode <- match.arg(objective_mode, choices = c("legacy_exact", "stable"))
  finalize_mode <- "stable"
  fit <- build_gp_from_params_cpp(
    data = as.matrix(template_fit$data),
    fi = fi,
    f_matrix = as.matrix(template_fit$f_matrix),
    nugget = nugget_use,
    objective_mode = if (identical(objective_mode, "legacy_exact")) 1L else 0L,
    finalize_mode = 0L
  )
  fit$mean_source <- template_fit$mean_source %||% "default"
  fit$mean_structure <- template_fit$mean_structure %||% "formula: ~1"
  fit$mean_formula <- template_fit$mean_formula %||% "~1"
  fit$mean_terms <- template_fit$mean_terms %||% colnames(template_fit$f_matrix)
  fit$x_colnames_used <- template_fit$x_colnames_used %||% colnames(template_fit$data)[seq_len(ncol(template_fit$data) - 1L)]
  fit$timing <- list(elapsed = 0, user_self = 0, sys_self = 0)
  fit$optimizer_control <- template_fit$optimizer_control %||% NULL
  fit$optimizer_mode <- "supplied"
  fit$objective_mode <- objective_mode
  fit$search_objective_mode <- objective_mode
  fit$gp_finalize_mode <- finalize_mode
  fit$finalize_objective_mode <- "stable"
  fit$seed_requested <- NA_integer_
  fit$seed_cpp_used <- NA_integer_
  fit$r_seed_set_before_cpp <- FALSE
  fit$normalization <- template_fit$normalization %||% "none"
  fit$normalize_response <- template_fit$normalize_response %||% FALSE
  fit$input_normalizer <- template_fit$input_normalizer %||% NULL
  fit$response_normalizer <- template_fit$response_normalizer %||% NULL
  fit$training_data_original <- template_fit$training_data_original %||% NULL
  fit$range_requested <- c(fi, fi)
  fit$range_used <- c(fi, fi)
  fit$parameter_source <- "supplied"
  class(fit) <- c("gp_fit", setdiff(class(template_fit), "gp_fit"))
  fit$diagnostics <- ctgp_diagnostics(fit)
  fit
}

# Internal helper: rebuild a QQGP fit from supplied parameters without optimization.
.ctgp_rebuild_qqgp_from_template <- function(template_fit,
                                             fi,
                                             theta = NULL,
                                             t_matrix = NULL,
                                             nugget = NULL,
                                             objective_mode = NULL) {
  if (is.null(template_fit) || !inherits(template_fit, "qqgp_fit")) {
    stop("template_fit must be a qqgp_fit object.")
  }
  if (!xor(is.null(theta), is.null(t_matrix))) {
    stop("Provide exactly one of theta or t_matrix.")
  }
  fi <- as.numeric(fi)
  if (length(fi) != length(template_fit$fi)) {
    stop("fi has incompatible length for the supplied qqgp_fit template.")
  }
  if (!is.null(theta)) theta <- as.numeric(theta)
  if (!is.null(t_matrix)) t_matrix <- as.matrix(t_matrix)
  nugget_use <- if (is.null(nugget)) template_fit$nugget %||% NULL else as.numeric(nugget)
  objective_mode <- as.character(objective_mode %||% template_fit$search_objective_mode %||% template_fit$objective_mode %||% getOption("ctGP.internal.debug.qqgp_search_mode", getOption("ctGP.internal.qqgp_objective_mode", "legacy_exact")))
  objective_mode <- match.arg(objective_mode, choices = c("legacy_exact", "stable"))
  finalize_mode <- "stable"
  fit <- build_qqgp_from_params_cpp(
    design = as.matrix(template_fit$design),
    data = as.matrix(template_fit$data),
    fi = fi,
    theta = theta,
    t_matrix = t_matrix,
    f_matrix = as.matrix(template_fit$f_matrix),
    nugget = nugget_use,
    objective_mode = if (identical(objective_mode, "legacy_exact")) 1L else 0L,
    finalize_mode = 0L
  )
  fit$mean_source <- template_fit$mean_source %||% "default"
  fit$mean_structure <- template_fit$mean_structure %||% "formula: ~1 + level"
  fit$mean_formula <- template_fit$mean_formula %||% "~1 + level"
  fit$mean_terms <- template_fit$mean_terms %||% colnames(template_fit$f_matrix)
  fit$x_colnames_used <- template_fit$x_colnames_used %||% colnames(template_fit$design)
  fit$level_levels_used <- template_fit$level_levels_used %||% levels(factor(template_fit$data[, ncol(template_fit$data) - 1L]))
  fit$timing <- list(elapsed = 0, user_self = 0, sys_self = 0)
  fit$optimizer_control <- template_fit$optimizer_control %||% NULL
  fit$optimizer_mode <- "supplied"
  fit$objective_mode <- objective_mode
  fit$search_objective_mode <- objective_mode
  fit$finalize_objective_mode <- "stable"
  fit$qqgp_finalize_mode <- finalize_mode
  fit$fi_range_requested <- template_fit$fi_range_requested %||% NULL
  fit$fi_range_used <- c(fi, fi)
  fit$theta_range_requested <- template_fit$theta_range_requested %||% NULL
  fit$theta_range_used <- if (is.null(theta)) NULL else c(theta, theta)
  fit$theta_range_sanitized <- FALSE
  fit$fixed_t <- !is.null(t_matrix)
  fit$t_matrix_input_dim <- if (is.null(t_matrix)) c(0L, 0L) else as.integer(dim(t_matrix))
  fit$seed_requested <- NA_integer_
  fit$seed_cpp_used <- NA_integer_
  fit$r_seed_set_before_cpp <- FALSE
  fit$normalization <- template_fit$normalization %||% "none"
  fit$normalize_response <- template_fit$normalize_response %||% FALSE
  fit$input_normalizer <- template_fit$input_normalizer %||% NULL
  fit$response_normalizer <- template_fit$response_normalizer %||% NULL
  fit$training_data_original <- template_fit$training_data_original %||% NULL
  fit$parameter_source <- "supplied"
  class(fit) <- c("qqgp_fit", setdiff(class(template_fit), "qqgp_fit"))
  fit$diagnostics <- ctgp_diagnostics(fit)
  fit
}
