// ctmGP — leaf moment kernels for the unified EHVI engine.
//
// For a box [l, u] in R^d and a (multivariate) Gaussian predictive
// distribution N(mu, sigma) over the leaf's d outputs, the leaf moment is:
//
//   J(mu, sigma, l, u) = ∫_{l ≤ y ≤ u} ∏_{m=1..d} (u_m - y_m) f(y; mu, sigma) dy
//
// The product ∏ (u_m - y_m) is the per-box hypervolume contribution under
// Yang-Emmerich-Deutz-Bäck 2019's box decomposition.  EHVI is then
// Σ_k ∏_ℓ J_{k,ℓ} (sum over boxes, product over independent blocks).
//
// Five kernels:
//   moment_1d_cf       — d=1, closed form via Yang ψ helper
//   moment_diag_prod   — d≥2, diagonal Σ; product of d 1D closed forms
//   moment_2d_gh       — d=2, dense Σ; Gauss-Hermite (default 7² nodes)
//   moment_3d_gh       — d=3, dense Σ; Gauss-Hermite (default 5³ = 125 nodes)
//   moment_rqmc_stub   — d≥4, dense Σ; Sobol RQMC (DEFERRED — throws)
//
// Convention: minimization, so (u_m - y_m) ≥ 0 for y inside the box.  -Inf
// lower bounds are handled by R::pnorm(-Inf) = 0 and R::dnorm(-Inf) = 0.
//
// All identifiers are snake_case per the user's project-wide convention.

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <cmath>
#include <limits>
#include <random>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif

using namespace Rcpp;

namespace {

constexpr double pi_const = 3.14159265358979323846;
constexpr double two_pi   = 2.0 * pi_const;
constexpr double sqrt_pi  = 1.77245385090551602730;
constexpr double sqrt_two = 1.41421356237309504880;

// ----------------------------------------------------------------------------
// Yang ψ helper.  For univariate y ~ N(mu, sigma²), the "first-moment"
// integral up to b:
//
//   psi(a, b, mu, sigma) = ∫_{-∞}^{b} (a - y) φ((y-mu)/sigma)/sigma dy
//                        = (a - mu) Φ((b-mu)/sigma) + sigma φ((b-mu)/sigma)
//
// Used as building block for moment_1d_cf.  R::dnorm and R::pnorm handle
// b = ±∞ cleanly.
// ----------------------------------------------------------------------------
inline double psi(double a, double b, double mu, double sigma) {
  const double z = (b - mu) / sigma;
  const double phi_z = R::dnorm(z, 0.0, 1.0, /*log=*/0);
  const double cap_phi_z = R::pnorm(z, 0.0, 1.0, /*lower=*/1, /*log=*/0);
  return (a - mu) * cap_phi_z + sigma * phi_z;
}

// 1D leaf moment ∫_l^u (u - y) φ((y-mu)/sigma)/sigma dy
//   = psi(u, u, mu, sigma) - psi(u, l, mu, sigma)
//   = (u - mu) [Φ(z_u) - Φ(z_l)] + sigma [φ(z_u) - φ(z_l)]
//
// This is the "interior" moment — only the part of y in (l, u].  Use
// `moment_1d_anchor` for the EHVI dispatcher which also needs the "y < l"
// constant-contribution part.
inline double moment_1d_core(double mu, double sigma, double l, double u) {
  if (sigma <= 0.0) {
    if (mu >= l && mu <= u) return (u - mu);
    return 0.0;
  }
  return psi(u, u, mu, sigma) - psi(u, l, mu, sigma);
}

// Anchor-box 1D moment: E[ (u - max(y, l)) · 1{y < u} ] for y ~ N(mu, sigma²)
//
//   = (u - l) · Φ((l - μ)/σ)              [contribution when y ≤ l → clamp to l]
//   + ∫_l^u (u - y) · f(y) dy             [contribution when y ∈ (l, u]]
//
// When l = -Inf, the first term is (u - (-Inf))·0 which we evaluate as 0 in
// the limit (Φ((-Inf-μ)/σ) = 0 and (u-l) is the finite multiplier of zero).
inline double moment_1d_anchor(double mu, double sigma, double l, double u) {
  if (u <= l) return 0.0;
  double constant_part = 0.0;
  if (std::isfinite(l)) {
    if (sigma > 0.0) {
      const double prob_below_l = R::pnorm((l - mu) / sigma, 0.0, 1.0, /*lower=*/1, /*log=*/0);
      constant_part = (u - l) * prob_below_l;
    } else {
      // Degenerate sigma=0: y = mu deterministically.  prob(y ≤ l) = 1 if mu ≤ l else 0
      constant_part = (mu <= l) ? (u - l) : 0.0;
    }
  }
  // l = -Inf → constant_part stays 0 (the limit (u - (-Inf)) * 0 = 0)
  return constant_part + moment_1d_core(mu, sigma, l, u);
}

// ----------------------------------------------------------------------------
// Hard-coded Gauss-Hermite nodes and weights for n ∈ {3, 5, 7}.
// Standard formulation: ∫_{-∞}^∞ g(x) e^{-x²} dx ≈ Σ_i w_i g(x_i).
// To integrate g(y) · N(y; 0, 1) dy, use g(√2 x) and divide by √π:
//   ∫ g(y) N(y; 0, 1) dy ≈ (1/√π) Σ_i w_i g(√2 x_i)
// For multivariate: same nodes used per dimension; rescale via Cholesky.
// Values copied from Abramowitz & Stegun Table 25.10 / verified against numpy.
// ----------------------------------------------------------------------------

struct gh_table {
  std::vector<double> nodes;
  std::vector<double> weights;
};

// Generate or look up GH nodes/weights for given n.  We hard-code n=3,5,7,9
// (paper scope doesn't need higher).
gh_table get_gh_nodes(int n) {
  gh_table out;
  switch (n) {
    case 3:
      out.nodes   = {-1.2247448713915890, 0.0, 1.2247448713915890};
      out.weights = {0.2954089751509193, 1.1816359006036774, 0.2954089751509193};
      break;
    case 5:
      out.nodes   = {-2.0201828704560856, -0.9585724646138185, 0.0,
                       0.9585724646138185, 2.0201828704560856};
      out.weights = {0.0199532420590459, 0.3936193231522411, 0.9453087204829418,
                       0.3936193231522411, 0.0199532420590459};
      break;
    case 7:
      out.nodes   = {-2.6519613568352334, -1.6735516287674714, -0.8162878828589648,
                       0.0,
                       0.8162878828589648,  1.6735516287674714,  2.6519613568352334};
      out.weights = {0.0009717812450995, 0.0545155828191270, 0.4256072526101278,
                       0.8102646175568073,
                       0.4256072526101278, 0.0545155828191270, 0.0009717812450995};
      break;
    case 9:
      out.nodes   = {-3.1909932017815277, -2.2665805845318429, -1.4685532892166680,
                       -0.7235510187528376, 0.0, 0.7235510187528376,
                        1.4685532892166680, 2.2665805845318429, 3.1909932017815277};
      out.weights = {0.0000039606977263, 0.0004943624275537, 0.0088474527394377,
                       0.0656551938846412, 0.7202352156060510, 0.0656551938846412,
                       0.0088474527394377, 0.0004943624275537, 0.0000039606977263};
      break;
    default:
      Rcpp::stop("get_gh_nodes: n must be 3, 5, 7, or 9 (got %d).", n);
  }
  return out;
}

// ----------------------------------------------------------------------------
// 2D Gauss-Hermite moment.
//
// Integrate g(y) = (u_1 - y_1)(u_2 - y_2) · 1(l ≤ y ≤ u) against
// f(y) = N(y; mu, sigma2).  Transform y = mu + L z where LL' = sigma2,
// then dy = |det(L)| dz, f(y) dy = N(z; 0, I) dz.  Integral becomes:
//
//   J = ∫ (u - y(z))_+ · 1(l ≤ y(z) ≤ u) · N(z; 0, I) dz
//
// Apply 2D GH rule with the substitution z = √2 x:
//
//   J ≈ (1/π) Σ_{i,j} w_i w_j · ∏_m (u_m - y(√2 x))_m · 1(...)
//
// Returns 0.0 for degenerate sigma2 (treated as "use 1D path"; caller should
// have routed to moment_diag_prod or moment_1d_cf instead).
// ----------------------------------------------------------------------------
double moment_2d_gh_internal(const arma::vec& mu, const arma::mat& sigma2,
                              const arma::vec& l, const arma::vec& u,
                              int n_nodes) {
  if (mu.n_elem != 2 || l.n_elem != 2 || u.n_elem != 2 ||
      sigma2.n_rows != 2 || sigma2.n_cols != 2) {
    Rcpp::stop("moment_2d_gh: dimensions must all be 2.");
  }
  // Cholesky (lower) of sigma2; jitter on failure
  arma::mat L_chol;
  arma::mat S = sigma2;
  double jitter = 1e-12;
  bool ok = arma::chol(L_chol, S, "lower");
  while (!ok && jitter < 1e-4) {
    S = sigma2 + jitter * arma::eye(2, 2);
    ok = arma::chol(L_chol, S, "lower");
    jitter *= 10.0;
  }
  if (!ok) Rcpp::stop("moment_2d_gh: Cholesky failed even with 1e-4 jitter.");

  gh_table tab = get_gh_nodes(n_nodes);
  double acc = 0.0;
  arma::vec z(2), y(2);
  for (int i = 0; i < n_nodes; ++i) {
    for (int j = 0; j < n_nodes; ++j) {
      z[0] = sqrt_two * tab.nodes[i];
      z[1] = sqrt_two * tab.nodes[j];
      y = mu + L_chol * z;
      // Indicator
      if (y[0] < l[0] || y[0] > u[0] || y[1] < l[1] || y[1] > u[1]) continue;
      const double w = tab.weights[i] * tab.weights[j];
      acc += w * (u[0] - y[0]) * (u[1] - y[1]);
    }
  }
  return acc / pi_const;  // 1/(√π)² = 1/π
}

// ----------------------------------------------------------------------------
// 3D Gauss-Hermite moment.  Same idea, triple sum.  Default n=5 → 125 nodes.
// ----------------------------------------------------------------------------
double moment_3d_gh_internal(const arma::vec& mu, const arma::mat& sigma3,
                              const arma::vec& l, const arma::vec& u,
                              int n_nodes) {
  if (mu.n_elem != 3 || l.n_elem != 3 || u.n_elem != 3 ||
      sigma3.n_rows != 3 || sigma3.n_cols != 3) {
    Rcpp::stop("moment_3d_gh: dimensions must all be 3.");
  }
  arma::mat L_chol;
  arma::mat S = sigma3;
  double jitter = 1e-12;
  bool ok = arma::chol(L_chol, S, "lower");
  while (!ok && jitter < 1e-4) {
    S = sigma3 + jitter * arma::eye(3, 3);
    ok = arma::chol(L_chol, S, "lower");
    jitter *= 10.0;
  }
  if (!ok) Rcpp::stop("moment_3d_gh: Cholesky failed even with 1e-4 jitter.");

  gh_table tab = get_gh_nodes(n_nodes);
  double acc = 0.0;
  arma::vec z(3), y(3);
  for (int i = 0; i < n_nodes; ++i) {
    for (int j = 0; j < n_nodes; ++j) {
      for (int k = 0; k < n_nodes; ++k) {
        z[0] = sqrt_two * tab.nodes[i];
        z[1] = sqrt_two * tab.nodes[j];
        z[2] = sqrt_two * tab.nodes[k];
        y = mu + L_chol * z;
        if (y[0] < l[0] || y[0] > u[0] ||
            y[1] < l[1] || y[1] > u[1] ||
            y[2] < l[2] || y[2] > u[2]) continue;
        const double w = tab.weights[i] * tab.weights[j] * tab.weights[k];
        acc += w * (u[0] - y[0]) * (u[1] - y[1]) * (u[2] - y[2]);
      }
    }
  }
  return acc / (pi_const * sqrt_pi);  // 1/(√π)³
}

}  // namespace

// ============================================================================
// Public Rcpp exports
// ============================================================================

//' Anchor-box 1D moment (closed form).
//'
//' \eqn{E[(u - \max(y, l)) \cdot \mathbf{1}\{y < u\}]} for y ~ N(mu, sigma²).
//' Equals \eqn{(u - l)\,\Phi((l-\mu)/\sigma) + \int_l^u (u-y)\,\phi(\cdot)\,dy}.
//' This is the per-box per-1D contribution used by the EHVI dispatcher under
//' Yang 2019 anchor box decomposition; it differs from the bare
//' \eqn{\int_l^u (u-y) \phi(\cdot)} (= "interior moment") in including the
//' constant-(u - l) contribution from samples with y ≤ l.
//'
//' For l = -Inf, the constant part is taken as 0 in the limit.
//'
//' @param mu scalar predictive mean.
//' @param sigma scalar predictive standard deviation.  Must be ≥ 0.
//' @param l scalar lower box bound (may be -Inf).
//' @param u scalar upper box bound.
//' @return non-negative scalar moment.
// [[Rcpp::export]]
double ctmgp_moment_1d_anchor_cpp(double mu, double sigma, double l, double u) {
  if (sigma < 0.0) Rcpp::stop("sigma must be ≥ 0.");
  return moment_1d_anchor(mu, sigma, l, u);
}

//' Interior 1D moment (closed form; legacy / sanity).
//'
//' \eqn{\int_l^u (u - y) \phi((y-\mu)/\sigma)/\sigma \, dy}.
//' This is NOT the per-box dispatcher kernel — use
//' `ctmgp_moment_1d_anchor_cpp` for that.  Kept for sanity tests and as a
//' building block.
//'
//' @param mu scalar predictive mean.
//' @param sigma scalar predictive standard deviation.  Must be > 0.
//' @param l scalar lower box bound (may be -Inf).
//' @param u scalar upper box bound.
//' @return non-negative scalar moment.
// [[Rcpp::export]]
double ctmgp_moment_1d_cf_cpp(double mu, double sigma, double l, double u) {
  if (sigma < 0.0) Rcpp::stop("ctmgp_moment_1d_cf_cpp: sigma must be >= 0.");
  if (u <= l) return 0.0;
  return moment_1d_core(mu, sigma, l, u);
}

//' Diagonal-leaf anchor moment (product of 1D anchor closed forms).
//'
//' For independent (diagonal-Σ) leaves of any d, the d-D anchor-box moment
//' factorises into a product of d univariate `moment_1d_anchor` values.
//' Same engine path used by QQiGP (forces full diagonal) and by ctmGP leaves
//' whose tree-induced Σ is diagonal within the leaf.
//'
//' @param mu length-d predictive mean.
//' @param sigma_diag length-d predictive standard deviations (sqrt of variances).
//' @param l length-d lower box bound (may contain -Inf).
//' @param u length-d upper box bound.
//' @return non-negative scalar moment.
// [[Rcpp::export]]
double ctmgp_moment_diag_prod_cpp(const arma::vec& mu,
                                    const arma::vec& sigma_diag,
                                    const arma::vec& l, const arma::vec& u) {
  const arma::uword d = mu.n_elem;
  if (sigma_diag.n_elem != d || l.n_elem != d || u.n_elem != d) {
    Rcpp::stop("ctmgp_moment_diag_prod_cpp: all inputs must have the same length.");
  }
  double prod = 1.0;
  for (arma::uword m = 0; m < d; ++m) {
    if (sigma_diag[m] < 0.0)
      Rcpp::stop("ctmgp_moment_diag_prod_cpp: sigma_diag[%d] < 0.",
                 static_cast<int>(m + 1));
    if (u[m] <= l[m]) return 0.0;
    prod *= moment_1d_anchor(mu[m], sigma_diag[m], l[m], u[m]);
    if (prod <= 0.0) return 0.0;
  }
  return prod;
}

//' 2D dense-leaf moment via Gauss-Hermite quadrature.
//'
//' For a 2-D leaf with full predictive covariance, integrate
//' \eqn{(u_1-y_1)(u_2-y_2) \cdot \mathbf{1}\{l \le y \le u\}} against
//' \eqn{N(y; \mu, \Sigma)} using product Gauss-Hermite rule of order
//' `n_nodes` per dimension.
//'
//' Validated convergence: 7-node default gives < 1e-5 relative error vs MC
//' on benign correlated cases (verify per problem; see Rahat et al. 2022 for
//' independent benchmark).
//'
//' @param mu length-2 predictive mean.
//' @param sigma2 2x2 predictive covariance (must be PSD).
//' @param l length-2 lower box bound.
//' @param u length-2 upper box bound.
//' @param n_nodes nodes per dimension; one of 3, 5, 7, 9.  Default 7.
//' @return non-negative scalar moment.
// [[Rcpp::export]]
double ctmgp_moment_2d_gh_cpp(const arma::vec& mu, const arma::mat& sigma2,
                                const arma::vec& l, const arma::vec& u,
                                int n_nodes = 7) {
  if (u[0] <= l[0] || u[1] <= l[1]) return 0.0;
  return moment_2d_gh_internal(mu, sigma2, l, u, n_nodes);
}

//' 3D dense-leaf moment via Gauss-Hermite quadrature.
//'
//' Triple Gauss-Hermite sum.  Default 5³ = 125 nodes; bump to 7³ = 343 if
//' validation flags accuracy issues on a particular problem.
//'
//' @param mu length-3 predictive mean.
//' @param sigma3 3x3 predictive covariance (must be PSD).
//' @param l length-3 lower box bound.
//' @param u length-3 upper box bound.
//' @param n_nodes nodes per dimension; one of 3, 5, 7, 9.  Default 5.
//' @return non-negative scalar moment.
// [[Rcpp::export]]
double ctmgp_moment_3d_gh_cpp(const arma::vec& mu, const arma::mat& sigma3,
                                const arma::vec& l, const arma::vec& u,
                                int n_nodes = 5) {
  if (u[0] <= l[0] || u[1] <= l[1] || u[2] <= l[2]) return 0.0;
  return moment_3d_gh_internal(mu, sigma3, l, u, n_nodes);
}

// ----------------------------------------------------------------------------
// Generic OpenMP MC moment for d >= 2 dense leaves.
//
// Indicator-function integrals (box-restricted moments) are notoriously bad
// for product Gauss-Hermite quadrature: the product rule assumes a smooth
// integrand, but the box edge creates a hard cutoff that no polynomial of
// any degree can resolve.  Empirically, increasing GH node count beyond
// 7 PER DIM made the 2D-correlated case LESS accurate (catastrophic loss).
//
// MC is the robust default.  Cholesky once, embarrassingly parallel across
// samples, OpenMP reduction over samples.
// ----------------------------------------------------------------------------
double moment_dense_mc_internal(const arma::vec& mu, const arma::mat& sigma,
                                  const arma::vec& l, const arma::vec& u,
                                  int n_samples, int seed) {
  const arma::uword d = mu.n_elem;
  arma::mat L_chol;
  arma::mat S = sigma;
  double jitter = 1e-12;
  bool ok = arma::chol(L_chol, S, "lower");
  while (!ok && jitter < 1e-4) {
    S = sigma + jitter * arma::eye(d, d);
    ok = arma::chol(L_chol, S, "lower");
    jitter *= 10.0;
  }
  if (!ok) Rcpp::stop("moment_dense_mc: Cholesky failed even with 1e-4 jitter.");

  double acc = 0.0;
#ifdef _OPENMP
  #pragma omp parallel reduction(+:acc)
#endif
  {
    const int tid =
#ifdef _OPENMP
      omp_get_thread_num();
#else
      0;
#endif
    std::mt19937_64 gen(static_cast<uint64_t>(seed) + 1337ULL * static_cast<uint64_t>(tid));
    std::normal_distribution<double> std_norm(0.0, 1.0);
    arma::vec z(d), y(d);

#ifdef _OPENMP
    #pragma omp for schedule(static)
#endif
    for (int s = 0; s < n_samples; ++s) {
      for (arma::uword m = 0; m < d; ++m) z[m] = std_norm(gen);
      y = mu + L_chol * z;
      // Indicator + product
      bool in_box = true;
      double prod = 1.0;
      for (arma::uword m = 0; m < d; ++m) {
        if (y[m] < l[m] || y[m] > u[m]) { in_box = false; break; }
        prod *= (u[m] - y[m]);
      }
      if (in_box) acc += prod;
    }
  }
  return acc / static_cast<double>(n_samples);
}

//' Generic d-D dense-leaf MC moment (RECOMMENDED for d=2 and d=3 dense).
//'
//' Embarrassingly parallel over MC samples via OpenMP.  Convergence is
//' classical 1/√n; default 10000 samples gives roughly 1% relative error
//' on benign cases (verify per problem).  Robust to any covariance structure
//' as long as Σ is PSD (small jitter added if not).
//'
//' Use this instead of `ctmgp_moment_2d_gh_cpp` / `ctmgp_moment_3d_gh_cpp`
//' for production: GH is mathematically a good rule for SMOOTH integrands but
//' the box-restricted indicator makes it diverge in correlated cases.
//'
//' Same-seed across candidates enables common-random-numbers variance
//' reduction in the upstream EHVI dispatcher.
//'
//' @param mu length-d predictive mean.
//' @param sigma d×d predictive covariance (PSD).
//' @param l length-d lower box bound (may contain -Inf).
//' @param u length-d upper box bound.
//' @param n_samples number of MC samples (default 10000).
//' @param seed RNG seed (default 1).
//' @return non-negative scalar moment estimate.
// [[Rcpp::export]]
double ctmgp_moment_dense_mc_cpp(const arma::vec& mu, const arma::mat& sigma,
                                   const arma::vec& l, const arma::vec& u,
                                   int n_samples = 10000, int seed = 1) {
  const arma::uword d = mu.n_elem;
  if (sigma.n_rows != d || sigma.n_cols != d || l.n_elem != d || u.n_elem != d)
    Rcpp::stop("ctmgp_moment_dense_mc_cpp: dimension mismatch.");
  if (d < 2) Rcpp::stop("ctmgp_moment_dense_mc_cpp: use 1D CF for d=1.");
  for (arma::uword m = 0; m < d; ++m) if (u[m] <= l[m]) return 0.0;
  return moment_dense_mc_internal(mu, sigma, l, u, n_samples, seed);
}

//' RQMC moment for d >= 4 dense leaves — DEFERRED.
//'
//' Sobol-sequence randomized quasi-Monte Carlo path for high-dim dense leaves.
//' Currently throws; not in the current paper scope (T <= 3).
//' Slated for v1.5.
// [[Rcpp::export]]
double ctmgp_moment_rqmc_cpp(const arma::vec& mu, const arma::mat& sigma,
                               const arma::vec& l, const arma::vec& u,
                               int n_samples = 10000, int seed = 1) {
  (void) mu; (void) sigma; (void) l; (void) u; (void) n_samples; (void) seed;
  Rcpp::stop("ctmgp_moment_rqmc_cpp: deferred (paper scope is T <= 3). "
             "Implement when first 4-D dense leaf appears.");
  return 0.0;
}
