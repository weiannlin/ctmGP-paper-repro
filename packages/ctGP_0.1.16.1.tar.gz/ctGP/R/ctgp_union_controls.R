.ctgp_resolve_union_mode <- function(union_mode = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional")) {
  mode <- match.arg(union_mode, choices = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional"))
  if (identical(mode, "exported")) return("fullgrid_exported")
  if (identical(mode, "conditional")) return("conditional_missing_only")
  mode
}

.ctgp_union_mode_short_label <- function(union_mode) {
  mode <- .ctgp_resolve_union_mode(union_mode)
  if (identical(mode, "fullgrid_exported")) return("exported")
  if (identical(mode, "conditional_missing_only")) return("conditional")
  NA_character_
}

.ctgp_union_deterministic_route <- function(union_mode = NULL, regime = NULL) {
  if (!is.null(regime) && identical(as.character(regime[[1L]]), "common")) return("common_observed")
  if (is.null(union_mode) || (length(union_mode) == 1L && is.na(union_mode))) return(NA_character_)
  mode <- .ctgp_resolve_union_mode(union_mode)
  if (identical(mode, "fullgrid_exported")) return("union_fullgrid_exported")
  if (identical(mode, "conditional_missing_only")) return("union_conditional_missing_only")
  NA_character_
}

.ctgp_union_merge_controls <- function(union_control = list(), imputation_control = NULL) {
  if (is.null(imputation_control)) {
    return(union_control)
  }
  imp <- imputation_control
  if (!is.null(imp$mcmc_samples) && is.null(imp$mc_samples)) {
    imp$mc_samples <- imp$mcmc_samples
  }
  utils::modifyList(imp, union_control)
}

ctgp_union_control_defaults <- function(union_control = list(),
                                        optimizer_control = list(),
                                        imputation_control = NULL) {
  opt <- .ctgp_optimizer_control_defaults(optimizer_control)
  merged <- .ctgp_union_merge_controls(union_control = union_control, imputation_control = imputation_control)

  ctrl <- utils::modifyList(list(
    backend = "ctgp_union_candidate_cpp",
    mode = "fullgrid_exported",
    conditioning_mode = "fullgrid",
    level_fi_policy = "fit_per_level",
    duplicate_policy = "mean",
    parallel_mode = "inner_only",
    mc_samples = 50L,
    cache_level_fi = FALSE,
    cache_level_posterior = FALSE,
    use_openmp = opt$use_openmp,
    num_threads = opt$num_threads,
    seed = if (opt$seed < 0L) NULL else opt$seed,
    compat_output = TRUE
  ), merged)

  if (!is.null(ctrl$mcmc_samples) && is.null(ctrl$mc_samples)) {
    ctrl$mc_samples <- ctrl$mcmc_samples
  }

  ctrl$backend <- as.character(ctrl$backend[[1L]])
  ctrl$mode <- .ctgp_resolve_union_mode(as.character(ctrl$mode[[1L]]))
  ctrl$conditioning_mode <- as.character(ctrl$conditioning_mode[[1L]])
  ctrl$level_fi_policy <- as.character(ctrl$level_fi_policy[[1L]])
  ctrl$duplicate_policy <- as.character(ctrl$duplicate_policy[[1L]])
  ctrl$parallel_mode <- as.character(ctrl$parallel_mode[[1L]])
  ctrl$mc_samples <- as.integer(ctrl$mc_samples)
  ctrl$cache_level_fi <- isTRUE(ctrl$cache_level_fi)
  ctrl$cache_level_posterior <- isTRUE(ctrl$cache_level_posterior)
  ctrl$use_openmp <- isTRUE(ctrl$use_openmp)
  ctrl$num_threads <- as.integer(ctrl$num_threads)
  ctrl$seed <- if (is.null(ctrl$seed)) NULL else as.integer(ctrl$seed)
  ctrl$compat_output <- isTRUE(ctrl$compat_output)

  valid_backends <- c("ctgp_union_cpp", "ctgp_union_shadow_cpp", "ctgp_union_candidate_cpp")
  if (!ctrl$backend %in% valid_backends) {
    stop(
      "ctgp_union_control_defaults() currently supports only backend in ",
      paste(shQuote(valid_backends), collapse = ", "), ".",
      call. = FALSE
    )
  }

  valid_modes <- c("fullgrid_exported", "conditional_missing_only")
  if (!ctrl$mode %in% valid_modes) {
    stop(
      "ctgp_union_control_defaults() currently supports only mode in ",
      paste(shQuote(valid_modes), collapse = ", "), ".",
      call. = FALSE
    )
  }

  if (identical(ctrl$mode, "fullgrid_exported")) {
    if (!identical(ctrl$conditioning_mode, "fullgrid")) {
      stop(
        "ctgp_union full-grid shadow mode requires conditioning_mode = 'fullgrid'.",
        call. = FALSE
      )
    }
    ctrl$backend <- "ctgp_union_shadow_cpp"
  } else {
    if (!identical(ctrl$conditioning_mode, "missing_only")) {
      stop(
        "ctgp_union conditional missing-only mode requires conditioning_mode = 'missing_only'.",
        call. = FALSE
      )
    }
    ctrl$backend <- "ctgp_union_candidate_cpp"
  }

  if (!identical(ctrl$level_fi_policy, "fit_per_level")) {
    stop(
      "ctgp_union backend currently supports only level_fi_policy = 'fit_per_level'. ",
      "The shared-global and warm-cached policies remain reserved for later work.",
      call. = FALSE
    )
  }
  if (!identical(ctrl$duplicate_policy, "mean")) {
    stop("ctgp_union backend currently supports only duplicate_policy = 'mean'.", call. = FALSE)
  }
  if (!ctrl$parallel_mode %in% c("inner_only", "serial")) {
    stop(
      "ctgp_union backend currently supports only parallel_mode = 'inner_only' or 'serial'. ",
      "The sample_outer branch remains reserved for a later step.",
      call. = FALSE
    )
  }
  if (!is.finite(ctrl$mc_samples) || ctrl$mc_samples < 1L) {
    stop("ctgp_union backend requires mc_samples to be a positive integer.", call. = FALSE)
  }

  ctrl$parallel_mode_requested <- ctrl$parallel_mode
  if (identical(ctrl$parallel_mode, "serial")) {
    ctrl$parallel_mode <- "inner_only"
    ctrl$use_openmp <- FALSE
    ctrl$num_threads <- 1L
  }

  ctrl$is_shadow_mode <- identical(ctrl$mode, "fullgrid_exported") && identical(ctrl$conditioning_mode, "fullgrid")
  ctrl$is_candidate_mode <- !ctrl$is_shadow_mode
  ctrl$backend_shadow_of <- if (ctrl$is_shadow_mode) "ctgp_bcd_loop_core(regime = 'union')" else NULL
  ctrl$candidate_family <- if (ctrl$is_candidate_mode) "observed_clamped_missing_only" else NULL
  ctrl$supported_modes <- valid_modes
  ctrl$supported_conditioning_modes <- c("fullgrid", "missing_only")
  ctrl$planned_level_fi_policy <- c("shared_global", "fit_per_level_warm_cached")
  ctrl$planned_parallel_modes <- c("sample_outer")
  ctrl
}
