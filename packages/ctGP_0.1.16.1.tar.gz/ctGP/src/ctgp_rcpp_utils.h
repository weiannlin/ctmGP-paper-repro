#ifndef CTGP_RCPP_UTILS_H
#define CTGP_RCPP_UTILS_H

#include <RcppArmadillo.h>

inline bool sexp_is_null(SEXP x) {
  return Rf_isNull(x);
}

inline bool sexp_is_matrix(SEXP x) {
  return Rf_isMatrix(x);
}

template <typename T>
inline bool nullable_is_not_null(const Rcpp::Nullable<T>& x) {
  return x.isNotNull();
}

template <typename T>
inline bool nullable_is_null(const Rcpp::Nullable<T>& x) {
  return x.isNull();
}

inline bool contains_element_named(const Rcpp::List& x, const char* name) {
  return x.containsElementNamed(name);
}

#endif
