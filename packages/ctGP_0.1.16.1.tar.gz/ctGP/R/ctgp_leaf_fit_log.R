#' Extract per-leaf optimization logs from a ctGP fit
#'
#' This helper is mainly intended for internal parity diagnostics. It returns
#' one row per final leaf and records optimizer/objective modes, requested
#' ranges, actual bounds, initial values, boundary hits, and whether a stage
#' T matrix was supplied to the leaf QQGP fit.
#'
#' @param object A `ctgp_fit` object or a tree object containing `leaf_fit`.
#' @param boundary_tol Absolute tolerance used to decide whether an optimizer
#'   solution is on a lower or upper bound.
#' @param digits Number of significant digits used when collapsing vectors into
#'   character fields for CSV-friendly output.
#' @param include_row_index Logical; if `TRUE`, include the row indices routed
#'   to each leaf as a collapsed character column.
#'
#' @return A data frame with one row per leaf. The full raw per-leaf objects are
#'   attached as attribute `"raw_logs"`.
#' @export
ctgp_leaf_fit_log <- function(object, boundary_tol = 1e-8, digits = 16, include_row_index = FALSE) {
  tree <- if (inherits(object, "ctgp_fit")) object$final_tree else object
  if (is.null(tree) || !is.list(tree) || is.null(tree$is_leaf)) {
    stop("ctgp_leaf_fit_log() expects a ctgp_fit object or a tree node object.")
  }
  `%||%` <- function(x, y) if (is.null(x)) y else x
  fmt_num <- function(x) {
    if (is.null(x)) return(NA_character_)
    x <- as.numeric(x)
    if (!length(x)) return("")
    paste(formatC(x, digits = digits, format = "fg", flag = "#"), collapse = "|")
  }
  fmt_int <- function(x) {
    if (is.null(x)) return(NA_character_)
    x <- as.integer(x)
    if (!length(x)) return("")
    paste(x, collapse = "|")
  }
  fmt_dim <- function(x) {
    if (is.null(x)) return(NA_character_)
    x <- as.integer(x)
    if (!length(x)) return("")
    paste(x, collapse = "x")
  }
  rows <- list()
  raw_logs <- list()
  rec <- function(node) {
    if (isTRUE(node$is_leaf)) {
      fit <- node$leaf_fit
      disp <- fit$ctgp_leaf_dispatch_log %||% list()
      leaf_model <- node$leaf_model %||% disp$leaf_model %||% NA_character_
      fit_class <- if (is.null(fit)) NA_character_ else class(fit)[1L]
      best_full <- numeric(0)
      param_names <- character(0)
      if (!is.null(fit$fi)) {
        best_full <- c(best_full, as.numeric(fit$fi))
        param_names <- c(param_names, paste0("fi", seq_along(fit$fi)))
      }
      if (!is.null(fit$theta)) {
        theta_vec <- as.numeric(fit$theta)
        if (length(theta_vec) > 0L) {
          best_full <- c(best_full, theta_vec)
          param_names <- c(param_names, paste0("theta", seq_along(theta_vec)))
        }
      }
      lower <- if (is.null(fit$lower)) numeric(0) else as.numeric(fit$lower)
      upper <- if (is.null(fit$upper)) numeric(0) else as.numeric(fit$upper)
      on_lower <- integer(0); on_upper <- integer(0)
      min_to_lower <- NA_real_; min_to_upper <- NA_real_
      if (length(best_full) > 0L && length(lower) == length(best_full) && length(upper) == length(best_full)) {
        on_lower <- which(abs(best_full - lower) <= boundary_tol)
        on_upper <- which(abs(upper - best_full) <= boundary_tol)
        min_to_lower <- min(best_full - lower)
        min_to_upper <- min(upper - best_full)
      }
      row <- data.frame(
        node_id = as.integer(disp$node_id %||% node$node_id),
        depth = as.integer(disp$depth %||% node$depth),
        n_rows = as.integer(disp$n_rows %||% node$n_rows),
        n_combined = as.integer(disp$n_combined %||% length(node$combined_ids)),
        pure = isTRUE(disp$is_pure %||% (length(node$combined_ids) <= 1L)),
        combined_ids = fmt_int(sort(as.integer(disp$combined_ids %||% node$combined_ids))),
        leaf_model = as.character(leaf_model),
        fit_class = fit_class,
        optimizer_mode = as.character(fit$optimizer_mode %||% fit$optimizer_mode_cpp %||% NA_character_),
        objective_mode = as.character(fit$objective_mode %||% NA_character_),
        search_objective_mode = as.character(fit$search_objective_mode %||% fit$objective_mode %||% NA_character_),
        finalize_objective_mode = as.character(fit$finalize_objective_mode %||% NA_character_),
        qqgp_finalize_mode = as.character(fit$qqgp_finalize_mode %||% NA_character_),
        optimizer_swarm_size = as.integer((fit$optimizer_control %||% list())$swarm_size %||% NA_integer_),
        optimizer_max_iter = as.integer((fit$optimizer_control %||% list())$max_iter %||% NA_integer_),
        seed_requested = as.integer(fit$seed_requested %||% (fit$optimizer_control %||% list())$seed %||% NA_integer_),
        seed_cpp_used = as.integer(fit$seed_cpp_used %||% NA_integer_),
        r_seed_set_before_cpp = isTRUE(fit$r_seed_set_before_cpp),
        tau_matrix_source = as.character(disp$tau_matrix_source %||% NA_character_),
        tau_matrix_supplied = isTRUE(disp$tau_matrix_supplied),
        tau_matrix_dim = fmt_dim(disp$tau_matrix_dim %||% fit$t_matrix_input_dim),
        fixed_t = isTRUE(fit$fixed_t %||% disp$tau_matrix_supplied),
        range_requested = fmt_num(fit$range_requested %||% fit$fi_range_requested),
        range_used = fmt_num(fit$range_used %||% fit$fi_range_used),
        theta_range_requested = fmt_num(fit$theta_range_requested),
        theta_range_used = fmt_num(fit$theta_range_used),
        theta_range_sanitized = isTRUE(fit$theta_range_sanitized),
        lower = fmt_num(lower),
        upper = fmt_num(upper),
        init_param = fmt_num(fit$init_param),
        fi = fmt_num(fit$fi),
        theta = fmt_num(fit$theta),
        best_param = fmt_num(best_full),
        best_on_lower = length(on_lower) > 0L,
        best_on_upper = length(on_upper) > 0L,
        best_on_lower_dims = if (length(on_lower) > 0L) paste(param_names[on_lower], collapse = "|") else "",
        best_on_upper_dims = if (length(on_upper) > 0L) paste(param_names[on_upper], collapse = "|") else "",
        min_dist_to_lower = min_to_lower,
        min_dist_to_upper = min_to_upper,
        raw_rcond = as.numeric(fit$raw_rcond %||% NA_real_),
        nugget_added = if (is.null(fit$nugget_added)) NA else isTRUE(fit$nugget_added),
        effective_nugget = as.numeric(fit$effective_nugget %||% fit$nugget %||% NA_real_),
        neg_log_lik = as.numeric(fit$neg_log_lik %||% NA_real_),
        neg_log_lik_search = as.numeric(fit$neg_log_lik_search %||% NA_real_),
        neg_log_lik_stable = as.numeric(fit$neg_log_lik_stable %||% NA_real_),
        optim_best_value = as.numeric(fit$optim_best_value %||% NA_real_),
        optim_n_eval = as.integer(fit$optim_n_eval %||% NA_integer_),
        optim_converged = if (is.null(fit$optim_converged)) NA else isTRUE(fit$optim_converged),
        stage_fi_init = fmt_num(disp$stage_fi_init),
        stringsAsFactors = FALSE
      )
      if (isTRUE(include_row_index)) row$row_index <- fmt_int(disp$row_index)
      rows[[length(rows) + 1L]] <<- row
      raw_logs[[length(raw_logs) + 1L]] <<- list(node = node, fit = fit, dispatch = disp)
      return(invisible(NULL))
    }
    rec(node$left); rec(node$right)
  }
  rec(tree)
  out <- if (length(rows) > 0L) do.call(rbind, rows) else data.frame()
  rownames(out) <- NULL
  attr(out, "raw_logs") <- raw_logs
  out
}
