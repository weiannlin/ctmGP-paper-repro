
.ctgp_null_coalesce <- function(x, y) if (is.null(x)) y else x

.ctgp_resolve_prediction_control_qq <- function(prediction_control, fit, allow_use_nugget = TRUE) {
  opt <- fit$optimizer_control
  defaults <- list(
    use_openmp = if (!is.null(opt$use_openmp)) isTRUE(opt$use_openmp) else TRUE,
    num_threads = if (!is.null(opt$num_threads)) as.integer(opt$num_threads) else 0L,
    block_size = NULL,
    variance_mode = 'universal'
  )
  if (allow_use_nugget) {
    defaults$use_nugget <- TRUE
  }

  if (is.null(prediction_control)) prediction_control <- list()
  if (!is.list(prediction_control)) stop('prediction_control must be a list.')
  unknown <- setdiff(names(prediction_control), names(defaults))
  if (length(unknown) > 0L) {
    stop('Unknown entries in prediction_control: ', paste(unknown, collapse = ', '), '.')
  }
  control <- defaults
  if (length(prediction_control) > 0L) control[names(prediction_control)] <- prediction_control
  control$use_openmp <- isTRUE(control$use_openmp)
  control$num_threads <- as.integer(control$num_threads)
  if (!is.null(control$block_size)) control$block_size <- as.integer(control$block_size)

  if (allow_use_nugget) {
    ug <- control$use_nugget
    if (is.logical(ug)) {
      if (length(ug) != 1L || is.na(ug)) {
        stop('prediction_control$use_nugget must be a non-missing logical scalar, a character mode, or a nonnegative numeric scalar.')
      }
      control$use_nugget <- if (isTRUE(ug)) 'effective' else 'none'
    } else if (is.character(ug)) {
      if (length(ug) != 1L || is.na(ug)) {
        stop('prediction_control$use_nugget must be a length-1 non-missing character string.')
      }
      ug_norm <- tolower(trimws(ug))
      if (ug_norm %in% c('effective', 'fit', 'true')) {
        control$use_nugget <- 'effective'
      } else if (ug_norm %in% c('none', 'false', 'off', 'no')) {
        control$use_nugget <- 'none'
      } else if (ug_norm %in% c('given', 'input')) {
        control$use_nugget <- 'given'
      } else {
        stop("prediction_control$use_nugget must be one of TRUE/FALSE, 'effective', 'none', 'given', or a nonnegative numeric scalar.")
      }
    } else if (is.numeric(ug)) {
      if (length(ug) != 1L || is.na(ug) || !is.finite(ug) || ug < 0) {
        stop('prediction_control$use_nugget as numeric must be a finite nonnegative scalar.')
      }
      control$use_nugget <- as.numeric(ug)
    } else {
      stop('prediction_control$use_nugget must be logical, character, or numeric.')
    }
  }

  if (length(control$num_threads) != 1L || is.na(control$num_threads)) stop('prediction_control$num_threads must be an integer scalar.')
  if (!is.null(control$block_size) && (length(control$block_size) != 1L || is.na(control$block_size) || control$block_size < 1L)) {
    stop('prediction_control$block_size must be NULL or a positive integer scalar.')
  }
  vm <- control$variance_mode
  if (!is.character(vm) || length(vm) != 1L || is.na(vm)) stop("prediction_control$variance_mode must be a non-missing character scalar.")
  vm <- tolower(trimws(vm))
  if (!vm %in% c('universal', 'legacy')) stop("prediction_control$variance_mode must be either 'universal' or 'legacy'.")
  control$variance_mode <- vm
  control
}

if (!exists('.ctgp_formula_rhs', mode = 'function')) {
  .ctgp_formula_rhs <- function(formula_like) {
    if (is.character(formula_like)) formula_like <- stats::as.formula(formula_like)
    if (!inherits(formula_like, 'formula')) {
      stop('mean_formula must be NULL, a formula, or a character string that can be converted to a formula.')
    }
    trm <- stats::delete.response(stats::terms(formula_like))
    stats::formula(trm)
  }
}

.ctgp_qqgp_infer_mean_source <- function(fit) {
  if (!is.null(fit$mean_source)) return(as.character(fit$mean_source))
  mf <- if (!is.null(fit$mean_formula)) gsub('\\s+', '', fit$mean_formula) else NULL
  ms <- if (!is.null(fit$mean_structure)) gsub('\\s+', '', fit$mean_structure) else NULL
  if (!is.null(mf) && identical(mf, '~1+level')) return('default')
  if (!is.null(ms) && identical(ms, 'formula:~1+level')) return('default')
  if (!is.null(fit$mean_formula)) return('formula')
  if (!is.null(fit$f_matrix)) return('f_matrix')
  'default'
}

.ctgp_qqgp_normalize_newdata <- function(newdata, x_colnames_used, level_levels_used) {
  d <- length(x_colnames_used)
  required_cols <- d + 1L
  if (is.vector(newdata) && !is.list(newdata)) {
    new_point <- as.numeric(newdata)
    if (length(new_point) != required_cols) stop(sprintf('A plain vector is interpreted as a single prediction point, so its length must be exactly %d (%d continuous variables + 1 categorical level).', required_cols, d))
    cont_mat <- matrix(new_point[seq_len(d)], nrow = 1L)
    level_raw <- new_point[d + 1L]
  } else if (is.matrix(newdata)) {
    if (ncol(newdata) != required_cols) stop(sprintf('newdata matrix must have exactly %d columns (%d continuous variables + 1 categorical level).', required_cols, d))
    cont_mat <- newdata[, seq_len(d), drop = FALSE]
    level_raw <- newdata[, d + 1L]
  } else if (is.data.frame(newdata)) {
    nd <- newdata
    if (!is.null(names(nd))) {
      nm <- make.names(names(nd), unique = TRUE)
      names(nd) <- nm
      if (all(x_colnames_used %in% nm) && 'level' %in% nm) nd <- nd[, c(x_colnames_used, 'level'), drop = FALSE]
    }
    if (ncol(nd) != required_cols) stop(sprintf('newdata data.frame must have exactly %d columns (%d continuous variables + 1 categorical level).', required_cols, d))
    cont_mat <- data.matrix(nd[, seq_len(d), drop = FALSE])
    level_raw <- nd[[d + 1L]]
  } else {
    stop(paste0('newdata must be either:\n', '- a numeric vector of length contiDim + 1 for a single point, or\n', '- a matrix/data.frame with contiDim + 1 columns for multiple points.'))
  }
  storage.mode(cont_mat) <- 'double'
  if (any(!is.finite(cont_mat))) stop('newdata continuous part must contain only finite numeric values.')
  if (is.null(colnames(cont_mat))) {
    colnames(cont_mat) <- x_colnames_used
  } else {
    colnames(cont_mat) <- make.names(colnames(cont_mat), unique = TRUE)
    if (!identical(colnames(cont_mat), x_colnames_used)) {
      if (all(x_colnames_used %in% colnames(cont_mat))) cont_mat <- cont_mat[, x_colnames_used, drop = FALSE] else colnames(cont_mat) <- x_colnames_used
    }
  }
  if (is.factor(level_raw) || is.character(level_raw)) {
    lev_chr <- as.character(level_raw)
    if (is.null(level_levels_used)) stop('fit does not contain level metadata needed to interpret character/factor newdata$level.')
    idx <- match(lev_chr, level_levels_used)
    if (anyNA(idx)) stop('newdata contains categorical levels not seen during fitting.')
    level_num <- as.numeric(idx)
  } else {
    level_num <- as.numeric(level_raw)
    if (any(!is.finite(level_num))) stop('newdata categorical level must contain only finite values.')
    level_num <- as.integer(round(level_num))
  }
  out_mat <- cbind(cont_mat, level_num)
  storage.mode(out_mat) <- 'double'
  mean_df <- as.data.frame(cont_mat, stringsAsFactors = FALSE)
  names(mean_df) <- x_colnames_used
  mean_df$level <- factor(level_num, levels = seq_along(level_levels_used), labels = level_levels_used)
  list(matrix = out_mat, mean_data = mean_df)
}

.ctgp_qqgp_build_prediction_f_matrix <- function(fit, newdata_df, f_matrix = NULL) {
  source <- .ctgp_qqgp_infer_mean_source(fit)
  if (source == 'default') {
    FPred <- stats::model.matrix(~ 1 + level, data = newdata_df)
    if (!is.null(fit$mean_terms) && !identical(colnames(FPred), fit$mean_terms)) stop('Prediction mean terms generated from default QQGP mean do not match training mean terms.')
    return(FPred)
  }
  if (source == 'formula') {
    if (is.null(fit$mean_formula)) stop('fit does not contain mean_formula needed for prediction.')
    rhs_formula <- .ctgp_formula_rhs(fit$mean_formula)
    FPred <- stats::model.matrix(rhs_formula, data = newdata_df)
    if (!is.null(fit$mean_terms) && !identical(colnames(FPred), fit$mean_terms)) stop('Prediction mean design matrix generated from fit$mean_formula does not match the training mean terms.')
    return(FPred)
  }
  if (source == 'f_matrix') {
    if (is.null(f_matrix)) {
      stop('This QQGP fit was created using a custom f_matrix. For prediction you must provide the prediction f_matrix explicitly. If you want automatic prediction mean construction, fit the model with mean_formula instead.')
    }
    FPred <- as.matrix(f_matrix)
    storage.mode(FPred) <- 'double'
    if (nrow(FPred) != nrow(newdata_df)) stop('Prediction f_matrix must have the same number of rows as newdata.')
    if (!is.null(fit$mean_terms) && ncol(FPred) != length(fit$mean_terms)) stop('Prediction f_matrix must have the same number of columns as the training f_matrix.')
    if (any(!is.finite(FPred))) stop('Prediction f_matrix must contain only finite values.')
    if (!is.null(fit$mean_terms) && is.null(colnames(FPred))) colnames(FPred) <- fit$mean_terms
    return(FPred)
  }
  stop('Unknown QQGP mean_source in fit object.')
}

predict_qqgp <- function(fit, newdata, f_matrix = NULL, indep = FALSE, prediction_control = list(), ...) {
  UseMethod('predict_qqgp')
}

#' @export
predict_qqgp.qqgp_fit <- function(object, newdata, f_matrix = NULL, indep = FALSE, prediction_control = list(), ...) {
  if (is.null(object$data)) stop('fit does not look like a valid qqgp_fit object.')
  x_colnames_used <- object$x_colnames_used
  if (is.null(x_colnames_used)) {
    d <- ncol(as.matrix(object$design)); x_colnames_used <- paste0('x', seq_len(d))
  }
  level_levels_used <- object$level_levels_used
  if (is.null(level_levels_used)) {
    d <- ncol(as.matrix(object$design)); level_levels_used <- levels(factor(as.matrix(object$data)[, d + 1L]))
  }
  new_info <- .ctgp_qqgp_normalize_newdata(newdata, x_colnames_used, level_levels_used)
  if (!is.null(object$input_normalizer)) {
    x_norm <- .ctgp_apply_fit_input_normalizer(new_info$matrix[, seq_len(length(x_colnames_used)), drop = FALSE], object)
    new_info$matrix[, seq_len(length(x_colnames_used))] <- x_norm
    new_info$mean_data[, x_colnames_used] <- as.data.frame(x_norm, stringsAsFactors = FALSE, check.names = FALSE)
  }
  FPred <- .ctgp_qqgp_build_prediction_f_matrix(object, new_info$mean_data, f_matrix = f_matrix)
  control <- .ctgp_resolve_prediction_control_qq(prediction_control, object, allow_use_nugget = TRUE)
  t_start <- proc.time()

  nugget_override <- NULL
  use_nugget_flag <- TRUE

  if (is.character(control$use_nugget)) {
    if (identical(control$use_nugget, 'none')) {
      use_nugget_flag <- FALSE
    } else if (identical(control$use_nugget, 'effective')) {
      use_nugget_flag <- TRUE
    } else if (identical(control$use_nugget, 'given')) {
      if (is.null(object$nugget_provided) || !isTRUE(object$nugget_provided) || is.null(object$nugget) || !is.finite(object$nugget) || object$nugget < 0) {
        stop(
          "prediction_control$use_nugget = 'given' requires a fit created with an explicit nonnegative nugget."
        )
      }
      nugget_override <- as.numeric(object$nugget)
      use_nugget_flag <- TRUE
    }
  } else if (is.numeric(control$use_nugget)) {
    nugget_override <- as.numeric(control$use_nugget)
    use_nugget_flag <- TRUE
  }

  out <- predict_qqgp_cpp(
    model = object,
    new_point = new_info$matrix,
    f_matrix = FPred,
    indep = indep,
    use_nugget = use_nugget_flag,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    block_size = if (is.null(control$block_size)) 0L else control$block_size,
    nugget_override = nugget_override,
    variance_mode = control$variance_mode
  )
  elapsed <- proc.time() - t_start
  if (!is.null(out$pred_var)) {
    out$pred_var <- pmax(0, as.numeric(out$pred_var))
  } else if (!is.null(out$pred_sigma_sq)) {
    out$pred_var <- pmax(0, diag(out$pred_sigma_sq))
  } else {
    stop("QQGP prediction did not return pred_var or pred_sigma_sq.")
  }
  out <- .ctgp_inverse_prediction_scale(out, object$response_normalizer)
  out$timing <- list(
    wall_sec  = unname(elapsed['elapsed']),
    cpu_sec   = unname(elapsed['user.self'] + elapsed['sys.self']),
    user_sec  = unname(elapsed['user.self']),
    sys_sec   = unname(elapsed['sys.self']),
    elapsed   = unname(elapsed['elapsed']),
    user.self = unname(elapsed['user.self']),
    sys.self  = unname(elapsed['sys.self'])
  )
  out$prediction_control <- control
  out$variance_mode <- control$variance_mode
  out
}

#' @export
predict_qqgp.qqgp_regression_fit <- function(object, newdata, f_matrix = NULL, indep = FALSE, prediction_control = list(), ...) {
  if (is.null(object$data)) stop('fit does not look like a valid qqgp_regression_fit object.')
  x_colnames_used <- object$x_colnames_used
  if (is.null(x_colnames_used)) {
    d <- ncol(as.matrix(object$design)); x_colnames_used <- paste0('x', seq_len(d))
  }
  level_levels_used <- object$level_levels_used
  if (is.null(level_levels_used)) {
    d <- ncol(as.matrix(object$design)); level_levels_used <- levels(factor(as.matrix(object$data)[, d + 1L]))
  }
  new_info <- .ctgp_qqgp_normalize_newdata(newdata, x_colnames_used, level_levels_used)
  if (!is.null(object$input_normalizer)) {
    x_norm <- .ctgp_apply_fit_input_normalizer(new_info$matrix[, seq_len(length(x_colnames_used)), drop = FALSE], object)
    new_info$matrix[, seq_len(length(x_colnames_used))] <- x_norm
    new_info$mean_data[, x_colnames_used] <- as.data.frame(x_norm, stringsAsFactors = FALSE, check.names = FALSE)
  }
  FPred <- .ctgp_qqgp_build_prediction_f_matrix(object, new_info$mean_data, f_matrix = f_matrix)
  control <- .ctgp_resolve_prediction_control_qq(prediction_control, object, allow_use_nugget = FALSE)
  t_start <- proc.time()
  out <- predict_qqgp_cpp(
    model = object,
    new_point = new_info$matrix,
    f_matrix = FPred,
    indep = indep,
    use_nugget = TRUE,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    block_size = if (is.null(control$block_size)) 0L else control$block_size,
    variance_mode = control$variance_mode
  )
  elapsed <- proc.time() - t_start
  if (!is.null(out$pred_var)) {
    out$pred_var <- pmax(0, as.numeric(out$pred_var))
  } else if (!is.null(out$pred_sigma_sq)) {
    out$pred_var <- pmax(0, diag(out$pred_sigma_sq))
  } else {
    stop("QQGP prediction did not return pred_var or pred_sigma_sq.")
  }
  out <- .ctgp_inverse_prediction_scale(out, object$response_normalizer)
  out$timing <- list(
    wall_sec  = unname(elapsed['elapsed']),
    cpu_sec   = unname(elapsed['user.self'] + elapsed['sys.self']),
    user_sec  = unname(elapsed['user.self']),
    sys_sec   = unname(elapsed['sys.self']),
    elapsed   = unname(elapsed['elapsed']),
    user.self = unname(elapsed['user.self']),
    sys.self  = unname(elapsed['sys.self'])
  )
  out$prediction_control <- control
  out$variance_mode <- control$variance_mode
  out
}

