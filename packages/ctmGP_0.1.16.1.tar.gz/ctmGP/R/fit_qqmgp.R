# ctmGP — joint multi-output QQGP without tree (paper §4.3 QQmGP baseline).
#
# fit_qqmgp = long-format MO + concatenate W + response_id into a single
# joint level code → fit_qqgp.  Same kernel as QQiGP/ctmGP but no tree split
# and no per-output decomposition: ALL outputs and ALL categorical levels live
# in one big QQGP fit.

#' Fit a joint multi-output QQGP (QQmGP) on multi-output data.
#'
#' @param data data.frame containing all relevant columns; or NULL if X_mat /
#'   W_mat / Y_mat are passed directly.
#' @param x_cols character vector; names of continuous columns.
#' @param w_cols character vector; names of categorical columns (may be empty).
#' @param y_cols character vector of length T (≥ 2); names of response columns.
#' @param X_mat,W_mat,Y_mat optional matrices when `data` is NULL.
#' @param response_id_name name of the synthesized response indicator factor.
#' @param ... passed to `fit_qqgp()`.
#' @return list of class `qqmgp_fit` with the underlying `qqgp_fit` plus
#'   `mo_meta` and `level_key` (ordering of joint level codes).
#' @export
fit_qqmgp <- function(data = NULL,
                      x_cols = NULL,
                      w_cols = NULL,
                      y_cols = NULL,
                      X_mat = NULL,
                      W_mat = NULL,
                      Y_mat = NULL,
                      response_id_name = "response_id",
                      ...) {
  long <- mo_to_long_format(
    data = data, x_cols = x_cols, w_cols = w_cols, y_cols = y_cols,
    X_mat = X_mat, W_mat = W_mat, Y_mat = Y_mat,
    response_id_name = response_id_name, response_value_name = "y"
  )
  meta <- attr(long, "mo_meta")

  # Combine all categorical cols (W + response_id) into one joint level code
  # via the project's coerce_fun convention (paste with || separator → match).
  all_cat_cols <- c(meta$w_cols, meta$response_id_name)
  cat_chr <- as.data.frame(lapply(long[all_cat_cols], function(z) {
    if (is.factor(z)) as.character(z) else as.character(z)
  }), stringsAsFactors = FALSE, check.names = FALSE)
  level_key <- apply(cat_chr, 1, function(z) paste(z, collapse = "||"))
  level_key_unique <- unique(level_key)
  level_vec <- match(level_key, level_key_unique)

  design <- as.matrix(long[meta$x_cols])
  storage.mode(design) <- "double"
  data_mat <- cbind(design, c.T = level_vec, Y = long$y)
  storage.mode(data_mat) <- "double"

  t_start <- proc.time()
  fit <- fit_qqgp(design = design, data = data_mat, ...)
  elapsed <- proc.time() - t_start

  fit$mo_meta <- meta
  fit$level_key <- level_key_unique     # decode joint level code → "wcat||rid"
  fit$all_cat_cols <- all_cat_cols
  fit$timing_qqmgp <- list(
    wall_sec = unname(elapsed["elapsed"]),
    cpu_sec  = unname(elapsed["user.self"] + elapsed["sys.self"])
  )
  class(fit) <- c("qqmgp_fit", class(fit))
  fit
}

#' Predict from a fitted QQmGP.
#'
#' Tiles `newdata` T times along response_id, encodes joint cat levels via the
#' same level_key as the fit, calls `predict_qqgp(indep = FALSE)` to obtain
#' the full nT × nT joint covariance, then reshapes into per-candidate T×T Σ.
#'
#' Result Σ at each candidate is DENSE (no inter-output zero-block structure);
#' feeding it to `acq_ehvi(block_indices = list(seq_len(T)))` will use the
#' dense MC path.
#'
#' @param fit `qqmgp_fit` from `fit_qqmgp()`.
#' @param newdata data.frame with x_cols + w_cols (no response columns).
#' @param joint logical (TRUE → per-candidate T×T sigma list).
#' @param ... passed to underlying `predict_qqgp()`.
#' @return list with mu, sigma (list of n_new T×T), sigma_marginal,
#'   blocks=list(seq_len(T)), timing.
#' @export
predict_qqmgp <- function(fit, newdata, joint = TRUE, ...) {
  if (!inherits(fit, "qqmgp_fit"))
    stop("fit must be a qqmgp_fit object (from fit_qqmgp).")
  meta <- fit$mo_meta
  newdata <- as.data.frame(newdata, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c(meta$x_cols, meta$w_cols)
  miss <- setdiff(required, names(newdata))
  if (length(miss)) stop("newdata missing columns: ", paste(miss, collapse=", "), ".")
  n_new <- nrow(newdata); T_ <- meta$T

  # Tile T times, attach response_id, then look up joint level code via fit's
  # level_key (so unseen factor combos error explicitly).
  long_new <- newdata[rep(seq_len(n_new), times = T_), required, drop = FALSE]
  rid_chr  <- rep(meta$response_id_levels, each = n_new)
  long_new[[meta$response_id_name]] <- rid_chr

  cat_chr <- as.data.frame(lapply(long_new[fit$all_cat_cols], as.character),
                            stringsAsFactors = FALSE, check.names = FALSE)
  joint_keys <- apply(cat_chr, 1, function(z) paste(z, collapse = "||"))
  level_vec  <- match(joint_keys, fit$level_key)
  if (anyNA(level_vec)) stop(
    "predict_qqmgp: newdata contains categorical level combinations not seen ",
    "during fit (no joint level code available).")

  newdata_qq <- cbind(as.matrix(long_new[meta$x_cols]), c.T = level_vec)

  t_start <- proc.time()
  pr <- predict_qqgp(fit, newdata = as.data.frame(newdata_qq), indep = FALSE, ...)
  elapsed <- proc.time() - t_start

  # Reshape: row i of long_new corresponds to (response (i-1)%/%n_new + 1, candidate (i-1)%%n_new + 1)
  mu_T <- matrix(pr$pred_mean, nrow = n_new, ncol = T_)
  mu_T <- t(mu_T)                                          # T × n_new
  var_T <- matrix(pr$pred_var, nrow = n_new, ncol = T_)
  var_T[var_T < 0] <- 0     # avoid pmax(0, matrix) which drops dim
  sd_T <- t(sqrt(var_T))     # T × n_new

  sigma_list <- NULL
  if (isTRUE(joint)) {
    sigma_list <- vector("list", n_new)
    Sfull <- pr$pred_sigma_sq
    for (c in seq_len(n_new)) {
      idx <- (seq_len(T_) - 1L) * n_new + c
      sigma_list[[c]] <- Sfull[idx, idx, drop = FALSE]
    }
    # Project to PSD — kriging drift can produce indefinite blocks that break
    # downstream Cholesky in the EHVI engine.
    sigma_list <- .psd_project_list(sigma_list)
  }

  list(
    mu              = mu_T,
    sigma           = sigma_list,
    sigma_marginal  = sd_T,
    blocks          = list(seq_len(T_)),
    timing          = list(
      wall_sec = unname(elapsed["elapsed"]),
      cpu_sec  = unname(elapsed["user.self"] + elapsed["sys.self"])
    )
  )
}
