#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

namespace {

void validate_method(const std::string& method) {
  if (!(method == "none" || method == "min_max" || method == "standardize")) {
    Rcpp::stop("method must be one of 'none', 'min_max', or 'standardize'.");
  }
}

Rcpp::List build_normalizer_core(const arma::mat& x, const std::string& method) {
  validate_method(method);
  if (x.n_cols < 1) Rcpp::stop("x must have at least one column.");
  if (!x.is_finite()) Rcpp::stop("x must contain only finite numeric values.");

  arma::rowvec offset(x.n_cols, arma::fill::zeros);
  arma::rowvec scale(x.n_cols, arma::fill::ones);
  arma::uvec constant_mask(x.n_cols, arma::fill::zeros);

  if (method == "min_max") {
    for (arma::uword j = 0; j < x.n_cols; ++j) {
      const double mn = x.col(j).min();
      const double mx = x.col(j).max();
      offset(j) = mn;
      scale(j) = mx - mn;
      if (!std::isfinite(scale(j)) || scale(j) <= 0.0) {
        scale(j) = 1.0;
        constant_mask(j) = 1u;
      }
    }
  } else if (method == "standardize") {
    for (arma::uword j = 0; j < x.n_cols; ++j) {
      const arma::vec col = x.col(j);
      const double mu = arma::mean(col);
      double sd = arma::stddev(col, 0); // sample sd
      offset(j) = mu;
      if (!std::isfinite(sd) || sd <= 0.0) {
        sd = 1.0;
        constant_mask(j) = 1u;
      }
      scale(j) = sd;
    }
  }

  return Rcpp::List::create(
    Rcpp::Named("method") = method,
    Rcpp::Named("offset") = offset,
    Rcpp::Named("scale") = scale,
    Rcpp::Named("constant_mask") = constant_mask,
    Rcpp::Named("n_col") = static_cast<int>(x.n_cols)
  );
}

arma::mat apply_normalizer_core(const arma::mat& x, const Rcpp::List& spec) {
  if (!x.is_finite()) Rcpp::stop("x must contain only finite numeric values.");
  std::string method = Rcpp::as<std::string>(spec["method"]);
  validate_method(method);
  arma::rowvec offset = Rcpp::as<arma::rowvec>(spec["offset"]);
  arma::rowvec scale = Rcpp::as<arma::rowvec>(spec["scale"]);
  if (x.n_cols != offset.n_elem || x.n_cols != scale.n_elem) {
    Rcpp::stop("x has incompatible number of columns for the supplied normalizer.");
  }
  if (method == "none") return x;
  arma::mat out = x;
  if (method == "min_max") {
    out.each_row() -= offset;
    out.each_row() /= scale;
  } else if (method == "standardize") {
    out.each_row() -= offset;
    out.each_row() /= scale;
  }
  return out;
}

arma::mat inverse_normalizer_core(const arma::mat& x, const Rcpp::List& spec) {
  if (!x.is_finite()) Rcpp::stop("x must contain only finite numeric values.");
  std::string method = Rcpp::as<std::string>(spec["method"]);
  validate_method(method);
  arma::rowvec offset = Rcpp::as<arma::rowvec>(spec["offset"]);
  arma::rowvec scale = Rcpp::as<arma::rowvec>(spec["scale"]);
  if (x.n_cols != offset.n_elem || x.n_cols != scale.n_elem) {
    Rcpp::stop("x has incompatible number of columns for the supplied normalizer.");
  }
  if (method == "none") return x;
  arma::mat out = x;
  out.each_row() %= scale;
  out.each_row() += offset;
  return out;
}

arma::mat inverse_variance_core(const arma::mat& x, const Rcpp::List& spec) {
  if (!x.is_finite()) Rcpp::stop("x must contain only finite numeric values.");
  std::string method = Rcpp::as<std::string>(spec["method"]);
  validate_method(method);
  arma::rowvec scale = Rcpp::as<arma::rowvec>(spec["scale"]);
  if (x.n_cols != scale.n_elem) {
    Rcpp::stop("x has incompatible number of columns for the supplied normalizer.");
  }
  if (method == "none") return x;
  arma::rowvec scale_sq = arma::square(scale);
  arma::mat out = x;
  out.each_row() %= scale_sq;
  return out;
}

} // namespace

// [[Rcpp::export]]
Rcpp::List ctgp_build_normalizer_cpp(const arma::mat& x, std::string method = "none") {
  return build_normalizer_core(x, method);
}

// [[Rcpp::export]]
arma::mat ctgp_apply_normalizer_cpp(const arma::mat& x, const Rcpp::List& spec) {
  return apply_normalizer_core(x, spec);
}

// [[Rcpp::export]]
arma::mat ctgp_inverse_normalizer_cpp(const arma::mat& x, const Rcpp::List& spec) {
  return inverse_normalizer_core(x, spec);
}

// [[Rcpp::export]]
arma::mat ctgp_inverse_variance_cpp(const arma::mat& x, const Rcpp::List& spec) {
  return inverse_variance_core(x, spec);
}
