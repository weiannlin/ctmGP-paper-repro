#include "gp_regression_model.h"
#include <cmath>
#include <limits>
#include <algorithm>

namespace {

arma::mat gpreg_build_corr_matrix(
    const arma::mat& design,
    const arma::vec& fi,
    double nugget
) {
  int n = static_cast<int>(design.n_rows);
  int d = static_cast<int>(design.n_cols);

  arma::vec theta = arma::exp(fi * std::log(10.0));
  arma::mat H(n, n, arma::fill::eye);

  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = design(i, k) - design(j, k);
        s += theta(k) * diff * diff;
      }
      double val = std::exp(-s);
      H(i, j) = val;
      H(j, i) = val;
    }
  }

  if (nugget > 0.0) {
    H.diag() += nugget;
  }

  return H;
}

double gpreg_compute_stabilization_jitter(
    const arma::mat& H,
    double max_cond = 1e12
) {
  arma::mat Hsym = 0.5 * (H + H.t());

  arma::vec eigval;
  bool ok = arma::eig_sym(eigval, Hsym);
  if (!ok || eigval.n_elem == 0) {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }

  double lam_min = eigval.min();
  double lam_max = eigval.max();
  if (!std::isfinite(lam_min) || !std::isfinite(lam_max)) {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }

  double check_cond = std::abs(lam_max) - max_cond * std::abs(lam_min);
  if (check_cond >= 0.0) {
    return check_cond / (max_cond - 1.0);
  }

  return std::sqrt(std::numeric_limits<double>::epsilon());
}

} // anonymous namespace

Rcpp::List gpreg_default_fi_bounds(const arma::mat& design) {
  int n = static_cast<int>(design.n_rows);
  int d = static_cast<int>(design.n_cols);

  double max_sum_sqdiff = 0.0;
  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = design(i, k) - design(j, k);
        s += diff * diff;
      }
      if (s > max_sum_sqdiff) {
        max_sum_sqdiff = s;
      }
    }
  }

  if (max_sum_sqdiff <= 0.0) {
    max_sum_sqdiff = 1.0;
  }

  double upp = std::log10(-std::log(0.1) / max_sum_sqdiff);
  double low = std::log10(-std::log(0.9) / max_sum_sqdiff);

  arma::vec low_bound(d); low_bound.fill(low);
  arma::vec upp_bound(d); upp_bound.fill(upp);

  return Rcpp::List::create(
    Rcpp::Named("lower") = low_bound,
    Rcpp::Named("upper") = upp_bound
  );
}

Rcpp::List gpreg_default_nugget_spec(const arma::vec& y) {
  double y_var = arma::var(y);
  if (!std::isfinite(y_var) || y_var <= 0.0) {
    y_var = 1.0;
  }

  double lower = std::max(1e-8 * y_var, 1e-12);
  double upper = std::max(y_var, lower * 1e4);
  double init = std::sqrt(lower * upper);

  return Rcpp::List::create(
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper,
    Rcpp::Named("init") = init
  );
}

gp_regression_profile_result gpreg_profile_fit(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    double nugget,
    const arma::mat& f_matrix
) {
  gp_regression_profile_result out;

  if (!(std::isfinite(nugget) && nugget > 0.0)) {
    return out;
  }
  if ((int)f_matrix.n_rows != (int)design.n_rows || f_matrix.n_cols < 1) {
    return out;
  }

  arma::mat H = gpreg_build_corr_matrix(design, fi, nugget);
  arma::mat H_work = H;

  double stabilization_jitter = 0.0;

  double rc = arma::rcond(H_work);
  bool bad_rcond = (!std::isfinite(rc) || rc <= 1e-10);

  arma::mat L;
  bool chol_ok = false;

  if (!bad_rcond) {
    chol_ok = arma::chol(L, H_work, "lower");
  }

  if (!chol_ok) {
    stabilization_jitter = gpreg_compute_stabilization_jitter(H_work, 1e12);
    if (!(std::isfinite(stabilization_jitter) && stabilization_jitter > 0.0)) {
      return out;
    }
    H_work.diag() += stabilization_jitter;
    chol_ok = arma::chol(L, H_work, "lower");
    if (!chol_ok) {
      return out;
    }
  }

  arma::mat h_inv_f = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), f_matrix)
  );

  arma::vec Hiy = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), y)
  );

  arma::mat ft_h_inv_f = f_matrix.t() * h_inv_f;
  ft_h_inv_f = 0.5 * (ft_h_inv_f + ft_h_inv_f.t());

  arma::vec rhs = f_matrix.t() * Hiy;

  arma::vec beta_vec;
  bool beta_ok = arma::solve(
    beta_vec,
    ft_h_inv_f,
    rhs,
    arma::solve_opts::fast + arma::solve_opts::likely_sympd
  );
  if (!beta_ok) {
    beta_ok = arma::solve(beta_vec, ft_h_inv_f, rhs);
  }
  if (!beta_ok || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;
  arma::vec alpha_vec = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), resid)
  );

  double sigma_sq = arma::dot(resid, alpha_vec) / static_cast<double>(design.n_rows);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  double logdet_h = 2.0 * arma::sum(arma::log(L.diag()));
  double neg_log_lik = static_cast<double>(design.n_rows) * std::log(sigma_sq) + logdet_h;

  out.H = H_work;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.sigma_sq = sigma_sq;
  out.nugget = nugget;
  out.log10_nugget = std::log10(nugget);
  out.stabilization_jitter = stabilization_jitter;
  out.effective_nugget = nugget + stabilization_jitter;
  out.neg_log_lik = neg_log_lik;
  out.success = true;

  return out;
}

double gp_regression_likelihood_objective::eval(const arma::vec& par) {
  int d = static_cast<int>(design_.n_cols);
  if ((int)par.n_elem != d + 1) {
    return arma::datum::inf;
  }

  arma::vec fi = par.subvec(0, d - 1);
  double eta = par(d);
  double nugget = std::pow(10.0, eta);

  if (!(std::isfinite(nugget) && nugget > 0.0)) {
    return arma::datum::inf;
  }

  gp_regression_profile_result fit = gpreg_profile_fit(
    design_, y_, fi, nugget, f_matrix_
  );

  if (!fit.success || !std::isfinite(fit.neg_log_lik)) {
    return arma::datum::inf;
  }

  return fit.neg_log_lik;
}
