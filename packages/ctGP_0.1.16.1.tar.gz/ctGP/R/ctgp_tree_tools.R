.ctgp_legacy_comb_list <- function(levels_chr) {
  # Intentionally mimic TBGP.R::splitNode.general() literally, including the
  # 1:0 loop/subset quirk when only one level is present in the current node.
  levels_chr <- as.character(levels_chr)
  cate_num <- length(levels_chr)
  comb_list <- list()

  if (cate_num <= 0L) {
    return(list())
  }

  if (cate_num == 1L) {
    # In TBGP.R, for (j in 1:(1-1)) becomes for (j in 1:0), so j = 1 executes
    # and produces the single existing level as a degenerate candidate. The
    # downstream score for this candidate becomes 2 because one child is empty.
    return(list(levels_chr))
  }

  for (j in 1:(cate_num - 1L)) {
    if (j != 0L) {
      comb_list <- c(comb_list, utils::combn(levels_chr, j, simplify = FALSE))
    }
  }

  keep_n <- 2^(cate_num - 1L) - 1L
  comb_list[seq_len(keep_n)]
}

.ctgp_tau_cross_max_legacy <- function(tau_matrix, left_ids, right_ids, use_abs_tau = FALSE) {
  left_ids <- unique(as.integer(left_ids))
  right_ids <- unique(as.integer(right_ids))
  if (length(left_ids) < 1L || length(right_ids) < 1L) return(2)
  vals <- as.numeric(tau_matrix[left_ids, right_ids, drop = FALSE])
  if (isTRUE(use_abs_tau)) vals <- abs(vals)
  if (length(vals) < 1L || any(!is.finite(vals))) return(2)
  max(vals)
}

.ctgp_find_best_split_legacy <- function(prepped,
                                         tau_matrix,
                                         node_mask = rep(TRUE, nrow(prepped$data)),
                                         min_rows = 1L,
                                         min_combined = 1L,
                                         use_abs_tau = FALSE) {
  node_mask <- as.logical(node_mask)
  if (length(node_mask) != nrow(prepped$data)) stop("node_mask has wrong length.")

  combined_ids <- unique(as.integer(prepped$combined_id[node_mask]))
  if (length(combined_ids) <= 1L) {
    return(list(is_leaf = TRUE, reason = "single combined category"))
  }

  tau_matrix <- as.matrix(tau_matrix)
  qual_df <- prepped$qualitative_data
  qual_names <- names(qual_df)
  if (length(qual_names) < 1L) {
    return(list(is_leaf = TRUE, reason = "no qualitative variables"))
  }

  cate_corr_vec <- vector("list", length = ncol(qual_df))
  comb_list_vec <- vector("list", length = ncol(qual_df))
  cate_levels_vec <- vector("list", length = ncol(qual_df))

  for (i in seq_len(ncol(qual_df))) {
    # Match TBGP.R more closely than levels(factor(.)): preserve first-hit order
    # inside the current node.
    node_levels <- unique(as.character(qual_df[[i]][node_mask]))
    cate_levels_vec[[i]] <- node_levels
    comb_list <- .ctgp_legacy_comb_list(node_levels)
    comb_list_vec[[i]] <- comb_list

    if (length(comb_list) < 1L) {
      cate_corr_vec[[i]] <- numeric(0)
      next
    }

    score_vec <- rep(0, length(comb_list))
    for (j in seq_along(comb_list)) {
      right_levels <- as.character(unlist(comb_list[[j]]))
      right_mask <- node_mask & (as.character(qual_df[[i]]) %in% right_levels)
      left_mask <- node_mask & (!right_mask)

      if (sum(left_mask) < as.integer(min_rows) || sum(right_mask) < as.integer(min_rows)) {
        score_vec[[j]] <- 2
        next
      }

      left_ids <- unique(as.integer(prepped$combined_id[left_mask]))
      right_ids <- unique(as.integer(prepped$combined_id[right_mask]))
      if (length(left_ids) < as.integer(min_combined) || length(right_ids) < as.integer(min_combined)) {
        score_vec[[j]] <- 2
        next
      }

      vals <- as.numeric(tau_matrix[left_ids, right_ids, drop = FALSE])
      if (isTRUE(use_abs_tau)) {
        vals <- abs(vals)
      }
      score_vec[[j]] <- if (length(vals) < 1L || any(!is.finite(vals))) 2 else max(vals)
    }

    cate_corr_vec[[i]] <- score_vec
  }

  # Keep this part structurally identical to TBGP.R. The critical fix is that
  # constant qualitative factors now contribute a score vector containing 2,
  # rather than an empty vector that injects a bogus 0 into min_max_corr.
  min_per_var <- vapply(cate_corr_vec, function(x) {
    if (length(x) > 0L) min(x) else 0
  }, numeric(1))
  min_max_corr <- min(min_per_var)

  split_var_idx <- which(vapply(cate_corr_vec, function(x) any(x == min_max_corr), logical(1)))[1L]
  if (!length(split_var_idx) || is.na(split_var_idx)) {
    return(list(is_leaf = TRUE, reason = "no admissible split"))
  }

  split_pos <- which(cate_corr_vec[[split_var_idx]] == min_max_corr)[1L]
  if (!length(split_pos) || is.na(split_pos)) {
    return(list(is_leaf = TRUE, reason = "no admissible split"))
  }

  split_var <- qual_names[[split_var_idx]]
  right_levels <- as.character(unlist(comb_list_vec[[split_var_idx]][[split_pos]]))
  left_levels <- setdiff(as.character(cate_levels_vec[[split_var_idx]]), right_levels)

  right_mask <- node_mask & (as.character(qual_df[[split_var_idx]]) %in% right_levels)
  left_mask <- node_mask & (!right_mask)
  left_ids <- unique(as.integer(prepped$combined_id[left_mask]))
  right_ids <- unique(as.integer(prepped$combined_id[right_mask]))

  list(
    is_leaf = FALSE,
    split_var = split_var,
    split_var_index = as.integer(split_var_idx),
    right_levels = right_levels,
    left_levels = left_levels,
    score = as.numeric(min_max_corr),
    left_mask = left_mask,
    right_mask = right_mask,
    left_ids = as.integer(left_ids),
    right_ids = as.integer(right_ids),
    node_ids = as.integer(combined_ids),
    n_left = as.integer(sum(left_mask)),
    n_right = as.integer(sum(right_mask)),
    backend = "legacy"
  )
}

.ctgp_find_best_split <- function(prepped,
                                  tau_matrix,
                                  node_mask = rep(TRUE, nrow(prepped$data)),
                                  min_rows = 1L,
                                  min_combined = 1L,
                                  use_openmp = TRUE,
                                  num_threads = 0L,
                                  backend = c("cpp", "legacy"),
                                  use_abs_tau = FALSE) {
  backend <- match.arg(backend)
  node_mask <- as.logical(node_mask)
  if (length(node_mask) != nrow(prepped$data)) stop("node_mask has wrong length.")

  combined_ids <- unique(as.integer(prepped$combined_id[node_mask]))
  if (length(combined_ids) <= 1L) {
    return(list(is_leaf = TRUE, reason = "single combined category"))
  }

  if (identical(backend, "legacy")) {
    return(.ctgp_find_best_split_legacy(
      prepped = prepped,
      tau_matrix = tau_matrix,
      node_mask = node_mask,
      min_rows = min_rows,
      min_combined = min_combined,
      use_abs_tau = use_abs_tau
    ))
  }

  node_rows <- which(node_mask)
  qual_df <- prepped$qualitative_data
  qual_names <- names(qual_df)
  qual_codes <- do.call(cbind, lapply(qual_df, function(z) as.integer(z)))
  storage.mode(qual_codes) <- "double"

  cpp <- ctgp_find_best_split_cpp(
    qualitative_codes = as.matrix(qual_codes),
    combined_id = as.integer(prepped$combined_id),
    tau_matrix = as.matrix(tau_matrix),
    node_rows = as.integer(node_rows),
    min_rows = as.integer(min_rows),
    min_combined = as.integer(min_combined),
    use_openmp = isTRUE(use_openmp),
    num_threads = as.integer(num_threads),
    use_abs_tau = isTRUE(use_abs_tau)
  )

  if (isTRUE(cpp$is_leaf)) {
    return(cpp)
  }

  var_idx <- as.integer(cpp$split_var_index)
  var_name <- qual_names[var_idx]
  levels_map <- levels(qual_df[[var_name]])
  left_codes <- as.integer(cpp$left_codes)
  right_codes <- as.integer(cpp$right_codes)
  left_rows <- as.integer(cpp$left_rows)
  right_rows <- as.integer(cpp$right_rows)

  left_mask <- rep(FALSE, nrow(prepped$data))
  right_mask <- rep(FALSE, nrow(prepped$data))
  left_mask[left_rows] <- TRUE
  right_mask[right_rows] <- TRUE

  list(
    is_leaf = FALSE,
    split_var = var_name,
    split_var_index = var_idx,
    right_levels = levels_map[right_codes],
    left_levels = levels_map[left_codes],
    score = as.numeric(cpp$score),
    left_mask = left_mask,
    right_mask = right_mask,
    left_ids = as.integer(cpp$left_ids),
    right_ids = as.integer(cpp$right_ids),
    node_ids = as.integer(cpp$node_ids),
    n_left = as.integer(cpp$n_left),
    n_right = as.integer(cpp$n_right),
    backend = "cpp",
    cpp = cpp
  )
}

.ctgp_flatten_tree <- function(tree) {
  rows <- list()
  rec <- function(node) {
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = node$node_id,
      parent_id = if (is.null(node$parent_id)) NA_integer_ else node$parent_id,
      depth = node$depth,
      is_leaf = node$is_leaf,
      split_var = if (is.null(node$split_var)) NA_character_ else node$split_var,
      score = if (is.null(node$score)) NA_real_ else node$score,
      n_rows = node$n_rows,
      n_combined = length(node$combined_ids),
      reason = if (is.null(node$reason)) NA_character_ else node$reason,
      leaf_model = if (is.null(node$leaf_model)) NA_character_ else as.character(node$leaf_model),
      stringsAsFactors = FALSE
    )
    if (!isTRUE(node$is_leaf)) {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  do.call(rbind, rows)
}

.ctgp_grow_tree <- function(prepped,
                            tau_matrix,
                            node_mask = rep(TRUE, nrow(prepped$data)),
                            node_id = 1L,
                            parent_id = NULL,
                            depth = 0L,
                            max_depth = NULL,
                            min_rows = 1L,
                            min_combined = 1L,
                            use_openmp = TRUE,
                            num_threads = 0L,
                            backend = c("cpp", "legacy"),
                            use_abs_tau = FALSE) {
  backend <- match.arg(backend)
  node_mask <- as.logical(node_mask)
  combined_ids <- unique(as.integer(prepped$combined_id[node_mask]))

  node <- list(
    node_id = as.integer(node_id),
    parent_id = if (is.null(parent_id)) NULL else as.integer(parent_id),
    depth = as.integer(depth),
    row_mask = node_mask,
    combined_ids = combined_ids,
    n_rows = sum(node_mask),
    is_leaf = TRUE
  )

  hit_max_depth <- !is.null(max_depth) && is.finite(max_depth) && depth >= as.integer(max_depth)
  if (hit_max_depth || length(combined_ids) <= 1L || sum(node_mask) < 2L * min_rows) {
    node$reason <- if (hit_max_depth) "max_depth" else if (length(combined_ids) <= 1L) "single combined category" else "too few rows"
    return(node)
  }

  split <- .ctgp_find_best_split(
    prepped = prepped,
    tau_matrix = tau_matrix,
    node_mask = node_mask,
    min_rows = min_rows,
    min_combined = min_combined,
    use_openmp = use_openmp,
    num_threads = num_threads,
    backend = backend,
    use_abs_tau = use_abs_tau
  )

  if (isTRUE(split$is_leaf)) {
    node$reason <- split$reason
    return(node)
  }

  node$is_leaf <- FALSE
  node$split_var <- split$split_var
  node$left_levels <- split$left_levels
  node$right_levels <- split$right_levels
  node$score <- split$score

  node$left <- .ctgp_grow_tree(
    prepped = prepped,
    tau_matrix = tau_matrix,
    node_mask = split$left_mask,
    node_id = 2L * node_id,
    parent_id = node_id,
    depth = depth + 1L,
    max_depth = max_depth,
    min_rows = min_rows,
    min_combined = min_combined,
    use_openmp = use_openmp,
    num_threads = num_threads,
    backend = backend,
    use_abs_tau = use_abs_tau
  )

  node$right <- .ctgp_grow_tree(
    prepped = prepped,
    tau_matrix = tau_matrix,
    node_mask = split$right_mask,
    node_id = 2L * node_id + 1L,
    parent_id = node_id,
    depth = depth + 1L,
    max_depth = max_depth,
    min_rows = min_rows,
    min_combined = min_combined,
    use_openmp = use_openmp,
    num_threads = num_threads,
    backend = backend,
    use_abs_tau = use_abs_tau
  )

  node
}
