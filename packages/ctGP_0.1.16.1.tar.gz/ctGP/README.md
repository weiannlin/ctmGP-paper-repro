# ctGP

`ctGP` provides Gaussian-process emulators for continuous inputs, QQGP
models for mixed continuous and qualitative inputs, and category-tree
Gaussian-process models that recursively partition qualitative-factor
levels via a learned correlation matrix.

The package supports common-design and union-design data, ships an
OpenMP-parallel C++ backend (PSO + Cholesky / eigen kernels), exposes a
`legacy_exact` LOOCV engine for prune validation, and records per-call
timing on every `fit_*` and `predict_*` return object.

Sister packages **ctmGP** (multi-output / MOBO) and **ctmfGP**
(multi-fidelity) build on this base.

## Installation

Install the R-side dependencies first if you don't have them:

```r
install.packages(c("Rcpp", "RcppArmadillo", "ggplot2"))
```

`lhs`, `knitr`, `rmarkdown`, and the other packages listed under
`Suggests:` are only needed for selected examples and reports.

### Platform prerequisites

- **Windows** — recent R + Rtools45.
- **macOS** — `xcode-select --install`; if OpenMP isn't picked up
  automatically, install a compatible `libomp` runtime.  The package
  treats missing compiled OpenMP as a configure-time error by default;
  set `CTGP_ALLOW_NO_OPENMP=1` (or `configure.args = "--disable-openmp"`)
  only if you intentionally want a serial build.
- **Linux / Ubuntu** —
  `sudo apt install build-essential gfortran libopenblas-dev liblapack-dev pkg-config`.

### Install ctGP

From a local source tarball:

```r
install.packages("ctGP_0.1.16.1.tar.gz", repos = NULL, type = "source")
```

From a cloned source directory:

```r
install.packages(".", repos = NULL, type = "source")
```

## Quick start

### Common-design ctGP

```r
library(ctGP)

ex  <- ctgp_example(quick = TRUE)
fit <- fit_ctgp(ex$prepared, verbose = TRUE, progress_mode = "bar")

pred <- predict_ctgp(fit, newdata = ex$test, indep = TRUE)
head(pred$pred_mean)
fit$fit_control$deterministic_route   # "common_observed"
```

### Union-design ctGP

```r
library(ctGP)

toy   <- ctgp_example(quick = TRUE)
train <- toy$train

drop_idx <- c(
  which(train$c_1 == "c1.1" & train$c_2 == "c2.1")[1],
  which(train$c_1 == "c1.1" & train$c_2 == "c2.2")[2],
  which(train$c_1 == "c1.2" & train$c_2 == "c2.1")[3],
  which(train$c_1 == "c1.2" & train$c_2 == "c2.2")[4]
)
train <- train[-drop_idx, ]

fit_u <- fit_ctgp(
  train,
  design      = "x_1",
  response    = "y",
  qualitative = c("c_1", "c_2"),
  verbose     = TRUE,
  progress_mode = "bar"
)

fit_u$fit_control$deterministic_route   # "union_fullgrid_exported"
```

## Lower-level model interfaces

If you want a single global model instead of a category tree, or to
inspect noisy (`*_regression`) leaves separately:

- `fit_gp()` / `predict_gp()`
- `fit_gp_regression()` / `predict_gp()`
- `fit_qqgp()` / `predict_qqgp()`
- `fit_qqgp_regression()` / `predict_qqgp()`

## Verbosity

`fit_ctgp(data, ..., verbose = TRUE, progress_mode = c("auto","bar","plain","none"))`.
For silent batch jobs use `verbose = FALSE` or `progress_mode = "none"`.

## Runtime inspection

```r
library(ctGP)
ctgp_openmp_enabled_cpp()
ctgp_openmp_max_threads_cpp()
ctgp_openmp_policy_cpp(n_tasks = 8L)
```

## Current deterministic defaults

- `stage_backend = "cpp"`, `split_backend = "cpp"`
- `loocv_engine  = "fast"`, `split_use_abs_tau = TRUE`
- `allow_union_imputation = TRUE`
- default union route = `fullgrid_exported`

`conditional_missing_only` remains available as an explicit alternative.

## Recent changes

- **0.1.16.1** — union-design Monte Carlo imputation sampler now uses
  symmetric eigendecomposition (mvtnorm `method = "eigen"`-equivalent)
  instead of Cholesky.  Cholesky was failing in BO loops where the
  predictive Σ at acquired-near-existing points becomes rank-deficient;
  the eigen path clamps non-positive eigenvalues to zero and returns
  `B = V · diag(sqrt(λ_+))` directly as the sampling factor.  Sister
  packages ctmGP (`Imports: ctGP`) and ctmfGP (manual fork) are aligned
  to the same version and patch.
- **0.1.15.0** — fixed an inherited C++ shadow bug in
  `predict_qqgp_cpp(indep = FALSE)` where a local `arma::mat t_matrix`
  shadowed the outer categorical correlation parameter, collapsing the
  full predictive Σ to a zero diagonal.  Marginal `indep = TRUE` was
  unaffected.
- **0.1.14.3** — uniform per-call timing record (`wall_sec`, `cpu_sec`,
  `user_sec`, `sys_sec`) on every `fit_*` / `predict_*` return.
- **0.1.14.2** — deterministic union default fixed at
  `fullgrid_exported`; OpenMP guard removed from union-stage BCD;
  optional fitting progress bar in the public API.
