#ifndef GP_REGRESSION_MODEL_H
#define GP_REGRESSION_MODEL_H

#include <RcppArmadillo.h>
#include <limits>
#include "objective_base.h"

struct gp_regression_profile_result {
  arma::mat H;
  arma::mat l_matrix;
  arma::vec alpha_vec;
  arma::mat f_matrix;
  arma::vec beta_vec;
  double sigma_sq;
  double nugget;
  double log10_nugget;
  double stabilization_jitter;
  double effective_nugget;
  double neg_log_lik;
  bool success;

  gp_regression_profile_result()
    : sigma_sq(arma::datum::inf),
      nugget(arma::datum::nan),
      log10_nugget(arma::datum::nan),
      stabilization_jitter(0.0),
      effective_nugget(arma::datum::nan),
      neg_log_lik(arma::datum::inf),
      success(false) {}
};

Rcpp::List gpreg_default_fi_bounds(const arma::mat& design);
Rcpp::List gpreg_default_nugget_spec(const arma::vec& y);

gp_regression_profile_result gpreg_profile_fit(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    double nugget,
    const arma::mat& f_matrix
);

class gp_regression_likelihood_objective : public objective_base {
private:
  arma::mat design_;
  arma::vec y_;
  arma::mat f_matrix_;

public:
  gp_regression_likelihood_objective(
    const arma::mat& design,
    const arma::vec& y,
    const arma::mat& f_matrix
  )
    : design_(design), y_(y), f_matrix_(f_matrix) {}

  double eval(const arma::vec& par) override;
};

#endif
