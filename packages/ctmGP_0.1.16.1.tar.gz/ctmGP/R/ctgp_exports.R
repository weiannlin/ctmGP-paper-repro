#' ctmGP namespace declarations
#'
#' Internal roxygen block that keeps the package namespace aligned with the
#' public API and S3 methods.
#'
#' ctmGP `Imports: ctGP` rather than carrying its own copy of the ctGP base;
#' only the multi-output adapters, EHVI/EIM/IGD+ acquisition layer, and the
#' BO-loop driver live here.  S3 dispatch on `predict_ctgp` / `predict_qqgp`
#' works through the parent ctGP package because `fit_ctmgp` / `fit_qqmgp`
#' return objects whose class vectors inherit from `ctgp_fit` / `qqgp_fit`
#' respectively.
#'
#' @name ctmgp_namespace
#' @keywords internal
#' @noRd
#' @rawNamespace useDynLib(ctmGP, .registration = TRUE)
#' @rawNamespace importFrom(Rcpp, evalCpp)
#' @rawNamespace importFrom(ctGP, fit_ctgp)
#' @rawNamespace importFrom(ctGP, fit_qqgp)
#' @rawNamespace importFrom(ctGP, predict_ctgp)
#' @rawNamespace importFrom(ctGP, predict_qqgp)
#' @rawNamespace export(acq_ehvi)
#' @rawNamespace export(acq_eim)
#' @rawNamespace export(anchor_decompose)
#' @rawNamespace export(bo_loop)
#' @rawNamespace export(box_decompose)
#' @rawNamespace export(ctmgp_default_ref_point)
#' @rawNamespace export(ctmgp_find_sigma_components_cpp)
#' @rawNamespace export(ctmgp_method_codes)
#' @rawNamespace export(fit_ctmgp)
#' @rawNamespace export(fit_qqigp)
#' @rawNamespace export(fit_qqmgp)
#' @rawNamespace export(hv_contribution)
#' @rawNamespace export(hypervolume)
#' @rawNamespace export(igd_plus)
#' @rawNamespace export(mo_to_long_format)
#' @rawNamespace export(pareto_front)
#' @rawNamespace export(pareto_mask)
#' @rawNamespace export(predict_ctmgp)
#' @rawNamespace export(predict_qqigp)
#' @rawNamespace export(predict_qqmgp)
NULL
