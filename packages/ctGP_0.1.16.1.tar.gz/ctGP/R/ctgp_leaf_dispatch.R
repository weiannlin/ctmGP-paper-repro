.ctgp_leaf_dispatch_defaults <- function(mode = "deterministic",
                                         pure_model = NULL,
                                         mixed_model = NULL) {
  mode <- match.arg(mode, choices = c("deterministic", "regression"))
  defaults <- if (identical(mode, "deterministic")) {
    list(pure_model = "GP", mixed_model = "QQGP")
  } else {
    list(pure_model = "GPR", mixed_model = "QQGPR")
  }

  pure_model <- if (is.null(pure_model)) defaults$pure_model else toupper(as.character(pure_model[[1L]]))
  mixed_model <- if (is.null(mixed_model)) defaults$mixed_model else toupper(as.character(mixed_model[[1L]]))

  if (!pure_model %in% c("GP", "GPR")) {
    stop("pure_model must be either 'GP' or 'GPR'.")
  }
  if (!mixed_model %in% c("QQGP", "QQGPR")) {
    stop("mixed_model must be either 'QQGP' or 'QQGPR'.")
  }

  list(mode = mode, pure_model = pure_model, mixed_model = mixed_model)
}

.ctgp_normalize_fi_range <- function(range, d, arg_name) {
  .ctgp_expand_fi_range(range, d = d, arg_name = arg_name)
}

.ctgp_normalize_theta_range <- function(theta_range) {
  .ctgp_prepare_theta_range_current(theta_range, arg_name = "mixed_theta_range")
}

.ctgp_leaf_dispatch_range_spec <- function(prepped,
                                           pure_range = NULL,
                                           mixed_fi_range = NULL,
                                           mixed_theta_range = NULL) {
  d <- prepped$schema$conti_dim
  list(
    pure_range = .ctgp_normalize_fi_range(pure_range, d = d, arg_name = "pure_range"),
    mixed_fi_range = .ctgp_normalize_fi_range(mixed_fi_range, d = d, arg_name = "mixed_fi_range"),
    mixed_theta_range = .ctgp_normalize_theta_range(mixed_theta_range)
  )
}

.ctgp_leaf_training_block <- function(node, prepped) {
  if (is.null(node$row_mask)) {
    stop("Leaf dispatch requires each tree node to retain row_mask.")
  }
  idx <- which(as.logical(node$row_mask))
  if (length(idx) < 1L) {
    stop("Encountered an empty leaf while dispatching ctGP leaf models.")
  }
  list(
    index = idx,
    design = as.matrix(prepped$continuous_data[idx, , drop = FALSE]),
    y = as.numeric(prepped$y[idx]),
    combined_id = as.integer(prepped$combined_id[idx])
  )
}

.ctgp_leaf_tau_submatrix <- function(node, bcd_object) {
  if (is.null(bcd_object) || is.null(bcd_object$tau_matrix)) return(NULL)
  col_idx <- .ctgp_tree_node_column_index(node, bcd_object)
  as.matrix(bcd_object$tau_matrix[col_idx, col_idx, drop = FALSE])
}

.ctgp_leaf_init_fi <- function(bcd_object) {
  if (is.null(bcd_object) || is.null(bcd_object$fi)) return(NULL)
  as.numeric(bcd_object$fi)
}

.ctgp_fit_leaf_one <- function(node,
                               prepped,
                               bcd_object = NULL,
                               pure_model,
                               mixed_model,
                               optimizer_control = list(),
                               pure_optimizer_control = optimizer_control,
                               mixed_optimizer_control = optimizer_control,
                               nugget = NULL,
                               nugget_init = NULL,
                               nugget_range = NULL,
                               pure_mean_formula = NULL,
                               mixed_mean_formula = NULL,
                               tau_matrix_source = c("stage", "none"),
                               pure_range = NULL,
                               mixed_fi_range = NULL,
                               mixed_theta_range = NULL) {
  tau_matrix_source <- match.arg(tau_matrix_source, choices = c("stage", "none"))
  train <- .ctgp_leaf_training_block(node, prepped)
  is_pure <- length(unique(train$combined_id)) <= 1L
  model_label <- if (is_pure) pure_model else mixed_model
  fi_init <- .ctgp_leaf_init_fi(bcd_object)
  tau_matrix <- NULL

  if (identical(model_label, "GP")) {
    dat <- cbind(train$design, y = train$y)
    fit <- fit_gp(
      data = dat,
      init_param = fi_init,
      range = pure_range,
      nugget = nugget,
      mean_formula = pure_mean_formula,
      optimizer_control = pure_optimizer_control
    )
  } else if (identical(model_label, "GPR")) {
    dat <- cbind(train$design, y = train$y)
    fit <- fit_gp_regression(
      data = dat,
      init_param = fi_init,
      range = pure_range,
      nugget_init = nugget_init,
      nugget_range = nugget_range,
      mean_formula = pure_mean_formula,
      optimizer_control = pure_optimizer_control
    )
  } else if (identical(model_label, "QQGP")) {
    level_code <- match(train$combined_id, as.integer(node$combined_ids))
    dat <- cbind(train$design, level = level_code, y = train$y)
    tau_matrix <- if (identical(tau_matrix_source, "stage")) .ctgp_leaf_tau_submatrix(node, bcd_object) else NULL
    fit <- fit_qqgp(
      design = train$design,
      data = dat,
      init_param = fi_init,
      fi_range = mixed_fi_range,
      theta_range = mixed_theta_range,
      t_matrix = tau_matrix,
      nugget = nugget,
      mean_formula = mixed_mean_formula,
      optimizer_control = mixed_optimizer_control
    )
  } else if (identical(model_label, "QQGPR")) {
    level_code <- match(train$combined_id, as.integer(node$combined_ids))
    dat <- cbind(train$design, level = level_code, y = train$y)
    tau_matrix <- if (identical(tau_matrix_source, "stage")) .ctgp_leaf_tau_submatrix(node, bcd_object) else NULL
    fit <- fit_qqgp_regression(
      design = train$design,
      data = dat,
      init_param = fi_init,
      fi_range = mixed_fi_range,
      theta_range = mixed_theta_range,
      t_matrix = tau_matrix,
      nugget_init = nugget_init,
      nugget_range = nugget_range,
      mean_formula = mixed_mean_formula,
      optimizer_control = mixed_optimizer_control
    )
  } else {
    stop("Unsupported leaf model label: ", model_label)
  }

  fit$ctgp_leaf_dispatch_log <- list(
    node_id = as.integer(node$node_id),
    depth = as.integer(node$depth),
    n_rows = as.integer(length(train$index)),
    n_combined = as.integer(length(unique(train$combined_id))),
    combined_ids = as.integer(unique(train$combined_id)),
    row_index = as.integer(train$index),
    is_pure = isTRUE(is_pure),
    leaf_model = as.character(model_label),
    stage_fi_init = if (is.null(fi_init)) NULL else as.numeric(fi_init),
    tau_matrix_source = if (isTRUE(is_pure)) NA_character_ else as.character(tau_matrix_source),
    tau_matrix_supplied = !is.null(tau_matrix),
    tau_matrix_dim = if (is.null(tau_matrix)) c(0L, 0L) else as.integer(dim(tau_matrix))
  )

  node$leaf_model <- model_label
  node$leaf_fit <- fit
  node
}

.ctgp_leaf_dispatch_summary <- function(tree) {
  rows <- list()
  rec <- function(node) {
    if (isTRUE(node$is_leaf)) {
      fit <- node$leaf_fit
      rows[[length(rows) + 1L]] <<- data.frame(
        node_id = as.integer(node$node_id),
        depth = as.integer(node$depth),
        n_rows = as.integer(node$n_rows),
        n_combined = as.integer(length(node$combined_ids)),
        leaf_model = if (is.null(node$leaf_model)) NA_character_ else as.character(node$leaf_model),
        fit_class = if (is.null(fit)) NA_character_ else class(fit)[1L],
        converged = if (is.null(fit) || is.null(fit$optim_converged)) NA else isTRUE(fit$optim_converged),
        stringsAsFactors = FALSE
      )
    } else {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

ctgp_dispatch_leaf_models <- function(tree,
                                      prepped,
                                      stage_or_bcd = NULL,
                                      mode = "deterministic",
                                      pure_model = NULL,
                                      mixed_model = NULL,
                                      optimizer_control = list(),
                                      pure_optimizer_control = NULL,
                                      mixed_optimizer_control = NULL,
                                      nugget = NULL,
                                      nugget_init = NULL,
                                      nugget_range = NULL,
                                      pure_mean_formula = NULL,
                                      mixed_mean_formula = NULL,
                                      tau_matrix_source = "none",
                                      pure_range = NULL,
                                      mixed_fi_range = NULL,
                                      mixed_theta_range = NULL,
                                      progress_callback = NULL) {
  if (!inherits(prepped, "ctgp_prepared_data")) {
    stop("ctgp_dispatch_leaf_models() expects `prepped` from ctgp_prepare_data().")
  }
  spec <- .ctgp_leaf_dispatch_defaults(mode = mode, pure_model = pure_model, mixed_model = mixed_model)
  range_spec <- .ctgp_leaf_dispatch_range_spec(prepped, pure_range = pure_range, mixed_fi_range = mixed_fi_range, mixed_theta_range = mixed_theta_range)
  bcd_object <- if (is.null(stage_or_bcd)) NULL else .ctgp_resolve_bcd_object(stage_or_bcd)
  tau_matrix_source <- match.arg(tau_matrix_source, choices = c("stage", "none"))
  if (is.null(pure_optimizer_control)) pure_optimizer_control <- optimizer_control
  if (is.null(mixed_optimizer_control)) mixed_optimizer_control <- optimizer_control

  leaf_total <- .ctgp_tree_leaf_count(tree)
  leaf_counter <- 0L

  rec <- function(node) {
    if (isTRUE(node$is_leaf)) {
      leaf_counter <<- leaf_counter + 1L
      leaf_index <- as.integer(leaf_counter)
      if (is.function(progress_callback)) {
        progress_callback(
          phase = "leaf_begin",
          leaf_index = leaf_index,
          leaf_total = as.integer(leaf_total),
          node_id = as.integer(node$node_id)
        )
      }
      node <- .ctgp_fit_leaf_one(
        node = node,
        prepped = prepped,
        bcd_object = bcd_object,
        pure_model = spec$pure_model,
        mixed_model = spec$mixed_model,
        optimizer_control = optimizer_control,
        pure_optimizer_control = pure_optimizer_control,
        mixed_optimizer_control = mixed_optimizer_control,
        nugget = nugget,
        nugget_init = nugget_init,
        nugget_range = nugget_range,
        pure_mean_formula = pure_mean_formula,
        mixed_mean_formula = mixed_mean_formula,
        tau_matrix_source = tau_matrix_source,
        pure_range = range_spec$pure_range,
        mixed_fi_range = range_spec$mixed_fi_range,
        mixed_theta_range = range_spec$mixed_theta_range
      )
      if (is.function(progress_callback)) {
        progress_callback(
          phase = "leaf_done",
          leaf_index = leaf_index,
          leaf_total = as.integer(leaf_total),
          node_id = as.integer(node$node_id),
          leaf_model = as.character(node$leaf_model %||% NA_character_)
        )
      }
      return(node)
    }
    node$left <- rec(node$left)
    node$right <- rec(node$right)
    node
  }

  out <- rec(tree)
  out <- .ctgp_copy_tree_metadata(out, tree)
  attr(out, "leaf_dispatch") <- list(
    mode = spec$mode,
    pure_model = spec$pure_model,
    mixed_model = spec$mixed_model,
    tau_matrix_source = tau_matrix_source,
    pure_range = range_spec$pure_range,
    mixed_fi_range = range_spec$mixed_fi_range,
    mixed_theta_range = range_spec$mixed_theta_range
  )
  attr(out, "leaf_fit_summary") <- .ctgp_leaf_dispatch_summary(out)
  out
}

fit_ctgp <- function(data,
                     design = NULL,
                     response = NULL,
                     quantitative = NULL,
                     qualitative = NULL,
                     init_param = NULL,
                     global_range = NULL,
                     nugget = NULL,
                     optimizer_control = list(),
                     leaf_optimizer_control = NULL,
                     pure_optimizer_control = NULL,
                     mixed_optimizer_control = NULL,
                     bcd_control = list(),
                     imputation_control = list(),
                     union_control = list(),
                     union_mode = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional"),
                     allow_union_imputation = TRUE,
                     preprocessing_tol = 1e-8,
                     normalization = "none",
                     normalize_response = FALSE,
                     max_depth = NULL,
                     min_rows = 1L,
                     min_combined = 1L,
                     use_openmp = TRUE,
                     num_threads = 0L,
                     do_prune = TRUE,
                     prune_tol = 0,
                     max_prune_passes = 100L,
                     do_leaf_dispatch = TRUE,
                     leaf_mode = "deterministic",
                     pure_model = NULL,
                     mixed_model = NULL,
                     pure_range = NULL,
                     mixed_fi_range = NULL,
                     mixed_theta_range = NULL,
                     pure_mean_formula = NULL,
                     mixed_mean_formula = NULL,
                     nugget_init = NULL,
                     nugget_range = NULL,
                     tau_matrix_source = "none",
                     loocv_engine = "fast",
                     stage_backend = c("cpp", "auto", "legacy"),
                     split_backend = c("cpp", "auto", "legacy"),
                     split_use_abs_tau = .ctgp_default_split_use_abs_tau(),
                     legacy_parallel = FALSE,
                     verbose = TRUE,
                     progress_mode = c("auto", "bar", "plain", "none")) {
  .t_start <- proc.time()
  leaf_mode <- match.arg(leaf_mode, choices = c("deterministic", "regression"))
  union_mode <- .ctgp_resolve_union_mode(union_mode)
  tau_matrix_source <- match.arg(tau_matrix_source, choices = c("stage", "none"))
  loocv_engine <- .ctgp_match_loocv_engine(loocv_engine)
  stage_backend <- match.arg(stage_backend)
  split_backend <- match.arg(split_backend)
  progress_mode <- match.arg(progress_mode)
  total_progress_steps <- if (isTRUE(do_leaf_dispatch)) 6L else 5L
  progress_env <- .ctgp_fit_progress_new(
    total_steps = total_progress_steps,
    enabled = isTRUE(verbose),
    mode = progress_mode,
    title = "fit_ctgp"
  )
  on.exit(.ctgp_fit_progress_close(progress_env), add = TRUE)
  .ctgp_fit_progress_set(
    progress_env,
    done_units = 0,
    step_index = 1L,
    step_label = "prepare data",
    detail = if (inherits(data, "ctgp_prepared_data")) "prepared input" else "coerce raw data"
  )
  prepped <- if (inherits(data, "ctgp_prepared_data")) {
    data
  } else {
    ctgp_prepare_data(
      data = data,
      design = design,
      response = response,
      quantitative = quantitative,
      qualitative = qualitative
    )
  }
  prepped <- .ctgp_apply_prepared_normalization(
    prepped,
    normalization = normalization,
    normalize_response = normalize_response
  )
  regime_hint <- tryCatch(ctgp_detect_design_regime(prepped, preprocessing_tol = preprocessing_tol)$regime, error = function(e) NA_character_)
  .ctgp_fit_progress_set(
    progress_env,
    done_units = 1,
    step_index = 2L,
    step_label = "global stage",
    detail = paste0(
      "regime_hint=", as.character(regime_hint %||% NA_character_),
      " | ",
      .ctgp_fit_progress_stage_hint(
        union_mode = union_mode,
        optimizer_control = optimizer_control,
        bcd_control = bcd_control,
        imputation_control = imputation_control
      )
    )
  )

  if (is.null(leaf_optimizer_control)) {
    leaf_optimizer_control <- optimizer_control
  }
  if (is.null(pure_optimizer_control)) {
    pure_optimizer_control <- leaf_optimizer_control
  }
  if (is.null(mixed_optimizer_control)) {
    mixed_optimizer_control <- leaf_optimizer_control
  }

  stage <- ctgp_global_stage(
    prepped,
    init_param = init_param,
    range = global_range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = bcd_control,
    imputation_control = imputation_control,
    union_control = union_control,
    union_mode = union_mode,
    allow_union_imputation = allow_union_imputation,
    preprocessing_tol = preprocessing_tol,
    backend = stage_backend,
    legacy_parallel = legacy_parallel
  )
  if (is.null(stage$bcd)) {
    stop(
      "fit_ctgp() did not receive a completed deterministic BCD object. ",
      "This usually means union-design data were supplied while allow_union_imputation = FALSE. ",
      "Set allow_union_imputation = TRUE to run the unified deterministic workflow on union-design data, ",
      "or supply common-design data.",
      call. = FALSE
    )
  }
  stage$bcd <- .ctgp_attach_legacy_loocv_state(stage$bcd, prepped)
  stage$prepared <- prepped
  .ctgp_fit_progress_set(
    progress_env,
    done_units = 2,
    step_index = 3L,
    step_label = "grow tree",
    detail = paste0(
      "route=", as.character(stage$deterministic_route %||% .ctgp_union_deterministic_route(union_mode = union_mode, regime = stage$regime$regime)),
      " | split_backend=", split_backend
    )
  )

  grown_tree <- ctgp_grow_tree(
    prepped,
    tau_matrix = stage$bcd$tau_matrix,
    max_depth = max_depth,
    min_rows = min_rows,
    min_combined = min_combined,
    use_openmp = use_openmp,
    num_threads = num_threads,
    backend = split_backend,
    use_abs_tau = split_use_abs_tau
  )

  .ctgp_fit_progress_set(
    progress_env,
    done_units = 3,
    step_index = 4L,
    step_label = "LOOCV",
    detail = .ctgp_fit_progress_tree_brief(grown_tree)
  )

  grown_loocv <- ctgp_loocv_summary(
    grown_tree,
    stage,
    use_cpp = TRUE,
    use_openmp = use_openmp,
    num_threads = num_threads,
    engine = loocv_engine
  )

  .ctgp_fit_progress_set(
    progress_env,
    done_units = 4,
    step_index = 5L,
    step_label = if (isTRUE(do_prune)) "prune tree" else "skip prune",
    detail = if (isTRUE(do_prune)) paste0("max_passes<=", as.integer(max_prune_passes), " | tol=", format(prune_tol, scientific = TRUE)) else "pruning disabled"
  )

  final_tree <- if (isTRUE(do_prune)) {
    ctgp_prune_tree(
      grown_tree,
      stage,
      prune_tol = prune_tol,
      max_passes = max_prune_passes,
      attach_loocv_summary = TRUE,
      loocv_summary = grown_loocv,
      use_cpp = TRUE,
      use_openmp = use_openmp,
      num_threads = num_threads,
      loocv_engine = loocv_engine
    )
  } else {
    out <- grown_tree
    attr(out, "loocv_summary") <- grown_loocv
    out
  }

  if (isTRUE(do_leaf_dispatch)) {
    leaf_total <- .ctgp_tree_leaf_count(final_tree)
    .ctgp_fit_progress_set(
      progress_env,
      done_units = 5,
      step_index = 6L,
      step_label = "leaf dispatch",
      detail = paste0("0/", as.integer(leaf_total), " leaves")
    )
    leaf_progress_callback <- function(phase, leaf_index, leaf_total, node_id, leaf_model = NA_character_) {
      if (!isTRUE(verbose)) return(invisible(NULL))
      frac <- if (isTRUE(leaf_total > 0L)) {
        if (identical(phase, "leaf_done")) {
          5 + as.numeric(leaf_index) / as.numeric(leaf_total)
        } else {
          5 + max(0, as.numeric(leaf_index) - 1) / as.numeric(leaf_total)
        }
      } else {
        5
      }
      detail_txt <- paste0(
        as.integer(leaf_index), "/", as.integer(leaf_total),
        " leaves | node=", as.integer(node_id),
        if (!is.na(leaf_model) && nzchar(as.character(leaf_model))) paste0(" | model=", as.character(leaf_model)) else ""
      )
      .ctgp_fit_progress_set(
        progress_env,
        done_units = frac,
        step_index = 6L,
        step_label = "leaf dispatch",
        detail = detail_txt
      )
    }
    final_tree <- ctgp_dispatch_leaf_models(
      final_tree,
      prepped = prepped,
      stage_or_bcd = stage$bcd,
      mode = leaf_mode,
      pure_model = pure_model,
      mixed_model = mixed_model,
      optimizer_control = leaf_optimizer_control,
      pure_optimizer_control = pure_optimizer_control,
      mixed_optimizer_control = mixed_optimizer_control,
      nugget = nugget,
      nugget_init = nugget_init,
      nugget_range = nugget_range,
      pure_mean_formula = pure_mean_formula,
      mixed_mean_formula = mixed_mean_formula,
      tau_matrix_source = tau_matrix_source,
      pure_range = pure_range,
      mixed_fi_range = mixed_fi_range,
      mixed_theta_range = mixed_theta_range,
      progress_callback = leaf_progress_callback
    )
    .ctgp_fit_progress_set(
      progress_env,
      done_units = 6,
      step_index = 6L,
      step_label = "leaf dispatch",
      detail = paste0(as.integer(leaf_total), " leaves complete")
    )
  } else {
    .ctgp_fit_progress_set(
      progress_env,
      done_units = 5,
      step_index = 5L,
      step_label = "finalize",
      detail = "leaf dispatch disabled"
    )
  }

  out <- list(
    prepared = prepped,
    stage = stage,
    grown_tree = grown_tree,
    grown_loocv = grown_loocv,
    final_tree = final_tree,
    leaf_fit_log = if (isTRUE(do_leaf_dispatch)) ctgp_leaf_fit_log(final_tree) else NULL,
    fit_control = list(
      global_range = global_range,
      pure_range = pure_range,
      mixed_fi_range = mixed_fi_range,
      mixed_theta_range = mixed_theta_range,
      tau_matrix_source = tau_matrix_source,
      normalization = normalization,
      normalize_response = isTRUE(normalize_response),
      loocv_engine = loocv_engine,
      stage_backend = stage_backend,
      split_backend = split_backend,
      split_use_abs_tau = isTRUE(split_use_abs_tau),
      allow_union_imputation = isTRUE(allow_union_imputation),
      union_mode = union_mode,
      deterministic_route = as.character(stage$deterministic_route %||% if (!is.null(stage$regime$regime) && identical(stage$regime$regime, "common")) "common_observed" else .ctgp_union_deterministic_route(union_mode)),
      workflow_family = as.character(stage$workflow_family %||% "deterministic"),
      legacy_parallel = isTRUE(legacy_parallel),
      verbose = isTRUE(verbose),
      progress_mode = if (isTRUE(verbose)) as.character(progress_mode) else "none",
      workflow_progress_checkpoints = if (isTRUE(do_leaf_dispatch)) c("prepare_data", "global_stage", "grow_tree", "loocv", "prune_tree", "leaf_dispatch") else c("prepare_data", "global_stage", "grow_tree", "loocv", "prune_tree")
    )
  )
  out$call <- match.call()
  out$timing <- .ctgp_make_timing(.t_start)
  class(out) <- c("ctgp_fit", "list")
  out
}
