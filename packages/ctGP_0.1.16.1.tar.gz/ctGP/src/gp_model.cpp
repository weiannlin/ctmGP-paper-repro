#include "gp_model.h"
#include "ctgp_rcpp_utils.h"
#include <cmath>
#include <limits>
#include <algorithm>

#ifdef _OPENMP
  #include <omp.h>
#endif

namespace {


int gp_effective_num_threads(bool use_openmp, int requested, int n_tasks) {
  int tasks = std::max(1, n_tasks);
#ifdef _OPENMP
  if (!use_openmp) {
    return 1;
  }
  int max_threads = omp_get_max_threads();
  int out = (requested > 0) ? requested : max_threads;
  out = std::max(1, std::min(out, max_threads));
  out = std::min(out, tasks);
  return std::max(1, out);
#else
  (void)use_openmp;
  (void)requested;
  (void)tasks;
  return 1;
#endif
}

arma::mat gp_cross_corr_matrix(
    const arma::mat& Xnew,
    const arma::mat& Xtrain,
    const arma::vec& theta,
    bool use_openmp,
    int num_threads
) {
  int m = Xnew.n_rows;
  int n = Xtrain.n_rows;
  int d = Xtrain.n_cols;

  arma::mat R(m, n, arma::fill::zeros);
  int n_threads = gp_effective_num_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    for (int j = 0; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = Xnew(i, k) - Xtrain(j, k);
        s += theta(k) * diff * diff;
      }
      R(i, j) = std::exp(-s);
    }
  }

  return R;
}

arma::mat gp_self_corr_matrix(
    const arma::mat& Xnew,
    const arma::vec& theta,
    bool use_nugget,
    double effective_nugget,
    bool use_openmp,
    int num_threads
) {
  int m = Xnew.n_rows;
  int d = Xnew.n_cols;

  arma::mat SXX(m, m, arma::fill::eye);
  int n_threads = gp_effective_num_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    for (int j = i + 1; j < m; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = Xnew(i, k) - Xnew(j, k);
        s += theta(k) * diff * diff;
      }
      double val = std::exp(-s);
      SXX(i, j) = val;
      SXX(j, i) = val;
    }
  }

  if (use_nugget && effective_nugget > 0.0) {
    SXX.diag() += effective_nugget;
  }

  return SXX;
}

arma::mat gp_resolve_new_points(SEXP new_point_sexp, int d) {
  arma::mat new_point;
  if (sexp_is_matrix(new_point_sexp)) {
    new_point = Rcpp::as<arma::mat>(new_point_sexp);
  } else {
    arma::vec v = Rcpp::as<arma::vec>(new_point_sexp);
    new_point = v.t();
  }

  if ((int)new_point.n_cols != d) {
    Rcpp::stop("new_point has incompatible number of columns for GP prediction.");
  }
  if (!new_point.is_finite()) {
    Rcpp::stop("new_point must contain only finite numeric values.");
  }

  return new_point;
}

} // anonymous namespace

// ----------------------------------------------------
// objective mode helpers
// ----------------------------------------------------

namespace {

gp_profile_result gp_profile_fit_stable_impl(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided
);

gp_profile_result gp_profile_fit_legacy_exact_impl(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided
);

} // anonymous namespace

// ----------------------------------------------------
// helper: pairwise corr matrix
// H_ij = exp( - sum_k 10^{fi_k} (x_ik - x_jk)^2 )
// ----------------------------------------------------
arma::mat build_corr_matrix(
    const arma::mat& design,
    const arma::vec& fi,
    double nugget
) {
  int n = design.n_rows;
  int d = design.n_cols;

  arma::vec theta = arma::exp(fi * std::log(10.0));
  arma::mat H(n, n, arma::fill::eye);

  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = design(i, k) - design(j, k);
        s += theta(k) * diff * diff;
      }
      double val = std::exp(-s);
      H(i, j) = val;
      H(j, i) = val;
    }
  }

  if (nugget > 0.0) {
    H.diag() += nugget;
  }

  return H;
}

// ----------------------------------------------------
// 根據 eigenvalue 計算最小 nugget，使 condition number
// 不超過 max_cond
// ----------------------------------------------------
double compute_nugget_from_eigen(
    const arma::mat& H,
    double max_cond
) {
  arma::mat Hsym = 0.5 * (H + H.t());

  arma::vec eigval;
  bool ok = arma::eig_sym(eigval, Hsym);

  if (!ok || eigval.n_elem == 0) {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }

  double lam_min = eigval.min();
  double lam_max = eigval.max();

  if (!std::isfinite(lam_min) || !std::isfinite(lam_max)) {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }

  double check_cond = std::abs(lam_max) - max_cond * std::abs(lam_min);

  if (check_cond >= 0.0) {
    return check_cond / (max_cond - 1.0);
  } else {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }
}

// ----------------------------------------------------
// default bounds
// 使用相關性範圍：0.1 到 0.9
// ----------------------------------------------------
Rcpp::List default_fi_bounds(const arma::mat& design) {
  int n = design.n_rows;
  int d = design.n_cols;

  double max_sum_sqdiff = 0.0;

  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        double diff = design(i, k) - design(j, k);
        s += diff * diff;
      }
      if (s > max_sum_sqdiff) {
        max_sum_sqdiff = s;
      }
    }
  }

  if (max_sum_sqdiff <= 0.0) {
    max_sum_sqdiff = 1.0;
  }

  double upp = std::log10(-std::log(0.1) / max_sum_sqdiff);
  double low = std::log10(-std::log(0.9) / max_sum_sqdiff);

  arma::vec low_bound(d); low_bound.fill(low);
  arma::vec upp_bound(d); upp_bound.fill(upp);

  return Rcpp::List::create(
    Rcpp::Named("lower") = low_bound,
    Rcpp::Named("upper") = upp_bound
  );
}

// ----------------------------------------------------
// 給定 fi 與 f_matrix，做 profile likelihood
// ----------------------------------------------------
namespace {

gp_profile_result gp_profile_fit_stable_impl(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided
) {
  gp_profile_result out;
  out.objective_mode = GP_OBJECTIVE_STABLE;

  if ((int)f_matrix.n_rows != (int)design.n_rows || f_matrix.n_cols < 1) {
    return out;
  }

  arma::mat H = build_corr_matrix(design, fi, 0.0);
  arma::mat H_work = H;

  double effective_nugget = 0.0;

  double rc = arma::rcond(H);
  out.raw_rcond = rc;
  bool bad_rcond = (!std::isfinite(rc) || rc <= 1e-6);

  if (!nugget_provided) {
    if (bad_rcond) {
      effective_nugget = compute_nugget_from_eigen(H, 1e10);
      if (effective_nugget > 0.0) {
        H_work.diag() += effective_nugget;
      }
    }
  } else {
    if (nugget == 0.0) {
      effective_nugget = 0.0;
    } else if (nugget > 0.0) {
      if (bad_rcond) {
        effective_nugget = nugget;
        H_work.diag() += effective_nugget;
      }
    }
  }

  arma::mat L;
  bool chol_ok = arma::chol(L, H_work, "lower");
  if (!chol_ok) {
    return out;
  }

  arma::mat h_inv_f = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), f_matrix)
  );

  arma::vec Hiy = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), y)
  );

  arma::mat ft_h_inv_f = f_matrix.t() * h_inv_f;
  arma::vec rhs = f_matrix.t() * Hiy;

  arma::vec beta_vec;
  bool beta_ok = arma::solve(
    beta_vec,
    ft_h_inv_f,
    rhs,
    arma::solve_opts::fast + arma::solve_opts::likely_sympd
  );
  if (!beta_ok) {
    beta_ok = arma::solve(beta_vec, ft_h_inv_f, rhs);
  }
  if (!beta_ok || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;

  arma::vec alpha_vec = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), resid)
  );

  double sigma_sq = arma::dot(resid, alpha_vec) / static_cast<double>(design.n_rows);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  double logdet_h = 2.0 * arma::sum(arma::log(L.diag()));
  double neg_log_lik = static_cast<double>(design.n_rows) * std::log(sigma_sq) + logdet_h;

  arma::mat I = arma::eye<arma::mat>(design.n_rows, design.n_rows);
  arma::mat h_inv = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), I)
  );

  out.H = H_work;
  out.h_inv = h_inv;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.beta = (beta_vec.n_elem == 1) ? beta_vec(0) : std::numeric_limits<double>::quiet_NaN();
  out.sigma_sq = sigma_sq;
  out.neg_log_lik = neg_log_lik;
  out.effective_nugget = effective_nugget;
  out.nugget_added = (effective_nugget > 0.0);
  out.success = true;

  return out;
}

gp_profile_result gp_profile_fit_legacy_exact_impl(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided
) {
  gp_profile_result out;
  out.objective_mode = GP_OBJECTIVE_LEGACY_EXACT;

  if ((int)f_matrix.n_rows != (int)design.n_rows || f_matrix.n_cols < 1) {
    return out;
  }

  arma::mat H = build_corr_matrix(design, fi, 0.0);
  arma::mat H_work = 0.5 * (H + H.t());

  double rc = arma::rcond(H_work);
  out.raw_rcond = rc;
  const bool bad_rcond = (!std::isfinite(rc) || rc <= 1e-6);

  double effective_nugget = 0.0;
  if (bad_rcond && nugget_provided && std::isfinite(nugget) && nugget > 0.0) {
    effective_nugget = nugget;
    H_work.diag() += effective_nugget;
  }

  arma::mat I = arma::eye<arma::mat>(H_work.n_rows, H_work.n_cols);
  arma::mat H_inv;
  bool solve_ok = arma::solve(H_inv, H_work, I);
  if (!solve_ok || !H_inv.is_finite()) {
    return out;
  }

  arma::mat ft_h_inv_f = f_matrix.t() * H_inv * f_matrix;
  arma::vec rhs = f_matrix.t() * H_inv * y;

  arma::vec beta_vec;
  bool beta_ok = arma::solve(beta_vec, ft_h_inv_f, rhs);
  if (!beta_ok || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;
  arma::vec alpha_vec = H_inv * resid;
  if (!alpha_vec.is_finite()) {
    return out;
  }

  double sigma_sq = arma::as_scalar(resid.t() * H_inv * resid) / static_cast<double>(design.n_rows);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  const double det_h = arma::det(H_work);
  const double neg_log_lik = static_cast<double>(design.n_rows) * std::log(sigma_sq) + std::log(det_h);

  arma::mat L;
  if (!arma::chol(L, H_work, "lower")) {
    return out;
  }

  out.H = H_work;
  out.h_inv = H_inv;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.beta = (beta_vec.n_elem == 1) ? beta_vec(0) : std::numeric_limits<double>::quiet_NaN();
  out.sigma_sq = sigma_sq;
  out.neg_log_lik = neg_log_lik;
  out.effective_nugget = effective_nugget;
  out.nugget_added = (effective_nugget > 0.0);
  out.success = true;
  return out;
}

} // anonymous namespace

gp_profile_result gp_profile_fit(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget,
    bool nugget_provided,
    int objective_mode
) {
  const int resolved = gp_resolve_objective_mode_int(objective_mode);
  if (resolved == GP_OBJECTIVE_LEGACY_EXACT) {
    return gp_profile_fit_legacy_exact_impl(design, y, fi, f_matrix, nugget, nugget_provided);
  }
  return gp_profile_fit_stable_impl(design, y, fi, f_matrix, nugget, nugget_provided);
}

// ----------------------------------------------------
// objective 給 PSO 用
// ----------------------------------------------------
double gp_likelihood_objective::eval(const arma::vec& par) {
  gp_profile_result fit = gp_profile_fit(
    design_,
    y_,
    par,
    f_matrix_,
    nugget_,
    nugget_provided_,
    objective_mode_
  );

  if (!fit.success) {
    return arma::datum::inf;
  }
  if (std::isnan(fit.neg_log_lik)) {
    return arma::datum::inf;
  }
  return fit.neg_log_lik;
}


namespace {

gp_profile_result gp_profile_fit_exact_nugget(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget
) {
  gp_profile_result out;

  if (!std::isfinite(nugget) || nugget < 0.0) {
    return out;
  }

  arma::mat H = build_corr_matrix(design, fi, nugget);
  arma::mat H_work = 0.5 * (H + H.t());

  arma::mat L;
  bool chol_ok = arma::chol(L, H_work, "lower");
  if (!chol_ok) {
    return out;
  }

  arma::mat h_inv_f = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), f_matrix)
  );

  arma::vec Hiy = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), y)
  );

  arma::mat ft_h_inv_f = f_matrix.t() * h_inv_f;
  ft_h_inv_f = 0.5 * (ft_h_inv_f + ft_h_inv_f.t());
  arma::vec rhs = f_matrix.t() * Hiy;

  arma::vec beta_vec;
  bool beta_ok = arma::solve(
    beta_vec,
    ft_h_inv_f,
    rhs,
    arma::solve_opts::fast + arma::solve_opts::likely_sympd
  );
  if (!beta_ok) {
    beta_ok = arma::solve(beta_vec, ft_h_inv_f, rhs);
  }
  if (!beta_ok || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;

  arma::vec alpha_vec = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), resid)
  );

  double sigma_sq = arma::dot(resid, alpha_vec) / static_cast<double>(design.n_rows);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  double logdet_h = 2.0 * arma::sum(arma::log(L.diag()));
  double neg_log_lik = static_cast<double>(design.n_rows) * std::log(sigma_sq) + logdet_h;

  arma::mat I = arma::eye<arma::mat>(design.n_rows, design.n_rows);
  arma::mat h_inv = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), I)
  );

  out.H = H_work;
  out.h_inv = h_inv;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.beta = (beta_vec.n_elem == 1) ? beta_vec(0) : std::numeric_limits<double>::quiet_NaN();
  out.sigma_sq = sigma_sq;
  out.neg_log_lik = neg_log_lik;
  out.effective_nugget = nugget;
  out.success = true;

  return out;
}

} // anonymous namespace

// ----------------------------------------------------
// prediction helper
// ----------------------------------------------------
Rcpp::List gp_predict_from_fit(
    const Rcpp::List& model,
    SEXP new_point_sexp,
    const arma::mat& f_pred_matrix,
    bool indep,
    bool use_nugget,
    bool use_openmp,
    int num_threads,
    int block_size,
    bool has_nugget_override,
    double nugget_override,
    bool use_universal_variance
) {
  arma::mat data = Rcpp::as<arma::mat>(model["data"]);
  arma::vec fi = Rcpp::as<arma::vec>(model["fi"]);
  arma::mat f_matrix_train = Rcpp::as<arma::mat>(model["f_matrix"]);

  int d = data.n_cols - 1;
  arma::mat design = data.cols(0, d - 1);
  arma::vec y = data.col(d);

  arma::mat np = gp_resolve_new_points(new_point_sexp, d);
  int m = np.n_rows;

  if ((int)f_pred_matrix.n_rows != m) {
    Rcpp::stop("f_pred_matrix must have the same number of rows as newdata.");
  }
  if ((int)f_pred_matrix.n_cols != (int)f_matrix_train.n_cols) {
    Rcpp::stop("f_pred_matrix must have the same number of columns as the training f_matrix.");
  }
  if (!f_pred_matrix.is_finite()) {
    Rcpp::stop("f_pred_matrix must contain only finite numeric values.");
  }

  bool is_regression = contains_element_named(model, "log10_nugget");

  arma::mat l_matrix;
  arma::vec alpha_vec;
  arma::vec beta_vec;
  double sigma_sq = arma::datum::nan;
  double effective_nugget = 0.0;

  if (is_regression) {
    l_matrix = Rcpp::as<arma::mat>(model["l_matrix"]);
    alpha_vec = Rcpp::as<arma::vec>(model["alpha_vec"]);
    beta_vec = Rcpp::as<arma::vec>(model["beta_vec"]);
    sigma_sq = Rcpp::as<double>(model["sigma_sq"]);
    if (contains_element_named(model, "effective_nugget")) {
      effective_nugget = Rcpp::as<double>(model["effective_nugget"]);
    }
  } else {
    if (has_nugget_override) {
      gp_profile_result refit = gp_profile_fit_exact_nugget(
        design,
        y,
        fi,
        f_matrix_train,
        nugget_override
      );
      if (!refit.success) {
        Rcpp::stop(
          "Deterministic GP prediction failed while rebuilding the conditioning system with the requested nugget value."
        );
      }
      l_matrix = refit.l_matrix;
      alpha_vec = refit.alpha_vec;
      beta_vec = refit.beta_vec;
      sigma_sq = refit.sigma_sq;
      effective_nugget = refit.effective_nugget;
    } else if (!use_nugget) {
      gp_profile_result refit = gp_profile_fit_exact_nugget(
        design,
        y,
        fi,
        f_matrix_train,
        0.0
      );
      if (!refit.success) {
        Rcpp::stop(
          "Deterministic GP prediction with use_nugget = FALSE failed because the no-nugget conditioning system is numerically unstable. "
          "Try prediction_control = list(use_nugget = TRUE)."
        );
      }
      l_matrix = refit.l_matrix;
      alpha_vec = refit.alpha_vec;
      beta_vec = refit.beta_vec;
      sigma_sq = refit.sigma_sq;
      effective_nugget = 0.0;
    } else {
      l_matrix = Rcpp::as<arma::mat>(model["l_matrix"]);
      alpha_vec = Rcpp::as<arma::vec>(model["alpha_vec"]);
      beta_vec = Rcpp::as<arma::vec>(model["beta_vec"]);
      sigma_sq = Rcpp::as<double>(model["sigma_sq"]);
      if (contains_element_named(model, "effective_nugget")) {
        effective_nugget = Rcpp::as<double>(model["effective_nugget"]);
      }
    }
  }

  arma::vec theta = arma::exp(fi * std::log(10.0));

  arma::mat h_inv_f;
  arma::mat ft_h_inv_f_inv;
  if (use_universal_variance) {
    h_inv_f = arma::solve(
      arma::trimatu(l_matrix.t()),
      arma::solve(arma::trimatl(l_matrix), f_matrix_train)
    );

    arma::mat ft_h_inv_f = f_matrix_train.t() * h_inv_f;
    ft_h_inv_f = 0.5 * (ft_h_inv_f + ft_h_inv_f.t());

    bool m_ok = arma::inv_sympd(ft_h_inv_f_inv, ft_h_inv_f);
    if (!m_ok) {
      m_ok = arma::solve(ft_h_inv_f_inv, ft_h_inv_f, arma::eye<arma::mat>(ft_h_inv_f.n_rows, ft_h_inv_f.n_cols));
    }
    if (!m_ok || !ft_h_inv_f_inv.is_finite()) {
      if (!use_nugget && !is_regression && !has_nugget_override) {
        Rcpp::stop(
          "Deterministic GP prediction with use_nugget = FALSE failed because the no-nugget conditioning system is numerically unstable. "
          "Try prediction_control = list(use_nugget = TRUE)."
        );
      }
      Rcpp::stop("GP prediction failed because (F' H^{-1} F) is singular or ill-conditioned.");
    }
  }

  arma::vec y_predict(m, arma::fill::zeros);
  arma::vec pred_var;
  arma::mat pred_sigma_sq;

  if (indep) {
    int b = (block_size > 0) ? block_size : std::max(64, std::min(1024, m));
    int n_blocks = (m + b - 1) / b;
    int block_threads = gp_effective_num_threads(use_openmp, num_threads, n_blocks);
#ifndef _OPENMP
    (void)block_threads;
#endif
    pred_var.set_size(m);
    pred_var.zeros();
    double base_var = 1.0 + ((use_nugget && effective_nugget > 0.0) ? effective_nugget : 0.0);

#ifdef _OPENMP
#pragma omp parallel for if(block_threads > 1) schedule(dynamic) num_threads(block_threads)
#endif
    for (int bi = 0; bi < n_blocks; ++bi) {
      int start = bi * b;
      int end = std::min(start + b - 1, m - 1);
      arma::mat np_block = np.rows(start, end);
      arma::mat F_block = f_pred_matrix.rows(start, end);

      arma::mat r_block = gp_cross_corr_matrix(np_block, design, theta, false, 1);
      arma::mat Ublock = arma::solve(arma::trimatl(l_matrix), r_block.t());

      arma::vec diag_a = arma::sum(arma::square(Ublock), 0).t();
      arma::vec diag_b(diag_a.n_elem, arma::fill::zeros);
      if (use_universal_variance) {
        arma::mat rh_inv_f = r_block * h_inv_f;
        arma::mat t_block = F_block - rh_inv_f;
        arma::mat TM = t_block * ft_h_inv_f_inv;
        diag_b = arma::sum(TM % t_block, 1);
      }
      arma::vec mean_block = F_block * beta_vec + r_block * alpha_vec;
      arma::vec var_block = sigma_sq * (base_var - diag_a + diag_b);

      for (arma::uword i = 0; i < var_block.n_elem; ++i) {
        if (!std::isfinite(var_block(i))) {
          if (!use_nugget && !is_regression && !has_nugget_override) {
            Rcpp::stop(
              "GP prediction variance became numerically unstable. "
              "Try prediction_control = list(use_nugget = TRUE)."
            );
          } else {
            Rcpp::stop("GP prediction variance became numerically unstable.");
          }
        }
        var_block(i) = std::max(0.0, var_block(i));
      }

      for (int i = start; i <= end; ++i) {
        int li = i - start;
        y_predict(i) = mean_block(li);
        pred_var(i) = var_block(li);
      }
    }
  } else {
    arma::mat r_vec_hat = gp_cross_corr_matrix(np, design, theta, use_openmp, num_threads);
    arma::mat U = arma::solve(arma::trimatl(l_matrix), r_vec_hat.t());
    arma::mat t_matrix;
    arma::mat t_matrix_m;
    if (use_universal_variance) {
      arma::mat rh_inv_f = r_vec_hat * h_inv_f;
      t_matrix = f_pred_matrix - rh_inv_f;
      t_matrix_m = t_matrix * ft_h_inv_f_inv;
    }

    y_predict = f_pred_matrix * beta_vec + r_vec_hat * alpha_vec;

    int b = (block_size > 0) ? block_size : std::max(64, std::min(256, m));
    int n_blocks = (m + b - 1) / b;
    int block_threads = gp_effective_num_threads(use_openmp, num_threads, n_blocks);
#ifndef _OPENMP
    (void)block_threads;
#endif

    pred_sigma_sq.set_size(m, m);
    pred_sigma_sq.zeros();

#ifdef _OPENMP
#pragma omp parallel for if(block_threads > 1) schedule(dynamic) num_threads(block_threads)
#endif
    for (int bi = 0; bi < n_blocks; ++bi) {
      int i_start = bi * b;
      int i_end = std::min(i_start + b - 1, m - 1);

      arma::mat Xi = np.rows(i_start, i_end);
      arma::mat Ui = U.cols(i_start, i_end);
      arma::mat Ti;
      arma::mat t_i_m;
      if (use_universal_variance) {
        Ti = t_matrix.rows(i_start, i_end);
        t_i_m = t_matrix_m.rows(i_start, i_end);
      }

      for (int bj = bi; bj < n_blocks; ++bj) {
        int j_start = bj * b;
        int j_end = std::min(j_start + b - 1, m - 1);

        arma::mat Xj = np.rows(j_start, j_end);
        arma::mat Uj = U.cols(j_start, j_end);
        arma::mat Tj;
        if (use_universal_variance) {
          Tj = t_matrix.rows(j_start, j_end);
        }

        arma::mat Sblock;
        if (bi == bj) {
          Sblock = gp_self_corr_matrix(Xi, theta, use_nugget, effective_nugget, false, 1);
        } else {
          Sblock = gp_cross_corr_matrix(Xi, Xj, theta, false, 1);
        }

        arma::mat Ablock = Ui.t() * Uj;
        arma::mat Cblock;
        if (use_universal_variance) {
          arma::mat Bblock = t_i_m * Tj.t();
          Cblock = sigma_sq * (Sblock - Ablock + Bblock);
        } else {
          Cblock = sigma_sq * (Sblock - Ablock);
        }

        if (bi == bj) {
          Cblock = 0.5 * (Cblock + Cblock.t());
          for (arma::uword k = 0; k < Cblock.n_rows; ++k) {
            Cblock(k, k) = std::max(0.0, Cblock(k, k));
          }
          pred_sigma_sq.submat(i_start, i_start, i_end, i_end) = Cblock;
        } else {
          pred_sigma_sq.submat(i_start, j_start, i_end, j_end) = Cblock;
          pred_sigma_sq.submat(j_start, i_start, j_end, i_end) = Cblock.t();
        }
      }
    }

    if (!pred_sigma_sq.is_finite()) {
      if (!use_nugget && !is_regression && !has_nugget_override) {
        Rcpp::stop(
          "GP prediction covariance became numerically unstable. "
          "Try prediction_control = list(use_nugget = TRUE)."
        );
      } else {
        Rcpp::stop("GP prediction covariance became numerically unstable.");
      }
    }
  }

  if (indep) {
    return Rcpp::List::create(
      Rcpp::Named("pred_mean") = y_predict,
      Rcpp::Named("pred_var") = pred_var
    );
  }

  return Rcpp::List::create(
    Rcpp::Named("pred_mean") = y_predict,
    Rcpp::Named("pred_sigma_sq") = pred_sigma_sq
  );
}
