ctgp_corr_to_fi_range <- function(design, corr_min, corr_max) {
  design <- as.matrix(design)
  if (!is.numeric(design)) {
    stop("design must be coercible to a numeric matrix.")
  }
  if (nrow(design) < 2L) {
    stop("design must contain at least two rows.")
  }
  corr_min <- as.numeric(corr_min[[1L]])
  corr_max <- as.numeric(corr_max[[1L]])
  if (!is.finite(corr_min) || !is.finite(corr_max) || !(0 < corr_min && corr_min < corr_max && corr_max < 1)) {
    stop("corr_min and corr_max must satisfy 0 < corr_min < corr_max < 1.")
  }
  d2_max <- 0
  for (i in seq_len(nrow(design) - 1L)) {
    for (j in (i + 1L):nrow(design)) {
      d2_max <- max(d2_max, sum((design[i, , drop = FALSE] - design[j, , drop = FALSE])^2))
    }
  }
  if (!(d2_max > 0)) {
    stop("design has zero maximum pairwise squared distance; cannot derive fi range.")
  }
  lower <- log10(-log(corr_max) / d2_max)
  upper <- log10(-log(corr_min) / d2_max)
  c(lower, upper)
}

.ctgp_legacy_toy_settings <- function(prepared = NULL,
                                      design = NULL,
                                      global_corr = c(0.2, 0.8),
                                      pure_range = c(-1, 1),
                                      mixed_fi_range = c(-1, 1),
                                      mixed_theta_range = c(0, pi / 2),
                                      global_swarm_size = 32L,
                                      global_max_iter = 5L,
                                      global_seed = 10000L,
                                      pure_swarm_size = 64L,
                                      pure_max_iter = 10L,
                                      pure_seed = 10000L,
                                      mixed_swarm_size = 64L,
                                      mixed_max_iter = 10L,
                                      mixed_seed = 1000000L,
                                      bcd_loops = 3L,
                                      bcd_tol = 1e-6,
                                      use_openmp = FALSE,
                                      num_threads = 0L) {
  if (!is.null(prepared)) {
    if (!inherits(prepared, "ctgp_prepared_data")) {
      stop("prepared must be the result of ctgp_prepare_data().")
    }
    design_mat <- as.matrix(prepared$continuous_data)
  } else if (!is.null(design)) {
    design_mat <- as.matrix(design)
  } else {
    stop("Provide either `prepared` or `design`.")
  }

  global_corr <- as.numeric(global_corr)
  if (length(global_corr) != 2L) {
    stop("global_corr must be a numeric vector of length 2.")
  }

  mixed_theta_range_raw <- as.numeric(mixed_theta_range)
  mixed_theta_range <- .ctgp_prepare_theta_range_current(
    mixed_theta_range_raw,
    arg_name = 'mixed_theta_range',
    warn = FALSE
  )

  settings <- list(
    global_corr = global_corr,
    global_range = ctgp_corr_to_fi_range(design_mat, corr_min = global_corr[1L], corr_max = global_corr[2L]),
    pure_range = as.numeric(pure_range),
    mixed_fi_range = as.numeric(mixed_fi_range),
    mixed_theta_range_raw = mixed_theta_range_raw,
    mixed_theta_range = mixed_theta_range,
    optimizer_control = list(
      swarm_size = as.integer(global_swarm_size),
      max_iter = as.integer(global_max_iter),
      c1 = 2.0,
      c2 = 2.0,
      w = 0.7,
      tol = 1e-8,
      use_openmp = isTRUE(use_openmp),
      num_threads = as.integer(num_threads),
      seed = as.integer(global_seed)
    ),
    leaf_optimizer_control = list(
      swarm_size = as.integer(pure_swarm_size),
      max_iter = as.integer(pure_max_iter),
      c1 = 2.0,
      c2 = 2.0,
      w = 0.7,
      tol = 1e-8,
      use_openmp = isTRUE(use_openmp),
      num_threads = as.integer(num_threads),
      seed = as.integer(pure_seed)
    ),
    pure_optimizer_control = list(
      swarm_size = as.integer(pure_swarm_size),
      max_iter = as.integer(pure_max_iter),
      c1 = 2.0,
      c2 = 2.0,
      w = 0.7,
      tol = 1e-8,
      use_openmp = isTRUE(use_openmp),
      num_threads = as.integer(num_threads),
      seed = as.integer(pure_seed)
    ),
    mixed_optimizer_control = list(
      swarm_size = as.integer(mixed_swarm_size),
      max_iter = as.integer(mixed_max_iter),
      c1 = 2.0,
      c2 = 2.0,
      w = 0.7,
      tol = 1e-8,
      use_openmp = isTRUE(use_openmp),
      num_threads = as.integer(num_threads),
      seed = as.integer(mixed_seed)
    ),
    bcd_control = list(
      max_iter = as.integer(bcd_loops),
      tol = as.numeric(bcd_tol)
    )
  )

  settings$fit_arguments <- list(
    global_range = settings$global_range,
    optimizer_control = settings$optimizer_control,
    leaf_optimizer_control = settings$leaf_optimizer_control,
    pure_optimizer_control = settings$pure_optimizer_control,
    mixed_optimizer_control = settings$mixed_optimizer_control,
    bcd_control = settings$bcd_control,
    pure_range = settings$pure_range,
    mixed_fi_range = settings$mixed_fi_range,
    mixed_theta_range = settings$mixed_theta_range
  )

  class(settings) <- c("ctgp_legacy_toy_settings", "list")
  settings
}
