.ctgp_default_corr_bounds <- function() {
  c(0.2, 0.8)
}

.ctgp_default_corr_to_fi_range <- function(design) {
  corr <- .ctgp_default_corr_bounds()
  ctgp_corr_to_fi_range(design, corr_min = corr[1L], corr_max = corr[2L])
}
