.ctgp_toy_response <- function(x, z_1, z_2) {
  if (z_1 == 1L && z_2 == 1L) {
    cos(3.5 * pi * x) * exp(-2 * x)
  } else if (z_1 == 1L && z_2 == 2L) {
    cos(3.5 * pi * x) * exp(-0.5 * x)
  } else if (z_1 == 2L && z_2 == 1L) {
    x - 0.5
  } else {
    2 * x - 1
  }
}

.ctgp_make_toy_data <- function(seed = 10000L,
                                n_train_per_level = 6L,
                                n_test_grid = 101L,
                                use_lhs = FALSE) {
  set.seed(as.integer(seed))
  if (isTRUE(use_lhs) && requireNamespace("lhs", quietly = TRUE)) {
    x_train <- lhs::maximinLHS(as.integer(n_train_per_level), 1L, maxIter = 1000000)[, 1]
    x_train <- as.numeric(sort(x_train))
  } else {
    x_train <- seq(0.05, 0.95, length.out = as.integer(n_train_per_level))
  }
  x_test <- seq(0, 1, length.out = as.integer(n_test_grid))

  build_block <- function(x_vec, z_1, z_2) {
    y <- vapply(x_vec, function(x) .ctgp_toy_response(x, z_1 = z_1, z_2 = z_2), numeric(1))
    data.frame(
      x_1 = x_vec,
      c_1 = factor(paste0("c1.", z_1), levels = c("c1.1", "c1.2")),
      c_2 = factor(paste0("c2.", z_2), levels = c("c2.1", "c2.2")),
      y = y,
      stringsAsFactors = FALSE
    )
  }

  train <- do.call(rbind, list(
    build_block(x_train, 1L, 1L),
    build_block(x_train, 1L, 2L),
    build_block(x_train, 2L, 1L),
    build_block(x_train, 2L, 2L)
  ))
  test <- do.call(rbind, list(
    build_block(x_test, 1L, 1L),
    build_block(x_test, 1L, 2L),
    build_block(x_test, 2L, 1L),
    build_block(x_test, 2L, 2L)
  ))

  rownames(train) <- NULL
  rownames(test) <- NULL
  list(train = train, test = test)
}

.ctgp_independent_gp_predict <- function(fit_list, newdata) {
  out <- numeric(nrow(newdata))
  keys <- paste(newdata$c_1, newdata$c_2, sep = "||")
  for (key in names(fit_list)) {
    idx <- which(keys == key)
    if (length(idx) == 0L) next
    pred <- predict_gp(fit_list[[key]], newdata = as.matrix(newdata[idx, "x_1", drop = FALSE]), indep = TRUE)
    out[idx] <- as.numeric(pred$pred_mean)
  }
  out
}


ctgp_example <- function(seed = 10000L,
                         n_train_per_level = 6L,
                         n_test_grid = 101L,
                         quick = TRUE,
                         show_plot = FALSE,
                         use_lhs = FALSE,
                         comparison_mode = c("paper_like", "same_range_controlled"),
                         gp_range = c(-1, 1),
                         qq_fi_range = c(-1, 1),
                         qq_theta_range = c(0, pi / 2),
                         ctgp_global_corr = NULL,
                         ctgp_tau_matrix_source = "none",
                         nugget = sqrt(.Machine$double.eps),
                         use_legacy_optimizer_controls = TRUE) {
  comparison_mode <- match.arg(comparison_mode)
  ctgp_tau_matrix_source <- match.arg(ctgp_tau_matrix_source, choices = c("none", "stage"))
  if (is.null(ctgp_global_corr)) {
    ctgp_global_corr <- if (identical(comparison_mode, "paper_like")) c(0.2, 0.8) else .ctgp_default_corr_bounds()
  }
  ctgp_global_corr <- as.numeric(ctgp_global_corr)
  qq_theta_range_requested <- as.numeric(qq_theta_range)
  qq_theta_range_used <- .ctgp_prepare_theta_range_current(
    qq_theta_range_requested,
    arg_name = 'qq_theta_range',
    warn = FALSE
  )

  toy <- .ctgp_make_toy_data(
    seed = seed,
    n_train_per_level = n_train_per_level,
    n_test_grid = n_test_grid,
    use_lhs = use_lhs
  )
  train <- toy$train
  test <- toy$test
  prep <- ctgp_prepare_data(data = train, design = "x_1", response = "y", qualitative = c("c_1", "c_2"))

  if (isTRUE(use_legacy_optimizer_controls)) {
    legacy_settings <- .ctgp_legacy_toy_settings(
      prepared = prep,
      global_corr = ctgp_global_corr,
      pure_range = gp_range,
      mixed_fi_range = qq_fi_range,
      mixed_theta_range = qq_theta_range,
      use_openmp = FALSE,
      num_threads = 0L
    )
    gp_control <- legacy_settings$pure_optimizer_control
    qq_control <- legacy_settings$mixed_optimizer_control
    ctgp_global_control <- legacy_settings$optimizer_control
    ctgp_pure_control <- legacy_settings$pure_optimizer_control
    ctgp_mixed_control <- legacy_settings$mixed_optimizer_control
    global_range <- legacy_settings$global_range
    pure_range <- legacy_settings$pure_range
    mixed_fi_range <- legacy_settings$mixed_fi_range
    mixed_theta_range <- legacy_settings$mixed_theta_range
  } else {
    legacy_settings <- .ctgp_legacy_toy_settings(
      prepared = prep,
      global_corr = ctgp_global_corr,
      pure_range = gp_range,
      mixed_fi_range = qq_fi_range,
      mixed_theta_range = qq_theta_range,
      use_openmp = TRUE,
      num_threads = 0L
    )
    gp_control <- list(swarm_size = if (quick) 24L else 64L, max_iter = if (quick) 12L else 60L, seed = as.integer(seed), use_openmp = TRUE)
    qq_control <- list(swarm_size = if (quick) 24L else 64L, max_iter = if (quick) 12L else 60L, seed = as.integer(seed) + 1L, use_openmp = TRUE)
    ctgp_global_control <- gp_control
    ctgp_pure_control <- qq_control
    ctgp_mixed_control <- qq_control
    global_range <- ctgp_corr_to_fi_range(prep$continuous_data, corr_min = ctgp_global_corr[1L], corr_max = ctgp_global_corr[2L])
    pure_range <- gp_range
    mixed_fi_range <- qq_fi_range
    mixed_theta_range <- qq_theta_range_used
  }

  if (identical(comparison_mode, "paper_like")) {
    standalone_gp_range <- NULL
    standalone_qqgp_fi_range <- NULL
    standalone_qqgp_theta_range <- NULL
  } else {
    standalone_gp_range <- pure_range
    standalone_qqgp_fi_range <- mixed_fi_range
    standalone_qqgp_theta_range <- mixed_theta_range
  }

  gp_keys <- unique(paste(train$c_1, train$c_2, sep = "||"))
  gp_fits <- setNames(vector("list", length(gp_keys)), gp_keys)
  gp_fit_time <- system.time({
    for (key in gp_keys) {
      idx <- which(paste(train$c_1, train$c_2, sep = "||") == key)
      gp_dat <- cbind(x_1 = train$x_1[idx], y = train$y[idx])
      fit_args <- list(data = gp_dat, optimizer_control = gp_control)
      if (!is.null(standalone_gp_range)) {
        fit_args$range <- standalone_gp_range
      }
      gp_fits[[key]] <- do.call(fit_gp, fit_args)
    }
  })[3L]
  gp_pred <- NULL
  gp_pred_time <- system.time({
    gp_pred <- .ctgp_independent_gp_predict(gp_fits, test)
  })[3L]
  gp_rmse <- sqrt(mean((gp_pred - test$y)^2))

  qq_all <- coerce_fun(
    data = rbind(train, test),
    design = rbind(train["x_1"], test["x_1"]),
    include_sub_cate = TRUE
  )
  qq_train <- qq_all[seq_len(nrow(train)), , drop = FALSE]
  qq_test <- qq_all[nrow(train) + seq_len(nrow(test)), , drop = FALSE]

  qq_fit <- NULL
  qq_fit_time <- system.time({
    fit_args <- list(
      design = qq_train["x_1"],
      data = qq_train,
      optimizer_control = qq_control
    )
    if (!is.null(standalone_qqgp_fi_range)) {
      fit_args$fi_range <- standalone_qqgp_fi_range
    }
    if (!is.null(standalone_qqgp_theta_range)) {
      fit_args$theta_range <- standalone_qqgp_theta_range
    }
    qq_fit <- do.call(fit_qqgp, fit_args)
  })[3L]
  qq_pred <- NULL
  qq_pred_time <- system.time({
    qq_pred <- predict_qqgp(
      qq_fit,
      newdata = qq_test[, c("x_1", "c.T"), drop = FALSE],
      indep = TRUE
    )
  })[3L]
  qq_rmse <- sqrt(mean((as.numeric(qq_pred$pred_mean) - test$y)^2))

  ctgp_fit <- NULL
  ctgp_fit_time <- system.time({
    ctgp_fit <- fit_ctgp(
      prep,
      global_range = global_range,
      nugget = nugget,
      pure_range = pure_range,
      mixed_fi_range = mixed_fi_range,
      mixed_theta_range = mixed_theta_range,
      tau_matrix_source = ctgp_tau_matrix_source,
      optimizer_control = ctgp_global_control,
      leaf_optimizer_control = ctgp_pure_control,
      pure_optimizer_control = ctgp_pure_control,
      mixed_optimizer_control = ctgp_mixed_control,
      bcd_control = legacy_settings$bcd_control,
      use_openmp = isTRUE(ctgp_global_control$use_openmp),
      num_threads = ctgp_global_control$num_threads
    )
  })[3L]
  ctgp_pred <- NULL
  ctgp_pred_time <- system.time({
    ctgp_pred <- predict_ctgp(ctgp_fit, newdata = test, indep = TRUE)
  })[3L]
  ctgp_rmse <- sqrt(mean((as.numeric(ctgp_pred$pred_mean) - test$y)^2))

  exact_two_leaf_match <- .ctgp_grouping_matches(
    .ctgp_collect_leaf_groups(ctgp_fit$final_tree),
    list(c(1L, 2L), c(3L, 4L))
  )
  root_group_match <- .ctgp_toy_root_groups_match_curve_line(ctgp_fit$final_tree, prep)
  curve_line_separated <- .ctgp_toy_leaf_groups_separated_curve_line(ctgp_fit$final_tree, prep)

  comparison <- data.frame(
    model = c("independent_gp", "one_qqgp", "one_ctgp"),
    fit_time = c(gp_fit_time, qq_fit_time, ctgp_fit_time),
    pred_time = c(gp_pred_time, qq_pred_time, ctgp_pred_time),
    rmse = c(gp_rmse, qq_rmse, ctgp_rmse),
    fi_mean = c(NA_real_, NA_real_, mean(as.numeric(ctgp_fit$stage$bcd$fi))),
    stringsAsFactors = FALSE
  )

  tree_plot <- NULL
  if (isTRUE(show_plot)) {
    tree_plot <- plot_ctgp_tree(ctgp_fit$final_tree, loocv_values = attr(ctgp_fit$final_tree, "loocv_summary", exact = TRUE))
  }

  package_default_range <- .ctgp_default_corr_to_fi_range(prep$continuous_data)

  out <- list(
    train = train,
    test = test,
    prepared = prep,
    comparison_mode = comparison_mode,
    global_range = global_range,
    legacy_settings = legacy_settings,
    range_settings = list(
      comparison_mode = comparison_mode,
      package_default_corr_bounds = .ctgp_default_corr_bounds(),
      ctgp_leaf_gp_range = gp_range,
      ctgp_leaf_qq_fi_range = qq_fi_range,
      ctgp_leaf_qq_theta_range = mixed_theta_range,
      ctgp_leaf_qq_theta_range_requested = qq_theta_range_requested,
      ctgp_leaf_qq_theta_range_used = mixed_theta_range,
      ctgp_global_corr = ctgp_global_corr,
      ctgp_global_range_used = legacy_settings$global_range,
      standalone_gp_range_mode = if (identical(comparison_mode, "paper_like")) "package_default_0.1_0.9" else "same_as_ctgp_leaf",
      standalone_gp_range_used = if (identical(comparison_mode, "paper_like")) package_default_range else gp_range,
      standalone_qqgp_fi_range_mode = if (identical(comparison_mode, "paper_like")) "package_default_0.1_0.9" else "same_as_ctgp_leaf",
      standalone_qqgp_fi_range_used = if (identical(comparison_mode, "paper_like")) package_default_range else qq_fi_range,
      standalone_qqgp_theta_range_mode = if (identical(comparison_mode, "paper_like")) "package_default_backend" else "same_as_ctgp_leaf",
      ctgp_tau_matrix_source = ctgp_tau_matrix_source,
      nugget = as.numeric(nugget),
      use_legacy_optimizer_controls = isTRUE(use_legacy_optimizer_controls)
    ),
    legacy_theta_range_requested = qq_theta_range_requested,
    legacy_theta_range = legacy_settings$mixed_theta_range,
    independent_gp_fits = gp_fits,
    qqgp_fit = qq_fit,
    qqgp_level_key = attr(qq_all, "level_key"),
    ctgp_fit = ctgp_fit,
    ctgp_groups = .ctgp_collect_leaf_groups(ctgp_fit$final_tree),
    expected_grouping = list(curves = c(1L, 2L), lines = c(3L, 4L)),
    expected_grouping_match = exact_two_leaf_match,
    group_diagnostics = list(
      exact_two_leaf_match = exact_two_leaf_match,
      root_group_match = root_group_match,
      curve_line_separated = curve_line_separated
    ),
    comparison = comparison,
    tree_plot = tree_plot
  )
  class(out) <- c("ctgp_example", "list")
  out
}
