.ctgp_gp_beta_names <- function(object) {
  terms <- NULL

  if (!is.null(object$mean_terms)) {
    terms <- object$mean_terms
  } else if (!is.null(object$f_matrix) && !is.null(colnames(object$f_matrix))) {
    terms <- colnames(object$f_matrix)
  } else if (!is.null(rownames(object$beta_vec))) {
    terms <- rownames(object$beta_vec)
  }

  if (is.null(terms) || length(terms) != length(object$beta_vec)) {
    terms <- paste0("beta[", seq_along(object$beta_vec), "]")
  }

  terms
}

.ctgp_gp_mean_source <- function(object) {
  if (!is.null(object$mean_source)) {
    as.character(object$mean_source)
  } else if (!is.null(object$f_matrix) && is.matrix(object$f_matrix) &&
             ncol(object$f_matrix) == 1L && all(abs(object$f_matrix[, 1] - 1) < 1e-12)) {
    "default"
  } else {
    "unknown"
  }
}

.ctgp_gp_mean_structure <- function(object) {
  if (!is.null(object$mean_structure)) {
    as.character(object$mean_structure)
  } else {
    "formula: ~1"
  }
}

#' @export
print.gp_fit <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("GP fit object\n\n")

  data <- x$data
  n <- if (!is.null(data)) nrow(data) else NA_integer_
  p <- if (!is.null(data)) ncol(data) - 1L else NA_integer_
  mean_structure <- .ctgp_gp_mean_structure(x)
  mean_terms <- .ctgp_gp_beta_names(x)

  cat("Data:\n")
  cat("  Number of observations :", n, "\n")
  cat("  Input dimension        :", p, "\n")
  if (!is.null(x$x_colnames_used)) {
    cat("  Input names            :", paste(x$x_colnames_used, collapse = ", "), "\n")
  }
  cat("\n")

  cat("Model:\n")
  cat("  Mean structure         :", mean_structure, "\n")
  if (!is.null(x$mean_formula)) {
    cat("  Mean formula           :", x$mean_formula, "\n")
  }
  cat("  Mean terms             :", paste(mean_terms, collapse = ", "), "\n")
  cat("  Correlation            : exp(-sum_j 10^fi_j (x_j - x'_j)^2)\n\n")

  cat("Estimated parameters:\n")
  cat(
    "  fi                     :",
    paste(formatC(as.numeric(x$fi), digits = digits, format = "fg"), collapse = ", "),
    "\n"
  )

  if (length(x$beta_vec) == 1L) {
    cat(
      "  beta                   :",
      formatC(as.numeric(x$beta_vec), digits = digits, format = "fg"),
      "\n"
    )
  } else {
    cat("  beta_vec                :\n")
    beta_df <- data.frame(
      term = mean_terms,
      estimate = formatC(as.numeric(x$beta_vec), digits = digits, format = "fg"),
      stringsAsFactors = FALSE
    )
    print(beta_df, row.names = FALSE, right = FALSE)
  }

  cat(
    "  sigma_sq                :",
    formatC(as.numeric(x$sigma_sq), digits = digits, format = "fg"),
    "\n"
  )
  cat("  nugget provided        :", x$nugget_provided, "\n")
  cat(
    "  input nugget           :",
    formatC(as.numeric(x$nugget), digits = digits, format = "fg"),
    "\n"
  )
  cat(
    "  effective nugget       :",
    formatC(as.numeric(x$effective_nugget), digits = digits, format = "fg"),
    "\n\n"
  )

  cat("Optimization:\n")
  cat("  converged              :", x$optim_converged, "\n")
  cat(
    "  objective value        :",
    formatC(as.numeric(x$optim_best_value), digits = digits, format = "fg"),
    "\n"
  )
  cat(
    "  final neg_log_lik        :",
    formatC(as.numeric(x$neg_log_lik), digits = digits, format = "fg"),
    "\n"
  )
  cat("  function evaluations   :", x$optim_n_eval, "\n")

  if (!is.null(x$optimizer_control)) {
    control <- x$optimizer_control
    cat("\nOptimizer control:\n")
    cat("  swarm_size             :", control$swarm_size, "\n")
    cat("  max_iter               :", control$max_iter, "\n")
    cat("  c1                     :", formatC(control$c1, digits = digits, format = "fg"), "\n")
    cat("  c2                     :", formatC(control$c2, digits = digits, format = "fg"), "\n")
    cat("  w                      :", formatC(control$w, digits = digits, format = "fg"), "\n")
    cat("  tol                    :", formatC(control$tol, digits = digits, format = "fg"), "\n")
    cat("  use_openmp             :", control$use_openmp, "\n")
    cat("  num_threads            :", control$num_threads, "\n")
    if (!is.null(control$seed)) {
      cat("  seed                   :", control$seed, "\n")
    }
  }

  if (!is.null(x$omp)) {
    omp <- x$omp
    cat("\nParallel:\n")
    cat("  OpenMP compiled        :", omp$compiled, "\n")
    cat("  OpenMP enabled         :", omp$use_openmp, "\n")
    cat("  threads requested      :", omp$num_threads_requested, "\n")
    cat("  runtime max threads    :", omp$num_threads_runtime_max, "\n")
  }

  if (!is.null(x$timing)) {
    cat("\nTiming:\n")
    cat(
      "  elapsed                :",
      formatC(as.numeric(x$timing$elapsed), digits = digits, format = "fg"),
      "seconds\n"
    )
    if (!is.null(x$timing$user_self)) {
      cat(
        "  user_self              :",
        formatC(as.numeric(x$timing$user_self), digits = digits, format = "fg"),
        "seconds\n"
      )
    }
    if (!is.null(x$timing$sys_self)) {
      cat(
        "  sys_self               :",
        formatC(as.numeric(x$timing$sys_self), digits = digits, format = "fg"),
        "seconds\n"
      )
    }
  }

  invisible(x)
}

#' @export
summary.gp_fit <- function(object, ...) {
  data <- object$data
  n <- if (!is.null(data)) nrow(data) else NA_integer_
  p <- if (!is.null(data)) ncol(data) - 1L else NA_integer_

  out <- list(
    call = match.call(),
    n = n,
    p = p,
    x_colnames_used = object$x_colnames_used,
    mean_source = .ctgp_gp_mean_source(object),
    mean_structure = .ctgp_gp_mean_structure(object),
    mean_formula = object$mean_formula,
    mean_terms = .ctgp_gp_beta_names(object),
    fi = object$fi,
    beta_vec = as.numeric(object$beta_vec),
    sigma_sq = object$sigma_sq,
    nugget = object$nugget,
    nugget_provided = object$nugget_provided,
    effective_nugget = object$effective_nugget,
    neg_log_lik = object$neg_log_lik,
    optim_best_value = object$optim_best_value,
    optim_converged = object$optim_converged,
    optim_n_eval = object$optim_n_eval,
    lower = object$lower,
    upper = object$upper,
    init_param = object$init_param,
    timing = object$timing,
    optimizer_control = object$optimizer_control,
    omp = object$omp
  )

  class(out) <- "summary.gp_fit"
  out
}

#' @export
print.summary.gp_fit <- function(x,
                                 digits = max(3L, getOption("digits") - 2L),
                                 ...) {
  cat("Summary of GP fit\n\n")

  cat("Data:\n")
  cat("  Number of observations :", x$n, "\n")
  cat("  Input dimension        :", x$p, "\n")
  if (!is.null(x$x_colnames_used)) {
    cat("  Input names            :", paste(x$x_colnames_used, collapse = ", "), "\n")
  }
  cat("\n")

  cat("Model:\n")
  cat("  Mean source            :", x$mean_source, "\n")
  cat("  Mean structure         :", x$mean_structure, "\n")
  if (!is.null(x$mean_formula)) {
    cat("  Mean formula           :", x$mean_formula, "\n")
  }
  cat("  Mean terms             :", paste(x$mean_terms, collapse = ", "), "\n\n")

  cat("Parameter estimates:\n")
  fi_df <- data.frame(
    parameter = paste0("fi[", seq_along(x$fi), "]"),
    estimate = as.numeric(x$fi)
  )
  print(fi_df, row.names = FALSE, digits = digits)
  cat("\n")

  cat("Mean parameters:\n")
  beta_df <- data.frame(
    parameter = x$mean_terms,
    estimate = as.numeric(x$beta_vec)
  )
  print(beta_df, row.names = FALSE, digits = digits)
  cat("\n")

  cat("Nugget setting:\n")
  cat("  nugget provided        :", x$nugget_provided, "\n\n")

  cat("Other estimates:\n")
  other_df <- data.frame(
    quantity = c(
      "sigma_sq",
      "input nugget",
      "effective nugget",
      "neg_log_lik",
      "optim objective"
    ),
    value = c(
      x$sigma_sq,
      x$nugget,
      x$effective_nugget,
      x$neg_log_lik,
      x$optim_best_value
    )
  )
  print(other_df, row.names = FALSE, digits = digits)
  cat("\n")

  cat("Optimization status:\n")
  cat("  converged              :", x$optim_converged, "\n")
  cat("  function evaluations   :", x$optim_n_eval, "\n")

  if (!is.null(x$optimizer_control)) {
    control <- x$optimizer_control
    cat("\nOptimizer control:\n")
    settings <- c("swarm_size", "max_iter", "c1", "c2", "w", "tol", "use_openmp", "num_threads")
    values <- list(control$swarm_size, control$max_iter, control$c1, control$c2,
                   control$w, control$tol, control$use_openmp, control$num_threads)
    if (!is.null(control$seed)) {
      settings <- c(settings, "seed")
      values <- c(values, list(control$seed))
    }
    control_df <- data.frame(
      setting = settings,
      value = vapply(values, function(v) paste(v, collapse = ", "), character(1)),
      stringsAsFactors = FALSE
    )
    print(control_df, row.names = FALSE, right = FALSE)
  }

  if (!is.null(x$omp)) {
    omp <- x$omp
    cat("\nParallel:\n")
    omp_df <- data.frame(
      setting = c("OpenMP compiled", "OpenMP enabled", "threads requested", "runtime max threads"),
      value = c(omp$compiled, omp$use_openmp, omp$num_threads_requested, omp$num_threads_runtime_max),
      stringsAsFactors = FALSE
    )
    print(omp_df, row.names = FALSE, right = FALSE)
  }

  if (!is.null(x$timing)) {
    cat("\nTiming:\n")
    cat(
      "  elapsed                :",
      formatC(as.numeric(x$timing$elapsed), digits = digits, format = "fg"),
      "seconds\n"
    )
    if (!is.null(x$timing$user_self)) {
      cat(
        "  user_self              :",
        formatC(as.numeric(x$timing$user_self), digits = digits, format = "fg"),
        "seconds\n"
      )
    }
    if (!is.null(x$timing$sys_self)) {
      cat(
        "  sys_self               :",
        formatC(as.numeric(x$timing$sys_self), digits = digits, format = "fg"),
        "seconds\n"
      )
    }
  }

  cat("\nSearch bounds:\n")
  bounds_df <- data.frame(
    parameter = paste0("fi[", seq_along(x$lower), "]"),
    lower = as.numeric(x$lower),
    init = as.numeric(x$init_param),
    upper = as.numeric(x$upper)
  )
  print(bounds_df, row.names = FALSE, digits = digits)

  invisible(x)
}

#' @export
coef.gp_fit <- function(object, ...) {
  fi_part <- as.numeric(object$fi)
  names(fi_part) <- paste0("fi[", seq_along(object$fi), "]")

  beta_part <- as.numeric(object$beta_vec)
  names(beta_part) <- .ctgp_gp_beta_names(object)

  extra_part <- c(
    sigma_sq = as.numeric(object$sigma_sq),
    nugget = as.numeric(object$nugget),
    effective_nugget = as.numeric(object$effective_nugget)
  )

  c(fi_part, beta_part, extra_part)
}

#' @export
fitted.gp_fit <- function(object, ...) {
  data <- as.matrix(object$data)

  if (ncol(data) < 2L) {
    stop("object$data does not have the expected structure.")
  }

  x_train <- data[, seq_len(ncol(data) - 1L), drop = FALSE]
  FPred <- NULL
  if (.ctgp_gp_mean_source(object) == "f_matrix") {
    FPred <- object$f_matrix
  }

  pred <- predict_gp(object, x_train, f_matrix = FPred, indep = TRUE)
  as.numeric(pred$pred_mean)
}

#' @export
residuals.gp_fit <- function(object, ...) {
  data <- as.matrix(object$data)

  if (ncol(data) < 2L) {
    stop("object$data does not have the expected structure.")
  }

  y <- data[, ncol(data)]
  y - fitted(object)
}
