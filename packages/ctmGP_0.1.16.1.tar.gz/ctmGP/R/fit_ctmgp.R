# ctmGP — categorical-tree multi-output GP (paper §2.2 + §4.3 ctmGP).
#
# fit_ctmgp = thin wrapper: long-format the MO data + add response_id as an
# extra qualitative column → fit_ctgp.  predict_ctmgp = the inverse: tile the
# new (x, w) candidates T times along response_id, call predict_ctgp with
# indep=FALSE to get the joint within-leaf covariance, then reshape into the
# canonical (mu, sigma_per_cand, blocks) triple consumed by acq_ehvi/acq_eim.

#' Fit a category-tree multivariate GP (ctmGP) on multi-output data.
#'
#' @param data data.frame containing all relevant columns; or NULL if you pass
#'   X_mat / W_mat / Y_mat directly.
#' @param x_cols character vector; names of continuous columns.
#' @param w_cols character vector; names of categorical columns (may be empty).
#' @param y_cols character vector of length T (≥ 2); names of response columns.
#' @param X_mat,W_mat,Y_mat optional matrices when `data` is NULL.
#' @param response_id_name name for the synthesized response indicator
#'   categorical column.  Defaults to `"response_id"`.
#' @param ... passed to `fit_ctgp()` (e.g. `bcd_control`, `optimizer_control`,
#'   `prune_tol`, `nugget`, `max_depth`, ...).
#' @return list of class `ctmgp_fit` extending `ctgp_fit` with extra `mo_meta`.
#' @export
fit_ctmgp <- function(data = NULL,
                      x_cols = NULL,
                      w_cols = NULL,
                      y_cols = NULL,
                      X_mat = NULL,
                      W_mat = NULL,
                      Y_mat = NULL,
                      response_id_name = "response_id",
                      ...) {
  long <- mo_to_long_format(
    data = data, x_cols = x_cols, w_cols = w_cols, y_cols = y_cols,
    X_mat = X_mat, W_mat = W_mat, Y_mat = Y_mat,
    response_id_name = response_id_name, response_value_name = "y"
  )
  meta <- attr(long, "mo_meta")

  t_start <- proc.time()
  fit <- fit_ctgp(
    data = long,
    quantitative = meta$x_cols,
    qualitative  = c(meta$w_cols, meta$response_id_name),
    response     = meta$response_value_name,
    ...
  )
  elapsed <- proc.time() - t_start

  fit$mo_meta <- meta
  fit$timing_ctmgp <- list(
    wall_sec = unname(elapsed["elapsed"]),
    cpu_sec  = unname(elapsed["user.self"] + elapsed["sys.self"])
  )
  class(fit) <- c("ctmgp_fit", class(fit))
  fit
}

#' Predict from a fitted ctmGP.
#'
#' For each row of `newdata` (an (x, w) tuple), returns the multivariate-normal
#' joint predictive distribution over the T outputs.  The covariance comes from
#' the leaf-aware kriging cross-covariance: outputs assigned to the same leaf
#' share the within-leaf joint Σ block; cross-leaf entries are exactly 0.
#'
#' Use `block_indices = list(seq_len(T))` when feeding the returned `sigma`
#' into `acq_ehvi()` — the engine's auto-mode dispatcher will detect the
#' (per-candidate) block structure via Union-Find on the σ sparsity pattern.
#'
#' @param fit `ctmgp_fit` from `fit_ctmgp()`.
#' @param newdata data.frame with columns matching `mo_meta$x_cols` and
#'   `mo_meta$w_cols` (no response columns required).
#' @param joint logical; if TRUE return per-candidate T×T sigma list, if FALSE
#'   return only T × n marginal sd matrix.
#' @param ... passed to underlying `predict_ctgp()` (e.g. `prediction_control`).
#' @return list with `mu` (T × n_new), `sigma` (list of n_new T×T) if joint,
#'   `sigma_marginal` (T × n_new), `blocks = list(seq_len(T))`,
#'   `leaf_assignment` (T × n_new integer matrix of leaf node ids), `timing`.
#' @export
predict_ctmgp <- function(fit, newdata, joint = TRUE, ...) {
  if (!inherits(fit, "ctmgp_fit"))
    stop("fit must be a ctmgp_fit object (from fit_ctmgp).")
  meta <- fit$mo_meta
  if (is.null(meta)) stop("fit is missing mo_meta — was it really from fit_ctmgp?")

  newdata <- as.data.frame(newdata, stringsAsFactors = FALSE,
                            check.names = FALSE)
  required <- c(meta$x_cols, meta$w_cols)
  miss <- setdiff(required, names(newdata))
  if (length(miss)) stop("newdata missing columns: ", paste(miss, collapse=", "), ".")
  n_new <- nrow(newdata); T_ <- meta$T

  # Tile newdata T times, append response_id factor (must use the SAME levels
  # as the fit — order matters for the joint level encoding inside ctGP).
  long_new <- newdata[rep(seq_len(n_new), times = T_), required, drop = FALSE]
  rid <- factor(rep(meta$response_id_levels, each = n_new),
                 levels = meta$response_id_levels)
  long_new[[meta$response_id_name]] <- rid

  t_start <- proc.time()
  pr <- predict_ctgp(fit, newdata = long_new, indep = FALSE,
                     return_leaf_assignment = TRUE, ...)
  elapsed <- proc.time() - t_start

  # pr$pred_mean: length nT; pr$pred_sigma_sq: nT × nT (block-zero across leaves)
  # Long-format row index for (candidate c, response l): (l-1)*n_new + c
  mu_T <- matrix(pr$pred_mean, nrow = n_new, ncol = T_)   # n_new × T
  mu_T <- t(mu_T)                                          # T × n_new
  var_T <- matrix(pr$pred_var, nrow = n_new, ncol = T_)
  var_T[var_T < 0] <- 0     # avoid pmax(0, matrix) which drops dim in base R
  sd_T <- t(sqrt(var_T))     # T × n_new

  sigma_list <- NULL
  if (isTRUE(joint)) {
    sigma_list <- vector("list", n_new)
    Sfull <- pr$pred_sigma_sq
    for (c in seq_len(n_new)) {
      idx <- (seq_len(T_) - 1L) * n_new + c
      sigma_list[[c]] <- Sfull[idx, idx, drop = FALSE]
    }
    # Project each block to PSD; kriging drift on small leaves can produce
    # marginally indefinite blocks that break engine Cholesky.
    sigma_list <- .psd_project_list(sigma_list)
  }

  leaf_T <- matrix(pr$leaf_node_id, nrow = n_new, ncol = T_)  # n_new × T
  leaf_T <- t(leaf_T)                                          # T × n_new

  list(
    mu              = mu_T,
    sigma           = sigma_list,
    sigma_marginal  = sd_T,
    blocks          = list(seq_len(T_)),
    leaf_assignment = leaf_T,
    timing          = list(
      wall_sec = unname(elapsed["elapsed"]),
      cpu_sec  = unname(elapsed["user.self"] + elapsed["sys.self"])
    )
  )
}
