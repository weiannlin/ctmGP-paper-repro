#ifndef QQGP_MODEL_H
#define QQGP_MODEL_H

#include <RcppArmadillo.h>
#include <limits>
#include "objective_base.h"

// 與 gp_model.cpp 中相同的 helper；QQGP 這邊直接重用同一個概念
// 注意：不要在這裡重複給 default argument
double compute_nugget_from_eigen(
    const arma::mat& H,
    double max_cond
);

enum qqgp_objective_mode_code {
  QQGP_OBJECTIVE_STABLE = 0,
  QQGP_OBJECTIVE_LEGACY_EXACT = 1
};

// ----------------------------------------------------
// 用來存放 QQGP profile likelihood 中間結果
// ----------------------------------------------------
struct qqgp_profile_result {
  arma::mat h_matrix;      // continuous correlation
  arma::mat t_matrix;      // categorical correlation
  arma::mat r_matrix;      // whole-data correlation

  // 保留 inverse 給 C++ 內部研究/比較用途
  arma::mat r_inv;

  // 正式 prediction 路徑主要使用的量
  arma::mat l_matrix;      // Cholesky factor of r_matrix
  arma::vec alpha_vec;     // R^{-1}(y - F beta)

  arma::mat f_matrix;
  arma::vec beta_vec;

  double sigma_sq;
  double neg_log_lik;
  double effective_nugget;
  double raw_rcond;
  bool nugget_added;
  int objective_mode;

  bool success;

  qqgp_profile_result()
    : sigma_sq(arma::datum::inf),
      neg_log_lik(arma::datum::inf),
      effective_nugget(0.0),
      raw_rcond(arma::datum::nan),
      nugget_added(false),
      objective_mode(QQGP_OBJECTIVE_STABLE),
      success(false) {}
};

// ----------------------------------------------------
// Helper builders
// ----------------------------------------------------

// H_ij = exp( - sum_k 10^{fi_k} (x_ik - x_jk)^2 )
arma::mat qqgp_build_h_matrix(
    const arma::mat& design,
    const arma::vec& fi
);

// sphere decomposition -> T matrix
// theta 長度必須為 choose(level_num, 2)
arma::mat qqgp_build_t_matrix(
    const arma::vec& theta,
    int level_num
);

// whole-data correlation matrix
arma::mat qqgp_build_r_matrix(
    const arma::mat& h_matrix,
    const arma::mat& t_matrix,
    const arma::uvec& level_index
);

// 預設 treatment-style mean design matrix
// 第 1 欄永遠是 intercept，其餘欄位對應 level 2, ..., level_num
arma::mat qqgp_build_f_matrix(
    const arma::uvec& level_index,
    int level_num
);

// default bounds
// fi: based on corr in [0.1, 0.9]
// theta: default in [eps, pi - eps], eps = 1e-6
Rcpp::List qqgp_default_bounds(
    const arma::mat& design,
    int level_num,
    double theta_low = 1e-6,
    double theta_upp = arma::datum::pi - 1e-6
);

// ----------------------------------------------------
// Profile fit
//
// 規則與目前 GP 相同：
// 1. nugget_provided = false
//    -> 若 rcond 很差，才自動 compute_nug
//
// 2. nugget_provided = true 且 nugget == 0
//    -> 完全不補；若分解失敗就直接 fail
//
// 3. nugget_provided = true 且 nugget > 0
//    -> 只有在 rcond 很差時，才實際加上使用者給的 nugget
// ----------------------------------------------------

// 情況 A：T matrix 也要一起估（theta 為參數的一部分）
qqgp_profile_result qqgp_profile_fit(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::vec& theta,
    const arma::mat& f_matrix,
    double nugget = 0.0,
    bool nugget_provided = false,
    int objective_mode = QQGP_OBJECTIVE_STABLE
);

// 情況 B：T matrix 已固定，僅估 fi
qqgp_profile_result qqgp_profile_fit_fixed_t(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& t_matrix,
    const arma::mat& f_matrix,
    double nugget = 0.0,
    bool nugget_provided = false,
    int objective_mode = QQGP_OBJECTIVE_STABLE
);

// ----------------------------------------------------
// Objective class
// ----------------------------------------------------
class qqgp_likelihood_objective : public objective_base {
private:
  arma::mat design_;
  arma::uvec level_index_;
  arma::vec y_;
  int level_num_;
  arma::mat f_matrix_;

  double nugget_;
  bool nugget_provided_;

  bool fixed_t_;
  arma::mat fixed_t_matrix_;
  int objective_mode_;

public:
  // 情況 A：theta 要一起估
  qqgp_likelihood_objective(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    int level_num,
    const arma::mat& f_matrix,
    double nugget = 0.0,
    bool nugget_provided = false,
    int objective_mode = QQGP_OBJECTIVE_STABLE
  )
    : design_(design),
      level_index_(level_index),
      y_(y),
      level_num_(level_num),
      f_matrix_(f_matrix),
      nugget_(nugget),
      nugget_provided_(nugget_provided),
      fixed_t_(false),
      objective_mode_(objective_mode) {}

  // 情況 B：T matrix 固定
  qqgp_likelihood_objective(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    int level_num,
    const arma::mat& f_matrix,
    const arma::mat& fixed_t_matrix,
    double nugget = 0.0,
    bool nugget_provided = false,
    int objective_mode = QQGP_OBJECTIVE_STABLE
  )
    : design_(design),
      level_index_(level_index),
      y_(y),
      level_num_(level_num),
      f_matrix_(f_matrix),
      nugget_(nugget),
      nugget_provided_(nugget_provided),
      fixed_t_(true),
      fixed_t_matrix_(fixed_t_matrix),
      objective_mode_(objective_mode) {}

  double eval(const arma::vec& par) override;
};

// ----------------------------------------------------
// Prediction
//
// new_point 的格式預期為：
// - 前 conti_dim 欄：continuous x
// - 最後 1 欄：categorical level index (1, 2, ..., level_num)
//
// generic mean 時由 R wrapper 建立對應的 f_pred_matrix 傳入。
Rcpp::List qqgp_predict_from_fit(
    const Rcpp::List& model,
    SEXP new_point_sexp,
    const arma::mat& f_pred_matrix,
    bool indep = false,
    bool use_nugget = true,
    bool use_openmp = true,
    int num_threads = 0,
    int block_size = 0,
    bool has_nugget_override = false,
    double nugget_override = 0.0,
    bool use_universal_variance = true
);

#endif
