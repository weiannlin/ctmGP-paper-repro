plot_gp_1d <- function(model,
                       x_grid = NULL,
                       n_grid = 400,
                       level = 0.95,
                       smooth_band = FALSE,
                       smooth_band_spar = 0.55,
                       prediction_data = NULL,
                       title = "Gaussian Process Fit",
                       subtitle = NULL,
                       xlab = NULL,
                       ylab = NULL) {
  data <- as.matrix(model$data)
  
  if (ncol(data) != 2) {
    stop("plot_gp_1d() currently supports only 1D input.")
  }
  
  storage.mode(data) <- "double"
  
  x_train <- data[, 1]
  y_train <- data[, 2]
  
  if (is.null(xlab)) {
    xlab <- colnames(data)[1]
    if (is.null(xlab) || identical(xlab, "")) {
      xlab <- "x"
    }
  }
  
  if (is.null(ylab)) {
    ylab <- colnames(data)[2]
    if (is.null(ylab) || identical(ylab, "")) {
      ylab <- "Response"
    }
  }
  
  pred_obs_df <- NULL
  x_extra <- numeric(0)
  
  if (!is.null(prediction_data)) {
    pred_obs <- as.matrix(prediction_data)
    
    if (ncol(pred_obs) != 2) {
      stop("prediction_data must have exactly 2 columns: x and observed y.")
    }
    
    storage.mode(pred_obs) <- "double"
    
    pred_obs_df <- data.frame(
      x = pred_obs[, 1],
      y = pred_obs[, 2]
    )
    
    x_extra <- pred_obs_df$x
  }
  
  if (is.null(x_grid)) {
    x_min <- min(c(x_train, x_extra))
    x_max <- max(c(x_train, x_extra))
    x_grid <- seq(x_min, x_max, length.out = n_grid)
  } else {
    x_grid <- as.numeric(x_grid)
  }
  
  x_grid <- sort(unique(c(x_grid, x_train, x_extra)))
  
  pred <- predict_gp(model, x_grid, indep = TRUE)
  
  mu <- as.numeric(pred$pred_mean)
  sd_raw <- sqrt(pmax(diag(pred$pred_sigma_sq), 0))
  
  if (isTRUE(smooth_band)) {
    sd <- tryCatch(
      {
        stats::predict(
          stats::smooth.spline(
            x = x_grid,
            y = sd_raw,
            spar = smooth_band_spar
          ),
          x = x_grid
        )$y
      },
      error = function(e) sd_raw
    )
    sd <- pmax(sd, 0)
  } else {
    sd <- sd_raw
  }
  
  z <- stats::qnorm(1 - (1 - level) / 2)
  
  df_pred <- data.frame(
    x = x_grid,
    mean = mu,
    lower = mu - z * sd,
    upper = mu + z * sd
  )
  
  df_train <- data.frame(
    x = x_train,
    y = y_train
  )
  
  p <- ggplot2::ggplot(df_pred, ggplot2::aes(x = x, y = mean)) +
    ggplot2::geom_ribbon(
      ggplot2::aes(ymin = lower, ymax = upper),
      fill = "#7AA6DC",
      alpha = 0.22
    ) +
    ggplot2::geom_line(
      color = "#C0392B",
      linewidth = 1.2
    ) +
    ggplot2::geom_point(
      data = df_train,
      ggplot2::aes(x = x, y = y),
      inherit.aes = FALSE,
      shape = 21,
      size = 2.8,
      stroke = 0.7,
      fill = "white",
      color = "black"
    )
  
  if (!is.null(pred_obs_df)) {
    p <- p +
      ggplot2::geom_point(
        data = pred_obs_df,
        ggplot2::aes(x = x, y = y),
        inherit.aes = FALSE,
        shape = 24,
        size = 3.0,
        stroke = 0.7,
        fill = "#4C78A8",
        color = "#1F3A5F"
      )
  }
  
  p <- p +
    ggplot2::labs(
      title = title,
      subtitle = subtitle,
      x = xlab,
      y = ylab
    ) +
    ggplot2::theme_minimal(base_size = 14) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold"),
      plot.subtitle = ggplot2::element_text(color = "grey30"),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_blank(),
      axis.line = ggplot2::element_line(color = "black", linewidth = 0.3),
      legend.position = "none"
    )
  
  p
}