// ctmGP — Pareto-front and hypervolume utilities (T=2 exact, T>=3 stub).
//
// Provides:
//   ctmgp_pareto_filter_cpp(Y)                 — boolean mask of non-dominated points
//   ctmgp_pareto_extract_cpp(Y)                — sub-matrix of non-dominated points
//   ctmgp_hv_2d_cpp(PF, ref)                   — exact HV for T=2 (sort-and-sweep)
//   ctmgp_hv_contrib_2d_cpp(y, PF, ref)        — HV contribution of y to PF for T=2
//
// Minimization convention: smaller is better.  ref is an upper bound (worst-case).
// A point `p` dominates `q`  ⇔  (p <= q componentwise) AND (p != q).
//
// Higher-dim HV (T >= 3) is a separate file; kept minimal here to ship a tested
// T=2 core first.

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <algorithm>
#include <vector>

using namespace Rcpp;

// --------------------------------------------------------------------------
// Internal: componentwise dominance (min-convention)
// returns TRUE if p dominates q.
// --------------------------------------------------------------------------
static inline bool dominates_min(const arma::rowvec& p, const arma::rowvec& q) {
  bool any_strict = false;
  for (arma::uword k = 0; k < p.n_elem; ++k) {
    if (p[k] > q[k]) return false;        // p has a strictly worse component → not dominating
    if (p[k] < q[k]) any_strict = true;
  }
  return any_strict;
}

// --------------------------------------------------------------------------
//' Pareto filter — mark non-dominated rows of Y (minimization).
//'
//' @param Y numeric matrix with rows = points, cols = objectives.
//' @return LogicalVector of length nrow(Y); TRUE iff row is non-dominated.
// [[Rcpp::export]]
LogicalVector ctmgp_pareto_filter_cpp(const arma::mat& Y) {
  const arma::uword n = Y.n_rows;
  LogicalVector keep(n, true);
  for (arma::uword i = 0; i < n; ++i) {
    if (!keep[i]) continue;
    for (arma::uword j = 0; j < n; ++j) {
      if (i == j || !keep[j]) continue;
      if (dominates_min(Y.row(j), Y.row(i))) {
        keep[i] = false;
        break;
      }
    }
  }
  return keep;
}

//' Extract non-dominated rows of Y.
//'
//' @param Y numeric matrix; see ctmgp_pareto_filter_cpp.
//' @return matrix containing non-dominated rows of Y (order preserved).
// [[Rcpp::export]]
arma::mat ctmgp_pareto_extract_cpp(const arma::mat& Y) {
  LogicalVector keep = ctmgp_pareto_filter_cpp(Y);
  arma::uvec idx(Y.n_rows);
  arma::uword m = 0;
  for (arma::uword i = 0; i < Y.n_rows; ++i) if (keep[i]) idx[m++] = i;
  idx.resize(m);
  return Y.rows(idx);
}

// --------------------------------------------------------------------------
// HV 2D (exact).  Algorithm: sort PF by first objective ascending; walk and
// accumulate axis-aligned rectangles bounded by `ref`.
// --------------------------------------------------------------------------

//' Exact 2D hypervolume (minimization; T = 2).
//'
//' @param PF non-dominated front, matrix with 2 columns.
//' @param ref length-2 numeric vector, upper reference point (dominated by all).
//' @return scalar hypervolume of the union of dominated regions.
// [[Rcpp::export]]
double ctmgp_hv_2d_cpp(const arma::mat& PF, const arma::vec& ref) {
  if (PF.n_cols != 2) Rcpp::stop("ctmgp_hv_2d_cpp: PF must have 2 columns.");
  if (ref.n_elem != 2) Rcpp::stop("ctmgp_hv_2d_cpp: ref must have length 2.");
  if (PF.n_rows == 0) return 0.0;

  // Sort by first column ascending
  arma::uvec ord = arma::sort_index(PF.col(0), "ascend");
  arma::mat S = PF.rows(ord);

  double hv = 0.0;
  double prev_y1 = ref[1];
  for (arma::uword i = 0; i < S.n_rows; ++i) {
    const double x = S(i, 0);
    const double y = S(i, 1);
    if (x >= ref[0]) break;                                         // outside ref
    if (y >= prev_y1) continue;                                     // not on front
    hv += (ref[0] - x) * (prev_y1 - y);
    prev_y1 = y;
  }
  return hv;
}

//' HV contribution of a single point y to the current PF (T = 2, minimization).
//'
//' Returns the additional dominated area that point y would contribute if added
//' to PF.  0 if y is dominated by PF or not better than ref.
//'
//' @param y length-2 candidate point.
//' @param PF current non-dominated front (2 columns).
//' @param ref length-2 reference point.
//' @return scalar HV contribution, >= 0.
// [[Rcpp::export]]
double ctmgp_hv_contrib_2d_cpp(const arma::vec& y,
                                const arma::mat& PF,
                                const arma::vec& ref) {
  if (y.n_elem != 2) Rcpp::stop("y must have length 2.");
  if (ref.n_elem != 2) Rcpp::stop("ref must have length 2.");
  if (y[0] >= ref[0] || y[1] >= ref[1]) return 0.0;

  // If y is dominated by any PF point → contribution 0
  for (arma::uword i = 0; i < PF.n_rows; ++i) {
    if (PF(i, 0) <= y[0] && PF(i, 1) <= y[1] &&
        (PF(i, 0) < y[0] || PF(i, 1) < y[1])) {
      return 0.0;
    }
  }

  // HV(PF ∪ {y}) - HV(PF).  Compute the "strip" y contributes.
  // Collect points in PF with x < y[0] (these bound from below); walk right-to-left
  // to find y's upper neighbour's y-coordinate; similarly its left neighbour's
  // x-coordinate.  Dominated region gained is a rectangle minus any sub-strip.
  //
  // Simpler implementation: compute HV twice, HV(PF ∪ {y}) - HV(PF).
  arma::mat PF_plus = arma::join_vert(PF, y.t());
  arma::mat PF_plus_filtered = ctmgp_pareto_extract_cpp(PF_plus);
  double hv_new = ctmgp_hv_2d_cpp(PF_plus_filtered, ref);
  double hv_old = ctmgp_hv_2d_cpp(PF, ref);
  double contrib = hv_new - hv_old;
  if (contrib < 0.0) contrib = 0.0;                                 // numerical guard
  return contrib;
}

// --------------------------------------------------------------------------
// T = 3 HV via Hypervolume by Slicing Objectives (HSO).
//
// Algorithm (min convention):
//   Sort PF by z ascending: p_1.z ≤ p_2.z ≤ ... ≤ p_n.z.
//   For each i = 1..n, the z-slab [p_i.z, p_{i+1}.z] (with p_{n+1}.z = ref.z)
//   has dominated 2D area = HV_2D(staircase({p_1.xy, ..., p_i.xy}), ref_xy).
//   HV_3D = Σ_i (slab thickness) × (slab 2D HV).
//
// Complexity O(n² log n).  Paper-scale (n < 50) trivially fast.
// --------------------------------------------------------------------------

namespace {

// 2D staircase (min convention): sorted ascending by col 0, monotone-decreasing
// in col 1.  Same logic as box_decompose's helper, duplicated here so
// pareto.cpp doesn't need a shared header.
arma::mat build_2d_staircase_min(const arma::mat& pts) {
  const arma::uword m = pts.n_rows;
  if (m == 0) return arma::mat(0, 2);
  arma::uvec ord = arma::sort_index(pts.col(0), "ascend");
  arma::mat p = pts.rows(ord);
  std::vector<arma::uword> keep;
  keep.reserve(m);
  double y2_lower = std::numeric_limits<double>::infinity();
  for (arma::uword i = 0; i < m; ++i) {
    if (p(i, 1) < y2_lower) {
      keep.push_back(i);
      y2_lower = p(i, 1);
    }
  }
  arma::uvec idx(keep.size());
  for (std::size_t k = 0; k < keep.size(); ++k) idx[k] = keep[k];
  return p.rows(idx);
}

// HV of a 2D staircase given a 2D ref.  Direct formula: rectangles between
// consecutive staircase x-coordinates × the staircase's y-step at that point.
double hv_2d_staircase(const arma::mat& sc, const arma::vec& ref_2d) {
  const arma::uword n = sc.n_rows;
  if (n == 0) return 0.0;
  double hv = 0.0;
  double prev_y = ref_2d[1];
  for (arma::uword i = 0; i < n; ++i) {
    const double x = sc(i, 0);
    const double y = sc(i, 1);
    if (x >= ref_2d[0]) break;
    if (y >= prev_y) continue;
    hv += (ref_2d[0] - x) * (prev_y - y);
    prev_y = y;
  }
  return hv;
}

}  // namespace

//' Exact 3D hypervolume via HSO (minimization; T = 3).
//'
//' @param PF non-dominated front, matrix with 3 columns.
//' @param ref length-3 numeric vector, upper reference (must dominate every PF row).
//' @return scalar hypervolume.
// [[Rcpp::export]]
double ctmgp_hv_3d_cpp(const arma::mat& PF, const arma::vec& ref) {
  if (PF.n_cols != 3) Rcpp::stop("ctmgp_hv_3d_cpp: PF must have 3 columns.");
  if (ref.n_elem != 3) Rcpp::stop("ctmgp_hv_3d_cpp: ref must have length 3.");
  const arma::uword n = PF.n_rows;
  if (n == 0) return 0.0;

  // Sort PF by z ascending
  arma::uvec ord = arma::sort_index(PF.col(2), "ascend");
  arma::mat S = PF.rows(ord);

  arma::vec ref_2d = ref.subvec(0, 1);
  double hv = 0.0;
  for (arma::uword i = 0; i < n; ++i) {
    const double z_i    = S(i, 2);
    const double z_next = (i + 1 < n) ? S(i + 1, 2) : ref[2];
    if (z_i >= ref[2]) break;          // outside ref slab
    const double thick  = (z_next < ref[2]) ? (z_next - z_i) : (ref[2] - z_i);
    if (thick <= 0.0) continue;        // duplicate z values
    // Cumulative 2D staircase from {p_1.xy, ..., p_i.xy} (i+1 points)
    arma::mat prefix_2d = S.submat(0, 0, i, 1);
    arma::mat sc = build_2d_staircase_min(prefix_2d);
    hv += thick * hv_2d_staircase(sc, ref_2d);
  }
  return hv;
}

//' HV contribution of a single point y to the current PF (T = 3, minimization).
//'
//' Returns HV(PF ∪ {y}) - HV(PF), 0 if y is dominated by PF or by ref.
//'
//' @param y length-3 candidate point.
//' @param PF current non-dominated front (3 columns).
//' @param ref length-3 reference point.
//' @return scalar HV contribution, ≥ 0.
// [[Rcpp::export]]
double ctmgp_hv_contrib_3d_cpp(const arma::vec& y,
                                const arma::mat& PF,
                                const arma::vec& ref) {
  if (y.n_elem != 3) Rcpp::stop("y must have length 3.");
  if (ref.n_elem != 3) Rcpp::stop("ref must have length 3.");
  if (y[0] >= ref[0] || y[1] >= ref[1] || y[2] >= ref[2]) return 0.0;
  // y dominated by PF?
  for (arma::uword i = 0; i < PF.n_rows; ++i) {
    if (PF(i, 0) <= y[0] && PF(i, 1) <= y[1] && PF(i, 2) <= y[2] &&
        (PF(i, 0) < y[0] || PF(i, 1) < y[1] || PF(i, 2) < y[2])) {
      return 0.0;
    }
  }
  arma::mat PF_plus = arma::join_vert(PF, y.t());
  arma::mat PF_plus_filtered = ctmgp_pareto_extract_cpp(PF_plus);
  double hv_new = ctmgp_hv_3d_cpp(PF_plus_filtered, ref);
  double hv_old = ctmgp_hv_3d_cpp(PF, ref);
  double contrib = hv_new - hv_old;
  if (contrib < 0.0) contrib = 0.0;
  return contrib;
}

//' HV dispatcher by T (T = 2 → ctmgp_hv_2d_cpp; T = 3 → ctmgp_hv_3d_cpp).
//' T ≥ 4 not implemented (paper scope is T ≤ 3).
// [[Rcpp::export]]
double ctmgp_hv_general_cpp(const arma::mat& PF, const arma::vec& ref) {
  if (PF.n_cols != ref.n_elem)
    Rcpp::stop("ncol(PF) must equal length(ref).");
  if (PF.n_cols == 2) return ctmgp_hv_2d_cpp(PF, ref);
  if (PF.n_cols == 3) return ctmgp_hv_3d_cpp(PF, ref);
  Rcpp::stop("ctmgp_hv_general_cpp: T = %d not implemented (T ≤ 3).",
             static_cast<int>(PF.n_cols));
  return 0.0;
}

//' Batched HVI(y_k, PF, ref) for many y at once (T = 2 or 3).
//'
//' Computes hv_contribution for each column of Y and returns a vector.  Pre-
//' computes HV(PF) once and reuses it for all candidates.  Used by brute-MC
//' validation scripts to avoid R-loop overhead per sample.
//'
//' @param Y T × n_samples matrix of candidate points (columns).
//' @param PF non-dominated front, n_pf × T matrix.
//' @param ref length-T reference (componentwise dominates PF).
//' @return numeric vector of length n_samples.
// [[Rcpp::export]]
arma::vec ctmgp_hvi_batch_cpp(const arma::mat& Y, const arma::mat& PF,
                                const arma::vec& ref) {
  const arma::uword T = PF.n_cols;
  if (T != ref.n_elem) Rcpp::stop("ncol(PF) must equal length(ref).");
  if (Y.n_rows != T) Rcpp::stop("nrow(Y) must equal ncol(PF) (T).");
  if (T < 2 || T > 3) Rcpp::stop(
    "ctmgp_hvi_batch_cpp: T must be 2 or 3 (got %d).", static_cast<int>(T));

  const arma::uword n_samples = Y.n_cols;
  arma::vec out(n_samples, arma::fill::zeros);

  const double hv_pf = (T == 2) ? ctmgp_hv_2d_cpp(PF, ref)
                                : ctmgp_hv_3d_cpp(PF, ref);

  for (arma::uword s = 0; s < n_samples; ++s) {
    arma::vec y = Y.col(s);
    // Ref-domination guard
    bool above_ref = false;
    for (arma::uword m = 0; m < T; ++m) if (y[m] >= ref[m]) { above_ref = true; break; }
    if (above_ref) { out[s] = 0.0; continue; }
    // PF-domination guard
    bool dominated = false;
    for (arma::uword i = 0; i < PF.n_rows; ++i) {
      bool le_all = true;
      bool lt_any = false;
      for (arma::uword m = 0; m < T; ++m) {
        if (PF(i, m) > y[m]) { le_all = false; break; }
        if (PF(i, m) < y[m]) lt_any = true;
      }
      if (le_all && lt_any) { dominated = true; break; }
    }
    if (dominated) { out[s] = 0.0; continue; }
    // HV(PF + {y}): build PF_plus, filter, compute HV
    arma::mat PF_plus = arma::join_vert(PF, y.t());
    arma::mat PF_plus_filtered = ctmgp_pareto_extract_cpp(PF_plus);
    const double hv_new = (T == 2) ? ctmgp_hv_2d_cpp(PF_plus_filtered, ref)
                                   : ctmgp_hv_3d_cpp(PF_plus_filtered, ref);
    out[s] = std::max(0.0, hv_new - hv_pf);
  }
  return out;
}
