#ifndef OBJECTIVE_BASE_H
#define OBJECTIVE_BASE_H

#include <RcppArmadillo.h>

// 純 C++ objective 介面
class objective_base {
public:
  virtual double eval(const arma::vec& x) = 0;
  virtual ~objective_base() {}
};

#endif
