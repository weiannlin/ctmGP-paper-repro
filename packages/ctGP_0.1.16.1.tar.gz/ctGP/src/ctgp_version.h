#ifndef CTGP_VERSION_H
#define CTGP_VERSION_H

#define CTGP_PACKAGE_VERSION "0.1.16.1"

#endif
