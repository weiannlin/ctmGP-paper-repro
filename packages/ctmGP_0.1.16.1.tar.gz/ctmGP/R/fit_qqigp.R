# ctmGP — independent multi-output QQGP (paper §4.3 QQiGP baseline).
#
# fit_qqigp = T separate QQGP fits, one per response column.  No long-format
# stacking required — each fit consumes its own (X, W, y_l) slice.  Predictive
# Σ at any candidate is diagonal by construction.

#' Fit a per-output independent QQGP (QQiGP) on multi-output data.
#'
#' Fits T independent `fit_qqgp()` models, one per response column.  By
#' construction the predictive joint Σ at any candidate is diagonal — there is
#' no cross-output information sharing.
#'
#' @param data data.frame containing all relevant columns; or NULL if X_mat /
#'   W_mat / Y_mat are passed directly.
#' @param x_cols character vector; names of continuous columns.
#' @param w_cols character vector; names of categorical columns (may be empty).
#' @param y_cols character vector of length T (≥ 2); names of response columns.
#' @param X_mat,W_mat,Y_mat optional matrices when `data` is NULL.
#' @param ... passed to `fit_qqgp()` for each per-output fit.
#' @return list of class `qqigp_fit` with `fits` (length T), `mo_meta`,
#'   per-output `level_key`s, and aggregated `timing`.
#' @export
fit_qqigp <- function(data = NULL,
                      x_cols = NULL,
                      w_cols = NULL,
                      y_cols = NULL,
                      X_mat = NULL,
                      W_mat = NULL,
                      Y_mat = NULL,
                      ...) {
  # Resolve to (X_df, W_df, Y_mat) without long-format stacking
  if (!is.null(data)) {
    if (is.null(x_cols))  stop("Provide x_cols when passing `data`.")
    if (is.null(y_cols) || length(y_cols) < 2L)
      stop("Provide y_cols of length >= 2 when passing `data`.")
    data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
    miss <- setdiff(c(x_cols, w_cols, y_cols), names(data))
    if (length(miss)) stop("Columns not found in data: ", paste(miss, collapse=", "), ".")
    X_df <- data[, x_cols, drop = FALSE]
    W_df <- if (length(w_cols)) data[, w_cols, drop = FALSE] else NULL
    Y_mat <- as.matrix(data[, y_cols, drop = FALSE])
  } else {
    if (is.null(X_mat) || is.null(Y_mat))
      stop("Either pass `data` + column names, or `X_mat` + `Y_mat` directly.")
    X_mat <- as.matrix(X_mat); storage.mode(X_mat) <- "double"
    Y_mat <- as.matrix(Y_mat); storage.mode(Y_mat) <- "double"
    if (is.null(x_cols)) x_cols <- colnames(X_mat)
    if (is.null(x_cols)) x_cols <- paste0("x", seq_len(ncol(X_mat)))
    X_df <- as.data.frame(X_mat, stringsAsFactors = FALSE)
    names(X_df) <- x_cols
    W_df <- if (!is.null(W_mat)) {
      W_df_ <- as.data.frame(W_mat, stringsAsFactors = FALSE,
                              check.names = FALSE)
      if (is.null(w_cols)) w_cols <- colnames(W_df_)
      if (is.null(w_cols)) w_cols <- paste0("w", seq_len(ncol(W_df_)))
      names(W_df_) <- w_cols
      W_df_
    } else NULL
    if (is.null(y_cols)) y_cols <- colnames(Y_mat)
    if (is.null(y_cols)) y_cols <- paste0("y", seq_len(ncol(Y_mat)))
  }

  if (is.null(W_df) || ncol(W_df) == 0L) stop(
    "fit_qqigp: requires at least one categorical column (QQGP needs cat factor).")
  T_ <- ncol(Y_mat)

  # Combine W cols into a joint level via coerce_fun convention
  cat_chr <- as.data.frame(lapply(W_df, as.character),
                            stringsAsFactors = FALSE, check.names = FALSE)
  level_key      <- apply(cat_chr, 1, function(z) paste(z, collapse = "||"))
  level_key_uniq <- unique(level_key)
  level_vec      <- match(level_key, level_key_uniq)

  design <- as.matrix(X_df); storage.mode(design) <- "double"

  t_start <- proc.time()
  fits <- vector("list", T_)
  for (l in seq_len(T_)) {
    data_l <- cbind(design, c.T = level_vec, Y = as.numeric(Y_mat[, l]))
    storage.mode(data_l) <- "double"
    fits[[l]] <- fit_qqgp(design = design, data = data_l, ...)
  }
  elapsed <- proc.time() - t_start

  meta <- list(
    x_cols = x_cols,
    w_cols = if (!is.null(W_df)) names(W_df) else character(0),
    y_cols = y_cols,
    n_obs = nrow(X_df), T = T_
  )

  out <- list(
    fits        = fits,
    mo_meta     = meta,
    level_key   = level_key_uniq,
    all_cat_cols = meta$w_cols,
    timing      = list(
      wall_sec = unname(elapsed["elapsed"]),
      cpu_sec  = unname(elapsed["user.self"] + elapsed["sys.self"])
    )
  )
  class(out) <- c("qqigp_fit", "list")
  out
}

#' Predict from a fitted QQiGP.
#'
#' Calls `predict_qqgp()` on each per-output fit and stacks the marginals.
#' Joint Σ at every candidate is diagonal (independence by construction).
#'
#' @param fit `qqigp_fit` from `fit_qqigp()`.
#' @param newdata data.frame with x_cols + w_cols (no response columns).
#' @param joint logical (TRUE → per-candidate diagonal T×T sigma list).
#' @param ... passed to underlying `predict_qqgp()`.
#' @return list with mu, sigma (list of n_new diag T×T), sigma_marginal,
#'   blocks=as.list(seq_len(T)), timing.
#' @export
predict_qqigp <- function(fit, newdata, joint = TRUE, ...) {
  if (!inherits(fit, "qqigp_fit"))
    stop("fit must be a qqigp_fit object (from fit_qqigp).")
  meta <- fit$mo_meta
  newdata <- as.data.frame(newdata, stringsAsFactors = FALSE,
                            check.names = FALSE)
  required <- c(meta$x_cols, meta$w_cols)
  miss <- setdiff(required, names(newdata))
  if (length(miss)) stop("newdata missing columns: ", paste(miss, collapse=", "), ".")
  n_new <- nrow(newdata); T_ <- meta$T

  # Encode joint W level via fit's level_key
  cat_chr <- as.data.frame(lapply(newdata[meta$w_cols], as.character),
                            stringsAsFactors = FALSE, check.names = FALSE)
  joint_keys <- apply(cat_chr, 1, function(z) paste(z, collapse = "||"))
  level_vec  <- match(joint_keys, fit$level_key)
  if (anyNA(level_vec)) stop(
    "predict_qqigp: newdata contains categorical level combinations not seen ",
    "during fit (no joint level code available).")
  newdata_qq <- cbind(as.matrix(newdata[meta$x_cols]), c.T = level_vec)

  t_start <- proc.time()
  mu_T  <- matrix(NA_real_, nrow = T_, ncol = n_new)
  var_T <- matrix(NA_real_, nrow = T_, ncol = n_new)
  for (l in seq_len(T_)) {
    pl <- predict_qqgp(fit$fits[[l]], newdata = as.data.frame(newdata_qq),
                       indep = TRUE, ...)
    mu_T[l, ]  <- as.numeric(pl$pred_mean)
    var_T[l, ] <- as.numeric(pl$pred_var)
  }
  # Clip negative variance to 0 in-place (avoid pmax(scalar, matrix) which
  # drops dim in base R), then sqrt.
  var_T[var_T < 0] <- 0
  sd_T <- sqrt(var_T)
  elapsed <- proc.time() - t_start

  sigma_list <- if (isTRUE(joint))
    lapply(seq_len(n_new), function(c) diag(var_T[, c], T_, T_))
  else NULL

  list(
    mu              = mu_T,
    sigma           = sigma_list,
    sigma_marginal  = sd_T,
    blocks          = as.list(seq_len(T_)),
    timing          = list(
      wall_sec = unname(elapsed["elapsed"]),
      cpu_sec  = unname(elapsed["user.self"] + elapsed["sys.self"])
    )
  )
}
