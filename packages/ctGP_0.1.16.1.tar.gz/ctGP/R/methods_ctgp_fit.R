.ctgp_tree_stats <- function(tree) {
  flat <- ctgp_flatten_tree(tree)
  leaves <- flat[flat$is_leaf, , drop = FALSE]
  list(
    n_nodes = nrow(flat),
    n_leaves = nrow(leaves),
    max_depth = if (nrow(flat) > 0L) max(flat$depth) else 0L,
    leaf_models = if (nrow(leaves) > 0L && "leaf_model" %in% names(leaves)) sort(table(leaves$leaf_model), decreasing = TRUE) else integer(0),
    flat = flat,
    leaves = leaves
  )
}

#' @export
print.ctgp_fit <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  prep <- x$prepared
  stage <- x$stage
  final_tree <- x$final_tree
  grown_tree <- x$grown_tree
  grown_stats <- .ctgp_tree_stats(grown_tree)
  final_stats <- .ctgp_tree_stats(final_tree)
  regime <- if (!is.null(stage$regime$regime)) stage$regime$regime else NA_character_
  cat("ctGP fit object\n\n")
  cat("Data:\n")
  cat("  Number of observations :", nrow(prep$data), "\n")
  cat("  Quantitative dimension :", prep$schema$conti_dim, "\n")
  cat("  Qualitative factors    :", prep$schema$cate_num, "\n")
  cat("  Total combinations     :", prep$schema$level_num, "\n\n")
  cat("Global stage:\n")
  cat("  Design regime          :", regime, "\n")
  cat("  Deterministic route    :", as.character(x$fit_control$deterministic_route %||% stage$deterministic_route %||% NA_character_), "\n")
  cat("  Verbose progress       :", isTRUE(x$fit_control$verbose), " (mode:", as.character(x$fit_control$progress_mode %||% "none"), ")\n")
  cat("  BCD fi                 :", paste(formatC(as.numeric(stage$bcd$fi), digits = digits, format = "fg"), collapse = ", "), "\n")
  if (!is.null(x$fit_control$global_range)) {
    cat("  Global range           :", paste(formatC(as.numeric(x$fit_control$global_range), digits = digits, format = "fg"), collapse = ", "), "\n")
  }
  cat("\n")
  cat("Tree:\n")
  cat("  Grown nodes            :", grown_stats$n_nodes, "\n")
  cat("  Grown leaves           :", grown_stats$n_leaves, "\n")
  cat("  Final nodes            :", final_stats$n_nodes, "\n")
  cat("  Final leaves           :", final_stats$n_leaves, "\n")
  cat("  Final max depth        :", final_stats$max_depth, "\n")
  cat("  Tree stage             :", attr(final_tree, "tree_stage", exact = TRUE), "\n")
  cat("\n")
  if (length(final_stats$leaf_models) > 0L && !all(is.na(names(final_stats$leaf_models)))) {
    cat("Leaf models:\n")
    print(data.frame(model = names(final_stats$leaf_models), count = as.integer(final_stats$leaf_models), stringsAsFactors = FALSE), row.names = FALSE, right = FALSE)
    cat("\n")
  }
  invisible(x)
}

#' @export
summary.ctgp_fit <- function(object, ...) {
  prep <- object$prepared
  stage <- object$stage
  final_tree <- object$final_tree
  grown_tree <- object$grown_tree
  grown_stats <- .ctgp_tree_stats(grown_tree)
  final_stats <- .ctgp_tree_stats(final_tree)
  out <- list(
    call = object$call,
    n = nrow(prep$data),
    quantitative_dim = prep$schema$conti_dim,
    qualitative_count = prep$schema$cate_num,
    total_combinations = prep$schema$level_num,
    regime = if (!is.null(stage$regime$regime)) stage$regime$regime else NA_character_,
    deterministic_route = as.character(object$fit_control$deterministic_route %||% stage$deterministic_route %||% NA_character_),
    verbose = isTRUE(object$fit_control$verbose),
    progress_mode = as.character(object$fit_control$progress_mode %||% "none"),
    workflow_progress_checkpoints = object$fit_control$workflow_progress_checkpoints,
    bcd_fi = stage$bcd$fi,
    global_range = object$fit_control$global_range,
    pure_range = object$fit_control$pure_range,
    mixed_fi_range = object$fit_control$mixed_fi_range,
    mixed_theta_range = object$fit_control$mixed_theta_range,
    grown_nodes = grown_stats$n_nodes,
    grown_leaves = grown_stats$n_leaves,
    final_nodes = final_stats$n_nodes,
    final_leaves = final_stats$n_leaves,
    final_max_depth = final_stats$max_depth,
    tree_stage = attr(final_tree, "tree_stage", exact = TRUE),
    is_pruned = isTRUE(attr(final_tree, "is_pruned", exact = TRUE)),
    leaf_fit_summary = attr(final_tree, "leaf_fit_summary", exact = TRUE),
    prune_log = attr(final_tree, "prune_log", exact = TRUE),
    prune_trace_summary = attr(final_tree, "prune_trace_summary", exact = TRUE),
    loocv_summary = attr(final_tree, "loocv_summary", exact = TRUE)
  )
  class(out) <- "summary.ctgp_fit"
  out
}

#' @export
print.summary.ctgp_fit <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("Summary of ctGP fit\n\n")
  cat("Data:\n")
  cat("  Number of observations :", x$n, "\n")
  cat("  Quantitative dimension :", x$quantitative_dim, "\n")
  cat("  Qualitative factors    :", x$qualitative_count, "\n")
  cat("  Total combinations     :", x$total_combinations, "\n\n")
  cat("Global stage:\n")
  cat("  Design regime          :", x$regime, "\n")
  cat("  Deterministic route    :", x$deterministic_route, "\n")
  cat("  Verbose progress       :", isTRUE(x$verbose), " (mode:", as.character(x$progress_mode %||% "none"), ")\n")
  cat("  BCD fi                 :", paste(formatC(as.numeric(x$bcd_fi), digits = digits, format = "fg"), collapse = ", "), "\n")
  if (!is.null(x$global_range)) cat("  Global range           :", paste(formatC(as.numeric(x$global_range), digits = digits, format = "fg"), collapse = ", "), "\n")
  if (!is.null(x$pure_range)) cat("  Pure leaf range        :", paste(formatC(as.numeric(x$pure_range), digits = digits, format = "fg"), collapse = ", "), "\n")
  if (!is.null(x$mixed_fi_range)) cat("  Mixed fi range         :", paste(formatC(as.numeric(x$mixed_fi_range), digits = digits, format = "fg"), collapse = ", "), "\n")
  if (!is.null(x$mixed_theta_range)) cat("  Mixed theta range      :", paste(formatC(as.numeric(x$mixed_theta_range), digits = digits, format = "fg"), collapse = ", "), "\n")
  cat("\nTree:\n")
  cat("  Grown nodes            :", x$grown_nodes, "\n")
  cat("  Grown leaves           :", x$grown_leaves, "\n")
  cat("  Final nodes            :", x$final_nodes, "\n")
  cat("  Final leaves           :", x$final_leaves, "\n")
  cat("  Final max depth        :", x$final_max_depth, "\n")
  cat("  Tree stage             :", x$tree_stage, "\n")
  cat("  Pruned                 :", x$is_pruned, "\n\n")
  if (!is.null(x$leaf_fit_summary)) {
    cat("Leaf fit summary:\n")
    print(x$leaf_fit_summary, row.names = FALSE)
    cat("\n")
  }
  if (!is.null(x$prune_trace_summary)) {
    cat("Prune trace summary:\n")
    print(x$prune_trace_summary, row.names = FALSE)
    cat("\n")
  }
  if (!is.null(x$loocv_summary)) {
    cat("LOOCV summary (head):\n")
    print(utils::head(x$loocv_summary), row.names = FALSE)
    cat("\n")
  }
  invisible(x)
}
