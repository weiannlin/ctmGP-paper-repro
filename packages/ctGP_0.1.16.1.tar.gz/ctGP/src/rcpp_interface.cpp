#include <RcppArmadillo.h>
#include <algorithm>
#include <cctype>
#include <cmath>
// [[Rcpp::depends(RcppArmadillo)]]

#include "objective_base.h"
#include "optimizer_pso.h"
#include "gp_model.h"
#include "qqgp_model.h"
#include "ctgp_rcpp_utils.h"

namespace {


Rcpp::List make_omp_runtime_info(bool use_openmp, int requested_threads, int n_tasks) {
  const bool compiled = ctgp_openmp_compiled();
  const int max_threads = ctgp_openmp_max_threads_runtime();
  const bool auto_threads = (requested_threads <= 0);
  const int effective_threads = ctgp_openmp_resolve_threads(use_openmp, requested_threads, n_tasks);
  const int recommended_threads = ctgp_openmp_recommended_threads(n_tasks);

  return Rcpp::List::create(
    Rcpp::Named("omp_compiled") = compiled,
    Rcpp::Named("omp_enabled") = (compiled && use_openmp),
    Rcpp::Named("omp_requested_threads") = requested_threads,
    Rcpp::Named("omp_auto_threads") = auto_threads,
    Rcpp::Named("omp_effective_threads") = effective_threads,
    Rcpp::Named("omp_max_threads") = max_threads,
    Rcpp::Named("omp_recommended_threads") = recommended_threads
  );
}

arma::mat resolve_training_f_matrix(
    Rcpp::Nullable<arma::mat> f_matrix,
    int n_rows,
    const arma::mat& f_default,
    const char* context
) {
  arma::mat f_matrix_resolved = f_default;
  if (nullable_is_not_null(f_matrix)) {
    f_matrix_resolved = Rcpp::as<arma::mat>(f_matrix);
  }

  if ((int)f_matrix_resolved.n_rows != n_rows) {
    Rcpp::stop(std::string(context) + ": f_matrix must have the same number of rows as the training data.");
  }
  if ((int)f_matrix_resolved.n_cols < 1) {
    Rcpp::stop(std::string(context) + ": f_matrix must have at least one column.");
  }
  if (!f_matrix_resolved.is_finite()) {
    Rcpp::stop(std::string(context) + ": f_matrix must contain only finite numeric values.");
  }

  return f_matrix_resolved;
}

arma::mat coerce_gp_new_points(SEXP new_point_sexp, int d) {
  arma::mat new_point;
  if (sexp_is_matrix(new_point_sexp)) {
    new_point = Rcpp::as<arma::mat>(new_point_sexp);
  } else {
    arma::vec v = Rcpp::as<arma::vec>(new_point_sexp);
    new_point = v.t();
  }

  if ((int)new_point.n_cols != d) {
    Rcpp::stop("new_point has incompatible number of columns for GP prediction.");
  }
  if (!new_point.is_finite()) {
    Rcpp::stop("new_point must contain only finite numeric values.");
  }

  return new_point;
}

}  // namespace

// ------------------------------
// test objective: sphere function
// ------------------------------
class sphere_objective : public objective_base {
public:
  double eval(const arma::vec& x) override {
    return arma::dot(x, x);
  }
};

// [[Rcpp::export]]
bool ctgp_openmp_enabled_cpp() {
  return ctgp_openmp_compiled();
}

// [[Rcpp::export]]
int ctgp_openmp_max_threads_cpp() {
  return ctgp_openmp_max_threads_runtime();
}

// [[Rcpp::export]]
int ctgp_openmp_recommended_threads_cpp(int n_tasks) {
  if (n_tasks < 1) {
    Rcpp::stop("n_tasks must be positive.");
  }
  return ctgp_openmp_recommended_threads(n_tasks);
}

// [[Rcpp::export]]
Rcpp::List ctgp_openmp_policy_cpp(int n_tasks, bool use_openmp = true, int num_threads = 0) {
  if (n_tasks < 1) {
    Rcpp::stop("n_tasks must be positive.");
  }
  return make_omp_runtime_info(use_openmp, num_threads, n_tasks);
}

// [[Rcpp::export]]
Rcpp::List test_pso_cpp(
    const arma::vec& lower,
    const arma::vec& upper,
    int swarm_size = 40,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1
) {
  if (lower.n_elem == 0) {
    Rcpp::stop("lower must be non-empty.");
  }
  if (lower.n_elem != upper.n_elem) {
    Rcpp::stop("lower and upper must have the same length.");
  }

  pso_control control;
  control.kernel_mode = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;

  sphere_objective obj;
  pso_optimizer optimizer(control);
  optim_result res = optimizer.minimize(obj, lower, upper);

  const Rcpp::List omp_info = make_omp_runtime_info(use_openmp, num_threads, swarm_size);

  return Rcpp::List::create(
    Rcpp::Named("best_par") = res.best_par,
    Rcpp::Named("best_value") = res.best_value,
    Rcpp::Named("history") = res.history,
    Rcpp::Named("n_eval") = res.n_eval,
    Rcpp::Named("converged") = res.converged,
    Rcpp::Named("omp") = omp_info
  );
}

// ============================================================================
// GP interface
// ============================================================================

// [[Rcpp::export]]
Rcpp::List fit_gp_cpp(
    const arma::mat& data,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> range = R_NilValue,
    SEXP nugget = R_NilValue,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1,
    int objective_mode = 1,
    int finalize_mode = 0
) {
  if (data.n_cols < 2) {
    Rcpp::stop("data must have at least one input column and one response column.");
  }

  int d = data.n_cols - 1;
  arma::mat design = data.cols(0, d - 1);
  arma::vec y = data.col(d);

  bool nugget_provided = false;
  double nugget_value = 0.0;

  if (!sexp_is_null(nugget)) {
    nugget_value = Rcpp::as<double>(nugget);
    nugget_provided = true;

    if (!std::isfinite(nugget_value) || nugget_value < 0.0) {
      Rcpp::stop("nugget must be a finite nonnegative scalar.");
    }
  }

  objective_mode = gp_resolve_objective_mode_int(objective_mode);
  finalize_mode = gp_resolve_finalize_mode_int(finalize_mode);
  const std::string objective_mode_label = gp_objective_mode_label(objective_mode);
  const std::string finalize_mode_label = gp_finalize_mode_label(finalize_mode, objective_mode);

  arma::vec lower;
  arma::vec upper;

  if (nullable_is_not_null(range)) {
    arma::vec range_vec = Rcpp::as<arma::vec>(range);
    if ((int)range_vec.n_elem != 2 * d) {
      Rcpp::stop("range must have length 2 * conti_dim.");
    }
    lower = range_vec.subvec(0, d - 1);
    upper = range_vec.subvec(d, 2 * d - 1);
  } else {
    Rcpp::List bds = default_fi_bounds(design);
    lower = Rcpp::as<arma::vec>(bds["lower"]);
    upper = Rcpp::as<arma::vec>(bds["upper"]);
  }

  arma::vec init;
  if (nullable_is_not_null(init_param)) {
    init = Rcpp::as<arma::vec>(init_param);
    if ((int)init.n_elem != d) {
      Rcpp::stop("init_param must have length equal to conti_dim.");
    }
  } else {
    init = 0.8 * upper + 0.2 * lower;
  }

  arma::mat f_default(data.n_rows, 1, arma::fill::ones);
  arma::mat f_matrix_use = resolve_training_f_matrix(f_matrix, data.n_rows, f_default, "fit_gp_cpp");

  pso_control control;
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;

  gp_likelihood_objective obj(
      design,
      y,
      f_matrix_use,
      nugget_value,
      nugget_provided,
      objective_mode
  );

  pso_optimizer optimizer(control);
  optim_result opt = optimizer.minimize(obj, lower, upper, init);

  gp_profile_result fit = gp_profile_fit(
    design,
    y,
    opt.best_par,
    f_matrix_use,
    nugget_value,
    nugget_provided,
    (finalize_mode == GP_FINALIZE_MATCH_SEARCH) ? objective_mode : GP_OBJECTIVE_STABLE
  );

  if (!fit.success) {
    if (nugget_provided && nugget_value == 0.0) {
      Rcpp::stop(
        "Final GP fit failed under nugget = 0. "
        "The correlation matrix may be too ill-conditioned. "
        "Try widening/shrinking the parameter range or specify a positive nugget."
      );
    } else {
      Rcpp::stop(
        "Final GP fit failed. "
        "Try a different parameter range or specify a positive nugget."
      );
    }
  }

  const Rcpp::List omp_info = make_omp_runtime_info(use_openmp, num_threads, swarm_size);

  return Rcpp::List::create(
    Rcpp::Named("fi") = opt.best_par,
    Rcpp::Named("design") = design,
    Rcpp::Named("data") = data,
    Rcpp::Named("l_matrix") = fit.l_matrix,
    Rcpp::Named("alpha_vec") = fit.alpha_vec,
    Rcpp::Named("f_matrix") = fit.f_matrix,
    Rcpp::Named("beta_vec") = fit.beta_vec,
    Rcpp::Named("beta") = fit.beta,
    Rcpp::Named("sigma_sq") = fit.sigma_sq,
    Rcpp::Named("nugget") = nugget_value,
    Rcpp::Named("nugget_provided") = nugget_provided,
    Rcpp::Named("effective_nugget") = fit.effective_nugget,
    Rcpp::Named("raw_rcond") = fit.raw_rcond,
    Rcpp::Named("nugget_added") = fit.nugget_added,
    Rcpp::Named("neg_log_lik") = fit.neg_log_lik,
    Rcpp::Named("neg_log_lik_search") = opt.best_value,
    Rcpp::Named("objective_mode") = objective_mode_label,
    Rcpp::Named("search_objective_mode") = objective_mode_label,
    Rcpp::Named("finalize_objective_mode") = finalize_mode_label,
    Rcpp::Named("optim_best_value") = opt.best_value,
    Rcpp::Named("optim_history") = opt.history,
    Rcpp::Named("optim_n_eval") = opt.n_eval,
    Rcpp::Named("optim_converged") = opt.converged,
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper,
    Rcpp::Named("init_param") = init,
    Rcpp::Named("optimizer_mode") = ctgp_internal_pso_kernel_mode_label(control.kernel_mode),
    Rcpp::Named("seed_cpp_used") = seed,
    Rcpp::Named("omp") = omp_info
  );
}


// [[Rcpp::export]]
Rcpp::List build_gp_from_params_cpp(
    const arma::mat& data,
    const arma::vec& fi,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    SEXP nugget = R_NilValue,
    int objective_mode = 1,
    int finalize_mode = 0
) {
  if (data.n_cols < 2) {
    Rcpp::stop("data must have at least one input column and one response column.");
  }

  const arma::uword d = data.n_cols - 1;
  if (fi.n_elem != static_cast<arma::uword>(d)) {
    Rcpp::stop("fi must have length equal to conti_dim.");
  }

  arma::mat design = data.cols(0, d - 1);
  arma::vec y = data.col(d);

  bool nugget_provided = false;
  double nugget_value = 0.0;
  if (!sexp_is_null(nugget)) {
    nugget_value = Rcpp::as<double>(nugget);
    nugget_provided = true;
    if (!std::isfinite(nugget_value) || nugget_value < 0.0) {
      Rcpp::stop("nugget must be a finite nonnegative scalar.");
    }
  }

  objective_mode = gp_resolve_objective_mode_int(objective_mode);
  finalize_mode = gp_resolve_finalize_mode_int(finalize_mode);
  const std::string objective_mode_label = gp_objective_mode_label(objective_mode);
  const std::string finalize_mode_label = gp_finalize_mode_label(finalize_mode, objective_mode);

  arma::mat f_default(data.n_rows, 1, arma::fill::ones);
  arma::mat f_matrix_use = resolve_training_f_matrix(f_matrix, data.n_rows, f_default, "build_gp_from_params_cpp");

  gp_profile_result fit = gp_profile_fit(
    design,
    y,
    fi,
    f_matrix_use,
    nugget_value,
    nugget_provided,
    (finalize_mode == GP_FINALIZE_MATCH_SEARCH) ? objective_mode : GP_OBJECTIVE_STABLE
  );

  if (!fit.success) {
    if (nugget_provided && nugget_value == 0.0) {
      Rcpp::stop(
        "Fixed-parameter GP rebuild failed under nugget = 0. The correlation matrix may be too ill-conditioned."
      );
    }
    Rcpp::stop("Fixed-parameter GP rebuild failed.");
  }

  const Rcpp::List omp_info = make_omp_runtime_info(false, 0, 1);
  const double raw_rcond = arma::rcond(build_corr_matrix(design, fi, 0.0));
  return Rcpp::List::create(
    Rcpp::Named("fi") = fi,
    Rcpp::Named("design") = design,
    Rcpp::Named("data") = data,
    Rcpp::Named("corr_matrix") = fit.H,
    Rcpp::Named("l_matrix") = fit.l_matrix,
    Rcpp::Named("alpha_vec") = fit.alpha_vec,
    Rcpp::Named("f_matrix") = fit.f_matrix,
    Rcpp::Named("beta_vec") = fit.beta_vec,
    Rcpp::Named("beta") = fit.beta,
    Rcpp::Named("sigma_sq") = fit.sigma_sq,
    Rcpp::Named("nugget") = nugget_value,
    Rcpp::Named("nugget_provided") = nugget_provided,
    Rcpp::Named("effective_nugget") = fit.effective_nugget,
    Rcpp::Named("raw_rcond") = raw_rcond,
    Rcpp::Named("nugget_added") = (fit.effective_nugget > 0.0),
    Rcpp::Named("neg_log_lik") = fit.neg_log_lik,
    Rcpp::Named("neg_log_lik_search") = fit.neg_log_lik,
    Rcpp::Named("objective_mode") = objective_mode_label,
    Rcpp::Named("search_objective_mode") = objective_mode_label,
    Rcpp::Named("finalize_objective_mode") = finalize_mode_label,
    Rcpp::Named("optim_best_value") = fit.neg_log_lik,
    Rcpp::Named("optim_history") = R_NilValue,
    Rcpp::Named("optim_n_eval") = 1,
    Rcpp::Named("optim_converged") = true,
    Rcpp::Named("lower") = fi,
    Rcpp::Named("upper") = fi,
    Rcpp::Named("init_param") = fi,
    Rcpp::Named("fixed_t") = false,
    Rcpp::Named("optimizer_mode") = "supplied",
    Rcpp::Named("seed_cpp_used") = R_NilValue,
    Rcpp::Named("omp") = omp_info
  );
}

// [[Rcpp::export]]
Rcpp::List predict_gp_cpp(
    const Rcpp::List& model,
    SEXP new_point,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    bool indep = false,
    bool use_nugget = true,
    bool use_openmp = true,
    int num_threads = 0,
    int block_size = 0,
    SEXP nugget_override = R_NilValue,
    std::string variance_mode = "universal"
) {
  arma::mat data = Rcpp::as<arma::mat>(model["data"]);
  int d = data.n_cols - 1;
  arma::mat np = coerce_gp_new_points(new_point, d);

  arma::mat f_pred_matrix;
  if (nullable_is_not_null(f_matrix)) {
    f_pred_matrix = Rcpp::as<arma::mat>(f_matrix);
  } else {
    if (!contains_element_named(model, "f_matrix")) {
      Rcpp::stop("model does not contain f_matrix. Please provide prediction f_matrix explicitly.");
    }
    arma::mat f_train = Rcpp::as<arma::mat>(model["f_matrix"]);
    if ((int)f_train.n_cols == 1 && arma::approx_equal(f_train.col(0), arma::ones<arma::vec>(f_train.n_rows), "absdiff", 1e-12)) {
      f_pred_matrix = arma::mat(np.n_rows, 1, arma::fill::ones);
    } else {
      Rcpp::stop(
        "This GP fit was created using a non-default mean design. "
        "Please provide prediction f_matrix explicitly, or fit with mean_formula/high-level wrappers."
      );
    }
  }

  bool has_nugget_override = !sexp_is_null(nugget_override);
  double nugget_override_value = 0.0;
  if (has_nugget_override) {
    nugget_override_value = Rcpp::as<double>(nugget_override);
    if (!std::isfinite(nugget_override_value) || nugget_override_value < 0.0) {
      Rcpp::stop("nugget_override must be a finite nonnegative scalar.");
    }
  }

  std::string variance_mode_norm = variance_mode;
  std::transform(variance_mode_norm.begin(), variance_mode_norm.end(), variance_mode_norm.begin(),
                 [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  bool use_universal_variance;
  if (variance_mode_norm == "universal") {
    use_universal_variance = true;
  } else if (variance_mode_norm == "legacy") {
    use_universal_variance = false;
  } else {
    Rcpp::stop("variance_mode must be either 'universal' or 'legacy'.");
  }

  return gp_predict_from_fit(
    model,
    new_point,
    f_pred_matrix,
    indep,
    use_nugget,
    use_openmp,
    num_threads,
    block_size,
    has_nugget_override,
    nugget_override_value,
    use_universal_variance
  );
}

// ============================================================================
// QQGP interface
// ============================================================================

// [[Rcpp::export]]
Rcpp::List fit_qqgp_cpp(
    const arma::mat& design,
    const arma::mat& data,
    const arma::vec& init_param,
    Rcpp::Nullable<arma::vec> fi_range = R_NilValue,
    Rcpp::Nullable<arma::vec> theta_range = R_NilValue,
    Rcpp::Nullable<arma::mat> t_matrix = R_NilValue,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    SEXP nugget = R_NilValue,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1,
    int objective_mode = 0,
    int finalize_mode = 0
) {
  if (data.n_cols < 3) {
    Rcpp::stop("QQGP data must have continuous columns, one categorical level column, and one response column.");
  }

  const arma::uword d = design.n_cols;
  if (data.n_cols != (d + 2u)) {
    Rcpp::stop("For QQGP, data must have conti_dim continuous columns plus one level column plus one response column.");
  }

  arma::mat design_use = design;
  arma::uvec level_index = arma::conv_to<arma::uvec>::from(data.col(d));
  arma::vec y = data.col(d + 1);

  unsigned int level_num = arma::max(level_index);
  if (level_num < 1) {
    Rcpp::stop("Categorical level index must start from 1.");
  }

  objective_mode = (objective_mode == QQGP_OBJECTIVE_LEGACY_EXACT)
    ? QQGP_OBJECTIVE_LEGACY_EXACT
    : QQGP_OBJECTIVE_STABLE;
  const bool legacy_exact_objective = (objective_mode == QQGP_OBJECTIVE_LEGACY_EXACT);
  const bool finalize_with_search = legacy_exact_objective && (finalize_mode == 1);
  const std::string objective_mode_label = legacy_exact_objective ? "legacy_exact" : "stable";
  const std::string finalize_objective_mode_label = finalize_with_search ? objective_mode_label : "stable";

  bool nugget_provided = false;
  double nugget_value = 0.0;
  if (!sexp_is_null(nugget)) {
    nugget_value = Rcpp::as<double>(nugget);
    nugget_provided = true;
    if (!std::isfinite(nugget_value) || nugget_value < 0.0) {
      Rcpp::stop("nugget must be a finite nonnegative scalar.");
    }
  }

  arma::mat f_default = qqgp_build_f_matrix(level_index, static_cast<int>(level_num));
  arma::mat f_matrix_use = resolve_training_f_matrix(f_matrix, data.n_rows, f_default, "fit_qqgp_cpp");

  Rcpp::List default_bds = qqgp_default_bounds(design_use, level_num);
  arma::vec fi_lower = Rcpp::as<arma::vec>(default_bds["fi_lower"]);
  arma::vec fi_upper = Rcpp::as<arma::vec>(default_bds["fi_upper"]);

  arma::vec fi_low = fi_lower;
  arma::vec fi_upp = fi_upper;
  if (nullable_is_not_null(fi_range)) {
    arma::vec fi_range_vec = Rcpp::as<arma::vec>(fi_range);
    if (fi_range_vec.n_elem != (2u * d)) {
      Rcpp::stop("fi_range must have length 2 * conti_dim.");
    }
    fi_low = fi_range_vec.subvec(0, d - 1);
    fi_upp = fi_range_vec.subvec(d, 2 * d - 1);
  }

  const bool fixed_t = nullable_is_not_null(t_matrix);
  const int theta_dim = static_cast<int>(level_num * (level_num - 1) / 2);
  const int kernel_mode_resolved = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);
  const bool globpso_exact_kernel = (kernel_mode_resolved == PSO_KERNEL_GLOBPSO_EXACT);

  arma::vec lower;
  arma::vec upper;
  arma::vec init_full;

  if (!fixed_t) {
    double theta_low = 1e-6;
    double theta_upp = arma::datum::pi - 1e-6;
    if (nullable_is_not_null(theta_range)) {
      arma::vec theta_range_vec = Rcpp::as<arma::vec>(theta_range);
      if ((int)theta_range_vec.n_elem != 2) {
        Rcpp::stop("theta_range must have length 2.");
      }
      theta_low = theta_range_vec(0);
      theta_upp = theta_range_vec(1);
      const bool theta_ok = globpso_exact_kernel
        ? (std::isfinite(theta_low) && std::isfinite(theta_upp) && theta_low >= 0.0 && theta_upp <= arma::datum::pi && theta_low < theta_upp)
        : (std::isfinite(theta_low) && std::isfinite(theta_upp) && theta_low > 0.0 && theta_upp < arma::datum::pi && theta_low < theta_upp);
      if (!theta_ok) {
        if (globpso_exact_kernel) {
          Rcpp::stop("theta_range must satisfy 0 <= lower < upper <= pi under globpso_exact mode.");
        }
        Rcpp::stop("theta_range must satisfy 0 < lower < upper < pi.");
      }
    }

    lower = arma::vec(d + theta_dim, arma::fill::zeros);
    upper = arma::vec(d + theta_dim, arma::fill::zeros);
    lower.subvec(0, d - 1) = fi_low;
    upper.subvec(0, d - 1) = fi_upp;
    if (theta_dim > 0) {
      lower.subvec(d, d + theta_dim - 1).fill(theta_low);
      upper.subvec(d, d + theta_dim - 1).fill(theta_upp);
    }

    if (init_param.n_elem != static_cast<arma::uword>(d)) {
      Rcpp::stop("For QQGP with estimated T matrix, init_param must have length conti_dim.");
    }

    arma::vec theta_init(theta_dim, arma::fill::zeros);
    if (theta_dim > 0) {
      theta_init.fill(0.8 * theta_upp + 0.2 * theta_low);
    }
    init_full = arma::join_cols(init_param, theta_init);

    pso_control control;
    control.kernel_mode = kernel_mode_resolved;
    control.swarm_size = swarm_size;
    control.max_iter = max_iter;
    control.c1 = c1;
    control.c2 = c2;
    control.w = w;
    control.tol = tol;
    control.use_openmp = use_openmp;
    control.num_threads = num_threads;
    control.seed = seed;

    qqgp_likelihood_objective obj(
      design_use,
      level_index,
      y,
      static_cast<int>(level_num),
      f_matrix_use,
      nugget_value,
      nugget_provided,
      objective_mode
    );

    pso_optimizer optimizer(control);
    optim_result opt = optimizer.minimize(obj, lower, upper, init_full);

    if (control.kernel_mode != PSO_KERNEL_GLOBPSO_EXACT) {
      double init_value = obj.eval(init_full);
      if (std::isfinite(init_value) && init_value < opt.best_value) {
        opt.best_value = init_value;
        opt.best_par = init_full;
      }
    }

    arma::vec fi_hat = opt.best_par.subvec(0, d - 1);
    arma::vec theta_hat(theta_dim, arma::fill::zeros);
    if (theta_dim > 0) {
      theta_hat = opt.best_par.subvec(d, d + theta_dim - 1);
    }

    qqgp_profile_result fit_search = qqgp_profile_fit(
      design_use,
      level_index,
      y,
      fi_hat,
      theta_hat,
      f_matrix_use,
      nugget_value,
      nugget_provided,
      objective_mode
    );
    if (!fit_search.success) {
      if (nugget_provided && nugget_value == 0.0) {
        Rcpp::stop(
          "Final QQGP fit failed under nugget = 0. The correlation matrix may be too ill-conditioned. Try changing the parameter range or specify a positive nugget."
        );
      }
      Rcpp::stop("Final QQGP fit failed. Try a different parameter range or specify a positive nugget.");
    }

    qqgp_profile_result fit_final = fit_search;
    if (legacy_exact_objective && !finalize_with_search) {
      fit_final = qqgp_profile_fit(
        design_use,
        level_index,
        y,
        fi_hat,
        theta_hat,
        f_matrix_use,
        nugget_value,
        nugget_provided,
        QQGP_OBJECTIVE_STABLE
      );
      if (!fit_final.success) {
        if (nugget_provided && nugget_value == 0.0) {
          Rcpp::stop(
            "Stable final QQGP rebuild failed under nugget = 0. The correlation matrix may be too ill-conditioned. Try changing the parameter range or specify a positive nugget."
          );
        }
        Rcpp::stop("Stable final QQGP rebuild failed. Try a different parameter range or specify a positive nugget.");
      }
    }

    double neg_log_lik_search = fit_search.neg_log_lik;
    double neg_log_lik_stable = fit_final.neg_log_lik;
    if (legacy_exact_objective && finalize_with_search) {
      qqgp_profile_result fit_stable = qqgp_profile_fit(
        design_use,
        level_index,
        y,
        fi_hat,
        theta_hat,
        f_matrix_use,
        nugget_value,
        nugget_provided,
        QQGP_OBJECTIVE_STABLE
      );
      if (fit_stable.success) {
        neg_log_lik_stable = fit_stable.neg_log_lik;
      }
    }

    const Rcpp::List omp_info = make_omp_runtime_info(use_openmp, num_threads, swarm_size);
    return Rcpp::List::create(
      Rcpp::Named("fi") = fi_hat,
      Rcpp::Named("theta") = theta_hat,
      Rcpp::Named("design") = design_use,
      Rcpp::Named("data") = data,
      Rcpp::Named("t_matrix") = fit_final.t_matrix,
      Rcpp::Named("l_matrix") = fit_final.l_matrix,
      Rcpp::Named("alpha_vec") = fit_final.alpha_vec,
      Rcpp::Named("f_matrix") = fit_final.f_matrix,
      Rcpp::Named("beta_vec") = fit_final.beta_vec,
      Rcpp::Named("sigma_sq") = fit_final.sigma_sq,
      Rcpp::Named("nugget") = nugget_value,
      Rcpp::Named("nugget_provided") = nugget_provided,
      Rcpp::Named("effective_nugget") = fit_final.effective_nugget,
      Rcpp::Named("neg_log_lik") = fit_final.neg_log_lik,
      Rcpp::Named("neg_log_lik_search") = neg_log_lik_search,
      Rcpp::Named("neg_log_lik_stable") = neg_log_lik_stable,
      Rcpp::Named("objective_mode") = objective_mode_label,
      Rcpp::Named("objective_mode_code") = objective_mode,
      Rcpp::Named("search_objective_mode") = objective_mode_label,
      Rcpp::Named("finalize_objective_mode") = finalize_objective_mode_label,
      Rcpp::Named("finalize_objective_mode_code") = finalize_with_search ? objective_mode : QQGP_OBJECTIVE_STABLE,
      Rcpp::Named("raw_rcond") = fit_final.raw_rcond,
      Rcpp::Named("nugget_added") = fit_final.nugget_added,
      Rcpp::Named("optim_best_value") = opt.best_value,
      Rcpp::Named("optim_history") = opt.history,
      Rcpp::Named("optim_n_eval") = opt.n_eval,
      Rcpp::Named("optim_converged") = opt.converged,
      Rcpp::Named("lower") = lower,
      Rcpp::Named("upper") = upper,
      Rcpp::Named("init_param") = init_full,
      Rcpp::Named("level_num") = level_num,
      Rcpp::Named("fixed_t") = false,
      Rcpp::Named("optimizer_mode") = ctgp_internal_pso_kernel_mode_label(control.kernel_mode),
      Rcpp::Named("seed_cpp_used") = seed,
      Rcpp::Named("omp") = omp_info
    );
  }

  arma::mat t_matrix_fixed = Rcpp::as<arma::mat>(t_matrix);
  if ((int)t_matrix_fixed.n_rows != (int)level_num || (int)t_matrix_fixed.n_cols != (int)level_num) {
    Rcpp::stop("t_matrix must be a square matrix with dimension equal to the number of levels.");
  }

  lower = fi_low;
  upper = fi_upp;
  if (init_param.n_elem != static_cast<arma::uword>(d)) {
    Rcpp::stop("For QQGP with fixed T matrix, init_param must have length conti_dim.");
  }
  init_full = init_param;

  pso_control control;
  control.kernel_mode = kernel_mode_resolved;
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;

  qqgp_likelihood_objective obj(
    design_use,
    level_index,
    y,
    static_cast<int>(level_num),
    f_matrix_use,
    t_matrix_fixed,
    nugget_value,
    nugget_provided,
    objective_mode
  );

  pso_optimizer optimizer(control);
  optim_result opt = optimizer.minimize(obj, lower, upper, init_full);

  if (control.kernel_mode != PSO_KERNEL_GLOBPSO_EXACT) {
    double init_value = obj.eval(init_full);
    if (std::isfinite(init_value) && init_value < opt.best_value) {
      opt.best_value = init_value;
      opt.best_par = init_full;
    }
  }

  arma::vec fi_hat = opt.best_par.subvec(0, d - 1);
  qqgp_profile_result fit_search = qqgp_profile_fit_fixed_t(
    design_use,
    level_index,
    y,
    fi_hat,
    t_matrix_fixed,
    f_matrix_use,
    nugget_value,
    nugget_provided,
    objective_mode
  );
  if (!fit_search.success) {
    if (nugget_provided && nugget_value == 0.0) {
      Rcpp::stop(
        "Final QQGP fit failed under nugget = 0. The correlation matrix may be too ill-conditioned. Try changing the parameter range or specify a positive nugget."
      );
    }
    Rcpp::stop("Final QQGP fit failed. Try a different parameter range or specify a positive nugget.");
  }

  qqgp_profile_result fit_final = fit_search;
  if (legacy_exact_objective && !finalize_with_search) {
    fit_final = qqgp_profile_fit_fixed_t(
      design_use,
      level_index,
      y,
      fi_hat,
      t_matrix_fixed,
      f_matrix_use,
      nugget_value,
      nugget_provided,
      QQGP_OBJECTIVE_STABLE
    );
    if (!fit_final.success) {
      if (nugget_provided && nugget_value == 0.0) {
        Rcpp::stop(
          "Stable final QQGP rebuild failed under nugget = 0. The correlation matrix may be too ill-conditioned. Try changing the parameter range or specify a positive nugget."
        );
      }
      Rcpp::stop("Stable final QQGP rebuild failed. Try a different parameter range or specify a positive nugget.");
    }
  }

  double neg_log_lik_search = fit_search.neg_log_lik;
  double neg_log_lik_stable = fit_final.neg_log_lik;
  if (legacy_exact_objective && finalize_with_search) {
    qqgp_profile_result fit_stable = qqgp_profile_fit_fixed_t(
      design_use,
      level_index,
      y,
      fi_hat,
      t_matrix_fixed,
      f_matrix_use,
      nugget_value,
      nugget_provided,
      QQGP_OBJECTIVE_STABLE
    );
    if (fit_stable.success) {
      neg_log_lik_stable = fit_stable.neg_log_lik;
    }
  }

  const Rcpp::List omp_info = make_omp_runtime_info(use_openmp, num_threads, swarm_size);
  return Rcpp::List::create(
    Rcpp::Named("fi") = fi_hat,
    Rcpp::Named("theta") = R_NilValue,
    Rcpp::Named("design") = design_use,
    Rcpp::Named("data") = data,
    Rcpp::Named("t_matrix") = fit_final.t_matrix,
    Rcpp::Named("l_matrix") = fit_final.l_matrix,
    Rcpp::Named("alpha_vec") = fit_final.alpha_vec,
    Rcpp::Named("f_matrix") = fit_final.f_matrix,
    Rcpp::Named("beta_vec") = fit_final.beta_vec,
    Rcpp::Named("sigma_sq") = fit_final.sigma_sq,
    Rcpp::Named("nugget") = nugget_value,
    Rcpp::Named("nugget_provided") = nugget_provided,
    Rcpp::Named("effective_nugget") = fit_final.effective_nugget,
    Rcpp::Named("neg_log_lik") = fit_final.neg_log_lik,
    Rcpp::Named("neg_log_lik_search") = neg_log_lik_search,
    Rcpp::Named("neg_log_lik_stable") = neg_log_lik_stable,
    Rcpp::Named("objective_mode") = objective_mode_label,
    Rcpp::Named("objective_mode_code") = objective_mode,
    Rcpp::Named("search_objective_mode") = objective_mode_label,
    Rcpp::Named("finalize_objective_mode") = finalize_objective_mode_label,
    Rcpp::Named("finalize_objective_mode_code") = finalize_with_search ? objective_mode : QQGP_OBJECTIVE_STABLE,
    Rcpp::Named("raw_rcond") = fit_final.raw_rcond,
    Rcpp::Named("nugget_added") = fit_final.nugget_added,
    Rcpp::Named("optim_best_value") = opt.best_value,
    Rcpp::Named("optim_history") = opt.history,
    Rcpp::Named("optim_n_eval") = opt.n_eval,
    Rcpp::Named("optim_converged") = opt.converged,
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper,
    Rcpp::Named("init_param") = init_full,
    Rcpp::Named("level_num") = level_num,
    Rcpp::Named("fixed_t") = true,
    Rcpp::Named("optimizer_mode") = ctgp_internal_pso_kernel_mode_label(control.kernel_mode),
    Rcpp::Named("seed_cpp_used") = seed,
    Rcpp::Named("omp") = omp_info
  );
}


// [[Rcpp::export]]
Rcpp::List build_qqgp_from_params_cpp(
    const arma::mat& design,
    const arma::mat& data,
    const arma::vec& fi,
    Rcpp::Nullable<arma::vec> theta = R_NilValue,
    Rcpp::Nullable<arma::mat> t_matrix = R_NilValue,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    SEXP nugget = R_NilValue,
    int objective_mode = 0,
    int finalize_mode = 0
) {
  if (data.n_cols < 3) {
    Rcpp::stop("QQGP data must have continuous columns, one categorical level column, and one response column.");
  }

  const arma::uword d = design.n_cols;
  if (data.n_cols != (d + 2u)) {
    Rcpp::stop("For QQGP, data must have conti_dim continuous columns plus one level column plus one response column.");
  }
  if (fi.n_elem != static_cast<arma::uword>(d)) {
    Rcpp::stop("fi must have length equal to conti_dim.");
  }
  if (nullable_is_not_null(theta) && nullable_is_not_null(t_matrix)) {
    Rcpp::stop("Provide exactly one of theta or t_matrix when rebuilding QQGP from supplied parameters.");
  }
  if (!nullable_is_not_null(theta) && !nullable_is_not_null(t_matrix)) {
    Rcpp::stop("Provide one of theta or t_matrix when rebuilding QQGP from supplied parameters.");
  }

  arma::mat design_use = design;
  arma::uvec level_index = arma::conv_to<arma::uvec>::from(data.col(d));
  arma::vec y = data.col(d + 1);
  unsigned int level_num = arma::max(level_index);
  if (level_num < 1) {
    Rcpp::stop("Categorical level index must start from 1.");
  }

  objective_mode = (objective_mode == QQGP_OBJECTIVE_LEGACY_EXACT)
    ? QQGP_OBJECTIVE_LEGACY_EXACT
    : QQGP_OBJECTIVE_STABLE;
  const bool legacy_exact_objective = (objective_mode == QQGP_OBJECTIVE_LEGACY_EXACT);
  const bool finalize_with_search = legacy_exact_objective && (finalize_mode == 1);
  const std::string objective_mode_label = legacy_exact_objective ? "legacy_exact" : "stable";
  const std::string finalize_objective_mode_label = finalize_with_search ? objective_mode_label : "stable";

  bool nugget_provided = false;
  double nugget_value = 0.0;
  if (!sexp_is_null(nugget)) {
    nugget_value = Rcpp::as<double>(nugget);
    nugget_provided = true;
    if (!std::isfinite(nugget_value) || nugget_value < 0.0) {
      Rcpp::stop("nugget must be a finite nonnegative scalar.");
    }
  }

  arma::mat f_default = qqgp_build_f_matrix(level_index, static_cast<int>(level_num));
  arma::mat f_matrix_use = resolve_training_f_matrix(f_matrix, data.n_rows, f_default, "build_qqgp_from_params_cpp");

  const bool fixed_t = nullable_is_not_null(t_matrix);
  const int theta_dim = static_cast<int>(level_num * (level_num - 1) / 2);
  arma::vec theta_hat;
  arma::mat t_matrix_use;

  qqgp_profile_result fit_search;
  if (!fixed_t) {
    theta_hat = Rcpp::as<arma::vec>(theta);
    if ((int)theta_hat.n_elem != theta_dim) {
      Rcpp::stop("theta must have length choose(level_num, 2).");
    }
    fit_search = qqgp_profile_fit(
      design_use,
      level_index,
      y,
      fi,
      theta_hat,
      f_matrix_use,
      nugget_value,
      nugget_provided,
      objective_mode
    );
  } else {
    t_matrix_use = Rcpp::as<arma::mat>(t_matrix);
    if ((int)t_matrix_use.n_rows != (int)level_num || (int)t_matrix_use.n_cols != (int)level_num) {
      Rcpp::stop("t_matrix must be a square matrix with dimension equal to the number of levels.");
    }
    fit_search = qqgp_profile_fit_fixed_t(
      design_use,
      level_index,
      y,
      fi,
      t_matrix_use,
      f_matrix_use,
      nugget_value,
      nugget_provided,
      objective_mode
    );
  }

  if (!fit_search.success) {
    if (nugget_provided && nugget_value == 0.0) {
      Rcpp::stop("Fixed-parameter QQGP rebuild failed under nugget = 0. The correlation matrix may be too ill-conditioned.");
    }
    Rcpp::stop("Fixed-parameter QQGP rebuild failed.");
  }

  qqgp_profile_result fit_final = fit_search;
  if (legacy_exact_objective && !finalize_with_search) {
    if (!fixed_t) {
      fit_final = qqgp_profile_fit(
        design_use,
        level_index,
        y,
        fi,
        theta_hat,
        f_matrix_use,
        nugget_value,
        nugget_provided,
        QQGP_OBJECTIVE_STABLE
      );
    } else {
      fit_final = qqgp_profile_fit_fixed_t(
        design_use,
        level_index,
        y,
        fi,
        fit_search.t_matrix,
        f_matrix_use,
        nugget_value,
        nugget_provided,
        QQGP_OBJECTIVE_STABLE
      );
    }
    if (!fit_final.success) {
      if (nugget_provided && nugget_value == 0.0) {
        Rcpp::stop("Stable final QQGP rebuild failed under nugget = 0. The correlation matrix may be too ill-conditioned.");
      }
      Rcpp::stop("Stable final QQGP rebuild failed.");
    }
  }

  double neg_log_lik_search = fit_search.neg_log_lik;
  double neg_log_lik_stable = fit_final.neg_log_lik;
  if (legacy_exact_objective && finalize_with_search) {
    qqgp_profile_result fit_stable;
    if (!fixed_t) {
      fit_stable = qqgp_profile_fit(
        design_use,
        level_index,
        y,
        fi,
        theta_hat,
        f_matrix_use,
        nugget_value,
        nugget_provided,
        QQGP_OBJECTIVE_STABLE
      );
    } else {
      fit_stable = qqgp_profile_fit_fixed_t(
        design_use,
        level_index,
        y,
        fi,
        fit_search.t_matrix,
        f_matrix_use,
        nugget_value,
        nugget_provided,
        QQGP_OBJECTIVE_STABLE
      );
    }
    if (fit_stable.success) {
      neg_log_lik_stable = fit_stable.neg_log_lik;
    }
  }

  const Rcpp::List omp_info = make_omp_runtime_info(false, 0, 1);
  return Rcpp::List::create(
    Rcpp::Named("fi") = fi,
    Rcpp::Named("theta") = fixed_t ? R_NilValue : Rcpp::wrap(theta_hat),
    Rcpp::Named("design") = design_use,
    Rcpp::Named("data") = data,
    Rcpp::Named("h_matrix") = fit_final.h_matrix,
    Rcpp::Named("r_matrix") = fit_final.r_matrix,
    Rcpp::Named("t_matrix") = fit_final.t_matrix,
    Rcpp::Named("l_matrix") = fit_final.l_matrix,
    Rcpp::Named("alpha_vec") = fit_final.alpha_vec,
    Rcpp::Named("f_matrix") = fit_final.f_matrix,
    Rcpp::Named("beta_vec") = fit_final.beta_vec,
    Rcpp::Named("sigma_sq") = fit_final.sigma_sq,
    Rcpp::Named("nugget") = nugget_value,
    Rcpp::Named("nugget_provided") = nugget_provided,
    Rcpp::Named("effective_nugget") = fit_final.effective_nugget,
    Rcpp::Named("neg_log_lik") = fit_final.neg_log_lik,
    Rcpp::Named("neg_log_lik_search") = neg_log_lik_search,
    Rcpp::Named("neg_log_lik_stable") = neg_log_lik_stable,
    Rcpp::Named("objective_mode") = objective_mode_label,
    Rcpp::Named("objective_mode_code") = objective_mode,
    Rcpp::Named("search_objective_mode") = objective_mode_label,
    Rcpp::Named("finalize_objective_mode") = finalize_objective_mode_label,
    Rcpp::Named("finalize_objective_mode_code") = finalize_with_search ? objective_mode : QQGP_OBJECTIVE_STABLE,
    Rcpp::Named("raw_rcond") = fit_final.raw_rcond,
    Rcpp::Named("nugget_added") = fit_final.nugget_added,
    Rcpp::Named("optim_best_value") = fit_search.neg_log_lik,
    Rcpp::Named("optim_history") = R_NilValue,
    Rcpp::Named("optim_n_eval") = 1,
    Rcpp::Named("optim_converged") = true,
    Rcpp::Named("lower") = fixed_t ? fi : arma::join_cols(fi, theta_hat),
    Rcpp::Named("upper") = fixed_t ? fi : arma::join_cols(fi, theta_hat),
    Rcpp::Named("init_param") = fixed_t ? fi : arma::join_cols(fi, theta_hat),
    Rcpp::Named("level_num") = level_num,
    Rcpp::Named("fixed_t") = fixed_t,
    Rcpp::Named("optimizer_mode") = "supplied",
    Rcpp::Named("seed_cpp_used") = R_NilValue,
    Rcpp::Named("omp") = omp_info
  );
}

// [[Rcpp::export]]
Rcpp::List predict_qqgp_cpp(
    const Rcpp::List& model,
    SEXP new_point,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    bool indep = false,
    bool use_nugget = true,
    bool use_openmp = true,
    int num_threads = 0,
    int block_size = 0,
    SEXP nugget_override = R_NilValue,
    std::string variance_mode = "universal"
) {
  arma::mat data = Rcpp::as<arma::mat>(model["data"]);
  int d = data.n_cols - 2;

  arma::mat new_point_matrix;
  if (sexp_is_matrix(new_point)) {
    new_point_matrix = Rcpp::as<arma::mat>(new_point);
  } else {
    arma::vec v = Rcpp::as<arma::vec>(new_point);
    new_point_matrix = v.t();
  }
  if (new_point_matrix.n_cols != (d + 1u)) {
    Rcpp::stop("new_point must contain conti_dim continuous columns plus one categorical level column.");
  }

  arma::mat f_pred_matrix;
  if (nullable_is_not_null(f_matrix)) {
    f_pred_matrix = Rcpp::as<arma::mat>(f_matrix);
  } else {
    if (!contains_element_named(model, "f_matrix")) {
      Rcpp::stop("model does not contain f_matrix. Please provide prediction f_matrix explicitly.");
    }
    arma::mat f_train = Rcpp::as<arma::mat>(model["f_matrix"]);
    arma::uvec level_index = arma::conv_to<arma::uvec>::from(data.col(d));
    unsigned int level_num = contains_element_named(model, "level_num") ? Rcpp::as<unsigned int>(model["level_num"]) : arma::max(level_index);
    arma::mat f_default = qqgp_build_f_matrix(level_index, static_cast<int>(level_num));
    if ((int)f_train.n_cols == (int)f_default.n_cols && arma::approx_equal(f_train, f_default, "absdiff", 1e-12)) {
      arma::uvec new_level_index = arma::conv_to<arma::uvec>::from(new_point_matrix.col(d));
      f_pred_matrix = qqgp_build_f_matrix(new_level_index, static_cast<int>(level_num));
    } else {
      Rcpp::stop(
        "This QQGP fit was created using a non-default mean design. "
        "Please provide prediction f_matrix explicitly, or fit with mean_formula/high-level wrappers."
      );
    }
  }

  bool has_nugget_override = !sexp_is_null(nugget_override);
  double nugget_override_value = 0.0;
  if (has_nugget_override) {
    nugget_override_value = Rcpp::as<double>(nugget_override);
    if (!std::isfinite(nugget_override_value) || nugget_override_value < 0.0) {
      Rcpp::stop("nugget_override must be a finite nonnegative scalar.");
    }
  }

  std::string variance_mode_norm = variance_mode;
  std::transform(variance_mode_norm.begin(), variance_mode_norm.end(), variance_mode_norm.begin(),
                 [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  bool use_universal_variance;
  if (variance_mode_norm == "universal") {
    use_universal_variance = true;
  } else if (variance_mode_norm == "legacy") {
    use_universal_variance = false;
  } else {
    Rcpp::stop("variance_mode must be either 'universal' or 'legacy'.");
  }

  return qqgp_predict_from_fit(
    model,
    new_point,
    f_pred_matrix,
    indep,
    use_nugget,
    use_openmp,
    num_threads,
    block_size,
    has_nugget_override,
    nugget_override_value,
    use_universal_variance
  );
}
