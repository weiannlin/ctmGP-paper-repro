// ctmGP — box decomposition of the non-dominated region (minimization convention).
//
// Two functions exported:
//   ctmgp_box_decompose_cpp  — region tiling: tiles the non-dominated region
//                               with axis-aligned boxes (T=2 strip sweep,
//                               T=3 plane sweep).  This is GEOMETRICALLY
//                               correct as a region partition but does NOT
//                               give per-box HVI as a single (u-y) product.
//                               Useful for visualization / volume sums but
//                               NOT for the closed-form EHVI dispatcher.
//
//   ctmgp_anchor_decompose_cpp — Yang-2019-style anchor boxes (T=2 only here).
//                               Each anchor box k has anchor u_k such that
//                               HVI(y) = ∏_m (u_{k,m} - y_m) for y in box k.
//                               Sum over anchor boxes recovers EHVI exactly
//                               under the (mu, Σ) predictive.  This is what
//                               the EHVI engine dispatcher consumes.
//
// Conventions:
//   minimization: a point p dominates q iff (p <= q) componentwise AND p != q.
//   ref must componentwise-dominate every PF row.
//   PF rows must be mutually non-dominated — call pareto_front() first.

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <algorithm>
#include <limits>
#include <vector>
#include "ctmgp_anchor.h"

using namespace Rcpp;

namespace {

constexpr double neg_inf = -std::numeric_limits<double>::infinity();

// Compare two points in min-convention dominance.  Returns true if p dominates q.
inline bool dominates_min(const arma::rowvec& p, const arma::rowvec& q) {
  bool strict = false;
  for (arma::uword k = 0; k < p.n_elem; ++k) {
    if (p[k] > q[k]) return false;
    if (p[k] < q[k]) strict = true;
  }
  return strict;
}

// ----- T = 2 sweep -----
// After sorting PF ascending by col 0, a valid non-dominated PF has col 1
// strictly decreasing.  The non-dominated region is tiled by n+1 strips:
//   strip 0 : y_1 ∈ [-∞, p_1.x],     y_2 ∈ [-∞, ref.y]
//   strip i : y_1 ∈ [p_i.x, p_{i+1}.x], y_2 ∈ [-∞, p_i.y]  (i = 1 .. n-1)
//   strip n : y_1 ∈ [p_n.x, ref.x],  y_2 ∈ [-∞, p_n.y]
// where PF = {p_1, ..., p_n} sorted.
void box_decompose_2d(const arma::mat& pf, const arma::vec& ref,
                       arma::mat& out_l, arma::mat& out_u) {
  const arma::uword n = pf.n_rows;
  arma::uvec ord = arma::sort_index(pf.col(0), "ascend");
  arma::mat s = pf.rows(ord);

  // Validate: col 1 must be strictly decreasing after col 0 sort
  for (arma::uword i = 1; i < n; ++i) {
    if (s(i, 1) >= s(i - 1, 1)) {
      Rcpp::stop("box_decompose_2d: PF is not a valid non-dominated front "
                 "(call pareto_front() first).");
    }
  }

  const arma::uword n_boxes = n + 1;
  out_l.set_size(2, n_boxes);
  out_u.set_size(2, n_boxes);

  for (arma::uword i = 0; i < n_boxes; ++i) {
    // lower corner: (x-lower, -inf)  where x-lower = -inf if i==0 else s(i-1, 0)
    out_l(0, i) = (i == 0) ? neg_inf : s(i - 1, 0);
    out_l(1, i) = neg_inf;
    // upper corner: (x-upper, y-upper) where
    //   x-upper = ref[0] if i == n else s(i, 0)
    //   y-upper = ref[1] if i == 0 else s(i - 1, 1)
    out_u(0, i) = (i == n) ? ref[0] : s(i, 0);
    out_u(1, i) = (i == 0) ? ref[1] : s(i - 1, 1);
  }
}

// ----- T = 3 plane sweep -----
// Sort PF by col 2 (y_3) ascending.  For each z-level, maintain the 2D
// staircase (non-dominated 2D projection of all PF points seen so far).
// Between z-levels z_{i-1} < z_i, the 2D decomposition is fixed; emit each
// 2D rectangle × [z_{i-1}, z_i] as a 3D box.
//
// Total complexity: O(n² log n) for n = |PF|.  Good enough for paper's
// |PF| < 300 typical.

// Compute 2D staircase (non-dominated in min convention) from a set of 2D
// points.  Input `pts` is m × 2; output `sc` is the non-dominated subset,
// sorted ascending by col 0.
arma::mat build_2d_staircase(const arma::mat& pts) {
  const arma::uword m = pts.n_rows;
  if (m == 0) return arma::mat(0, 2);

  // Sort by col 0 ascending
  arma::uvec ord = arma::sort_index(pts.col(0), "ascend");
  arma::mat p = pts.rows(ord);

  // Sweep keeping a monotonically decreasing col 1
  std::vector<arma::uword> keep;
  keep.reserve(m);
  double y2_min = std::numeric_limits<double>::infinity();
  // Walk RIGHT to LEFT so we keep smaller-y2 as we go left
  // Actually easier: walk LEFT to RIGHT; keep point only if its y_2 strictly
  // less than every subsequent point we've kept → no, staircase rule is:
  // after sorting by y_1 asc, a point at position i is on the non-dom front iff
  // its y_2 is strictly less than ALL points before it (smaller y_1).
  //
  // Equivalent: walk left to right, track running min of y_2; keep point if
  // its y_2 < running_min.
  //
  // Wait — min convention: point (x1, y1) is dominated by (x2, y2) if
  // x2 <= x1 AND y2 <= y1.  After sorting by x ascending, point i is dominated
  // by an earlier point j < i iff y_j <= y_i.  So we want to keep i iff all
  // earlier j have y_j > y_i, i.e. y_i < min of earlier y's.
  double y2_lower = std::numeric_limits<double>::infinity();
  for (arma::uword i = 0; i < m; ++i) {
    const double y1 = p(i, 0);
    const double y2 = p(i, 1);
    if (y2 < y2_lower) {
      keep.push_back(i);
      y2_lower = y2;
    } else if (y2 == y2_lower && !keep.empty() && p(keep.back(), 0) == y1) {
      // exact duplicate — skip
    }
    // else: dominated by a previous point — drop
  }
  (void) y2_min;

  arma::uvec idx(keep.size());
  for (std::size_t k = 0; k < keep.size(); ++k) idx[k] = keep[k];
  return p.rows(idx);
}

// Given a 2D staircase (sorted ascending by col 0, col 1 strictly decreasing)
// and a 2D ref point, emit its (|sc|+1) 2D rectangles.  Output appended to
// the growing (l, u) column list; only the 2D portion is filled — caller
// writes the z-bound into row 2.
void emit_2d_rectangles(const arma::mat& sc, const arma::vec& ref_2d,
                         std::vector<double>& l_flat,
                         std::vector<double>& u_flat) {
  // Empty staircase: one rectangle covering the whole 2D space bounded by ref
  if (sc.n_rows == 0) {
    l_flat.push_back(neg_inf); l_flat.push_back(neg_inf);
    u_flat.push_back(ref_2d[0]); u_flat.push_back(ref_2d[1]);
    return;
  }
  const arma::uword n = sc.n_rows;
  for (arma::uword i = 0; i <= n; ++i) {
    const double l1 = (i == 0) ? neg_inf : sc(i - 1, 0);
    const double u1 = (i == n) ? ref_2d[0] : sc(i, 0);
    const double l2 = neg_inf;
    const double u2 = (i == 0) ? ref_2d[1] : sc(i - 1, 1);
    l_flat.push_back(l1); l_flat.push_back(l2);
    u_flat.push_back(u1); u_flat.push_back(u2);
  }
}

void box_decompose_3d(const arma::mat& pf, const arma::vec& ref,
                       arma::mat& out_l, arma::mat& out_u) {
  const arma::uword n = pf.n_rows;
  arma::uvec ord = arma::sort_index(pf.col(2), "ascend");
  arma::mat s = pf.rows(ord);

  arma::vec ref_2d = ref.subvec(0, 1);

  // For each i in 0..n, the active PF-prefix (before z-slab i) is s.rows(0..i-1).
  // Slab i has z ∈ [z_low, z_high] where:
  //   z_low = (i == 0) ? neg_inf : s(i-1, 2)
  //   z_high = (i == n) ? ref[2] : s(i, 2)
  // The staircase for slab i uses prefix s.rows(0..i-1).

  // Collect all box corners as flat vectors, then copy to matrices.
  std::vector<double> l_flat, u_flat;
  l_flat.reserve(3 * (n + 1) * (n + 1));
  u_flat.reserve(3 * (n + 1) * (n + 1));

  for (arma::uword i = 0; i <= n; ++i) {
    // Build 2D staircase from prefix
    arma::mat prefix_2d;
    if (i > 0) prefix_2d = s.submat(0, 0, i - 1, 1);
    else       prefix_2d = arma::mat(0, 2);
    arma::mat sc = build_2d_staircase(prefix_2d);

    // Emit 2D rectangles for this slab, append z bounds
    const double z_low = (i == 0) ? neg_inf : s(i - 1, 2);
    const double z_high = (i == n) ? ref[2] : s(i, 2);

    std::size_t rect_l_before = l_flat.size();
    std::size_t rect_u_before = u_flat.size();
    std::vector<double> rect_l, rect_u;
    emit_2d_rectangles(sc, ref_2d, rect_l, rect_u);
    // Now interleave with the z bound
    const std::size_t n_rects = rect_l.size() / 2;
    for (std::size_t k = 0; k < n_rects; ++k) {
      l_flat.push_back(rect_l[2 * k]);
      l_flat.push_back(rect_l[2 * k + 1]);
      l_flat.push_back(z_low);
      u_flat.push_back(rect_u[2 * k]);
      u_flat.push_back(rect_u[2 * k + 1]);
      u_flat.push_back(z_high);
    }
    (void) rect_l_before; (void) rect_u_before;
  }

  const std::size_t n_boxes = l_flat.size() / 3;
  out_l.set_size(3, n_boxes);
  out_u.set_size(3, n_boxes);
  for (std::size_t k = 0; k < n_boxes; ++k) {
    out_l(0, k) = l_flat[3 * k + 0];
    out_l(1, k) = l_flat[3 * k + 1];
    out_l(2, k) = l_flat[3 * k + 2];
    out_u(0, k) = u_flat[3 * k + 0];
    out_u(1, k) = u_flat[3 * k + 1];
    out_u(2, k) = u_flat[3 * k + 2];
  }
}

}  // namespace

// --------------------------------------------------------------------------
// Rcpp exports
// --------------------------------------------------------------------------

//' Box decomposition of the non-dominated region.
//'
//' @param pf non-dominated Pareto front, n × T matrix (min convention).
//' @param ref length-T reference point; must componentwise-dominate all PF rows.
//' @return list with `lower` and `upper`, each T × n_boxes matrices; column k
//'   defines box k's bounds.  -Inf is used for implicit lower bounds of the
//'   non-dominated region.
// [[Rcpp::export]]
Rcpp::List ctmgp_box_decompose_cpp(const arma::mat& pf, const arma::vec& ref) {
  if (pf.n_cols != ref.n_elem) Rcpp::stop("ncol(pf) must equal length(ref).");
  if (pf.n_cols < 2) Rcpp::stop("T must be at least 2.");
  if (pf.n_cols > 3) Rcpp::stop("ctmgp_box_decompose_cpp: T >= 4 not yet "
                                 "implemented (paper scope is T ≤ 3).");
  // Validate ref dominates PF componentwise (permit equality; Yang 2019 requires
  // strict, but we allow slack for numerical safety)
  for (arma::uword l = 0; l < pf.n_cols; ++l) {
    const double ml = pf.col(l).max();
    if (ml >= ref[l]) {
      Rcpp::stop("ref[%d] = %.4g must be strictly greater than max(PF[,%d]) = %.4g.",
                  static_cast<int>(l + 1), ref[l], static_cast<int>(l + 1), ml);
    }
  }

  arma::mat out_l, out_u;
  if (pf.n_cols == 2) box_decompose_2d(pf, ref, out_l, out_u);
  else                box_decompose_3d(pf, ref, out_l, out_u);

  return Rcpp::List::create(
    Rcpp::Named("lower") = out_l,
    Rcpp::Named("upper") = out_u
  );
}

// ============================================================================
// Yang-2019-style anchor decomposition for T = 2.
// ============================================================================
//
// Algorithm (per Hupkens-Yang-Emmerich 2014 / Yang et al. 2019, T=2 case):
//
// Given PF sorted ascending by x_1 with sentinels p_0 = (-Inf, ref_2) and
// p_{n+1} = (ref_1, -Inf), the EHVI integral splits into a SUM over O(n)
// anchor boxes B_{i,j} (j ≤ i, both in 1..n+1) where each box contributes
// E[(u_{i,j,1} - Y_1)(u_{i,j,2} - Y_2) · 1_{B_{i,j}}(Y)] to EHVI.
//
// For T=2 the box B_{i,j} (with j ≤ i) is:
//     y_1 ∈ (p_{j-1}.x_1, p_j.x_1],   y_2 ∈ (p_i.x_2, p_{i-1}.x_2]
//
// and the corresponding anchor u_{i,j} (the "upper-right corner that y would
// dominate exclusively in this box") is:
//     u_{i,j} = (p_j.x_1, p_{i-1}.x_2)
//
// Only triangular indices j ≤ i are emitted (i and j both range over 1..n+1).
// Total = (n+1)(n+2)/2 anchor boxes.  For n=30 PF points → 496 boxes;
// for n=100 → 5151 boxes.
//
// Each emitted box satisfies: HVI(y) = (u_{i,j,1} - y_1)(u_{i,j,2} - y_2)
// for any y ∈ B_{i,j} that is non-dominated by PF.  CRITICALLY, this only
// holds when the strict triangular index ordering j ≤ i is enforced AND the
// box bounds are EXCLUSIVE on the lower side, INCLUSIVE on the upper side —
// our integrals treat boundaries as measure-zero (Gaussian density), so the
// open-vs-closed distinction is moot for the EHVI sum.
//
// REFERENCE: Hupkens, I., Yang, K., Emmerich, M., Deutz, A. (2014).  "Faster
// exact algorithms for computing expected hypervolume improvement."  EMO 2015,
// LNCS 9019.  Yang, K., Emmerich, M., Deutz, A., Bäck, T. (2019).  "Efficient
// computation of expected hypervolume improvement using box decomposition
// algorithms."  J. Global Optim. 75:3-34.

// External linkage so ctmgp_ehvi_engine.cpp can call directly.
// Header: ctmgp_anchor.h.
void ctmgp_anchor_decompose_2d_impl(const arma::mat& pf, const arma::vec& ref,
                                      arma::mat& out_l, arma::mat& out_u) {
  const arma::uword n = pf.n_rows;

  // Sort PF ascending by col 0; col 1 must then be strictly decreasing.
  arma::uvec ord = arma::sort_index(pf.col(0), "ascend");
  arma::mat s = pf.rows(ord);
  for (arma::uword i = 1; i < n; ++i) {
    if (s(i, 1) >= s(i - 1, 1)) Rcpp::stop(
      "anchor_decompose_2d: PF is not a strictly non-dominated front "
      "(call pareto_front() first).");
  }

  // x_grid[k] for k = 0..n+1: x_grid[0] = -Inf, x_grid[n+1] = ref[0],
  //                            x_grid[k] = s(k-1, 0) for 1..n.
  // y_grid[k] analogously: y_grid[0] = ref[1], y_grid[n+1] = -Inf.
  std::vector<double> x_grid(n + 2), y_grid(n + 2);
  x_grid[0] = neg_inf;
  y_grid[0] = ref[1];
  for (arma::uword k = 1; k <= n; ++k) {
    x_grid[k] = s(k - 1, 0);
    y_grid[k] = s(k - 1, 1);
  }
  x_grid[n + 1] = ref[0];
  y_grid[n + 1] = neg_inf;

  // Triangular enumeration: for j in 1..n+1, for i in j..n+1:
  //   box_lower = (x_grid[j-1], y_grid[i])
  //   box_upper = (x_grid[j],   y_grid[i-1])
  //   anchor    = box_upper      (used externally; engine multiplies (u - y))
  // Total boxes: (n+1)(n+2)/2 — but we drop boxes where the upper bound
  // collapses to -Inf (which can happen when i = n+1 and y_grid[n+1] = -Inf,
  // so the y-axis upper is also -Inf).  Wait — y_grid[i-1] is never -Inf for
  // i ≥ 1 because y_grid[k] = -Inf only for k = n+1.  So when i = n+1, the
  // y-bound y_grid[i-1] = y_grid[n] = s(n-1, 1), which is finite.  Good.
  // The lower y-bound y_grid[i] = -Inf when i = n+1; that's allowed (Gaussian
  // CDF at -Inf is 0 so the integral converges).

  const arma::uword n_boxes = ((n + 1) * (n + 2)) / 2;
  out_l.set_size(2, n_boxes);
  out_u.set_size(2, n_boxes);

  arma::uword k = 0;
  for (arma::uword j = 1; j <= n + 1; ++j) {
    for (arma::uword i = j; i <= n + 1; ++i) {
      out_l(0, k) = x_grid[j - 1];
      out_l(1, k) = y_grid[i];
      out_u(0, k) = x_grid[j];
      out_u(1, k) = y_grid[i - 1];
      ++k;
    }
  }
}

// ============================================================================
// T = 3 anchor decomposition via slab construction.
// ============================================================================
//
// Algorithm (min convention):
//   Sort PF by z ascending.  Sentinels z_0 = -Inf, z_{n+1} = ref.z give n+1
//   z-slabs.  For slab i ∈ {1, ..., n+1} (z ∈ [z_{i-1}, z_i]):
//     - Active 2D PF = staircase of {p_1.xy, ..., p_{i-1}.xy} (z-sorted prefix).
//     - Run T=2 anchor decomp on this 2D staircase against ref_2d.
//     - Promote each 2D anchor box (l_2d, u_2d) to 3D anchor box
//         l_3d = (l_2d, z_{i-1}),   u_3d = (u_2d, z_i).
//
// HVI per 3D box [l, u] for y in box:
//   HVI(y) = ∏_{m=1..3} (u[m] - max(y[m], l[m]))
//
// Total boxes ≤ Σ_{i=1..n+1} (s_i+1)(s_i+2)/2 where s_i = |stair_i|.
// Worst case O(n³); paper-scale (n < 30) trivially fast.

namespace {

// 2D staircase build (min convention).  Same logic as the one in pareto.cpp;
// kept local since cross-TU sharing of static helpers needs a header and
// this is small enough to duplicate.
arma::mat build_2d_staircase_for_anchor(const arma::mat& pts) {
  const arma::uword m = pts.n_rows;
  if (m == 0) return arma::mat(0, 2);
  arma::uvec ord = arma::sort_index(pts.col(0), "ascend");
  arma::mat p = pts.rows(ord);
  std::vector<arma::uword> keep;
  keep.reserve(m);
  double y2_lower = std::numeric_limits<double>::infinity();
  for (arma::uword i = 0; i < m; ++i) {
    if (p(i, 1) < y2_lower) {
      keep.push_back(i);
      y2_lower = p(i, 1);
    }
  }
  arma::uvec idx(keep.size());
  for (std::size_t k = 0; k < keep.size(); ++k) idx[k] = keep[k];
  return p.rows(idx);
}

}  // namespace

void ctmgp_anchor_decompose_3d_impl(const arma::mat& pf, const arma::vec& ref,
                                      arma::mat& out_l, arma::mat& out_u) {
  const arma::uword n = pf.n_rows;
  arma::vec ref_2d = ref.subvec(0, 1);

  // Sort PF by z ascending
  arma::uvec ord = arma::sort_index(pf.col(2), "ascend");
  arma::mat s = pf.rows(ord);

  std::vector<double> all_l, all_u;
  // Pre-reserve enough for typical paper-scale PFs
  all_l.reserve(3 * (n + 1) * 8);
  all_u.reserve(3 * (n + 1) * 8);

  for (arma::uword i = 1; i <= n + 1; ++i) {
    const double z_low  = (i == 1)     ? neg_inf : s(i - 2, 2);
    const double z_high = (i == n + 1) ? ref[2]  : s(i - 1, 2);
    if (z_high <= z_low) continue;     // duplicate-z slab; skip

    arma::mat prefix_2d;
    if (i == 1) prefix_2d = arma::mat(0, 2);
    else        prefix_2d = s.submat(0, 0, i - 2, 1);
    arma::mat sc = build_2d_staircase_for_anchor(prefix_2d);

    arma::mat l2, u2;
    ctmgp_anchor_decompose_2d_impl(sc, ref_2d, l2, u2);

    const arma::uword nb2 = l2.n_cols;
    for (arma::uword k = 0; k < nb2; ++k) {
      all_l.push_back(l2(0, k));
      all_l.push_back(l2(1, k));
      all_l.push_back(z_low);
      all_u.push_back(u2(0, k));
      all_u.push_back(u2(1, k));
      all_u.push_back(z_high);
    }
  }

  const arma::uword n_boxes = all_l.size() / 3;
  out_l.set_size(3, n_boxes);
  out_u.set_size(3, n_boxes);
  for (arma::uword k = 0; k < n_boxes; ++k) {
    out_l(0, k) = all_l[3 * k + 0];
    out_l(1, k) = all_l[3 * k + 1];
    out_l(2, k) = all_l[3 * k + 2];
    out_u(0, k) = all_u[3 * k + 0];
    out_u(1, k) = all_u[3 * k + 1];
    out_u(2, k) = all_u[3 * k + 2];
  }
}

//' Yang-2019-style anchor box decomposition (T = 2 or 3).
//'
//' Returns anchor boxes such that for each box k and any y inside it (and y
//' non-dominated by PF), HVI(y, PF, ref) equals
//' \eqn{\prod_m (upper[m, k] - \max(y_m, lower[m, k]))}.
//' This is what the EHVI engine dispatcher consumes for per-leaf moments.
//'
//' T = 2: triangular enumeration → (n+1)(n+2)/2 boxes (Hupkens-Yang-Emmerich 2014).
//' T = 3: slab construction over z-sorted PF → for each of n+1 z-slabs, run
//'   T=2 anchor decomp on the cumulative 2D staircase below the slab; promote
//'   each 2D box to 3D by adding the slab's z-bounds.  Worst case O(n³).
//'
//' @param pf non-dominated Pareto front, n × T (min convention).
//' @param ref length-T reference; must componentwise strictly dominate every PF row.
//' @return list with `lower` (T × n_boxes) and `upper` (T × n_boxes) box
//'   corner matrices.  Anchor of box k is `upper[, k]`.
// [[Rcpp::export]]
Rcpp::List ctmgp_anchor_decompose_cpp(const arma::mat& pf, const arma::vec& ref) {
  if (pf.n_cols != ref.n_elem) Rcpp::stop("ncol(pf) must equal length(ref).");
  const arma::uword T = pf.n_cols;
  if (T < 2 || T > 3) Rcpp::stop(
    "ctmgp_anchor_decompose_cpp: T must be 2 or 3 (got %d).",
    static_cast<int>(T));
  for (arma::uword l = 0; l < T; ++l) {
    const double ml = pf.col(l).max();
    if (ml >= ref[l]) Rcpp::stop(
      "ref[%d] = %.4g must be strictly greater than max(PF[,%d]) = %.4g.",
      static_cast<int>(l + 1), ref[l], static_cast<int>(l + 1), ml);
  }
  arma::mat out_l, out_u;
  if (T == 2) ctmgp_anchor_decompose_2d_impl(pf, ref, out_l, out_u);
  else        ctmgp_anchor_decompose_3d_impl(pf, ref, out_l, out_u);
  return Rcpp::List::create(
    Rcpp::Named("lower") = out_l,
    Rcpp::Named("upper") = out_u
  );
}
