
.ctgp_qqgpreg_default_nugget_spec <- function(y) {
  y_var <- stats::var(as.numeric(y))
  if (!is.finite(y_var) || y_var <= 0) y_var <- 1
  lower <- max(1e-8 * y_var, 1e-12)
  upper <- max(y_var, lower * 1e4)
  init <- sqrt(lower * upper)
  list(lower = lower, upper = upper, init = init)
}

fit_qqgp_regression <- function(design,
                                data,
                                init_param = NULL,
                                fi_range = NULL,
                                theta_range = NULL,
                                t_matrix = NULL,
                                nugget_init = NULL,
                                nugget_range = NULL,
                                f_matrix = NULL,
                                mean_formula = NULL,
                                normalization = "none",
                                normalize_response = FALSE,
                                optimizer_control = list()) {
  design <- as.matrix(design)
  data <- as.matrix(data)
  storage.mode(design) <- 'double'
  storage.mode(data) <- 'double'

  if (ncol(data) < 3L) {
    stop('data must contain continuous columns, one categorical level column, and one response column.')
  }
  if (ncol(data) != ncol(design) + 2L) {
    stop('For QQGP regression, data must have continuous columns plus one categorical level column plus one response column.')
  }

  d <- ncol(design)
  normalization <- .ctgp_resolve_normalization_method(normalization)

  input_normalizer <- NULL
  response_normalizer <- NULL
  design_fit <- design
  data_fit <- data
  if (!identical(normalization, "none")) {
    x_norm <- .ctgp_normalize_training_matrix(design, normalization = normalization)
    design_fit <- as.matrix(x_norm$x)
    input_normalizer <- x_norm$normalizer
    data_fit[, seq_len(d)] <- design_fit
  }
  if (isTRUE(normalize_response) && !identical(normalization, "none")) {
    y_norm <- .ctgp_normalize_response_vector(data_fit[, ncol(data_fit)], normalization = normalization)
    data_fit[, ncol(data_fit)] <- y_norm$y
    response_normalizer <- y_norm$normalizer
  }

  if (!is.null(init_param)) {
    init_param <- as.numeric(init_param)
    if (length(init_param) != d) {
      stop('init_param must have length equal to the number of continuous variables in design.')
    }
  }
  if (!is.null(fi_range)) {
    fi_range <- .ctgp_expand_fi_range(fi_range, d = d, arg_name = 'fi_range')
  }
  control <- .ctgp_resolve_optimizer_control(optimizer_control)
  kernel_mode <- .ctgp_resolve_pso_kernel_mode()
  theta_range_requested <- theta_range
  theta_range_sanitized <- FALSE
  if (!is.null(theta_range)) {
    theta_range <- .ctgp_prepare_theta_range_current(theta_range, arg_name = 'theta_range')
    theta_range_sanitized <- isTRUE(attr(theta_range, 'sanitized'))
  }
  if (!is.null(t_matrix)) {
    t_matrix <- as.matrix(t_matrix)
    storage.mode(t_matrix) <- 'double'
    if (nrow(t_matrix) != ncol(t_matrix)) stop('t_matrix must be square.')
  }

  # data layout for QQGP regression is: [continuous columns | level | response]
  # so the response is in column d + 2 under R's 1-based indexing.
  y <- data_fit[, d + 2L]
  nugget_defaults <- .ctgp_qqgpreg_default_nugget_spec(y)
  if (is.null(nugget_range)) {
    nugget_range <- c(nugget_defaults$lower, nugget_defaults$upper)
  } else {
    nugget_range <- as.numeric(nugget_range)
    if (length(nugget_range) != 2L || any(!is.finite(nugget_range)) || nugget_range[1] <= 0 || nugget_range[2] <= nugget_range[1]) {
      stop('nugget_range must be a numeric vector of length 2 satisfying 0 < lower < upper.')
    }
  }
  if (is.null(nugget_init)) {
    nugget_init <- nugget_defaults$init
  } else {
    nugget_init <- as.numeric(nugget_init)
    if (length(nugget_init) != 1L || !is.finite(nugget_init) || nugget_init <= 0) {
      stop('nugget_init must be NULL or a positive finite numeric scalar.')
    }
  }
  if (nugget_init < nugget_range[1] || nugget_init > nugget_range[2]) {
    stop('nugget_init must lie within nugget_range.')
  }

  mean_info <- .ctgp_build_qqgp_f_matrix(
    design = design_fit,
    data = data_fit,
    f_matrix = f_matrix,
    mean_formula = mean_formula
  )

  if (is.null(init_param)) {
    if (!is.null(fi_range)) {
      lower <- fi_range[seq_len(d)]
      upper <- fi_range[d + seq_len(d)]
    } else {
      bds <- .ctgp_default_fi_bounds_qqgp(design_fit)
      lower <- bds$lower
      upper <- bds$upper
    }
    init_param <- 0.2 * lower + 0.8 * upper
  }

  t_start <- proc.time()

  seed_cpp <- if (is.null(control$seed)) -1L else control$seed
  if (identical(kernel_mode, 'globpso_exact') && !is.null(control$seed)) {
    set.seed(control$seed)
    seed_cpp <- -1L
  }

  fit <- fit_qqgp_regression_cpp(
    design = design_fit,
    data = data_fit,
    init_param = init_param,
    fi_range = fi_range,
    theta_range = theta_range,
    t_matrix = t_matrix,
    nugget_init = nugget_init,
    nugget_range = nugget_range,
    f_matrix = mean_info$f_matrix,
    swarm_size = control$swarm_size,
    max_iter = control$max_iter,
    c1 = control$c1,
    c2 = control$c2,
    w = control$w,
    tol = control$tol,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    seed = seed_cpp
  )

  elapsed <- proc.time() - t_start

  fit$f_matrix <- mean_info$f_matrix
  fit$mean_source <- mean_info$mean_source
  fit$mean_structure <- mean_info$mean_structure
  fit$mean_formula <- mean_info$mean_formula
  fit$mean_terms <- mean_info$mean_terms
  fit$x_colnames_used <- mean_info$x_colnames_used
  fit$level_levels_used <- mean_info$level_levels_used

  if (!is.null(fit$f_matrix)) {
    fit$f_matrix <- as.matrix(fit$f_matrix)
    colnames(fit$f_matrix) <- mean_info$mean_terms
  }
  if (!is.null(fit$beta_vec)) {
    fit$beta_vec <- as.matrix(fit$beta_vec)
    rownames(fit$beta_vec) <- mean_info$mean_terms
  }

  fit$timing <- list(
    elapsed = unname(elapsed['elapsed']),
    user_self = unname(elapsed['user.self']),
    sys_self = unname(elapsed['sys.self'])
  )
  fit$optimizer_control <- control
  fit$omp <- .ctgp_collect_omp_info(control)
  fit$theta_range_requested <- theta_range_requested
  fit$theta_range_used <- theta_range
  fit$theta_range_sanitized <- isTRUE(theta_range_sanitized)
  fit$noise_model <- 'estimated_nugget'
  fit$normalization <- normalization
  fit$normalize_response <- isTRUE(normalize_response)
  fit$input_normalizer <- input_normalizer
  fit$response_normalizer <- response_normalizer
  fit$training_data_original <- data

  class(fit) <- c('qqgp_regression_fit', class(fit))
  fit$diagnostics <- ctgp_diagnostics(fit)
  fit
}
