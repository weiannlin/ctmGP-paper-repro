.ctgp_resolve_bcd_object <- function(stage_or_bcd) {
  if (inherits(stage_or_bcd, c("ctgp_bcd_common", "ctgp_bcd_union"))) {
    return(stage_or_bcd)
  }
  if (is.list(stage_or_bcd) && !is.null(stage_or_bcd$bcd)) {
    return(stage_or_bcd$bcd)
  }
  stop("Expected either a ctgp_global_stage() result or a ctgp_bcd()/ctgp_global_stage()$bcd object.")
}

.ctgp_tree_metadata_fields <- function() {
  c("tree_stage", "is_pruned", "split_rule", "growth_control", "data_summary", "loocv_summary", "prune_grown_loocv_summary", "prune_log", "prune_node_table", "prune_trace_current", "prune_trace_dynamic_sim", "prune_trace_legacy_batch", "prune_trace_mode_compare", "prune_trace_summary", "leaf_dispatch", "leaf_fit_summary", "legacy_tree_big")
}

.ctgp_copy_tree_metadata <- function(tree, template) {
  for (nm in .ctgp_tree_metadata_fields()) {
    val <- attr(template, nm, exact = TRUE)
    if (!is.null(val)) attr(tree, nm) <- val
  }
  class(tree) <- unique(c("ctgp_tree", class(tree)))
  tree
}

.ctgp_tree_data_summary <- function(prepped) {
  list(
    n = nrow(prepped$data),
    quantitative_dim = prepped$schema$conti_dim,
    qualitative_count = prepped$schema$cate_num,
    combined_count = prepped$schema$level_num,
    qualitative_columns = prepped$schema$qualitative_columns,
    quantitative_columns = prepped$schema$continuous_columns,
    response_column = prepped$schema$response_column
  )
}

.ctgp_tree_node_column_index <- function(node, bcd_object) {
  common_index <- bcd_object$common_index
  if (is.null(common_index) || is.null(common_index$level_ids)) {
    stop("The supplied ctGP BCD object does not contain common_index$level_ids needed for LOOCV/pruning.")
  }
  idx <- match(as.integer(node$combined_ids), as.integer(common_index$level_ids))
  if (anyNA(idx)) {
    stop("Failed to map one or more node combined_ids into the BCD common_index$level_ids.")
  }
  as.integer(idx)
}

.ctgp_tree_collect_nodes <- function(tree) {
  rows <- list()
  combined_list <- list()
  rec <- function(node) {
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = as.integer(node$node_id),
      parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
      depth = as.integer(node$depth),
      is_leaf = isTRUE(node$is_leaf),
      left_id = if (!isTRUE(node$is_leaf) && !is.null(node$left)) as.integer(node$left$node_id) else NA_integer_,
      right_id = if (!isTRUE(node$is_leaf) && !is.null(node$right)) as.integer(node$right$node_id) else NA_integer_,
      n_rows = as.integer(node$n_rows),
      n_combined = as.integer(length(node$combined_ids)),
      reason = if (is.null(node$reason)) NA_character_ else as.character(node$reason),
      stringsAsFactors = FALSE
    )
    combined_list[[length(combined_list) + 1L]] <<- as.integer(node$combined_ids)
    if (!isTRUE(node$is_leaf)) {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out <- do.call(rbind, rows)
  out$combined_ids <- I(combined_list)
  rownames(out) <- NULL
  out
}


.ctgp_prune_fast_h_nugget_policy <- function() {
  opt <- getOption("ctGP.internal.prune_fast_h_nugget_policy", NULL)
  if (is.null(opt) || length(opt) < 1L || is.na(opt[[1L]]) || !nzchar(as.character(opt[[1L]]))) {
    return("tb_local")
  }
  opt_chr <- tolower(as.character(opt[[1L]]))
  if (opt_chr %in% c("tb_local", "tb", "local", "auto", "default")) return("tb_local")
  if (opt_chr %in% c("stage_global", "stage", "global", "input")) return("stage_global")
  stop("ctGP.internal.prune_fast_h_nugget_policy must be either 'tb_local' or 'stage_global'.")
}

.ctgp_prune_fast_h_nugget_arg <- function(bcd_object) {
  policy <- .ctgp_prune_fast_h_nugget_policy()
  if (identical(policy, "stage_global")) {
    nugget_value <- bcd_object$nugget
    if (!is.null(nugget_value) && length(nugget_value) == 1L && is.finite(nugget_value[[1L]])) {
      return(as.numeric(nugget_value[[1L]]))
    }
  }
  NULL
}


.ctgp_tree_node_loocv_fast <- function(node, bcd_object) {
  common_index <- bcd_object$common_index
  if (is.null(common_index) || is.null(common_index$common_design) || is.null(common_index$y_matrix)) {
    stop("The supplied ctGP BCD object must contain common_index$common_design and common_index$y_matrix.")
  }
  col_idx <- .ctgp_tree_node_column_index(node, bcd_object)
  design <- as.matrix(common_index$common_design)
  y_matrix <- as.matrix(common_index$y_matrix[, col_idx, drop = FALSE])
  mu_vec <- as.numeric(bcd_object$mu_vec[col_idx])
  tau_matrix <- if (ncol(y_matrix) > 1L) as.matrix(bcd_object$tau_matrix[col_idx, col_idx, drop = FALSE]) else NULL
  nugget_arg <- .ctgp_prune_fast_h_nugget_arg(bcd_object)
  out <- ctgp_loocv_cpp(
    design = design,
    y_matrix = y_matrix,
    fi = as.numeric(bcd_object$fi),
    mu_vec = mu_vec,
    tau_matrix = tau_matrix,
    nugget = nugget_arg
  )
  list(
    node_id = as.integer(node$node_id),
    parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
    depth = as.integer(node$depth),
    is_leaf = isTRUE(node$is_leaf),
    n_rows = as.integer(node$n_rows),
    n_combined = as.integer(length(node$combined_ids)),
    loocv_value = as.numeric(out$loocv_sse),
    h_nugget = as.numeric(out$h_nugget),
    t_nugget = as.numeric(out$t_nugget),
    used_tau = isTRUE(out$used_tau),
    tau_dim = as.integer(out$tau_dim)
  )
}

.ctgp_loocv_summary_fast <- function(tree, bcd_object, use_openmp = TRUE, num_threads = 0L) {
  common_index <- bcd_object$common_index
  if (is.null(common_index) || is.null(common_index$common_design) || is.null(common_index$y_matrix)) {
    stop("The supplied ctGP BCD object must contain common_index$common_design and common_index$y_matrix.")
  }
  nodes <- .ctgp_tree_collect_nodes(tree)
  column_index <- lapply(nodes$combined_ids, function(ids) {
    .ctgp_tree_node_column_index(list(combined_ids = ids), bcd_object)
  })
  tau_matrix <- if (!is.null(bcd_object$tau_matrix)) as.matrix(bcd_object$tau_matrix) else NULL
  nugget_arg <- .ctgp_prune_fast_h_nugget_arg(bcd_object)
  out <- ctgp_tree_loocv_cpp(
    design = as.matrix(common_index$common_design),
    y_matrix = as.matrix(common_index$y_matrix),
    fi = as.numeric(bcd_object$fi),
    mu_vec = as.numeric(bcd_object$mu_vec),
    tau_matrix = tau_matrix,
    node_id = as.integer(nodes$node_id),
    parent_id = as.integer(nodes$parent_id),
    depth = as.integer(nodes$depth),
    is_leaf = as.logical(nodes$is_leaf),
    n_rows = as.integer(nodes$n_rows),
    n_combined = as.integer(nodes$n_combined),
    column_index = column_index,
    nugget = nugget_arg,
    use_openmp = isTRUE(use_openmp),
    num_threads = as.integer(num_threads)
  )
  out <- as.data.frame(out, stringsAsFactors = FALSE)
  out <- out[order(out$depth, out$node_id), , drop = FALSE]
  rownames(out) <- NULL
  attr(out, "named_vector") <- stats::setNames(out$loocv_value, out$node_id)
  attr(out, "h_nugget_policy") <- .ctgp_prune_fast_h_nugget_policy()
  class(out) <- c("ctgp_loocv_summary", class(out))
  out
}

.ctgp_leaf_model_reset <- function(node) {
  node$leaf_model <- NULL
  node$leaf_fit <- NULL
  node
}

.ctgp_prune_once_slow <- function(node, bcd_object, prune_tol = 0) {
  decisions <- list()
  changed <- FALSE
  if (!isTRUE(node$is_leaf)) {
    left_res <- .ctgp_prune_once_slow(node$left, bcd_object = bcd_object, prune_tol = prune_tol)
    right_res <- .ctgp_prune_once_slow(node$right, bcd_object = bcd_object, prune_tol = prune_tol)
    node$left <- left_res$node
    node$right <- right_res$node
    decisions <- c(left_res$decisions, right_res$decisions)
    changed <- isTRUE(left_res$changed) || isTRUE(right_res$changed)
    if (isTRUE(node$left$is_leaf) && isTRUE(node$right$is_leaf)) {
      parent_loocv <- .ctgp_tree_node_loocv_fast(node, bcd_object)$loocv_value
      left_loocv <- .ctgp_tree_node_loocv_fast(node$left, bcd_object)$loocv_value
      right_loocv <- .ctgp_tree_node_loocv_fast(node$right, bcd_object)$loocv_value
      separate_loocv <- left_loocv + right_loocv
      should_prune <- is.finite(parent_loocv) && is.finite(separate_loocv) && (parent_loocv + prune_tol < separate_loocv)
      decisions[[length(decisions) + 1L]] <- data.frame(
        parent_node_id = as.integer(node$node_id),
        left_node_id = as.integer(node$left$node_id),
        right_node_id = as.integer(node$right$node_id),
        parent_loocv = as.numeric(parent_loocv),
        separate_loocv = as.numeric(separate_loocv),
        improvement = as.numeric(separate_loocv - parent_loocv),
        pruned = isTRUE(should_prune),
        stringsAsFactors = FALSE
      )
      if (isTRUE(should_prune)) {
        node$is_leaf <- TRUE
        node$reason <- "pruned"
        node$split_var <- NULL
        node$left_levels <- NULL
        node$right_levels <- NULL
        node$score <- NULL
        node$left <- NULL
        node$right <- NULL
        node <- .ctgp_leaf_model_reset(node)
        changed <- TRUE
      }
    }
  }
  list(node = node, changed = changed, decisions = decisions)
}

.ctgp_prune_apply_cpp_state <- function(tree, prune_state) {
  active_map <- stats::setNames(as.logical(prune_state$active), as.character(prune_state$node_id))
  leaf_map <- stats::setNames(as.logical(prune_state$final_is_leaf), as.character(prune_state$node_id))
  rec <- function(node) {
    key <- as.character(node$node_id)
    if (!isTRUE(active_map[[key]])) return(NULL)
    final_is_leaf <- isTRUE(leaf_map[[key]])
    if (final_is_leaf) {
      had_children <- !is.null(node$left) || !is.null(node$right)
      node$is_leaf <- TRUE
      if (isTRUE(had_children)) {
        node$reason <- "pruned"
        node$split_var <- NULL
        node$left_levels <- NULL
        node$right_levels <- NULL
        node$score <- NULL
        node$left <- NULL
        node$right <- NULL
        node <- .ctgp_leaf_model_reset(node)
      }
      return(node)
    }
    node$is_leaf <- FALSE
    node$left <- rec(node$left)
    node$right <- rec(node$right)
    node
  }
  rec(tree)
}

.ctgp_prune_log_split_by_pass <- function(log_df) {
  if (is.null(log_df) || nrow(log_df) < 1L) return(list())
  pass_col <- if ("prune_pass" %in% names(log_df)) "prune_pass" else if ("pass" %in% names(log_df)) "pass" else NULL
  if (is.null(pass_col)) {
    out <- list(as.data.frame(log_df, stringsAsFactors = FALSE))
    rownames(out[[1L]]) <- NULL
    return(out)
  }
  split_df <- split(log_df, log_df[[pass_col]])
  lapply(split_df, function(df) {
    if ("pass" %in% names(df)) df$pass <- NULL
    if ("prune_pass" %in% names(df)) df$prune_pass <- NULL
    rownames(df) <- NULL
    df
  })
}

.ctgp_prune_log_bind_passes <- function(prune_log) {
  if (is.null(prune_log) || length(prune_log) < 1L) return(data.frame())
  parts <- lapply(seq_along(prune_log), function(i) {
    df <- as.data.frame(prune_log[[i]], stringsAsFactors = FALSE)
    if (!"pass" %in% names(df)) {
      df$pass <- rep.int(as.integer(i), nrow(df))
    }
    df
  })
  if (!length(parts)) return(data.frame())
  out <- do.call(rbind, parts)
  rownames(out) <- NULL
  out
}

.ctgp_match_loocv_engine <- function(engine = NULL) {
  if (is.null(engine) || identical(engine, "")) return("fast")
  engine_chr <- tolower(as.character(engine[[1L]]))
  if (engine_chr %in% c("legacy", "default", "cpp", "legacy_exact", "exact")) return("legacy")
  if (engine_chr %in% c("fast", "reference", "common_index", "debug")) return("fast")
  if (engine_chr %in% c("slow", "r")) return("slow")
  stop("loocv_engine must be one of 'legacy', 'fast', or 'slow'.")
}

ctgp_loocv_summary <- function(tree, stage_or_bcd, use_cpp = TRUE, use_openmp = TRUE, num_threads = 0L, engine = "fast") {
  bcd_object <- .ctgp_resolve_bcd_object(stage_or_bcd)
  if (is.list(stage_or_bcd) && !is.null(stage_or_bcd$prepared)) {
    bcd_object$prepared <- stage_or_bcd$prepared
  }
  engine <- .ctgp_match_loocv_engine(engine)
  if (identical(engine, "legacy")) {
    bcd_object <- .ctgp_attach_legacy_loocv_state(bcd_object, prepped = bcd_object$prepared)
    return(.ctgp_loocv_summary_legacy(tree, bcd_object))
  }
  if (identical(engine, "fast")) return(.ctgp_loocv_summary_fast(tree, bcd_object, use_openmp = use_openmp, num_threads = num_threads))
  .ctgp_loocv_summary_slow(tree, bcd_object)
}

ctgp_prune_tree <- function(tree,
                            stage_or_bcd,
                            prune_tol = 0,
                            max_passes = 100L,
                            attach_loocv_summary = TRUE,
                            loocv_summary = NULL,
                            use_cpp = TRUE,
                            use_openmp = TRUE,
                            num_threads = 0L,
                            loocv_engine = "fast") {
  if (!is.list(tree) || is.null(tree$node_id) || is.null(tree$is_leaf)) {
    stop("ctgp_prune_tree() expects a tree object returned by ctgp_grow_tree().")
  }
  if (!is.finite(max_passes) || max_passes < 1L) stop("max_passes must be a positive integer.")
  bcd_object <- .ctgp_resolve_bcd_object(stage_or_bcd)
  if (is.list(stage_or_bcd) && !is.null(stage_or_bcd$prepared)) {
    bcd_object$prepared <- stage_or_bcd$prepared
  }
  loocv_engine <- .ctgp_match_loocv_engine(loocv_engine)

  if (is.null(loocv_summary)) {
    loocv_summary <- if (identical(loocv_engine, "legacy")) {
      bcd_object <- .ctgp_attach_legacy_loocv_state(bcd_object, prepped = bcd_object$prepared)
      .ctgp_loocv_summary_legacy(tree, bcd_object)
    } else if (identical(loocv_engine, "fast")) {
      .ctgp_loocv_summary_fast(tree, bcd_object, use_openmp = use_openmp, num_threads = num_threads)
    } else {
      .ctgp_loocv_summary_slow(tree, bcd_object)
    }
  }

  actual_log_df <- data.frame()
  actual_label <- if (isTRUE(use_cpp)) "cpp_actual" else "r_recursive_actual"

  if (isTRUE(use_cpp)) {
    node_df <- .ctgp_tree_collect_nodes(tree)
    loocv_map <- stats::setNames(as.numeric(loocv_summary$loocv_value), as.character(loocv_summary$node_id))
    node_loocv <- unname(loocv_map[as.character(node_df$node_id)])
    prune_state <- ctgp_prune_tree_cpp(
      node_id = as.integer(node_df$node_id),
      parent_id = as.integer(node_df$parent_id),
      depth = as.integer(node_df$depth),
      left_id = as.integer(node_df$left_id),
      right_id = as.integer(node_df$right_id),
      is_leaf = as.logical(node_df$is_leaf),
      loocv_value = as.numeric(node_loocv),
      prune_tol = as.numeric(prune_tol),
      max_passes = as.integer(max_passes)
    )
    current <- .ctgp_prune_apply_cpp_state(tree, prune_state)
    actual_log_df <- as.data.frame(prune_state$log, stringsAsFactors = FALSE)
  } else {
    current <- tree
    prune_log <- list()
    pass <- 0L
    changed <- TRUE
    while (isTRUE(changed) && pass < as.integer(max_passes)) {
      pass <- pass + 1L
      res <- .ctgp_prune_once_slow(current, bcd_object = bcd_object, prune_tol = prune_tol)
      current <- res$node
      changed <- isTRUE(res$changed)
      prune_log[[pass]] <- if (length(res$decisions) > 0L) do.call(rbind, res$decisions) else data.frame(
        parent_node_id = integer(0), left_node_id = integer(0), right_node_id = integer(0),
        parent_loocv = numeric(0), separate_loocv = numeric(0), improvement = numeric(0), pruned = logical(0),
        stringsAsFactors = FALSE
      )
    }
    actual_log_df <- .ctgp_prune_log_bind_passes(prune_log)
  }

  artifacts <- .ctgp_prune_trace_build_artifacts(
    tree = tree,
    final_tree = current,
    loocv_summary = loocv_summary,
    prune_tol = prune_tol,
    max_passes = max_passes,
    actual_log = actual_log_df,
    actual_label = actual_label
  )

  current <- .ctgp_copy_tree_metadata(current, tree)
  attr(current, "tree_stage") <- "pruned"
  attr(current, "is_pruned") <- TRUE
  attr(current, "prune_grown_loocv_summary") <- loocv_summary
  attr(current, "prune_node_table") <- artifacts$node_table
  attr(current, "prune_trace_current") <- artifacts$actual_trace
  attr(current, "prune_trace_dynamic_sim") <- artifacts$dynamic$log
  attr(current, "prune_trace_legacy_batch") <- artifacts$legacy_batch$log
  attr(current, "prune_trace_mode_compare") <- artifacts$mode_compare
  attr(current, "prune_trace_summary") <- artifacts$summary
  attr(current, "prune_log") <- .ctgp_prune_log_split_by_pass(artifacts$actual_trace)
  if (isTRUE(attach_loocv_summary)) {
    attr(current, "loocv_summary") <- if (identical(loocv_engine, "legacy")) {
      bcd_object <- .ctgp_attach_legacy_loocv_state(bcd_object, prepped = bcd_object$prepared)
      .ctgp_loocv_summary_legacy(current, bcd_object)
    } else if (identical(loocv_engine, "fast")) {
      .ctgp_loocv_summary_fast(current, bcd_object, use_openmp = use_openmp, num_threads = num_threads)
    } else {
      .ctgp_loocv_summary_slow(current, bcd_object)
    }
  }
  current
}
