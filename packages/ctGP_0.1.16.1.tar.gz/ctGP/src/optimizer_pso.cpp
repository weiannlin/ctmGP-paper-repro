#include "optimizer_pso.h"

#include <atomic>
#include <cmath>
#include <limits>
#include <string>

#include <R_ext/Random.h>

#ifdef _OPENMP
#include <omp.h>
#endif

namespace {

#ifdef _OPENMP
inline int clamp_threads(int requested, int n_tasks) {
  if (n_tasks <= 1) {
    return 1;
  }
  if (requested < 1) {
    requested = 1;
  }
  return (requested > n_tasks) ? n_tasks : requested;
}
#endif

inline int safe_varyfor(double frac, int max_iter) {
  if (max_iter <= 0) {
    return 1;
  }
  int out = static_cast<int>(std::floor(frac * static_cast<double>(max_iter)));
  if (out < 1) {
    out = 1;
  }
  return out;
}

class r_rng_scope_manual {
public:
  r_rng_scope_manual() { GetRNGstate(); }
  ~r_rng_scope_manual() { PutRNGstate(); }
};

inline int normalize_kernel_mode(int mode) {
  if (mode == PSO_KERNEL_GLOBPSO_EXACT) {
    return PSO_KERNEL_GLOBPSO_EXACT;
  }
  return PSO_KERNEL_STABLE;
}

inline arma::mat exact_randu_mat(int n_rows, int n_cols) {
  return arma::randu<arma::mat>(n_rows, n_cols);
}


inline double exact_randu_scalar() {
  return arma::randu<double>();
}

}  // namespace

bool ctgp_openmp_compiled() {
#ifdef _OPENMP
  return true;
#else
  return false;
#endif
}

int ctgp_openmp_max_threads_runtime() {
#ifdef _OPENMP
  return omp_get_max_threads();
#else
  return 1;
#endif
}

int ctgp_openmp_resolve_threads(bool use_openmp, int requested_threads, int n_tasks) {
#ifdef _OPENMP
  if (!use_openmp) {
    return 1;
  }
  const int max_threads = omp_get_max_threads();
  const int requested = (requested_threads > 0) ? requested_threads : max_threads;
  return clamp_threads(requested, n_tasks);
#else
  (void)use_openmp;
  (void)requested_threads;
  (void)n_tasks;
  return 1;
#endif
}

int ctgp_openmp_recommended_threads(int n_tasks) {
#ifdef _OPENMP
  return clamp_threads(omp_get_max_threads(), n_tasks);
#else
  (void)n_tasks;
  return 1;
#endif
}

std::string ctgp_internal_pso_kernel_mode_label(int mode) {
  mode = normalize_kernel_mode(mode);
  if (mode == PSO_KERNEL_GLOBPSO_EXACT) {
    return "globpso_exact";
  }
  return "qpso";
}

int ctgp_internal_pso_kernel_mode_from_option(int fallback) {
  fallback = normalize_kernel_mode(fallback);
  try {
    Rcpp::Function get_option("getOption");
    Rcpp::RObject mode_obj = get_option(
      "ctGP.internal.debug.optimizer_mode",
      Rcpp::wrap(ctgp_internal_pso_kernel_mode_label(fallback))
    );
    if (mode_obj.isNULL()) {
      return fallback;
    }

    if (TYPEOF(mode_obj) == INTSXP || TYPEOF(mode_obj) == REALSXP) {
      return normalize_kernel_mode(Rcpp::as<int>(mode_obj));
    }

    std::string mode = Rcpp::as<std::string>(mode_obj);
    if (mode == "globpso_exact" || mode == "qpso_exact") {
      return PSO_KERNEL_GLOBPSO_EXACT;
    }
    if (mode == "stable" || mode == "qpso") {
      return PSO_KERNEL_STABLE;
    }
  } catch (...) {
    return fallback;
  }
  return fallback;
}

pso_optimizer::pso_optimizer(const pso_control& control)
  : control_(control),
    use_internal_seed_(false),
    rng_(std::mt19937_64::result_type(0)) {
#ifdef _OPENMP
  if (control_.kernel_mode < 0) {
    if (omp_in_parallel()) {
      control_.kernel_mode = PSO_KERNEL_STABLE;
    } else {
      control_.kernel_mode = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);
    }
  } else {
    control_.kernel_mode = normalize_kernel_mode(control_.kernel_mode);
  }
#else
  control_.kernel_mode = (control_.kernel_mode < 0)
    ? ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE)
    : normalize_kernel_mode(control_.kernel_mode);
#endif
}

arma::mat pso_optimizer::random_uniform_matrix(int n_rows, int n_cols) {
  if (!use_internal_seed_) {
    return arma::randu<arma::mat>(n_rows, n_cols);
  }

  arma::mat out(n_rows, n_cols);
  std::uniform_real_distribution<double> dist(0.0, 1.0);
  for (int j = 0; j < n_cols; ++j) {
    for (int i = 0; i < n_rows; ++i) {
      out(i, j) = dist(rng_);
    }
  }
  return out;
}

arma::vec pso_optimizer::random_uniform_vector(int n) {
  if (!use_internal_seed_) {
    return arma::randu<arma::vec>(n);
  }

  arma::vec out(n, arma::fill::zeros);
  std::uniform_real_distribution<double> dist(0.0, 1.0);
  for (int i = 0; i < n; ++i) {
    out(i) = dist(rng_);
  }
  return out;
}

double pso_optimizer::random_uniform_scalar() {
  if (!use_internal_seed_) {
    return arma::as_scalar(arma::randu<arma::vec>(1));
  }
  std::uniform_real_distribution<double> dist(0.0, 1.0);
  return dist(rng_);
}

arma::vec pso_optimizer::clamp_vector(
    const arma::vec& x,
    const arma::vec& lower,
    const arma::vec& upper
) const {
  arma::vec out = x;
  for (arma::uword j = 0; j < out.n_elem; ++j) {
    if (out(j) < lower(j)) out(j) = lower(j);
    if (out(j) > upper(j)) out(j) = upper(j);
  }
  return out;
}

arma::mat pso_optimizer::initialize_swarm(
    int n_particles,
    int dim,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init_center
) {
  arma::mat swarm = random_uniform_matrix(n_particles, dim);
  const arma::vec span = upper - lower;
  for (int j = 0; j < dim; ++j) {
    swarm.col(j) = lower(j) + span(j) * swarm.col(j);
  }

  if (static_cast<int>(init_center.n_elem) == dim && n_particles >= 1) {
    swarm.row(0) = clamp_vector(init_center, lower, upper).t();
  }

  return swarm;
}

arma::mat pso_optimizer::initialize_velocity(
    int n_particles,
    int dim,
    const arma::vec& lower,
    const arma::vec& upper
) {
  (void)lower;
  (void)upper;
  return arma::mat(n_particles, dim, arma::fill::zeros);
}

int pso_optimizer::effective_num_threads(int n_tasks) const {
  if (control_.kernel_mode == PSO_KERNEL_GLOBPSO_EXACT) {
    return 1;
  }
  return ctgp_openmp_resolve_threads(control_.use_openmp, control_.num_threads, n_tasks);
}

void pso_optimizer::clamp_particles(
    arma::mat& swarm,
    const arma::vec& lower,
    const arma::vec& upper
) {
  const int n_particles = static_cast<int>(swarm.n_rows);
  const int dim = static_cast<int>(swarm.n_cols);
  if (n_particles <= 0 || dim <= 0) {
    return;
  }

  arma::mat var_ub = arma::repmat(upper.t(), n_particles, 1);
  arma::mat var_lb = arma::repmat(lower.t(), n_particles, 1);

  arma::uvec idx_upper = arma::find(swarm > var_ub);
  if (!idx_upper.is_empty()) {
    arma::mat tmp = arma::pow(random_uniform_matrix(n_particles, dim), 5e-2) % (var_ub - var_lb) + var_lb;
    arma::mat coin = random_uniform_matrix(n_particles, dim);
    arma::uvec coin_idx = arma::find(coin > 0.5);
    if (!coin_idx.is_empty()) {
      tmp.elem(coin_idx) = var_ub.elem(coin_idx);
    }
    swarm.elem(idx_upper) = tmp.elem(idx_upper);
  }

  arma::uvec idx_lower = arma::find(swarm < var_lb);
  if (!idx_lower.is_empty()) {
    arma::mat tmp = (1.0 - arma::pow(1.0 - random_uniform_matrix(n_particles, dim), 5e-2)) % (var_ub - var_lb) + var_lb;
    arma::mat coin = random_uniform_matrix(n_particles, dim);
    arma::uvec coin_idx = arma::find(coin > 0.5);
    if (!coin_idx.is_empty()) {
      tmp.elem(coin_idx) = var_lb.elem(coin_idx);
    }
    swarm.elem(idx_lower) = tmp.elem(idx_lower);
  }
}

void pso_optimizer::evaluate_swarm(
    objective_base& obj,
    const arma::mat& swarm,
    arma::vec& values
) const {
  const int n_particles = static_cast<int>(swarm.n_rows);
  values.set_size(n_particles);

#ifdef _OPENMP
  const int n_threads = effective_num_threads(n_particles);
  if (n_threads > 1) {
    std::atomic<bool> had_error(false);
    std::string error_message;
#pragma omp parallel for schedule(static) num_threads(n_threads)
    for (int i = 0; i < n_particles; ++i) {
      if (had_error.load(std::memory_order_relaxed)) {
        continue;
      }
      try {
        arma::vec xi = swarm.row(i).t();
        values(i) = obj.eval(xi);
      } catch (const std::exception& e) {
#pragma omp critical(pso_eval_error)
        {
          if (!had_error.load(std::memory_order_relaxed)) {
            error_message = e.what();
            had_error.store(true, std::memory_order_relaxed);
          }
        }
      } catch (...) {
#pragma omp critical(pso_eval_error)
        {
          if (!had_error.load(std::memory_order_relaxed)) {
            error_message = "Unknown exception thrown inside objective_base::eval().";
            had_error.store(true, std::memory_order_relaxed);
          }
        }
      }
    }
    if (had_error.load(std::memory_order_relaxed)) {
      Rcpp::stop(error_message);
    }
    return;
  }
#endif

  for (int i = 0; i < n_particles; ++i) {
    arma::vec xi = swarm.row(i).t();
    values(i) = obj.eval(xi);
  }
}

optim_result pso_optimizer::minimize_globpso_exact(
    objective_base& obj,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init_center
) {
  const int dim = static_cast<int>(lower.n_elem);
  const int n_particles = control_.swarm_size;

  if (control_.seed >= 0) {
    Rcpp::Function set_seed("set.seed");
    set_seed(control_.seed);
  }

  r_rng_scope_manual rng_scope;

  const arma::rowvec var_upper = upper.t();
  const arma::rowvec var_lower = lower.t();
  const arma::mat var_upper_mat = arma::repmat(var_upper, n_particles, 1);
  const arma::mat var_lower_mat = arma::repmat(var_lower, n_particles, 1);

  arma::mat swarm = exact_randu_mat(n_particles, dim) % (var_upper_mat - var_lower_mat) + var_lower_mat;
  if (static_cast<int>(init_center.n_elem) == dim && n_particles >= 1) {
    swarm.row(0) = init_center.t();
  }

  arma::mat v_step(n_particles, dim, arma::fill::zeros);
  const arma::rowvec vel_max = (upper - lower).t() / std::max(1.0, control_.vk);
  const arma::mat vel_max_mat = arma::repmat(vel_max, n_particles, 1);

  arma::vec f_swarm(n_particles, arma::fill::zeros);
  for (int i = 0; i < n_particles; ++i) {
    f_swarm(i) = obj.eval(swarm.row(i).t());
  }

  arma::mat p_best = swarm;
  arma::vec f_pbest = f_swarm;
  arma::uword gbest_idx = f_pbest.index_min();

  optim_result out;
  out.best_par = p_best.row(gbest_idx).t();
  out.best_value = f_pbest(gbest_idx);
  out.history = arma::vec(std::max(1, control_.max_iter + 1), arma::fill::zeros);
  out.history(0) = out.best_value;
  out.n_eval += n_particles;

  if (control_.max_iter == 0) {
    out.converged = true;
    return out;
  }

  const int w_varyfor = static_cast<int>(control_.w_var * static_cast<double>(control_.max_iter));
  double w_cur = control_.w0;
  const double w_dec = (w_varyfor > 0) ? ((control_.w0 - control_.w1) / static_cast<double>(w_varyfor)) : 0.0;

  const int q_a_varyfor = static_cast<int>(control_.q_a_var * static_cast<double>(control_.max_iter));
  double q_a_cur = control_.q_a0;
  const double q_a_dec = (q_a_varyfor > 0) ? ((control_.q_a0 - control_.q_a1) / static_cast<double>(q_a_varyfor)) : 0.0;

  for (int iter = 0; iter < control_.max_iter; ++iter) {
    const arma::rowvec gbest_row = out.best_par.t();
    const arma::mat gbest_mat = arma::repmat(gbest_row, n_particles, 1);

    if (control_.quantum) {
      arma::mat r1 = exact_randu_mat(n_particles, dim);
      arma::mat r2 = exact_randu_mat(n_particles, dim);
      arma::mat phi = (control_.c1 * r1) / (control_.c1 * r1 + control_.c2 * r2);
      arma::mat pm = phi % p_best + (1.0 - phi) % gbest_mat;

      arma::mat quantum_move;
      if (control_.q_center_type == 0) {
        quantum_move = q_a_cur * arma::abs(pm - swarm) % arma::log(1.0 / exact_randu_mat(n_particles, dim));
      } else {
        arma::mat mbest = arma::repmat(arma::sum(p_best, 0) / static_cast<double>(n_particles), n_particles, 1);
        quantum_move = q_a_cur * arma::abs(mbest - swarm) % arma::log(1.0 / exact_randu_mat(n_particles, dim));
      }

      arma::mat dice = exact_randu_mat(n_particles, dim);
      swarm = pm;
      arma::uvec plus_idx = arma::find(dice > 0.5);
      arma::uvec minus_idx = arma::find(dice <= 0.5);
      if (!plus_idx.is_empty()) {
        swarm.elem(plus_idx) += quantum_move.elem(plus_idx);
      }
      if (!minus_idx.is_empty()) {
        swarm.elem(minus_idx) -= quantum_move.elem(minus_idx);
      }
    } else {
      v_step = w_cur * v_step
        + control_.c1 * exact_randu_mat(n_particles, dim) % (p_best - swarm)
        + control_.c2 * exact_randu_mat(n_particles, dim) % (gbest_mat - swarm);
      v_step = arma::min(v_step, vel_max_mat);
      v_step = arma::max(v_step, (-1.0) * vel_max_mat);
      swarm += v_step;
    }

    arma::uvec swarm_change = arma::find(swarm > var_upper_mat);
    arma::mat swarm_tmp1 = arma::pow(exact_randu_mat(n_particles, dim), 5e-2) % (var_upper_mat - var_lower_mat) + var_lower_mat;
    for (int i = 0; i < n_particles; ++i) {
      for (int j = 0; j < dim; ++j) {
        double coin = exact_randu_scalar();
        if (coin > 0.5) {
          swarm_tmp1(i, j) = var_upper_mat(i, j);
        }
      }
    }
    if (!swarm_change.is_empty()) {
      swarm.elem(swarm_change) = swarm_tmp1.elem(swarm_change);
    }

    swarm_change = arma::find(swarm < var_lower_mat);
    swarm_tmp1 = (1.0 - arma::pow(1.0 - exact_randu_mat(n_particles, dim), 5e-2)) % (var_upper_mat - var_lower_mat) + var_lower_mat;
    for (int i = 0; i < n_particles; ++i) {
      for (int j = 0; j < dim; ++j) {
        double coin = exact_randu_scalar();
        if (coin > 0.5) {
          swarm_tmp1(i, j) = var_lower_mat(i, j);
        }
      }
    }
    if (!swarm_change.is_empty()) {
      swarm.elem(swarm_change) = swarm_tmp1.elem(swarm_change);
    }

    for (int i = 0; i < n_particles; ++i) {
      f_swarm(i) = obj.eval(swarm.row(i).t());
    }
    out.n_eval += n_particles;

    if (arma::any(f_swarm < f_pbest)) {
      arma::uvec row_change = arma::find(f_swarm < f_pbest);
      f_pbest.elem(row_change) = f_swarm.elem(row_change);
      p_best.rows(row_change) = swarm.rows(row_change);
    }
    if (arma::min(f_pbest) < out.best_value) {
      gbest_idx = f_pbest.index_min();
      out.best_value = f_pbest(gbest_idx);
      out.best_par = p_best.row(gbest_idx).t();
    }

    out.history(iter + 1) = out.best_value;

    if (iter > static_cast<int>(control_.free_run * static_cast<double>(control_.max_iter))) {
      if (std::abs(out.best_value - out.history(iter)) < control_.tol) {
        out.history.subvec(iter + 1, control_.max_iter).fill(out.best_value);
        out.converged = true;
        break;
      }
    }

    if (w_varyfor > 0 && iter <= w_varyfor) {
      w_cur -= w_dec;
    }
    if (control_.quantum && q_a_varyfor > 0 && iter <= q_a_varyfor) {
      q_a_cur -= q_a_dec;
    }
  }

  return out;
}

optim_result pso_optimizer::minimize(
    objective_base& obj,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init_center
) {
  const int dim = static_cast<int>(lower.n_elem);
  const int n_particles = control_.swarm_size;

  if (dim <= 0) {
    Rcpp::stop("lower must be non-empty.");
  }
  if (static_cast<int>(upper.n_elem) != dim) {
    Rcpp::stop("lower and upper must have the same length.");
  }
  if (n_particles <= 0) {
    Rcpp::stop("swarm_size must be positive.");
  }
  if (control_.max_iter < 0) {
    Rcpp::stop("max_iter must be nonnegative.");
  }

  if (control_.kernel_mode == PSO_KERNEL_GLOBPSO_EXACT) {
    return minimize_globpso_exact(obj, lower, upper, init_center);
  }

  use_internal_seed_ = (control_.seed >= 0);
  if (use_internal_seed_) {
    rng_.seed(static_cast<std::mt19937_64::result_type>(control_.seed));
  }

  arma::mat swarm = initialize_swarm(n_particles, dim, lower, upper, init_center);
  arma::mat velocity = initialize_velocity(n_particles, dim, lower, upper);
  const arma::vec span = upper - lower;
  arma::rowvec vel_max = (span / std::max(1.0, control_.vk)).t();

  arma::mat pbest = swarm;
  arma::vec pbest_val(n_particles, arma::fill::zeros);
  arma::vec current_val(n_particles, arma::fill::zeros);

  optim_result out;
  out.history.set_size(std::max(1, control_.max_iter + 1));

  evaluate_swarm(obj, swarm, current_val);
  out.n_eval += n_particles;

  pbest_val = current_val;
  arma::uword best_idx = current_val.index_min();
  out.best_value = current_val(best_idx);
  out.best_par = swarm.row(best_idx).t();
  out.history(0) = out.best_value;

  if (control_.max_iter == 0) {
    out.converged = true;
    return out;
  }

  const int w_varyfor = safe_varyfor(control_.w_var, control_.max_iter);
  const int q_a_varyfor = safe_varyfor(control_.q_a_var, control_.max_iter);
  double w_cur = control_.w0;
  const double w_dec = (control_.w0 - control_.w1) / static_cast<double>(w_varyfor);
  double q_a_cur = control_.q_a0;
  const double q_a_dec = (control_.q_a0 - control_.q_a1) / static_cast<double>(q_a_varyfor);

  int last_hist_idx = 0;

  for (int iter = 0; iter < control_.max_iter; ++iter) {
    arma::rowvec gbest_row = out.best_par.t();
    arma::mat gbest_mat = arma::repmat(gbest_row, n_particles, 1);

    if (control_.quantum) {
      arma::mat r1 = random_uniform_matrix(n_particles, dim);
      arma::mat r2 = random_uniform_matrix(n_particles, dim);
      arma::mat denom = control_.c1 * r1 + control_.c2 * r2;
      denom.elem(arma::find(denom <= std::numeric_limits<double>::epsilon())).fill(std::numeric_limits<double>::epsilon());
      arma::mat phi = (control_.c1 * r1) / denom;
      arma::mat pm = phi % pbest + (1.0 - phi) % gbest_mat;

      arma::mat qmove;
      if (control_.q_center_type == 0) {
        arma::mat u = random_uniform_matrix(n_particles, dim);
        u.elem(arma::find(u <= std::numeric_limits<double>::epsilon())).fill(std::numeric_limits<double>::epsilon());
        qmove = q_a_cur * arma::abs(pm - swarm) % arma::log(1.0 / u);
      } else {
        arma::rowvec mbest_row = arma::sum(pbest, 0) / static_cast<double>(n_particles);
        arma::mat mbest = arma::repmat(mbest_row, n_particles, 1);
        arma::mat u = random_uniform_matrix(n_particles, dim);
        u.elem(arma::find(u <= std::numeric_limits<double>::epsilon())).fill(std::numeric_limits<double>::epsilon());
        qmove = q_a_cur * arma::abs(mbest - swarm) % arma::log(1.0 / u);
      }

      arma::mat dice = random_uniform_matrix(n_particles, dim);
      swarm = pm;
      arma::uvec plus_idx = arma::find(dice > 0.5);
      arma::uvec minus_idx = arma::find(dice <= 0.5);
      if (!plus_idx.is_empty()) {
        swarm.elem(plus_idx) += qmove.elem(plus_idx);
      }
      if (!minus_idx.is_empty()) {
        swarm.elem(minus_idx) -= qmove.elem(minus_idx);
      }
    } else {
      arma::mat r1 = random_uniform_matrix(n_particles, dim);
      arma::mat r2 = random_uniform_matrix(n_particles, dim);
      arma::mat vel_max_mat = arma::repmat(vel_max, n_particles, 1);
      velocity = w_cur * velocity
        + control_.c1 * (r1 % (pbest - swarm))
        + control_.c2 * (r2 % (gbest_mat - swarm));
      velocity = arma::min(velocity, vel_max_mat);
      velocity = arma::max(velocity, -vel_max_mat);
      swarm += velocity;
    }

    clamp_particles(swarm, lower, upper);

    evaluate_swarm(obj, swarm, current_val);
    out.n_eval += n_particles;

    for (int i = 0; i < n_particles; ++i) {
      if (current_val(i) < pbest_val(i)) {
        pbest_val(i) = current_val(i);
        pbest.row(i) = swarm.row(i);
      }
    }

    arma::uword iter_best_idx = pbest_val.index_min();
    if (pbest_val(iter_best_idx) < out.best_value) {
      out.best_value = pbest_val(iter_best_idx);
      out.best_par = pbest.row(iter_best_idx).t();
    }

    last_hist_idx = iter + 1;
    out.history(last_hist_idx) = out.best_value;

    if (iter > static_cast<int>(control_.free_run * static_cast<double>(control_.max_iter))) {
      const double prev_best = out.history(iter);
      if (std::isfinite(prev_best) && std::isfinite(out.best_value) && std::abs(out.best_value - prev_best) < control_.tol) {
        for (int k = last_hist_idx + 1; k <= control_.max_iter; ++k) {
          out.history(k) = out.best_value;
        }
        out.converged = true;
        last_hist_idx = control_.max_iter;
        break;
      }
    }

    if (w_varyfor > 0 && iter <= w_varyfor) {
      w_cur -= w_dec;
    }
    if (control_.quantum && q_a_varyfor > 0 && iter <= q_a_varyfor) {
      q_a_cur -= q_a_dec;
    }
  }

  if (last_hist_idx + 1 < static_cast<int>(out.history.n_elem)) {
    out.history.resize(last_hist_idx + 1);
  }

  return out;
}
