.ctgp_trace_or <- function(x, y) {
  if (is.null(x) || length(x) == 0L) return(y)
  if (length(x) == 1L && is.na(x)) return(y)
  x
}

.ctgp_trace_collapse <- function(x, sep = ";") {
  if (is.null(x) || length(x) < 1L) return(NA_character_)
  paste(as.character(x), collapse = sep)
}

.ctgp_trace_sig_collapse <- function(x) {
  if (is.null(x) || length(x) < 1L) return(NA_character_)
  paste(as.character(x), collapse = "+")
}

.ctgp_tree_node_signature_map <- function(tree) {
  sig_map <- list()
  rec <- function(node) {
    if (isTRUE(node$is_leaf)) {
      sig <- paste0("L(", paste(sort(as.integer(node$combined_ids)), collapse = "+"), ")")
    } else {
      split_var <- if (is.null(node$split_var) || !length(node$split_var)) NA_character_ else as.character(node$split_var[[1L]])
      left_levels <- paste(sort(as.character(.ctgp_trace_or(node$left_levels, character()))), collapse = "+")
      right_levels <- paste(sort(as.character(.ctgp_trace_or(node$right_levels, character()))), collapse = "+")
      split_pair <- sort(c(left_levels, right_levels))
      child_sigs <- sort(c(rec(node$left), rec(node$right)))
      sig <- paste0(
        "N(", split_var, "{", split_pair[1L], "|", split_pair[2L], "}:",
        child_sigs[1L], ";", child_sigs[2L], ")"
      )
    }
    sig_map[[as.character(node$node_id)]] <<- sig
    sig
  }
  rec(tree)
  sig_map
}

.ctgp_tree_signature <- function(tree) {
  if (is.null(tree) || !is.list(tree) || is.null(tree$node_id)) return(NA_character_)
  sig_map <- .ctgp_tree_node_signature_map(tree)
  key <- as.character(tree$node_id[[1L]])
  out <- sig_map[[key]]
  if (is.null(out) || !length(out)) NA_character_ else as.character(out[[1L]])
}

.ctgp_tree_collect_trace_nodes <- function(tree) {
  rows <- list()
  combined_list <- list()
  left_levels_list <- list()
  right_levels_list <- list()

  rec <- function(node) {
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = as.integer(node$node_id),
      parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
      depth = as.integer(node$depth),
      is_leaf = isTRUE(node$is_leaf),
      left_id = if (!isTRUE(node$is_leaf) && !is.null(node$left)) as.integer(node$left$node_id) else NA_integer_,
      right_id = if (!isTRUE(node$is_leaf) && !is.null(node$right)) as.integer(node$right$node_id) else NA_integer_,
      split_var = if (is.null(node$split_var) || !length(node$split_var)) NA_character_ else as.character(node$split_var[[1L]]),
      score = if (is.null(node$score) || !length(node$score)) NA_real_ else as.numeric(node$score[[1L]]),
      n_rows = if (is.null(node$n_rows) || !length(node$n_rows)) NA_integer_ else as.integer(node$n_rows[[1L]]),
      n_combined = as.integer(length(.ctgp_trace_or(node$combined_ids, integer()))),
      reason = if (is.null(node$reason) || !length(node$reason)) NA_character_ else as.character(node$reason[[1L]]),
      leaf_model = if (is.null(node$leaf_model) || !length(node$leaf_model)) NA_character_ else as.character(node$leaf_model[[1L]]),
      stringsAsFactors = FALSE
    )
    combined_list[[length(combined_list) + 1L]] <<- sort(as.integer(.ctgp_trace_or(node$combined_ids, integer())))
    left_levels_list[[length(left_levels_list) + 1L]] <<- sort(as.character(.ctgp_trace_or(node$left_levels, character())))
    right_levels_list[[length(right_levels_list) + 1L]] <<- sort(as.character(.ctgp_trace_or(node$right_levels, character())))
    if (!isTRUE(node$is_leaf)) {
      rec(node$left)
      rec(node$right)
    }
  }

  rec(tree)
  out <- do.call(rbind, rows)
  out$combined_ids <- I(combined_list)
  out$left_levels <- I(left_levels_list)
  out$right_levels <- I(right_levels_list)
  out <- out[order(out$depth, out$node_id), , drop = FALSE]
  rownames(out) <- NULL

  sig_map <- .ctgp_tree_node_signature_map(tree)
  get_sig <- function(id) {
    key <- as.character(id)
    val <- sig_map[[key]]
    if (is.null(val) || !length(val)) NA_character_ else as.character(val[[1L]])
  }

  out$node_signature <- vapply(out$node_id, get_sig, character(1L))
  out$left_signature <- vapply(out$left_id, get_sig, character(1L))
  out$right_signature <- vapply(out$right_id, get_sig, character(1L))
  out$combined_ids_chr <- vapply(out$combined_ids, .ctgp_trace_sig_collapse, character(1L))
  out$left_levels_chr <- vapply(out$left_levels, .ctgp_trace_sig_collapse, character(1L))
  out$right_levels_chr <- vapply(out$right_levels, .ctgp_trace_sig_collapse, character(1L))
  out
}

.ctgp_tree_leaf_partition_signature <- function(tree) {
  if (is.null(tree) || !is.list(tree) || is.null(tree$node_id)) return(NA_character_)
  node_meta <- .ctgp_tree_collect_trace_nodes(tree)
  if (nrow(node_meta) < 1L) return(NA_character_)
  leaf_parts <- as.character(node_meta$combined_ids_chr[as.logical(node_meta$is_leaf)])
  leaf_parts <- leaf_parts[!is.na(leaf_parts)]
  if (!length(leaf_parts)) NA_character_ else paste(sort(leaf_parts), collapse = " / ")
}

.ctgp_prune_trace_loocv_df <- function(tree, loocv_summary) {
  if (is.null(loocv_summary) || length(loocv_summary) < 1L) {
    return(data.frame())
  }

  node_meta <- .ctgp_tree_collect_trace_nodes(tree)

  if (is.atomic(loocv_summary) && is.null(dim(loocv_summary))) {
    vals <- as.numeric(loocv_summary)
    nm <- names(loocv_summary)
    if (!is.null(nm) && length(nm) == length(vals)) {
      suppressWarnings(node_ids <- as.integer(nm))
      if (all(!is.na(node_ids))) {
        out <- data.frame(node_id = node_ids, loocv_value = vals, stringsAsFactors = FALSE)
        rownames(out) <- NULL
        return(out)
      }
    }
    if (length(vals) != nrow(node_meta)) {
      stop("Vector LOOCV summary length does not match the number of nodes in the supplied tree.")
    }
    out <- data.frame(node_id = node_meta$node_id, loocv_value = vals, stringsAsFactors = FALSE)
    rownames(out) <- NULL
    return(out)
  }

  out <- as.data.frame(loocv_summary, stringsAsFactors = FALSE)
  if (nrow(out) < 1L) {
    return(out)
  }
  if (all(c("node_id", "loocv_value") %in% names(out))) {
    rownames(out) <- NULL
    return(out)
  }
  if (ncol(out) == 1L) {
    if (nrow(out) != nrow(node_meta)) {
      stop("Single-column LOOCV summary does not match the number of nodes in the supplied tree.")
    }
    one_col <- names(out)[1L]
    out <- data.frame(node_id = node_meta$node_id, loocv_value = as.numeric(out[[one_col]]), stringsAsFactors = FALSE)
    rownames(out) <- NULL
    return(out)
  }
  stop("Unsupported LOOCV summary format. Expected a numeric vector or a data frame with node_id / loocv_value columns.")
}

.ctgp_prune_trace_loocv_map <- function(tree, loocv_summary) {
  loocv_df <- .ctgp_prune_trace_loocv_df(tree, loocv_summary)
  if (nrow(loocv_df) < 1L) {
    return(stats::setNames(numeric(), character()))
  }
  stats::setNames(as.numeric(loocv_df$loocv_value), as.character(loocv_df$node_id))
}

.ctgp_prune_trace_node_table <- function(tree, loocv_summary = NULL) {
  node_meta <- .ctgp_tree_collect_trace_nodes(tree)
  if (is.null(loocv_summary) || length(loocv_summary) < 1L) {
    rownames(node_meta) <- NULL
    return(node_meta)
  }
  loocv_df <- .ctgp_prune_trace_loocv_df(tree, loocv_summary)
  if (nrow(loocv_df) < 1L) {
    rownames(node_meta) <- NULL
    return(node_meta)
  }
  out <- node_meta
  idx <- match(out$node_id, loocv_df$node_id)
  extra_cols <- setdiff(names(loocv_df), names(out))
  for (nm in extra_cols) {
    out[[nm]] <- loocv_df[[nm]][idx]
  }
  rownames(out) <- NULL
  out
}

.ctgp_prune_trace_deactivate_subtree <- function(idx, left_idx, right_idx, active) {
  if (length(idx) != 1L || is.na(idx) || idx < 1L) return(active)
  rec <- function(j) {
    if (length(j) != 1L || is.na(j) || j < 1L) return(invisible(NULL))
    active[j] <<- FALSE
    rec(left_idx[j])
    rec(right_idx[j])
    invisible(NULL)
  }
  rec(idx)
  active
}

.ctgp_prune_trace_state_signature <- function(node_meta, active, leaf_state) {
  idx_map <- stats::setNames(seq_len(nrow(node_meta)), as.character(node_meta$node_id))
  root_idx <- which(is.na(node_meta$parent_id))[1L]
  if (!length(root_idx) || is.na(root_idx)) {
    return(list(tree_signature = NA_character_, leaf_partition_signature = NA_character_, final_leaf_count = 0L))
  }

  rec <- function(idx) {
    if (!isTRUE(active[idx])) return(NULL)
    if (isTRUE(leaf_state[idx])) {
      return(paste0("L(", node_meta$combined_ids_chr[idx], ")"))
    }
    li <- idx_map[[as.character(node_meta$left_id[idx])]]
    ri <- idx_map[[as.character(node_meta$right_id[idx])]]
    left_sig <- rec(li)
    right_sig <- rec(ri)
    child_sigs <- sort(c(left_sig, right_sig))
    split_pair <- sort(c(
      if (is.na(node_meta$left_levels_chr[idx])) "" else node_meta$left_levels_chr[idx],
      if (is.na(node_meta$right_levels_chr[idx])) "" else node_meta$right_levels_chr[idx]
    ))
    paste0(
      "N(", node_meta$split_var[idx], "{", split_pair[1L], "|", split_pair[2L], "}:",
      child_sigs[1L], ";", child_sigs[2L], ")"
    )
  }

  leaf_parts <- node_meta$combined_ids_chr[active & leaf_state]
  leaf_parts <- as.character(leaf_parts)
  leaf_parts <- leaf_parts[!is.na(leaf_parts)]
  list(
    tree_signature = rec(root_idx),
    leaf_partition_signature = if (length(leaf_parts) < 1L) NA_character_ else paste(sort(leaf_parts), collapse = " / "),
    final_leaf_count = as.integer(sum(active & leaf_state))
  )
}

.ctgp_prune_trace_enrich_log <- function(log_df,
                                         tree,
                                         loocv_summary = NULL,
                                         source = NA_character_) {
  if (is.null(log_df)) return(data.frame())
  out <- as.data.frame(log_df, stringsAsFactors = FALSE)
  if (nrow(out) < 1L) {
    rownames(out) <- NULL
    return(out)
  }

  if (!"prune_pass" %in% names(out)) {
    if ("pass" %in% names(out)) {
      out$prune_pass <- as.integer(out$pass)
    } else {
      out$prune_pass <- rep.int(1L, nrow(out))
    }
  } else {
    out$prune_pass <- as.integer(out$prune_pass)
  }
  if (!"traversal_order" %in% names(out)) {
    out$traversal_order <- ave(seq_len(nrow(out)), out$prune_pass, FUN = seq_along)
  } else {
    out$traversal_order <- as.integer(out$traversal_order)
  }
  if (!"traversal_order_global" %in% names(out)) {
    out$traversal_order_global <- seq_len(nrow(out))
  } else {
    out$traversal_order_global <- as.integer(out$traversal_order_global)
  }

  if (!"trace_source" %in% names(out)) {
    out$trace_source <- rep(as.character(source), nrow(out))
  } else {
    fill_idx <- is.na(out$trace_source) | !nzchar(as.character(out$trace_source))
    out$trace_source[fill_idx] <- as.character(source)
  }

  node_table <- .ctgp_prune_trace_node_table(tree, loocv_summary)
  parent_idx <- match(out$parent_node_id, node_table$node_id)
  left_idx <- if ("left_node_id" %in% names(out)) match(out$left_node_id, node_table$node_id) else rep.int(NA_integer_, nrow(out))
  right_idx <- if ("right_node_id" %in% names(out)) match(out$right_node_id, node_table$node_id) else rep.int(NA_integer_, nrow(out))

  fill_missing <- function(name, values) {
    if (!(name %in% names(out))) {
      out[[name]] <<- values
      return(invisible(NULL))
    }
    idx <- is.na(out[[name]])
    out[[name]][idx] <<- values[idx]
    invisible(NULL)
  }

  map_field <- function(field, idx, default = NA) {
    if (!(field %in% names(node_table))) return(rep(default, nrow(out)))
    node_table[[field]][idx]
  }

  fill_missing("parent_loocv", as.numeric(map_field("loocv_value", parent_idx, NA_real_)))
  fill_missing("left_loocv", as.numeric(map_field("loocv_value", left_idx, NA_real_)))
  fill_missing("right_loocv", as.numeric(map_field("loocv_value", right_idx, NA_real_)))

  if (!"separate_loocv" %in% names(out)) {
    out$separate_loocv <- as.numeric(out$left_loocv) + as.numeric(out$right_loocv)
  }
  if (!"improvement" %in% names(out)) {
    out$improvement <- as.numeric(out$separate_loocv) - as.numeric(out$parent_loocv)
  }
  if (!"delta" %in% names(out)) {
    out$delta <- as.numeric(out$parent_loocv) - as.numeric(out$separate_loocv)
  }
  if (!"decision_margin_abs" %in% names(out)) {
    out$decision_margin_abs <- abs(as.numeric(out$delta))
  }
  if (!"decision" %in% names(out) && "pruned" %in% names(out)) {
    out$decision <- ifelse(as.logical(out$pruned), "merge", "keep")
  }
  if (!"pruned" %in% names(out) && "decision" %in% names(out)) {
    out$pruned <- tolower(as.character(out$decision)) %in% c("merge", "prune", "combined")
  }

  ord <- order(out$parent_node_id, out$prune_pass, out$traversal_order, out$traversal_order_global)
  if (!"node_eval_index" %in% names(out)) {
    eval_idx <- integer(nrow(out))
    if (length(ord) > 0L) {
      tmp_parent <- out$parent_node_id[ord]
      split_idx <- split(seq_along(ord), tmp_parent)
      tmp_eval <- integer(length(ord))
      for (ids in split_idx) tmp_eval[ids] <- seq_along(ids)
      eval_idx[ord] <- tmp_eval
    }
    out$node_eval_index <- as.integer(eval_idx)
  } else {
    out$node_eval_index <- as.integer(out$node_eval_index)
  }

  fill_missing("node_signature", as.character(map_field("node_signature", parent_idx, NA_character_)))
  fill_missing("left_signature", as.character(map_field("node_signature", left_idx, NA_character_)))
  fill_missing("right_signature", as.character(map_field("node_signature", right_idx, NA_character_)))
  fill_missing("parent_combined_ids", as.character(map_field("combined_ids_chr", parent_idx, NA_character_)))
  fill_missing("left_combined_ids", as.character(map_field("combined_ids_chr", left_idx, NA_character_)))
  fill_missing("right_combined_ids", as.character(map_field("combined_ids_chr", right_idx, NA_character_)))

  role_fill <- function(role, idx) {
    prefix <- paste0(role, "_")
    fill_missing(paste0(prefix, "depth"), as.integer(map_field("depth", idx, NA_integer_)))
    fill_missing(paste0(prefix, "original_is_leaf"), as.logical(map_field("is_leaf", idx, NA)))
    fill_missing(paste0(prefix, "n_rows"), as.integer(map_field("n_rows", idx, NA_integer_)))
    fill_missing(paste0(prefix, "n_combined"), as.integer(map_field("n_combined", idx, NA_integer_)))
    fill_missing(paste0(prefix, "reason"), as.character(map_field("reason", idx, NA_character_)))
    fill_missing(paste0(prefix, "split_var"), as.character(map_field("split_var", idx, NA_character_)))
    fill_missing(paste0(prefix, "score"), as.numeric(map_field("score", idx, NA_real_)))
    fill_missing(paste0(prefix, "node_signature"), as.character(map_field("node_signature", idx, NA_character_)))
    fill_missing(paste0(prefix, "left_levels_chr"), as.character(map_field("left_levels_chr", idx, NA_character_)))
    fill_missing(paste0(prefix, "right_levels_chr"), as.character(map_field("right_levels_chr", idx, NA_character_)))
    if ("h_nugget" %in% names(node_table)) fill_missing(paste0(prefix, "h_nugget"), as.numeric(map_field("h_nugget", idx, NA_real_)))
    if ("t_nugget" %in% names(node_table)) fill_missing(paste0(prefix, "t_nugget"), as.numeric(map_field("t_nugget", idx, NA_real_)))
    if ("used_tau" %in% names(node_table)) fill_missing(paste0(prefix, "used_tau"), as.logical(map_field("used_tau", idx, NA)))
    if ("tau_dim" %in% names(node_table)) fill_missing(paste0(prefix, "tau_dim"), as.integer(map_field("tau_dim", idx, NA_integer_)))
    if ("dispatch_regime" %in% names(node_table)) fill_missing(paste0(prefix, "dispatch_regime"), as.character(map_field("dispatch_regime", idx, NA_character_)))
  }
  role_fill("parent", parent_idx)
  role_fill("left", left_idx)
  role_fill("right", right_idx)

  out <- out[order(out$prune_pass, out$traversal_order, out$traversal_order_global, out$parent_node_id), , drop = FALSE]
  rownames(out) <- NULL
  out
}

.ctgp_prune_trace_simulate <- function(tree,
                                       loocv_summary,
                                       prune_tol = 0,
                                       max_passes = 100L,
                                       mode = c("dynamic", "legacy_batch")) {
  mode <- match.arg(mode)
  node_meta <- .ctgp_tree_collect_trace_nodes(tree)
  n <- nrow(node_meta)
  if (n < 1L) {
    empty_df <- data.frame()
    return(list(
      log = empty_df,
      pass_summary = empty_df,
      final_state = empty_df,
      final_tree_signature = NA_character_,
      final_leaf_partition_signature = NA_character_,
      final_leaf_count = 0L,
      n_passes = 0L,
      changed_any = FALSE,
      mode = mode
    ))
  }

  left_idx <- match(node_meta$left_id, node_meta$node_id)
  right_idx <- match(node_meta$right_id, node_meta$node_id)
  loocv_map <- .ctgp_prune_trace_loocv_map(tree, loocv_summary)

  eligible_node <- function(idx, active_state, leaf_state) {
    if (length(idx) != 1L || is.na(idx) || idx < 1L) return(FALSE)
    if (!isTRUE(active_state[idx]) || isTRUE(leaf_state[idx])) return(FALSE)
    li <- left_idx[idx]
    ri <- right_idx[idx]
    if (is.na(li) || is.na(ri) || li < 1L || ri < 1L) return(FALSE)
    isTRUE(active_state[li]) && isTRUE(active_state[ri]) && isTRUE(leaf_state[li]) && isTRUE(leaf_state[ri])
  }

  dynamic_order <- order(-node_meta$depth, node_meta$node_id)
  active <- rep(TRUE, n)
  leaf_state <- as.logical(node_meta$is_leaf)
  node_eval_count <- integer(n)

  log_rows <- list()
  pass_rows <- list()
  global_order <- 0L
  n_passes <- 0L
  changed_any <- FALSE

  for (pass in seq_len(as.integer(max_passes))) {
    start_active <- active
    start_leaf <- leaf_state
    start_candidates <- which(vapply(seq_len(n), eligible_node, logical(1L), active_state = start_active, leaf_state = start_leaf))
    start_candidates <- start_candidates[order(node_meta$node_id[start_candidates])]

    changed <- FALSE
    eval_idx_this_pass <- integer(0)
    late_candidates <- integer(0)
    pruned_idx_this_pass <- integer(0)

    if (identical(mode, "legacy_batch")) {
      candidate_idx <- start_candidates
      if (length(candidate_idx) > 0L) {
        for (ord in seq_along(candidate_idx)) {
          idx <- candidate_idx[[ord]]
          li <- left_idx[idx]
          ri <- right_idx[idx]
          parent_val <- unname(loocv_map[as.character(node_meta$node_id[idx])])
          left_val <- unname(loocv_map[as.character(node_meta$node_id[li])])
          right_val <- unname(loocv_map[as.character(node_meta$node_id[ri])])
          sep_val <- left_val + right_val
          finite_ok <- is.finite(parent_val) && is.finite(sep_val)
          should_prune <- isTRUE(finite_ok) && (parent_val + prune_tol < sep_val)
          node_eval_count[idx] <- node_eval_count[idx] + 1L
          global_order <- global_order + 1L
          eval_idx_this_pass <- c(eval_idx_this_pass, idx)
          if (isTRUE(should_prune)) pruned_idx_this_pass <- c(pruned_idx_this_pass, idx)

          log_rows[[length(log_rows) + 1L]] <- data.frame(
            prune_pass = as.integer(pass),
            traversal_order = as.integer(ord),
            traversal_order_global = as.integer(global_order),
            simulation_mode = mode,
            traversal_rule = "node_id_ascending_batch",
            parent_node_id = as.integer(node_meta$node_id[idx]),
            parent_id = as.integer(node_meta$parent_id[idx]),
            depth = as.integer(node_meta$depth[idx]),
            left_node_id = as.integer(node_meta$node_id[li]),
            right_node_id = as.integer(node_meta$node_id[ri]),
            node_eval_index = as.integer(node_eval_count[idx]),
            node_signature = as.character(node_meta$node_signature[idx]),
            left_signature = as.character(node_meta$left_signature[idx]),
            right_signature = as.character(node_meta$right_signature[idx]),
            parent_combined_ids = as.character(node_meta$combined_ids_chr[idx]),
            left_combined_ids = as.character(node_meta$combined_ids_chr[li]),
            right_combined_ids = as.character(node_meta$combined_ids_chr[ri]),
            parent_loocv = as.numeric(parent_val),
            left_loocv = as.numeric(left_val),
            right_loocv = as.numeric(right_val),
            separate_loocv = as.numeric(sep_val),
            delta = as.numeric(parent_val - sep_val),
            improvement = as.numeric(sep_val - parent_val),
            decision_margin_abs = as.numeric(abs(parent_val - sep_val)),
            finite_ok = isTRUE(finite_ok),
            decision = if (isTRUE(should_prune)) "merge" else "keep",
            pruned = isTRUE(should_prune),
            eligible_at_pass_start = TRUE,
            eligible_at_eval = TRUE,
            became_eligible_within_pass = FALSE,
            prune_tol = as.numeric(prune_tol),
            stringsAsFactors = FALSE
          )
        }
      }

      if (length(pruned_idx_this_pass) > 0L) {
        for (idx in pruned_idx_this_pass) {
          leaf_state[idx] <- TRUE
          active <- .ctgp_prune_trace_deactivate_subtree(left_idx[idx], left_idx, right_idx, active)
          active <- .ctgp_prune_trace_deactivate_subtree(right_idx[idx], left_idx, right_idx, active)
        }
        changed <- TRUE
        changed_any <- TRUE
      }
    } else {
      ord_counter <- 0L
      for (idx in dynamic_order) {
        eligible_now <- eligible_node(idx, active, leaf_state)
        if (!isTRUE(eligible_now)) next
        ord_counter <- ord_counter + 1L
        li <- left_idx[idx]
        ri <- right_idx[idx]
        parent_val <- unname(loocv_map[as.character(node_meta$node_id[idx])])
        left_val <- unname(loocv_map[as.character(node_meta$node_id[li])])
        right_val <- unname(loocv_map[as.character(node_meta$node_id[ri])])
        sep_val <- left_val + right_val
        finite_ok <- is.finite(parent_val) && is.finite(sep_val)
        should_prune <- isTRUE(finite_ok) && (parent_val + prune_tol < sep_val)
        eligible_start <- eligible_node(idx, start_active, start_leaf)
        node_eval_count[idx] <- node_eval_count[idx] + 1L
        global_order <- global_order + 1L
        eval_idx_this_pass <- c(eval_idx_this_pass, idx)
        if (!isTRUE(eligible_start)) late_candidates <- c(late_candidates, idx)
        if (isTRUE(should_prune)) pruned_idx_this_pass <- c(pruned_idx_this_pass, idx)

        log_rows[[length(log_rows) + 1L]] <- data.frame(
          prune_pass = as.integer(pass),
          traversal_order = as.integer(ord_counter),
          traversal_order_global = as.integer(global_order),
          simulation_mode = mode,
          traversal_rule = "depth_desc_node_id_ascending_dynamic",
          parent_node_id = as.integer(node_meta$node_id[idx]),
          parent_id = as.integer(node_meta$parent_id[idx]),
          depth = as.integer(node_meta$depth[idx]),
          left_node_id = as.integer(node_meta$node_id[li]),
          right_node_id = as.integer(node_meta$node_id[ri]),
          node_eval_index = as.integer(node_eval_count[idx]),
          node_signature = as.character(node_meta$node_signature[idx]),
          left_signature = as.character(node_meta$left_signature[idx]),
          right_signature = as.character(node_meta$right_signature[idx]),
          parent_combined_ids = as.character(node_meta$combined_ids_chr[idx]),
          left_combined_ids = as.character(node_meta$combined_ids_chr[li]),
          right_combined_ids = as.character(node_meta$combined_ids_chr[ri]),
          parent_loocv = as.numeric(parent_val),
          left_loocv = as.numeric(left_val),
          right_loocv = as.numeric(right_val),
          separate_loocv = as.numeric(sep_val),
          delta = as.numeric(parent_val - sep_val),
          improvement = as.numeric(sep_val - parent_val),
          decision_margin_abs = as.numeric(abs(parent_val - sep_val)),
          finite_ok = isTRUE(finite_ok),
          decision = if (isTRUE(should_prune)) "merge" else "keep",
          pruned = isTRUE(should_prune),
          eligible_at_pass_start = isTRUE(eligible_start),
          eligible_at_eval = TRUE,
          became_eligible_within_pass = !isTRUE(eligible_start),
          prune_tol = as.numeric(prune_tol),
          stringsAsFactors = FALSE
        )

        if (isTRUE(should_prune)) {
          leaf_state[idx] <- TRUE
          active <- .ctgp_prune_trace_deactivate_subtree(left_idx[idx], left_idx, right_idx, active)
          active <- .ctgp_prune_trace_deactivate_subtree(right_idx[idx], left_idx, right_idx, active)
          changed <- TRUE
          changed_any <- TRUE
        }
      }
    }

    n_passes <- pass
    pass_rows[[length(pass_rows) + 1L]] <- data.frame(
      prune_pass = as.integer(pass),
      simulation_mode = mode,
      traversal_rule = if (identical(mode, "legacy_batch")) "node_id_ascending_batch" else "depth_desc_node_id_ascending_dynamic",
      pass_start_active_nodes = as.integer(sum(start_active)),
      pass_end_active_nodes = as.integer(sum(active)),
      pass_start_leaf_count = as.integer(sum(start_active & start_leaf)),
      pass_end_leaf_count = as.integer(sum(active & leaf_state)),
      candidate_count_pass_start = as.integer(length(start_candidates)),
      candidate_roots_pass_start = .ctgp_trace_collapse(node_meta$node_id[start_candidates]),
      evaluated_count = as.integer(length(eval_idx_this_pass)),
      evaluated_roots = .ctgp_trace_collapse(node_meta$node_id[eval_idx_this_pass]),
      late_candidate_count = as.integer(length(unique(late_candidates))),
      late_candidate_roots = .ctgp_trace_collapse(node_meta$node_id[unique(late_candidates)]),
      pruned_count = as.integer(length(unique(pruned_idx_this_pass))),
      pruned_roots = .ctgp_trace_collapse(node_meta$node_id[unique(pruned_idx_this_pass)]),
      changed = isTRUE(changed),
      stringsAsFactors = FALSE
    )

    if (!isTRUE(changed)) break
  }

  log_df <- if (length(log_rows) > 0L) do.call(rbind, log_rows) else data.frame()
  if (nrow(log_df) > 0L) {
    rownames(log_df) <- NULL
    log_df <- .ctgp_prune_trace_enrich_log(
      log_df,
      tree = tree,
      loocv_summary = loocv_summary,
      source = paste0("simulation_", mode)
    )
  }
  pass_df <- if (length(pass_rows) > 0L) do.call(rbind, pass_rows) else data.frame()
  if (nrow(pass_df) > 0L) rownames(pass_df) <- NULL

  final_state <- node_meta[, c(
    "node_id", "parent_id", "depth", "is_leaf", "left_id", "right_id", "split_var",
    "n_rows", "n_combined", "reason", "node_signature", "combined_ids", "combined_ids_chr"
  ), drop = FALSE]
  final_state$active <- as.logical(active)
  final_state$final_is_leaf <- as.logical(leaf_state)
  rownames(final_state) <- NULL

  state_sig <- .ctgp_prune_trace_state_signature(node_meta, active, leaf_state)
  list(
    log = log_df,
    pass_summary = pass_df,
    final_state = final_state,
    final_tree_signature = state_sig$tree_signature,
    final_leaf_partition_signature = state_sig$leaf_partition_signature,
    final_leaf_count = as.integer(state_sig$final_leaf_count),
    n_passes = as.integer(n_passes),
    changed_any = isTRUE(changed_any),
    mode = mode
  )
}

.ctgp_prune_trace_compare_modes <- function(lhs_log,
                                            rhs_log,
                                            lhs_name = "dynamic",
                                            rhs_name = "legacy_batch") {
  if (is.list(lhs_log) && !is.data.frame(lhs_log) && !is.null(lhs_log$log)) lhs_log <- lhs_log$log
  if (is.list(rhs_log) && !is.data.frame(rhs_log) && !is.null(rhs_log$log)) rhs_log <- rhs_log$log
  lhs <- if (is.null(lhs_log)) data.frame() else as.data.frame(lhs_log, stringsAsFactors = FALSE)
  rhs <- if (is.null(rhs_log)) data.frame() else as.data.frame(rhs_log, stringsAsFactors = FALSE)

  normalize_eval_index <- function(df) {
    if (nrow(df) < 1L) {
      df$node_eval_index <- integer(0)
      return(df)
    }
    if (!"node_eval_index" %in% names(df)) {
      df <- df[order(df$parent_node_id, df$prune_pass, df$traversal_order, df$traversal_order_global), , drop = FALSE]
      idx_list <- split(seq_len(nrow(df)), df$parent_node_id)
      node_eval_index <- integer(nrow(df))
      for (idx in idx_list) node_eval_index[idx] <- seq_along(idx)
      df$node_eval_index <- as.integer(node_eval_index)
    }
    df
  }

  lhs <- normalize_eval_index(lhs)
  rhs <- normalize_eval_index(rhs)

  keep_cols <- c(
    "parent_node_id", "node_eval_index", "prune_pass", "traversal_order", "traversal_order_global",
    "decision", "pruned", "delta", "improvement", "decision_margin_abs",
    "eligible_at_pass_start", "eligible_at_eval", "became_eligible_within_pass",
    "node_signature", "parent_combined_ids", "left_combined_ids", "right_combined_ids"
  )
  keep_cols_lhs <- intersect(keep_cols, names(lhs))
  keep_cols_rhs <- intersect(keep_cols, names(rhs))

  merged <- merge(
    lhs[, keep_cols_lhs, drop = FALSE],
    rhs[, keep_cols_rhs, drop = FALSE],
    by = c("parent_node_id", "node_eval_index"),
    all = TRUE,
    suffixes = c("_lhs", "_rhs")
  )
  if (nrow(merged) < 1L) {
    merged$lhs_mode <- character(0)
    merged$rhs_mode <- character(0)
    return(merged)
  }

  merged$lhs_mode <- lhs_name
  merged$rhs_mode <- rhs_name
  merged$same_decision <- merged$decision_lhs == merged$decision_rhs
  merged$same_pruned <- merged$pruned_lhs == merged$pruned_rhs
  merged$same_pass <- merged$prune_pass_lhs == merged$prune_pass_rhs
  merged$same_traversal_order <- merged$traversal_order_lhs == merged$traversal_order_rhs
  merged$same_delta <- merged$delta_lhs == merged$delta_rhs
  merged$pass_shift_rhs_minus_lhs <- as.numeric(merged$prune_pass_rhs) - as.numeric(merged$prune_pass_lhs)
  merged
}

.ctgp_loocv_payload_summary <- function(tree,
                                        bcd_object,
                                        engine = "legacy",
                                        prepped = NULL) {
  engine <- .ctgp_match_loocv_engine(engine)
  if (!is.null(prepped)) {
    bcd_object$prepared <- prepped
  }
  if (identical(engine, "legacy")) {
    bcd_object <- .ctgp_attach_legacy_loocv_state(bcd_object, prepped = .ctgp_trace_or(bcd_object$prepared, NULL))
    level_ids <- .ctgp_loocv_dispatch_level_ids(bcd_object)
    dispatch_data <- .ctgp_build_loocv_dispatch_data(bcd_object)
    dispatch_regime <- if (!is.null(bcd_object$loocv_dispatch$regime)) {
      as.character(bcd_object$loocv_dispatch$regime)
    } else if (inherits(bcd_object, "ctgp_bcd_union")) {
      "union-imputed"
    } else {
      "common-observed"
    }
  } else {
    level_ids <- if (!is.null(bcd_object$common_index) && !is.null(bcd_object$common_index$level_ids)) {
      as.integer(bcd_object$common_index$level_ids)
    } else if (!is.null(bcd_object$union_index) && !is.null(bcd_object$union_index$level_ids)) {
      as.integer(bcd_object$union_index$level_ids)
    } else {
      stop("Failed to locate level_ids needed for LOOCV payload tracing.")
    }
    dispatch_data <- NULL
    dispatch_regime <- if (inherits(bcd_object, "ctgp_bcd_union")) "union-index" else "common-index"
  }

  node_meta <- .ctgp_tree_collect_trace_nodes(tree)
  rows <- list()
  combined_list <- list()
  column_index_list <- list()
  tau_row_list <- list()
  tau_col_list <- list()
  mu_slice_list <- list()
  dispatch_ct_list <- list()
  dispatch_ct_full_list <- list()
  fi_values_list <- list()
  mu_values_list <- list()
  tau_values_list <- list()
  bcd_level_ids_list <- list()

  for (i in seq_len(nrow(node_meta))) {
    node_ids <- sort(as.integer(node_meta$combined_ids[[i]]))
    col_idx <- match(node_ids, level_ids)
    if (anyNA(col_idx)) {
      stop("Failed to map one or more node combined_ids into the BCD level_ids while building the LOOCV payload trace.")
    }
    dispatch_ct_order <- if (!is.null(dispatch_data)) {
      unique(as.integer(dispatch_data$c.T[dispatch_data$c.T %in% node_ids]))
    } else {
      as.integer(level_ids[col_idx])
    }
    dispatch_ct_full <- if (!is.null(dispatch_data)) {
      as.integer(dispatch_data$c.T[dispatch_data$c.T %in% node_ids])
    } else {
      design_n <- if (!is.null(bcd_object$common_index) && !is.null(bcd_object$common_index$common_design)) {
        nrow(as.matrix(bcd_object$common_index$common_design))
      } else {
        1L
      }
      rep(as.integer(level_ids[col_idx]), each = as.integer(design_n))
    }
    fi_values <- if (!is.null(bcd_object$fi)) as.numeric(bcd_object$fi) else rep(NA_real_, 0L)
    mu_values <- if (!is.null(bcd_object$mu_vec)) as.numeric(bcd_object$mu_vec[col_idx]) else rep(NA_real_, length(col_idx))
    tau_values <- if (!is.null(bcd_object$tau_matrix) && length(col_idx) > 1L) {
      as.numeric(as.vector(as.matrix(bcd_object$tau_matrix[col_idx, col_idx, drop = FALSE])))
    } else {
      rep(NA_real_, 0L)
    }

    rows[[length(rows) + 1L]] <- data.frame(
      node_id = as.integer(node_meta$node_id[i]),
      parent_id = as.integer(node_meta$parent_id[i]),
      depth = as.integer(node_meta$depth[i]),
      is_leaf = isTRUE(node_meta$is_leaf[i]),
      n_rows = as.integer(node_meta$n_rows[i]),
      n_combined = as.integer(node_meta$n_combined[i]),
      tau_dim = as.integer(length(col_idx)),
      node_signature = as.character(node_meta$node_signature[i]),
      dispatch_regime = as.character(dispatch_regime),
      payload_engine = as.character(engine),
      dispatch_row_count = if (!is.null(dispatch_data)) {
        as.integer(sum(dispatch_data$c.T %in% node_ids))
      } else {
        as.integer(length(dispatch_ct_full))
      },
      stringsAsFactors = FALSE
    )
    combined_list[[length(combined_list) + 1L]] <- node_ids
    column_index_list[[length(column_index_list) + 1L]] <- as.integer(col_idx)
    tau_row_list[[length(tau_row_list) + 1L]] <- as.integer(level_ids[col_idx])
    tau_col_list[[length(tau_col_list) + 1L]] <- as.integer(level_ids[col_idx])
    mu_slice_list[[length(mu_slice_list) + 1L]] <- as.integer(level_ids[col_idx])
    dispatch_ct_list[[length(dispatch_ct_list) + 1L]] <- as.integer(dispatch_ct_order)
    dispatch_ct_full_list[[length(dispatch_ct_full_list) + 1L]] <- as.integer(dispatch_ct_full)
    fi_values_list[[length(fi_values_list) + 1L]] <- as.numeric(fi_values)
    mu_values_list[[length(mu_values_list) + 1L]] <- as.numeric(mu_values)
    tau_values_list[[length(tau_values_list) + 1L]] <- as.numeric(tau_values)
    bcd_level_ids_list[[length(bcd_level_ids_list) + 1L]] <- as.integer(level_ids)
  }

  out <- do.call(rbind, rows)
  out$combined_ids <- I(combined_list)
  out$column_index <- I(column_index_list)
  out$tau_row_order <- I(tau_row_list)
  out$tau_col_order <- I(tau_col_list)
  out$mu_slice_order <- I(mu_slice_list)
  out$dispatch_ct_unique_order <- I(dispatch_ct_list)
  out$dispatch_ct_full_order <- I(dispatch_ct_full_list)
  out$fi_values <- I(fi_values_list)
  out$mu_values <- I(mu_values_list)
  out$tau_values <- I(tau_values_list)
  out$bcd_level_ids <- I(bcd_level_ids_list)
  rownames(out) <- NULL
  out
}

.ctgp_prune_trace_build_artifacts <- function(tree,
                                              final_tree = NULL,
                                              loocv_summary = NULL,
                                              prune_tol = 0,
                                              max_passes = 100L,
                                              actual_log = NULL,
                                              actual_label = "actual") {
  node_table <- .ctgp_prune_trace_node_table(tree, loocv_summary)
  actual_trace <- .ctgp_prune_trace_enrich_log(actual_log, tree, loocv_summary, source = actual_label)
  dynamic <- .ctgp_prune_trace_simulate(
    tree,
    loocv_summary,
    prune_tol = prune_tol,
    max_passes = max_passes,
    mode = "dynamic"
  )
  legacy_batch <- .ctgp_prune_trace_simulate(
    tree,
    loocv_summary,
    prune_tol = prune_tol,
    max_passes = max_passes,
    mode = "legacy_batch"
  )
  mode_compare <- .ctgp_prune_trace_compare_modes(
    dynamic$log,
    legacy_batch$log,
    lhs_name = "dynamic",
    rhs_name = "legacy_batch"
  )

  actual_tree_signature <- if (is.null(final_tree)) NA_character_ else .ctgp_tree_signature(final_tree)
  actual_leaf_partition_signature <- if (is.null(final_tree)) NA_character_ else .ctgp_tree_leaf_partition_signature(final_tree)
  actual_leaf_count <- if (is.null(final_tree)) NA_integer_ else {
    node_df <- .ctgp_tree_collect_trace_nodes(final_tree)
    as.integer(sum(as.logical(node_df$is_leaf)))
  }
  actual_n_passes <- if (nrow(actual_trace) > 0L) {
    suppressWarnings(max(as.integer(actual_trace$prune_pass), na.rm = TRUE))
  } else {
    0L
  }

  summary <- data.frame(
    actual_label = as.character(actual_label),
    actual_tree_signature = as.character(actual_tree_signature),
    actual_leaf_partition_signature = as.character(actual_leaf_partition_signature),
    actual_final_leaf_count = as.integer(actual_leaf_count),
    actual_n_passes = as.integer(actual_n_passes),
    dynamic_tree_signature = as.character(dynamic$final_tree_signature),
    dynamic_leaf_partition_signature = as.character(dynamic$final_leaf_partition_signature),
    dynamic_final_leaf_count = as.integer(dynamic$final_leaf_count),
    dynamic_n_passes = as.integer(dynamic$n_passes),
    legacy_batch_tree_signature = as.character(legacy_batch$final_tree_signature),
    legacy_batch_leaf_partition_signature = as.character(legacy_batch$final_leaf_partition_signature),
    legacy_batch_final_leaf_count = as.integer(legacy_batch$final_leaf_count),
    legacy_batch_n_passes = as.integer(legacy_batch$n_passes),
    dynamic_matches_actual_tree_signature = if (is.null(final_tree)) NA else isTRUE(dynamic$final_tree_signature == actual_tree_signature),
    dynamic_matches_actual_leaf_partition = if (is.null(final_tree)) NA else isTRUE(dynamic$final_leaf_partition_signature == actual_leaf_partition_signature),
    legacy_batch_matches_actual_tree_signature = if (is.null(final_tree)) NA else isTRUE(legacy_batch$final_tree_signature == actual_tree_signature),
    legacy_batch_matches_actual_leaf_partition = if (is.null(final_tree)) NA else isTRUE(legacy_batch$final_leaf_partition_signature == actual_leaf_partition_signature),
    prune_tol = as.numeric(prune_tol),
    max_passes = as.integer(max_passes),
    stringsAsFactors = FALSE
  )

  list(
    node_table = node_table,
    actual_trace = actual_trace,
    dynamic = dynamic,
    legacy_batch = legacy_batch,
    mode_compare = mode_compare,
    summary = summary
  )
}
