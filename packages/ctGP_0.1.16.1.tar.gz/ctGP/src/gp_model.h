#ifndef GP_MODEL_H
#define GP_MODEL_H

#include <RcppArmadillo.h>
#include <limits>
#include <string>
#include "objective_base.h"

// 用來存放 profile likelihood 中間結果
enum gp_objective_mode_code {
  GP_OBJECTIVE_STABLE = 0,
  GP_OBJECTIVE_LEGACY_EXACT = 1
};

inline int gp_resolve_objective_mode_int(int objective_mode) {
  return (objective_mode == GP_OBJECTIVE_LEGACY_EXACT) ? GP_OBJECTIVE_LEGACY_EXACT : GP_OBJECTIVE_STABLE;
}

inline std::string gp_objective_mode_label(int objective_mode) {
  return (gp_resolve_objective_mode_int(objective_mode) == GP_OBJECTIVE_LEGACY_EXACT) ? std::string("legacy_exact") : std::string("stable");
}

enum gp_finalize_mode_code {
  GP_FINALIZE_STABLE = 0,
  GP_FINALIZE_MATCH_SEARCH = 1
};

inline int gp_resolve_finalize_mode_int(int finalize_mode) {
  return (finalize_mode == GP_FINALIZE_MATCH_SEARCH) ? GP_FINALIZE_MATCH_SEARCH : GP_FINALIZE_STABLE;
}

inline std::string gp_finalize_mode_label(int finalize_mode, int objective_mode) {
  return (gp_resolve_finalize_mode_int(finalize_mode) == GP_FINALIZE_MATCH_SEARCH) ? gp_objective_mode_label(objective_mode) : std::string("stable");
}

struct gp_profile_result {
  arma::mat H;

  // 保留 inverse 給 C++ 內部研究/比較用途
  arma::mat h_inv;

  // 正式 prediction 路徑主要使用的量
  arma::mat l_matrix;       // Cholesky factor (lower triangular)
  arma::vec alpha_vec;   // H^{-1}(y - F beta)，但以 solve 算得

  arma::mat f_matrix;
  arma::vec beta_vec;

  // 僅在 constant mean 下等於 beta_vec(0)，多欄 mean 時設為 nan
  double beta;
  double sigma_sq;
  double neg_log_lik;

  // 實際在 H 對角上加上的 nugget
  double effective_nugget;
  double raw_rcond;
  bool nugget_added;
  int objective_mode;

  bool success;

  gp_profile_result()
    : beta(std::numeric_limits<double>::quiet_NaN()),
      sigma_sq(arma::datum::inf),
      neg_log_lik(arma::datum::inf),
      effective_nugget(0.0),
      raw_rcond(arma::datum::nan),
      nugget_added(false),
      objective_mode(GP_OBJECTIVE_STABLE),
      success(false) {}
};

// 建 correlation matrix
// H_ij = exp( - sum_k 10^{fi_k} (x_ik - x_jk)^2 )
arma::mat build_corr_matrix(
    const arma::mat& design,
    const arma::vec& fi,
    double nugget = 0.0
);

// 根據 eigenvalue 計算最小 nugget，使 condition number 不超過 max_cond
double compute_nugget_from_eigen(
    const arma::mat& H,
    double max_cond = 1e10
);

// 計算 default bound
Rcpp::List default_fi_bounds(const arma::mat& design);

// 給定參數 fi 與 mean design f_matrix，計算 profile likelihood 所需量
//
// nugget_provided 的語意：
// - false: 使用者沒有指定 nugget，若 rcond 很差，則以 compute_nugget_from_eigen() 自動補
// - true 且 nugget == 0: 使用者明確指定不用 nugget，若分解失敗就直接 fail
// - true 且 nugget > 0: 只有當 rcond 很差時，才實際加上使用者指定的 nugget
gp_profile_result gp_profile_fit(
    const arma::mat& design,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& f_matrix,
    double nugget = 0.0,
    bool nugget_provided = false,
    int objective_mode = GP_OBJECTIVE_STABLE
);

// objective class，直接接 PSO
class gp_likelihood_objective : public objective_base {
private:
  arma::mat design_;
  arma::vec y_;
  arma::mat f_matrix_;
  double nugget_;
  bool nugget_provided_;
  int objective_mode_;

public:
  gp_likelihood_objective(
    const arma::mat& design,
    const arma::vec& y,
    const arma::mat& f_matrix,
    double nugget = 0.0,
    bool nugget_provided = false,
    int objective_mode = GP_OBJECTIVE_STABLE
  )
    : design_(design),
      y_(y),
      f_matrix_(f_matrix),
      nugget_(nugget),
      nugget_provided_(nugget_provided),
      objective_mode_(objective_mode) {}

  double eval(const arma::vec& par) override;
};

// prediction
// model 至少需包含：data, fi, l_matrix, alpha_vec, beta_vec, sigma_sq, f_matrix
// generic mean 時需由 R wrapper 傳入對應新資料的 f_pred_matrix
Rcpp::List gp_predict_from_fit(
    const Rcpp::List& model,
    SEXP new_point_sexp,
    const arma::mat& f_pred_matrix,
    bool indep = false,
    bool use_nugget = true,
    bool use_openmp = true,
    int num_threads = 0,
    int block_size = 0,
    bool has_nugget_override = false,
    double nugget_override = 0.0,
    bool use_universal_variance = true
);

#endif
