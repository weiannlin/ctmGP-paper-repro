# ctmGP — multi-output (MO) data parser.
#
# All three multi-output surrogates (QQiGP, ctmGP, QQmGP) accept MO data of
# shape (X_cont, W_cat, Y_multi) where Y has T columns.  The paper §2.2 design
# casts MO into a single-output mixed-input problem by stacking observations
# T times and appending a response indicator categorical factor.  This file
# provides the shared helper.

#' Convert multi-output (X, W, Y) data into single-output long format.
#'
#' Stacks `Y[, l]` rows under each other for l = 1..T, replicating X and W,
#' and appends a categorical column `response_id` ∈ {"y1", ..., "yT"} encoding
#' the original output index.  This is the standard paper §2.2 long-format
#' construction; all three multi-output surrogates feed it into the
#' single-output ctGP / QQGP backends.
#'
#' @param data data.frame containing all relevant columns; or NULL if you pass
#'   X, W, Y directly via `X_mat` / `W_mat` / `Y_mat`.
#' @param x_cols character vector; names of continuous (quantitative) columns
#'   in `data`.
#' @param w_cols character vector; names of categorical (qualitative) columns
#'   in `data`.  May be empty (no categorical inputs).
#' @param y_cols character vector of length T; names of the response columns
#'   in `data`.  Must be at least 2.
#' @param X_mat optional n × d_cont matrix (used when `data` is NULL).
#' @param W_mat optional n × d_cat matrix or data.frame (used when `data` is NULL).
#' @param Y_mat optional n × T matrix (used when `data` is NULL).
#' @param response_id_name string; name of the new categorical column encoding
#'   the response index.  Default `"response_id"`.
#' @param response_value_name string; name of the response value column in the
#'   returned long-format frame.  Default `"y"`.
#' @return data.frame with `n × T` rows and columns:
#'   - the d_cont continuous columns (preserving original names)
#'   - the d_cat categorical columns (preserving original names)
#'   - `response_id_name`: factor with levels `y1, ..., yT` (order = y_cols order)
#'   - `response_value_name`: numeric response.
#'   Attribute `mo_meta` records the original `x_cols`, `w_cols`, `y_cols` so
#'   downstream high-level fits can dispatch correctly.
#' @export
mo_to_long_format <- function(data = NULL,
                                x_cols = NULL,
                                w_cols = NULL,
                                y_cols = NULL,
                                X_mat = NULL,
                                W_mat = NULL,
                                Y_mat = NULL,
                                response_id_name  = "response_id",
                                response_value_name = "y") {
  # --- Resolve to (X_df, W_df, Y_mat) ---
  if (!is.null(data)) {
    if (is.null(x_cols))  stop("Provide x_cols when passing `data`.")
    if (is.null(y_cols) || length(y_cols) < 2L)
      stop("Provide y_cols of length >= 2 (multi-output) when passing `data`.")
    data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
    miss_cols <- setdiff(c(x_cols, w_cols, y_cols), names(data))
    if (length(miss_cols)) stop(
      "Columns not found in data: ", paste(miss_cols, collapse = ", "), ".")
    X_df <- data[, x_cols, drop = FALSE]
    W_df <- if (length(w_cols)) data[, w_cols, drop = FALSE] else NULL
    Y_mat <- as.matrix(data[, y_cols, drop = FALSE])
  } else {
    if (is.null(X_mat) || is.null(Y_mat))
      stop("Either pass `data` + column names, or `X_mat` + `Y_mat` directly.")
    X_mat <- as.matrix(X_mat); storage.mode(X_mat) <- "double"
    Y_mat <- as.matrix(Y_mat); storage.mode(Y_mat) <- "double"
    if (ncol(Y_mat) < 2L) stop("Y_mat must have at least 2 columns.")
    if (nrow(X_mat) != nrow(Y_mat))
      stop("X_mat and Y_mat must have the same number of rows.")
    if (is.null(x_cols)) x_cols <- colnames(X_mat)
    if (is.null(x_cols)) x_cols <- paste0("x", seq_len(ncol(X_mat)))
    if (length(x_cols) != ncol(X_mat))
      stop("length(x_cols) must equal ncol(X_mat).")
    X_df <- as.data.frame(X_mat, stringsAsFactors = FALSE)
    names(X_df) <- x_cols
    if (!is.null(W_mat)) {
      W_df <- as.data.frame(W_mat, stringsAsFactors = FALSE,
                              check.names = FALSE)
      if (is.null(w_cols)) w_cols <- colnames(W_df)
      if (is.null(w_cols)) w_cols <- paste0("w", seq_len(ncol(W_df)))
      names(W_df) <- w_cols
    } else {
      W_df <- NULL
    }
    if (is.null(y_cols)) y_cols <- colnames(Y_mat)
    if (is.null(y_cols)) y_cols <- paste0("y", seq_len(ncol(Y_mat)))
    if (length(y_cols) != ncol(Y_mat))
      stop("length(y_cols) must equal ncol(Y_mat).")
  }

  n <- nrow(X_df); T_ <- ncol(Y_mat)

  # Replicate X and W blockwise — block l covers rows ((l-1)*n + 1):(l*n)
  X_long <- X_df[rep(seq_len(n), times = T_), , drop = FALSE]
  W_long <- if (!is.null(W_df)) W_df[rep(seq_len(n), times = T_), , drop = FALSE] else NULL

  # Build response_id as a factor with the SAME order as y_cols
  rid_levels <- paste0("y", seq_len(T_))
  rid_codes  <- rep(rid_levels, each = n)
  rid <- factor(rid_codes, levels = rid_levels)

  # Stack y values: column-major in Y → row-major in long format
  y_long <- as.numeric(as.matrix(Y_mat))   # column-major: y1's n rows, then y2's, ...

  out <- cbind(X_long, W_long,
               setNames(data.frame(rid, stringsAsFactors = FALSE,
                                    check.names = FALSE),
                        response_id_name),
               setNames(data.frame(y = y_long, check.names = FALSE),
                        response_value_name))
  rownames(out) <- NULL

  attr(out, "mo_meta") <- list(
    x_cols              = x_cols,
    w_cols              = if (length(w_cols)) w_cols else character(0),
    y_cols              = y_cols,
    response_id_name    = response_id_name,
    response_value_name = response_value_name,
    n_obs               = n,
    T                   = T_,
    response_id_levels  = rid_levels
  )
  out
}
