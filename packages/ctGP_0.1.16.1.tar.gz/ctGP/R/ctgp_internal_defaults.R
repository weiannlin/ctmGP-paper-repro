# Internal defaults for 0.1.13.0
# Stable public route frozen in 0.1.13.0:
# - common-design deterministic ctGP is the public default product
# - paper-style max-min absolute-correlation split rule remains the default
# - fast prune keeps the accepted TB-style local h_nugget policy
# - global GP / pure GP / QQGP search objective: legacy-exact
# - pure GP / QQGP finalize / rebuild: stable only
# - optimizer kernel: OMP-friendly QPSO
#
# Hidden internal diagnostics retained for package-development regression work:
#   options(ctGP.internal.debug.optimizer_mode = "globpso_exact")
#   options(ctGP.internal.debug.global_gp_search_mode = "legacy_exact")
#   options(ctGP.internal.debug.gp_search_mode = "legacy_exact")
#   options(ctGP.internal.debug.qqgp_search_mode = "legacy_exact")

.ctgp_default_split_use_abs_tau <- function() {
  TRUE
}

.ctgp_hidden_option_chr <- function(primary, fallback = NULL, default = NULL) {
  val <- getOption(primary, NULL)
  if (is.null(val) && !is.null(fallback)) {
    val <- getOption(fallback, NULL)
  }
  if (is.null(val)) {
    val <- default
  }
  if (is.null(val)) {
    return(NULL)
  }
  as.character(val[[1L]])
}

.ctgp_resolve_pso_kernel_mode <- function(mode = NULL) {
  if (is.null(mode)) {
    mode <- .ctgp_hidden_option_chr(
      'ctGP.internal.debug.optimizer_mode',
      fallback = 'ctGP.internal.pso_kernel_mode',
      default = 'qpso'
    )
  }
  mode <- as.character(mode[[1L]])
  if (mode %in% c('globpso_exact', 'qpso_exact')) {
    return('globpso_exact')
  }
  if (mode %in% c('stable', 'qpso')) {
    return('qpso')
  }
  stop("Internal optimizer mode must be one of 'qpso', 'stable', 'globpso_exact', or 'qpso_exact'.")
}

.ctgp_resolve_global_objective_mode <- function(mode = NULL) {
  if (is.null(mode)) {
    mode <- .ctgp_hidden_option_chr(
      'ctGP.internal.debug.global_gp_search_mode',
      fallback = 'ctGP.internal.global_gp_objective_mode',
      default = 'legacy_exact'
    )
  }
  mode <- as.character(mode[[1L]])
  if (!mode %in% c('legacy_exact', 'stable')) {
    stop("Internal global GP search mode must be either 'legacy_exact' or 'stable'.")
  }
  mode
}

.ctgp_resolve_gp_objective_mode <- function(mode = NULL) {
  if (is.null(mode)) {
    mode <- .ctgp_hidden_option_chr(
      'ctGP.internal.debug.gp_search_mode',
      fallback = 'ctGP.internal.gp_objective_mode',
      default = 'legacy_exact'
    )
  }
  mode <- as.character(mode[[1L]])
  if (!mode %in% c('legacy_exact', 'stable')) {
    stop("Internal GP search mode must be either 'legacy_exact' or 'stable'.")
  }
  mode
}

.ctgp_resolve_gp_finalize_mode <- function(objective_mode = NULL, mode = NULL) {
  invisible(.ctgp_resolve_gp_objective_mode(objective_mode))
  'stable'
}

.ctgp_resolve_qqgp_objective_mode <- function(mode = NULL) {
  if (is.null(mode)) {
    mode <- .ctgp_hidden_option_chr(
      'ctGP.internal.debug.qqgp_search_mode',
      fallback = 'ctGP.internal.qqgp_objective_mode',
      default = 'legacy_exact'
    )
  }
  mode <- as.character(mode[[1L]])
  if (!mode %in% c('legacy_exact', 'stable')) {
    stop("Internal QQGP search mode must be either 'legacy_exact' or 'stable'.")
  }
  mode
}

.ctgp_resolve_qqgp_finalize_mode <- function(objective_mode = NULL, mode = NULL) {
  invisible(.ctgp_resolve_qqgp_objective_mode(objective_mode))
  'stable'
}

