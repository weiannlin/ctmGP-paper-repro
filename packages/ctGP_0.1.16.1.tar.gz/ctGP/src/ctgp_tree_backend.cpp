#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <numeric>
#include <string>
#include <vector>
#include "gp_model.h"
#include "ctgp_rcpp_utils.h"

#ifdef _OPENMP
#include <omp.h>
#endif

namespace {

arma::mat solve_sympd_chol_tree(const arma::mat& A) {
  arma::mat L;
  arma::mat sym = 0.5 * (A + A.t());
  if (!arma::chol(L, sym, "lower")) {
    return arma::mat();
  }
  arma::mat I = arma::eye<arma::mat>(A.n_rows, A.n_cols);
  return arma::solve(arma::trimatu(L.t()), arma::solve(arma::trimatl(L), I));
}

void resolve_tree_nugget(SEXP nugget, bool& nugget_provided, double& nugget_value) {
  nugget_provided = false;
  nugget_value = 0.0;
  if (sexp_is_null(nugget)) {
    return;
  }
  Rcpp::NumericVector nv(nugget);
  if (nv.size() == 0) {
    return;
  }
  if (nv.size() != 1 || !R_finite(nv[0])) {
    Rcpp::stop("nugget must be NULL or a finite numeric scalar.");
  }
  nugget_provided = true;
  nugget_value = static_cast<double>(nv[0]);
}

int tree_effective_threads(bool use_openmp, int requested, int n_tasks) {
#ifdef _OPENMP
  if (!use_openmp) return 1;
  const int max_threads = omp_get_max_threads();
  if (n_tasks < 1) return 1;
  if (requested > 0) {
    return std::max(1, std::min(std::min(requested, max_threads), n_tasks));
  }
  return std::max(1, std::min(max_threads, n_tasks));
#else
  (void)use_openmp;
  (void)requested;
  (void)n_tasks;
  return 1;
#endif
}

std::vector<arma::uvec> parse_column_index(const Rcpp::List& column_index, arma::uword max_col) {
  std::vector<arma::uvec> out;
  out.reserve(column_index.size());
  for (R_xlen_t i = 0; i < column_index.size(); ++i) {
    Rcpp::IntegerVector idx = column_index[i];
    if (idx.size() < 1) {
      Rcpp::stop("Each element of column_index must contain at least one 1-based column index.");
    }
    arma::uvec cols(static_cast<arma::uword>(idx.size()));
    for (R_xlen_t j = 0; j < idx.size(); ++j) {
      if (idx[j] == NA_INTEGER || idx[j] < 1 || static_cast<arma::uword>(idx[j]) > max_col) {
        Rcpp::stop("column_index contains an out-of-range 1-based column index.");
      }
      cols(static_cast<arma::uword>(j)) = static_cast<arma::uword>(idx[j] - 1);
    }
    out.push_back(cols);
  }
  return out;
}

void deactivate_subtree_idx(
    int idx,
    const std::vector<int>& left_idx,
    const std::vector<int>& right_idx,
    std::vector<int>& active,
    std::vector<int>& current_is_leaf
) {
  if (idx < 0 || idx >= static_cast<int>(active.size())) return;
  active[idx] = 0;
  current_is_leaf[idx] = 0;
  if (left_idx[idx] >= 0) deactivate_subtree_idx(left_idx[idx], left_idx, right_idx, active, current_is_leaf);
  if (right_idx[idx] >= 0) deactivate_subtree_idx(right_idx[idx], left_idx, right_idx, active, current_is_leaf);
}

} // namespace

// [[Rcpp::export]]
Rcpp::DataFrame ctgp_tree_loocv_cpp(
    const arma::mat& design,
    const arma::mat& y_matrix,
    const arma::vec& fi,
    const arma::vec& mu_vec,
    Rcpp::Nullable<arma::mat> tau_matrix,
    const Rcpp::IntegerVector& node_id,
    const Rcpp::IntegerVector& parent_id,
    const Rcpp::IntegerVector& depth,
    const Rcpp::LogicalVector& is_leaf,
    const Rcpp::IntegerVector& n_rows,
    const Rcpp::IntegerVector& n_combined,
    const Rcpp::List& column_index,
    SEXP nugget = R_NilValue,
    bool use_openmp = true,
    int num_threads = 0
) {
  if (design.n_rows < 1 || design.n_cols < 1) {
    Rcpp::stop("design must be a non-empty numeric matrix.");
  }
  if (y_matrix.n_rows != design.n_rows || y_matrix.n_cols < 1) {
    Rcpp::stop("y_matrix must have the same number of rows as design and at least one column.");
  }
  if (fi.n_elem != design.n_cols) {
    Rcpp::stop("fi must have length ncol(design).");
  }
  if (mu_vec.n_elem != y_matrix.n_cols) {
    Rcpp::stop("mu_vec must have length ncol(y_matrix).");
  }
  const int n_nodes = node_id.size();
  if (parent_id.size() != n_nodes || depth.size() != n_nodes || is_leaf.size() != n_nodes ||
      n_rows.size() != n_nodes || n_combined.size() != n_nodes || column_index.size() != n_nodes) {
    Rcpp::stop("All node-level vectors and lists must have the same length.");
  }

  bool nugget_provided = false;
  double nugget_value = 0.0;
  resolve_tree_nugget(nugget, nugget_provided, nugget_value);

  arma::mat H_base = build_corr_matrix(design, fi, 0.0);
  const double h_nugget = nugget_provided ? nugget_value : compute_nugget_from_eigen(H_base, 1e8);
  arma::mat H_effective = H_base;
  if (std::isfinite(h_nugget) && h_nugget > 0.0) {
    H_effective.diag() += h_nugget;
  }
  H_effective = 0.5 * (H_effective + H_effective.t());
  arma::mat H_inv = solve_sympd_chol_tree(H_effective);
  if (H_inv.n_elem == 0) {
    Rcpp::stop("Failed to invert the ctGP H matrix in ctgp_tree_loocv_cpp().");
  }

  arma::mat Yc_full = y_matrix;
  for (arma::uword j = 0; j < Yc_full.n_cols; ++j) {
    Yc_full.col(j) -= mu_vec(j);
  }

  bool has_tau = false;
  arma::mat tau_full;
  if (tau_matrix) {
    tau_full = Rcpp::as<arma::mat>(tau_matrix);
    if (tau_full.n_rows != y_matrix.n_cols || tau_full.n_cols != y_matrix.n_cols) {
      Rcpp::stop("tau_matrix must be square with dimension ncol(y_matrix).");
    }
    tau_full = 0.5 * (tau_full + tau_full.t());
    has_tau = true;
  }

  const arma::vec diag_H = H_inv.diag();
  for (arma::uword i = 0; i < diag_H.n_elem; ++i) {
    if (!std::isfinite(diag_H(i)) || std::abs(diag_H(i)) <= std::numeric_limits<double>::epsilon()) {
      Rcpp::stop("Encountered a non-finite or near-zero ctGP LOOCV denominator in H.");
    }
  }

  const std::vector<arma::uvec> node_cols = parse_column_index(column_index, y_matrix.n_cols);

  Rcpp::NumericVector loocv_value(n_nodes, NA_REAL);
  Rcpp::NumericVector t_nugget(n_nodes, NA_REAL);
  Rcpp::LogicalVector used_tau(n_nodes, false);
  Rcpp::IntegerVector tau_dim(n_nodes, 0);

  const int n_threads = tree_effective_threads(use_openmp, num_threads, n_nodes);
#ifndef _OPENMP
  (void)n_threads;
#endif
#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int idx_node = 0; idx_node < n_nodes; ++idx_node) {
    const arma::uvec& cols = node_cols[static_cast<std::size_t>(idx_node)];
    const int k = static_cast<int>(cols.n_elem);
    tau_dim[idx_node] = k;

    if (k == 1) {
      arma::vec z = H_inv * Yc_full.col(cols(0));
      arma::vec resid = z / diag_H;
      loocv_value[idx_node] = arma::dot(resid, resid);
      t_nugget[idx_node] = 0.0;
      used_tau[idx_node] = false;
      continue;
    }

    if (!has_tau) {
      loocv_value[idx_node] = NA_REAL;
      t_nugget[idx_node] = NA_REAL;
      used_tau[idx_node] = false;
      continue;
    }

    arma::mat tau_sub = tau_full.submat(cols, cols);
    const double tau_nug = compute_nugget_from_eigen(tau_sub, 1e8);
    if (std::isfinite(tau_nug) && tau_nug > 0.0) {
      tau_sub.diag() += tau_nug;
    }
    tau_sub = 0.5 * (tau_sub + tau_sub.t());
    arma::mat T_inv = solve_sympd_chol_tree(tau_sub);
    if (T_inv.n_elem == 0) {
      loocv_value[idx_node] = NA_REAL;
      t_nugget[idx_node] = tau_nug;
      used_tau[idx_node] = true;
      continue;
    }

    arma::mat Z = H_inv * Yc_full.cols(cols) * T_inv;
    arma::vec diag_T = T_inv.diag();
    double sse = 0.0;
    bool ok = true;
    for (int j = 0; j < k; ++j) {
      const double d_t = diag_T(static_cast<arma::uword>(j));
      if (!std::isfinite(d_t) || std::abs(d_t) <= std::numeric_limits<double>::epsilon()) {
        ok = false;
        break;
      }
      arma::vec denom = diag_H * d_t;
      for (arma::uword r = 0; r < denom.n_elem; ++r) {
        if (!std::isfinite(denom(r)) || std::abs(denom(r)) <= std::numeric_limits<double>::epsilon()) {
          ok = false;
          break;
        }
      }
      if (!ok) break;
      arma::vec resid = Z.col(static_cast<arma::uword>(j)) / denom;
      sse += arma::dot(resid, resid);
    }
    loocv_value[idx_node] = ok ? sse : NA_REAL;
    t_nugget[idx_node] = tau_nug;
    used_tau[idx_node] = true;
  }

  return Rcpp::DataFrame::create(
    Rcpp::Named("node_id") = node_id,
    Rcpp::Named("parent_id") = parent_id,
    Rcpp::Named("depth") = depth,
    Rcpp::Named("is_leaf") = is_leaf,
    Rcpp::Named("n_rows") = n_rows,
    Rcpp::Named("n_combined") = n_combined,
    Rcpp::Named("loocv_value") = loocv_value,
    Rcpp::Named("h_nugget") = Rcpp::NumericVector(n_nodes, h_nugget),
    Rcpp::Named("t_nugget") = t_nugget,
    Rcpp::Named("used_tau") = used_tau,
    Rcpp::Named("tau_dim") = tau_dim
  );
}

// [[Rcpp::export]]
Rcpp::List ctgp_prune_tree_cpp(
    const Rcpp::IntegerVector& node_id,
    const Rcpp::IntegerVector& parent_id,
    const Rcpp::IntegerVector& depth,
    const Rcpp::IntegerVector& left_id,
    const Rcpp::IntegerVector& right_id,
    const Rcpp::LogicalVector& is_leaf,
    const Rcpp::NumericVector& loocv_value,
    double prune_tol = 0.0,
    int max_passes = 100
) {
  const int n = node_id.size();
  if (parent_id.size() != n || depth.size() != n || left_id.size() != n || right_id.size() != n ||
      is_leaf.size() != n || loocv_value.size() != n) {
    Rcpp::stop("All node-level vectors passed to ctgp_prune_tree_cpp() must have the same length.");
  }
  if (max_passes < 1) {
    Rcpp::stop("max_passes must be >= 1.");
  }

  std::map<int, int> id_to_idx;
  for (int i = 0; i < n; ++i) {
    id_to_idx[ node_id[i] ] = i;
  }

  std::vector<int> left_idx(n, -1);
  std::vector<int> right_idx(n, -1);
  for (int i = 0; i < n; ++i) {
    if (left_id[i] != NA_INTEGER) {
      std::map<int,int>::const_iterator it = id_to_idx.find(left_id[i]);
      if (it != id_to_idx.end()) left_idx[i] = it->second;
    }
    if (right_id[i] != NA_INTEGER) {
      std::map<int,int>::const_iterator it = id_to_idx.find(right_id[i]);
      if (it != id_to_idx.end()) right_idx[i] = it->second;
    }
  }

  std::vector<int> order(n);
  std::iota(order.begin(), order.end(), 0);
  std::sort(order.begin(), order.end(), [&](int a, int b) {
    if (depth[a] != depth[b]) return depth[a] > depth[b];
    return node_id[a] < node_id[b];
  });

  std::vector<int> active(n, 1);
  std::vector<int> current_is_leaf(n, 0);
  for (int i = 0; i < n; ++i) {
    current_is_leaf[i] = is_leaf[i] ? 1 : 0;
  }

  std::vector<int> log_pass;
  std::vector<int> log_parent;
  std::vector<int> log_left;
  std::vector<int> log_right;
  std::vector<double> log_parent_loocv;
  std::vector<double> log_sep_loocv;
  std::vector<double> log_improvement;
  std::vector<int> log_pruned;

  int n_passes = 0;
  bool changed_any = false;
  for (int pass = 1; pass <= max_passes; ++pass) {
    bool changed = false;
    for (std::size_t ord = 0; ord < order.size(); ++ord) {
      const int idx = order[ord];
      if (!active[idx] || current_is_leaf[idx]) continue;
      const int li = left_idx[idx];
      const int ri = right_idx[idx];
      if (li < 0 || ri < 0) continue;
      if (!active[li] || !active[ri]) continue;
      if (!current_is_leaf[li] || !current_is_leaf[ri]) continue;

      const double parent_val = loocv_value[idx];
      const double sep_val = loocv_value[li] + loocv_value[ri];
      const bool finite_ok = std::isfinite(parent_val) && std::isfinite(sep_val);
      const bool should_prune = finite_ok && (parent_val + prune_tol < sep_val);

      log_pass.push_back(pass);
      log_parent.push_back(node_id[idx]);
      log_left.push_back(node_id[li]);
      log_right.push_back(node_id[ri]);
      log_parent_loocv.push_back(parent_val);
      log_sep_loocv.push_back(sep_val);
      log_improvement.push_back(sep_val - parent_val);
      log_pruned.push_back(should_prune ? 1 : 0);

      if (should_prune) {
        current_is_leaf[idx] = 1;
        deactivate_subtree_idx(li, left_idx, right_idx, active, current_is_leaf);
        deactivate_subtree_idx(ri, left_idx, right_idx, active, current_is_leaf);
        changed = true;
        changed_any = true;
      }
    }
    n_passes = pass;
    if (!changed) break;
  }

  Rcpp::LogicalVector log_pruned_vec(log_pruned.size());
  for (std::size_t i = 0; i < log_pruned.size(); ++i) {
    log_pruned_vec[static_cast<R_xlen_t>(i)] = (log_pruned[i] != 0);
  }
  Rcpp::DataFrame log_df = Rcpp::DataFrame::create(
    Rcpp::Named("pass") = log_pass,
    Rcpp::Named("parent_node_id") = log_parent,
    Rcpp::Named("left_node_id") = log_left,
    Rcpp::Named("right_node_id") = log_right,
    Rcpp::Named("parent_loocv") = log_parent_loocv,
    Rcpp::Named("separate_loocv") = log_sep_loocv,
    Rcpp::Named("improvement") = log_improvement,
    Rcpp::Named("pruned") = log_pruned_vec
  );

  Rcpp::LogicalVector active_vec(n);
  Rcpp::LogicalVector final_leaf_vec(n);
  for (int i = 0; i < n; ++i) {
    active_vec[i] = (active[i] != 0);
    final_leaf_vec[i] = (current_is_leaf[i] != 0);
  }

  return Rcpp::List::create(
    Rcpp::Named("node_id") = node_id,
    Rcpp::Named("active") = active_vec,
    Rcpp::Named("final_is_leaf") = final_leaf_vec,
    Rcpp::Named("n_passes") = n_passes,
    Rcpp::Named("changed_any") = changed_any,
    Rcpp::Named("log") = log_df
  );
}


// [[Rcpp::export]]
Rcpp::List ctgp_loocv_legacy_cpp(
    const arma::mat& data,
    const arma::vec& fi,
    const arma::vec& mu_hat,
    Rcpp::Nullable<arma::mat> tau_matrix = R_NilValue
) {
  if (data.n_rows < 1 || data.n_cols < 2) {
    Rcpp::stop("data must contain at least one design row and a response column.");
  }
  const arma::uword conti_dim = data.n_cols - 1;
  if (fi.n_elem != conti_dim) {
    Rcpp::stop("fi must have length ncol(data) - 1.");
  }

  const arma::vec y_vec = data.col(conti_dim);
  arma::uword kernel_dim = data.n_rows;
  bool used_tau = false;
  double tau_nugget = 0.0;
  arma::mat tau_inv;

  if (nullable_is_not_null(tau_matrix)) {
    arma::mat tau = Rcpp::as<arma::mat>(tau_matrix);
    if (tau.n_rows != tau.n_cols || tau.n_rows < 1) {
      Rcpp::stop("tau_matrix must be a non-empty square matrix.");
    }
    if (data.n_rows % tau.n_rows != 0) {
      Rcpp::stop("nrow(data) must be an integer multiple of nrow(tau_matrix).");
    }
    kernel_dim = data.n_rows / tau.n_rows;
    if (mu_hat.n_elem != tau.n_rows) {
      Rcpp::stop("mu_hat must have length nrow(tau_matrix) when tau_matrix is supplied.");
    }
    tau = 0.5 * (tau + tau.t());
    tau_nugget = compute_nugget_from_eigen(tau, 1e8);
    if (std::isfinite(tau_nugget) && tau_nugget > 0.0) {
      tau.diag() += tau_nugget;
    }
    tau = 0.5 * (tau + tau.t());
    tau_inv = solve_sympd_chol_tree(tau);
    if (tau_inv.n_elem == 0) {
      Rcpp::stop("Failed to invert tau_matrix in ctgp_loocv_legacy_cpp().");
    }
    used_tau = true;
  } else {
    if (mu_hat.n_elem != 1) {
      Rcpp::stop("mu_hat must have length 1 when tau_matrix is NULL.");
    }
  }

  arma::mat design_block = data.cols(0, conti_dim - 1).rows(0, kernel_dim - 1);
  arma::mat h_matrix = build_corr_matrix(design_block, fi, 0.0);
  const double h_nugget = compute_nugget_from_eigen(h_matrix, 1e8);
  if (std::isfinite(h_nugget) && h_nugget > 0.0) {
    h_matrix.diag() += h_nugget;
  }
  h_matrix = 0.5 * (h_matrix + h_matrix.t());
  arma::mat h_inv = solve_sympd_chol_tree(h_matrix);
  if (h_inv.n_elem == 0) {
    Rcpp::stop("Failed to invert H matrix in ctgp_loocv_legacy_cpp().");
  }

  arma::mat inv_kernel;
  arma::vec mu_rep;
  if (used_tau) {
    inv_kernel = arma::kron(tau_inv, h_inv);
    mu_rep = arma::vec(y_vec.n_elem, arma::fill::zeros);
    for (arma::uword j = 0; j < mu_hat.n_elem; ++j) {
      const arma::uword start = j * kernel_dim;
      const arma::uword end = start + kernel_dim - 1;
      mu_rep.subvec(start, end).fill(mu_hat(j));
    }
  } else {
    inv_kernel = h_inv;
    mu_rep = arma::vec(y_vec.n_elem);
    mu_rep.fill(mu_hat(0));
  }

  arma::vec diag_inv = inv_kernel.diag();
  for (arma::uword i = 0; i < diag_inv.n_elem; ++i) {
    if (!std::isfinite(diag_inv(i)) || std::abs(diag_inv(i)) <= std::numeric_limits<double>::epsilon()) {
      Rcpp::stop("Encountered a non-finite or near-zero diagonal in invKernelMatrix.");
    }
  }

  arma::vec score = inv_kernel * (y_vec - mu_rep);
  arma::vec loocv_vec = score / diag_inv;
  const double loocv_sse = arma::dot(loocv_vec, loocv_vec);

  return Rcpp::List::create(
    Rcpp::Named("loocv_sse") = loocv_sse,
    Rcpp::Named("loocv_vec") = loocv_vec,
    Rcpp::Named("kernel_dim") = static_cast<int>(kernel_dim),
    Rcpp::Named("used_tau") = used_tau,
    Rcpp::Named("tau_dim") = used_tau ? static_cast<int>(tau_inv.n_rows) : 1,
    Rcpp::Named("h_nugget") = h_nugget,
    Rcpp::Named("t_nugget") = tau_nugget
  );
}
