#include <RcppArmadillo.h>
#include "ctgp_rcpp_utils.h"
#include <cmath>
// [[Rcpp::depends(RcppArmadillo)]]

#include "optimizer_pso.h"
#include "gp_regression_model.h"

// [[Rcpp::export]]
Rcpp::List fit_gp_regression_cpp(
    const arma::mat& data,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> range = R_NilValue,
    Rcpp::Nullable<double> nugget_init = R_NilValue,
    Rcpp::Nullable<arma::vec> nugget_range = R_NilValue,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1
) {
  if (data.n_cols < 2) {
    Rcpp::stop("data must have at least one input column and one response column.");
  }

  int d = data.n_cols - 1;
  arma::mat design = data.cols(0, d - 1);
  arma::vec y = data.col(d);

  arma::mat f_matrix_use;
  if (nullable_is_not_null(f_matrix)) {
    f_matrix_use = Rcpp::as<arma::mat>(f_matrix);
    if ((int)f_matrix_use.n_rows != (int)data.n_rows) {
      Rcpp::stop("f_matrix must have the same number of rows as data.");
    }
    if (f_matrix_use.n_cols < 1) {
      Rcpp::stop("f_matrix must have at least one column.");
    }
    if (!f_matrix_use.is_finite()) {
      Rcpp::stop("f_matrix must contain only finite numeric values.");
    }
  } else {
    f_matrix_use = arma::ones<arma::mat>(data.n_rows, 1);
  }

  arma::vec fi_lower;
  arma::vec fi_upper;
  if (nullable_is_not_null(range)) {
    arma::vec range_vec = Rcpp::as<arma::vec>(range);
    if ((int)range_vec.n_elem != 2 * d) {
      Rcpp::stop("range must have length 2 * input dimension.");
    }
    fi_lower = range_vec.subvec(0, d - 1);
    fi_upper = range_vec.subvec(d, 2 * d - 1);
  } else {
    Rcpp::List bds = gpreg_default_fi_bounds(design);
    fi_lower = Rcpp::as<arma::vec>(bds["lower"]);
    fi_upper = Rcpp::as<arma::vec>(bds["upper"]);
  }

  arma::vec fi_init;
  if (nullable_is_not_null(init_param)) {
    fi_init = Rcpp::as<arma::vec>(init_param);
    if ((int)fi_init.n_elem != d) {
      Rcpp::stop("init_param must have length equal to the number of input variables.");
    }
  } else {
    fi_init = 0.8 * fi_upper + 0.2 * fi_lower;
  }

  double nugget_low;
  double nugget_upp;
  double nugget_init_val;

  if (nullable_is_not_null(nugget_range)) {
    arma::vec nr = Rcpp::as<arma::vec>(nugget_range);
    if ((int)nr.n_elem != 2) {
      Rcpp::stop("nugget_range must have length 2.");
    }
    nugget_low = nr(0);
    nugget_upp = nr(1);
  } else {
    Rcpp::List nb = gpreg_default_nugget_spec(y);
    nugget_low = Rcpp::as<double>(nb["lower"]);
    nugget_upp = Rcpp::as<double>(nb["upper"]);
  }

  if (!(std::isfinite(nugget_low) && std::isfinite(nugget_upp) && nugget_low > 0.0 && nugget_upp > nugget_low)) {
    Rcpp::stop("nugget_range must satisfy 0 < lower < upper.");
  }

  if (nullable_is_not_null(nugget_init)) {
    nugget_init_val = Rcpp::as<double>(nugget_init);
  } else {
    nugget_init_val = std::sqrt(nugget_low * nugget_upp);
  }

  if (!(std::isfinite(nugget_init_val) && nugget_init_val > 0.0)) {
    Rcpp::stop("nugget_init must be a positive finite scalar.");
  }
  if (nugget_init_val < nugget_low || nugget_init_val > nugget_upp) {
    Rcpp::stop("nugget_init must lie within nugget_range.");
  }

  arma::vec lower(d + 1, arma::fill::zeros);
  arma::vec upper(d + 1, arma::fill::zeros);
  arma::vec init_full(d + 1, arma::fill::zeros);

  lower.subvec(0, d - 1) = fi_lower;
  upper.subvec(0, d - 1) = fi_upper;
  init_full.subvec(0, d - 1) = fi_init;

  lower(d) = std::log10(nugget_low);
  upper(d) = std::log10(nugget_upp);
  init_full(d) = std::log10(nugget_init_val);

  pso_control control;
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;

  gp_regression_likelihood_objective obj(design, y, f_matrix_use);
  pso_optimizer optimizer(control);
  optim_result opt = optimizer.minimize(obj, lower, upper, init_full);

  gp_regression_profile_result fit = gpreg_profile_fit(
    design,
    y,
    opt.best_par.subvec(0, d - 1),
    std::pow(10.0, opt.best_par(d)),
    f_matrix_use
  );

  if (!fit.success) {
    Rcpp::stop(
      "Final GP regression fit failed. Try changing range, nugget_range, or mean design."
    );
  }

  return Rcpp::List::create(
    Rcpp::Named("fi") = opt.best_par.subvec(0, d - 1),
    Rcpp::Named("log10_nugget") = opt.best_par(d),
    Rcpp::Named("nugget") = fit.nugget,
    Rcpp::Named("stabilization_jitter") = fit.stabilization_jitter,
    Rcpp::Named("effective_nugget") = fit.effective_nugget,
    Rcpp::Named("design") = design,
    Rcpp::Named("data") = data,
    Rcpp::Named("l_matrix") = fit.l_matrix,
    Rcpp::Named("alpha_vec") = fit.alpha_vec,
    Rcpp::Named("f_matrix") = fit.f_matrix,
    Rcpp::Named("beta_vec") = fit.beta_vec,
    Rcpp::Named("sigma_sq") = fit.sigma_sq,
    Rcpp::Named("neg_log_lik") = fit.neg_log_lik,
    Rcpp::Named("optim_best_value") = opt.best_value,
    Rcpp::Named("optim_history") = opt.history,
    Rcpp::Named("optim_n_eval") = opt.n_eval,
    Rcpp::Named("optim_converged") = opt.converged,
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper,
    Rcpp::Named("init_param") = init_full,
    Rcpp::Named("nugget_range") = arma::vec({nugget_low, nugget_upp}),
    Rcpp::Named("nugget_init") = nugget_init_val,
    Rcpp::Named("mean_is_default") = (
      fit.f_matrix.n_cols == 1 &&
      arma::approx_equal(fit.f_matrix, arma::ones<arma::mat>(fit.f_matrix.n_rows, 1), "absdiff", 1e-12)
    )
  );
}
