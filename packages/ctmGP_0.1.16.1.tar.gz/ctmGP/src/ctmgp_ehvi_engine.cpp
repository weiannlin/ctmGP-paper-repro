// ctmGP — unified EHVI engine (Yang 2019 anchor-box decomposition + per-leaf
// dispatcher with closed-form path for low-d / diagonal blocks).
//
// Single C++ entry point used by all three surrogates (QQiGP / ctmGP / QQmGP).
// Same algorithm, different Σ structure → different cost:
//   - QQiGP (diagonal Σ everywhere): all blocks size 1 → all closed-form
//   - ctmGP (block-diag Σ from tree): mixed — small blocks closed-form,
//                                     correlated blocks fall back to MC
//   - QQmGP (full T×T Σ): one big block → MC required (no closed-form for
//                          dense d ≥ 2 yet; bivariate exact deferred)
//
// Algorithm (T=2 today; T=3 falls back to brute MC):
//
//   anchor_boxes = anchor_decompose(PF, ref)        // O((n+1)(n+2)/2) for T=2
//   for each candidate c (OpenMP parallel):
//     for each anchor box k:
//       for each leaf block b:
//         moment_kb = leaf_moment_dispatch(d_b, Σ_b, μ_b, l_kb, u_kb)
//       box_contribution = ∏_b moment_kb
//     EHVI[c] = Σ_k box_contribution
//
// All identifiers are snake_case per project convention.

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <cmath>
#include <map>
#include <random>
#include <vector>
#include "ctmgp_anchor.h"
#ifdef _OPENMP
#include <omp.h>
#endif

using namespace Rcpp;

// Forward declarations from sister files
double ctmgp_moment_1d_anchor_cpp(double mu, double sigma, double l, double u);
double ctmgp_moment_diag_prod_cpp(const arma::vec& mu, const arma::vec& sigma_diag,
                                    const arma::vec& l, const arma::vec& u);
double ctmgp_hv_contrib_2d_cpp(const arma::vec& y, const arma::mat& PF,
                                const arma::vec& ref);

namespace {

// Method codes — keep in sync with ctmgp_method_codes() exported below.
constexpr int method_auto      = 0;
constexpr int method_cf_1d     = 1;
constexpr int method_diag_prod = 2;
constexpr int method_dense_mc  = 3;

// Detect whether a small covariance block is effectively diagonal.
inline bool is_diagonal_block(const arma::mat& s, double tol = 1e-10) {
  for (arma::uword i = 0; i < s.n_rows; ++i)
    for (arma::uword j = 0; j < s.n_cols; ++j)
      if (i != j && std::abs(s(i, j)) > tol) return false;
  return true;
}

// Find connected components of a covariance block's sparsity graph.
// Indices i, j (i ≠ j) are connected iff |sigma(i,j)| > tol.  Returns a
// list of arma::uvec, each containing the (within-block, 0-indexed) indices
// of one connected component.  Components are returned in ascending order of
// minimum index for deterministic output.
//
// Used by the auto-mode dispatcher to recursively decompose a "dense" leaf
// block whose Σ is itself block-diagonal (e.g. 4D leaf with structure
// {1,2} ⊕ {3,4} → two independent 2D dense moments instead of one 4D MC).
std::vector<arma::uvec> find_sigma_components(const arma::mat& s,
                                                double tol = 1e-10) {
  const int d = static_cast<int>(s.n_rows);
  std::vector<int> parent(d);
  for (int i = 0; i < d; ++i) parent[i] = i;
  // Union-Find with path compression
  std::function<int(int)> find_root = [&](int x) {
    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
    return x;
  };
  for (int i = 0; i < d; ++i) {
    for (int j = i + 1; j < d; ++j) {
      if (std::abs(s(i, j)) > tol) {
        const int ra = find_root(i), rb = find_root(j);
        if (ra != rb) parent[ra] = rb;
      }
    }
  }
  // Bucket indices by root, ordered by smallest member for determinism
  std::map<int, std::vector<arma::uword>> groups;
  for (int i = 0; i < d; ++i) groups[find_root(i)].push_back(i);
  // Re-key by min-index so the output order is stable (sorted by first elem)
  std::map<arma::uword, std::vector<arma::uword>> by_first;
  for (auto& kv : groups) by_first[kv.second.front()] = std::move(kv.second);
  std::vector<arma::uvec> out;
  out.reserve(by_first.size());
  for (auto& kv : by_first) {
    arma::uvec idx(kv.second.size());
    for (std::size_t k = 0; k < kv.second.size(); ++k) idx[k] = kv.second[k];
    out.push_back(std::move(idx));
  }
  return out;
}

// Per-block anchor moment dispatcher.  Returns:
//   E[ ∏_m (u_m - max(y_m, l_m)) · 1{y_m < u_m all m} ]
// where y_block ~ N(mu_b, sigma_b).
//
// Method codes:
//   auto       → 1D-CF if d=1; diag_prod if Σ diagonal; recurse on connected
//                components of Σ if Σ block-diagonal with ≥2 components;
//                dense MC otherwise.
//   cf_1d      → require d=1, use 1D anchor formula.
//   diag_prod  → product of 1D anchor formulas using sqrt(diag(Σ)) only
//                (drops off-diag — caller's responsibility if that's wrong).
//   dense_mc   → block-aware MC over the joint Gaussian (no recursion).
double dispatch_block_moment(const arma::vec& mu_b,
                              const arma::mat& sigma_b,
                              const arma::vec& l_b,
                              const arma::vec& u_b,
                              int method_code,
                              int mc_samples,
                              std::mt19937_64& gen,
                              std::normal_distribution<double>& std_norm) {
  const arma::uword d = mu_b.n_elem;

  // ---- Forced overrides --------------------------------------------------
  if (method_code == method_cf_1d) {
    if (d != 1) Rcpp::stop("dispatch_block_moment: method 'cf_1d' requires "
                            "block of size 1 (got d=%d).", static_cast<int>(d));
    return ctmgp_moment_1d_anchor_cpp(mu_b[0], std::sqrt(sigma_b(0, 0)),
                                        l_b[0], u_b[0]);
  }
  if (method_code == method_diag_prod) {
    return ctmgp_moment_diag_prod_cpp(mu_b, arma::sqrt(sigma_b.diag()),
                                        l_b, u_b);
  }
  if (method_code == method_dense_mc) {
    if (d < 2) {
      // Degenerate: fall through to 1D CF (dense_mc on 1D is a waste).
      return ctmgp_moment_1d_anchor_cpp(mu_b[0], std::sqrt(sigma_b(0, 0)),
                                          l_b[0], u_b[0]);
    }
    arma::mat L_chol;
    arma::mat S = sigma_b;
    double jitter = 1e-12;
    bool ok = arma::chol(L_chol, S, "lower");
    while (!ok && jitter < 1e-4) {
      S = sigma_b + jitter * arma::eye(d, d);
      ok = arma::chol(L_chol, S, "lower");
      jitter *= 10.0;
    }
    if (!ok) Rcpp::stop("dispatch_block_moment: Cholesky failed.");
    arma::vec z(d), y(d);
    double acc = 0.0;
    for (int s = 0; s < mc_samples; ++s) {
      for (arma::uword m = 0; m < d; ++m) z[m] = std_norm(gen);
      y = mu_b + L_chol * z;
      bool in = true;
      for (arma::uword m = 0; m < d; ++m) {
        if (y[m] >= u_b[m]) { in = false; break; }
      }
      if (!in) continue;
      double prod = 1.0;
      for (arma::uword m = 0; m < d; ++m) {
        const double clipped = std::max(y[m], l_b[m]);
        prod *= (u_b[m] - clipped);
      }
      acc += prod;
    }
    return acc / static_cast<double>(mc_samples);
  }

  // ---- Auto mode ---------------------------------------------------------
  // 1D closed form
  if (d == 1) {
    return ctmgp_moment_1d_anchor_cpp(mu_b[0], std::sqrt(sigma_b(0, 0)),
                                        l_b[0], u_b[0]);
  }
  // Fully diagonal: product of 1D anchor moments
  if (is_diagonal_block(sigma_b)) {
    return ctmgp_moment_diag_prod_cpp(mu_b, arma::sqrt(sigma_b.diag()),
                                        l_b, u_b);
  }
  // Recursive sub-block detection: connected components of Σ's sparsity graph.
  // If Σ splits into ≥2 independent sub-blocks, the joint moment factorises
  // into a product of sub-block moments — recurse on each component.
  // (Common case: ctmGP leaf wrapping >1 ctGP-type sub-leaf, where the
  // surrogate's covariance is block-diagonal across the sub-leaves.)
  {
    auto comps = find_sigma_components(sigma_b);
    if (comps.size() >= 2) {
      double prod = 1.0;
      for (const auto& idx : comps) {
        const arma::vec mu_c    = mu_b.elem(idx);
        const arma::mat sigma_c = sigma_b.submat(idx, idx);
        const arma::vec l_c     = l_b.elem(idx);
        const arma::vec u_c     = u_b.elem(idx);
        prod *= dispatch_block_moment(mu_c, sigma_c, l_c, u_c,
                                        method_auto, mc_samples, gen, std_norm);
        if (prod == 0.0) return 0.0;
      }
      return prod;
    }
  }
  // Single dense connected block: fall back to MC.
  arma::mat L_chol;
  arma::mat S = sigma_b;
  double jitter = 1e-12;
  bool ok = arma::chol(L_chol, S, "lower");
  while (!ok && jitter < 1e-4) {
    S = sigma_b + jitter * arma::eye(d, d);
    ok = arma::chol(L_chol, S, "lower");
    jitter *= 10.0;
  }
  if (!ok) Rcpp::stop("dispatch_block_moment: Cholesky failed.");

  arma::vec z(d), y(d);
  double acc = 0.0;
  for (int s = 0; s < mc_samples; ++s) {
    for (arma::uword m = 0; m < d; ++m) z[m] = std_norm(gen);
    y = mu_b + L_chol * z;
    bool in = true;
    for (arma::uword m = 0; m < d; ++m) {
      if (y[m] >= u_b[m]) { in = false; break; }
    }
    if (!in) continue;
    double prod = 1.0;
    for (arma::uword m = 0; m < d; ++m) {
      const double clipped = std::max(y[m], l_b[m]);
      prod *= (u_b[m] - clipped);
    }
    acc += prod;
  }
  return acc / static_cast<double>(mc_samples);
}

}  // namespace

// ============================================================================
// Public Rcpp exports
// ============================================================================

//' Unified EHVI engine — Yang 2019 anchor-box decomposition + per-leaf dispatch.
//'
//' Computes EHVI per candidate by (a) decomposing the non-dominated region
//' into Yang-2019 anchor boxes, (b) for each box, factorising the integral
//' across user-specified blocks, (c) dispatching each block to the cheapest
//' valid moment kernel: 1D closed form / diagonal product / dense MC.
//' OpenMP-parallel across candidates.
//'
//' Surrogate-agnostic.  Speed is determined by Σ block structure:
//'   - QQiGP: all 1D blocks → all closed-form (fastest)
//'   - ctmGP: mixed dim → mostly closed-form, occasional MC (middle)
//'   - QQmGP: single dense block → MC required (slowest at small T)
//'
//' Supports T = 2 (Hupkens-Yang triangular enumeration) and T = 3 (slab
//' construction over z-sorted PF).  T ≥ 4 not in paper scope.
//'
//' @param mu_per_cand T × n_cand matrix of predictive means.
//' @param sigma_per_cand list of n_cand T×T covariance matrices.
//' @param pareto_set non-dominated front, n_pf × T.
//' @param ref_point length-T reference point.
//' @param block_indices_r list of 1-indexed integer vectors partitioning
//'   {1,...,T}.  Each element = one independence block.  For QQiGP pass
//'   `as.list(seq_len(T))`; for QQmGP pass `list(seq_len(T))`; for ctmGP pass
//'   leaves derived from the tree.
//' @param block_methods_r integer vector of method codes per block (length
//'   = length(block_indices_r)).  Codes from `ctmgp_method_codes()`:
//'   0 = auto, 1 = cf_1d, 2 = diag_prod, 3 = dense_mc.  Use auto unless
//'   you specifically want to bypass the dispatcher (e.g., to benchmark
//'   one path).
//' @param mc_samples MC samples per dense-block call (default 5000).
//' @param seed RNG seed.
//' @return numeric vector of EHVI per candidate.
// [[Rcpp::export]]
arma::vec ctmgp_ehvi_engine_cpp(const arma::mat& mu_per_cand,
                                  const Rcpp::List& sigma_per_cand,
                                  const arma::mat& pareto_set,
                                  const arma::vec& ref_point,
                                  const Rcpp::List& block_indices_r,
                                  const Rcpp::IntegerVector& block_methods_r,
                                  int mc_samples = 5000,
                                  int seed = 1) {
  const int t_dim = static_cast<int>(mu_per_cand.n_rows);
  const int n_cand = static_cast<int>(mu_per_cand.n_cols);

  if (t_dim < 2 || t_dim > 3)
    Rcpp::stop("ctmgp_ehvi_engine_cpp: T must be 2 or 3 (got %d). "
               "T ≥ 4 not in paper scope.", t_dim);
  if (sigma_per_cand.size() != n_cand)
    Rcpp::stop("sigma_per_cand length must equal n_cand.");
  if (ref_point.n_elem != static_cast<arma::uword>(t_dim))
    Rcpp::stop("ref_point length must equal T.");
  if (pareto_set.n_cols != static_cast<arma::uword>(t_dim))
    Rcpp::stop("pareto_set ncol must equal T.");

  // Convert R-side 1-indexed block_indices to 0-indexed arma::uvec
  const int n_blocks = static_cast<int>(block_indices_r.size());
  std::vector<arma::uvec> blocks(n_blocks);
  for (int b = 0; b < n_blocks; ++b) {
    Rcpp::IntegerVector r_idx = block_indices_r[b];
    arma::uvec idx(r_idx.size());
    for (R_xlen_t k = 0; k < r_idx.size(); ++k) {
      const int v = r_idx[k];
      if (v < 1 || v > t_dim) Rcpp::stop(
        "block_indices_r: index %d out of range [1, %d].", v, t_dim);
      idx[k] = static_cast<arma::uword>(v - 1);
    }
    blocks[b] = idx;
  }
  // Validate partition
  std::vector<int> seen(t_dim, 0);
  for (const auto& b : blocks) for (auto i : b) seen[i]++;
  for (int i = 0; i < t_dim; ++i) {
    if (seen[i] != 1) Rcpp::stop(
      "block_indices_r must partition {1,...,T} exactly (index %d seen %d times).",
      i + 1, seen[i]);
  }

  // Validate block_methods_r length matches block count
  if (block_methods_r.size() != n_blocks) Rcpp::stop(
    "block_methods_r length (%d) must equal number of blocks (%d).",
    static_cast<int>(block_methods_r.size()), n_blocks);
  std::vector<int> block_method_vec(n_blocks);
  for (int b = 0; b < n_blocks; ++b) {
    const int mc = block_methods_r[b];
    if (mc < 0 || mc > 3) Rcpp::stop(
      "block_methods_r[%d] = %d is not a valid method code (0-3).",
      b + 1, mc);
    block_method_vec[b] = mc;
  }

  // Pre-extract sigmas
  std::vector<arma::mat> sigma_vec(n_cand);
  for (int c = 0; c < n_cand; ++c) {
    sigma_vec[c] = Rcpp::as<arma::mat>(sigma_per_cand[c]);
    if (sigma_vec[c].n_rows != static_cast<arma::uword>(t_dim) ||
        sigma_vec[c].n_cols != static_cast<arma::uword>(t_dim))
      Rcpp::stop("sigma_per_cand[%d] shape != T×T.", c + 1);
  }

  // Anchor box decomposition — fixed across candidates (PF doesn't change here).
  // Dispatched via ctmgp_anchor.h helpers; T=2 uses Hupkens-Yang triangular
  // enumeration, T=3 uses slab construction.
  arma::mat box_l, box_u;
  if (t_dim == 2) {
    ctmgp_anchor_decompose_2d_impl(pareto_set, ref_point, box_l, box_u);
  } else {
    ctmgp_anchor_decompose_3d_impl(pareto_set, ref_point, box_l, box_u);
  }
  const arma::uword n_boxes = box_l.n_cols;

  arma::vec ehvi_out(n_cand, arma::fill::zeros);

#ifdef _OPENMP
  #pragma omp parallel for schedule(static)
#endif
  for (int c = 0; c < n_cand; ++c) {
    const arma::vec mu_c = mu_per_cand.col(c);
    const arma::mat& sigma_c = sigma_vec[c];

    // Per-thread RNG for any dense MC blocks
    const int tid =
#ifdef _OPENMP
      omp_get_thread_num();
#else
      0;
#endif
    std::mt19937_64 gen(static_cast<uint64_t>(seed) +
                        17ULL * static_cast<uint64_t>(c) +
                        1337ULL * static_cast<uint64_t>(tid));
    std::normal_distribution<double> std_norm(0.0, 1.0);

    double acc = 0.0;
    for (arma::uword k = 0; k < n_boxes; ++k) {
      const arma::vec lk = box_l.col(k);
      const arma::vec uk = box_u.col(k);

      double box_prod = 1.0;
      for (int b = 0; b < n_blocks; ++b) {
        const arma::uvec& idx = blocks[b];
        const arma::vec mu_b = mu_c.elem(idx);
        const arma::mat sigma_b = sigma_c.submat(idx, idx);
        const arma::vec l_b = lk.elem(idx);
        const arma::vec u_b = uk.elem(idx);

        const double moment = dispatch_block_moment(
          mu_b, sigma_b, l_b, u_b, block_method_vec[b],
          mc_samples, gen, std_norm);
        box_prod *= moment;
        if (box_prod == 0.0) break;
      }
      acc += box_prod;
    }
    ehvi_out[c] = acc;
  }

  return ehvi_out;
}

//' Method codes used by `acq_ehvi(block_methods = ...)`.
// [[Rcpp::export]]
Rcpp::IntegerVector ctmgp_method_codes() {
  Rcpp::IntegerVector v = Rcpp::IntegerVector::create(
    Rcpp::Named("auto")      = 0,
    Rcpp::Named("cf_1d")     = 1,
    Rcpp::Named("diag_prod") = 2,
    Rcpp::Named("dense_mc")  = 3
  );
  return v;
}

//' Diagnostic: find connected components of a covariance block's sparsity graph.
//'
//' Indices i, j (i ≠ j, 1-indexed in the returned list) are in the same
//' component iff `|sigma[i, j]| > tol`.  This is the helper that
//' `ctmgp_ehvi_engine_cpp`'s auto-mode dispatcher uses to recursively split a
//' "dense" leaf block whose Σ is itself block-diagonal across sub-leaves.
//' Permutation-agnostic: a scrambled layout like {1,3} ⊕ {2,4} (with σ(1,3),
//' σ(2,4) non-zero and σ(1,2) = σ(1,4) = σ(2,3) = σ(3,4) = 0) is correctly
//' identified as two components.
//'
//' Exposed for inspection / unit testing; the engine never calls back into R.
//'
//' @param sigma square covariance block.
//' @param tol off-diagonal magnitude threshold for "non-zero" (default 1e-10).
//' @return list of integer vectors (1-indexed); each vector = one component.
// [[Rcpp::export]]
Rcpp::List ctmgp_find_sigma_components_cpp(const arma::mat& sigma,
                                             double tol = 1e-10) {
  if (sigma.n_rows != sigma.n_cols)
    Rcpp::stop("sigma must be square (got %d x %d).",
               static_cast<int>(sigma.n_rows), static_cast<int>(sigma.n_cols));
  // Re-implement the same Union-Find we use internally; small enough to inline
  // without creating a header.
  const int d = static_cast<int>(sigma.n_rows);
  std::vector<int> parent(d);
  for (int i = 0; i < d; ++i) parent[i] = i;
  std::function<int(int)> find_root = [&](int x) {
    while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
    return x;
  };
  for (int i = 0; i < d; ++i) {
    for (int j = i + 1; j < d; ++j) {
      if (std::abs(sigma(i, j)) > tol) {
        const int ra = find_root(i), rb = find_root(j);
        if (ra != rb) parent[ra] = rb;
      }
    }
  }
  std::map<int, std::vector<int>> groups;
  for (int i = 0; i < d; ++i) groups[find_root(i)].push_back(i + 1);
  std::map<int, std::vector<int>> by_first;
  for (auto& kv : groups) by_first[kv.second.front()] = std::move(kv.second);
  Rcpp::List out(by_first.size());
  int k = 0;
  for (auto& kv : by_first) {
    out[k++] = Rcpp::wrap(kv.second);
  }
  return out;
}
