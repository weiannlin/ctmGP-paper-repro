#ifndef QQGP_REGRESSION_MODEL_H
#define QQGP_REGRESSION_MODEL_H

#include <RcppArmadillo.h>
#include <limits>
#include "objective_base.h"
#include "qqgp_model.h"

struct qqgp_regression_profile_result {
  arma::mat h_matrix;
  arma::mat t_matrix;
  arma::mat r_matrix;
  arma::mat l_matrix;
  arma::vec alpha_vec;
  arma::mat f_matrix;
  arma::vec beta_vec;

  double sigma_sq;
  double nugget;
  double log10_nugget;
  double stabilization_jitter;
  double effective_nugget;
  double neg_log_lik;
  bool success;

  qqgp_regression_profile_result()
    : sigma_sq(arma::datum::inf),
      nugget(arma::datum::nan),
      log10_nugget(arma::datum::nan),
      stabilization_jitter(0.0),
      effective_nugget(arma::datum::nan),
      neg_log_lik(arma::datum::inf),
      success(false) {}
};

Rcpp::List qqgpreg_default_nugget_spec(const arma::vec& y);

qqgp_regression_profile_result qqgpreg_profile_fit(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::vec& theta,
    double nugget,
    const arma::mat& f_matrix
);

qqgp_regression_profile_result qqgpreg_profile_fit_fixed_t(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& t_matrix,
    double nugget,
    const arma::mat& f_matrix
);

class qqgp_regression_likelihood_objective : public objective_base {
private:
  arma::mat design_;
  arma::uvec level_index_;
  arma::vec y_;
  int level_num_;
  arma::mat f_matrix_;
  bool fixed_t_;
  arma::mat fixed_t_matrix_;

public:
  qqgp_regression_likelihood_objective(
      const arma::mat& design,
      const arma::uvec& level_index,
      const arma::vec& y,
      int level_num,
      const arma::mat& f_matrix
  )
    : design_(design), level_index_(level_index), y_(y), level_num_(level_num),
      f_matrix_(f_matrix), fixed_t_(false) {}

  qqgp_regression_likelihood_objective(
      const arma::mat& design,
      const arma::uvec& level_index,
      const arma::vec& y,
      int level_num,
      const arma::mat& f_matrix,
      const arma::mat& fixed_t_matrix
  )
    : design_(design), level_index_(level_index), y_(y), level_num_(level_num),
      f_matrix_(f_matrix), fixed_t_(true), fixed_t_matrix_(fixed_t_matrix) {}

  double eval(const arma::vec& par) override;
};

#endif
