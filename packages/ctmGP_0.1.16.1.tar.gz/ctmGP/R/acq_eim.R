# ctmGP — Expected Improvement Matrix (EIM) acquisition.
#
# Paper §3.2 (Zhan-Cheng-Liu 2017 / Manson-Chamberlain-Bourne 2021).
# Companion acquisition to EHVI: closed-form, consumes only per-objective
# marginal (μ, σ), naturally pairs with QQiGP-like (independent) surrogates
# while EHVI naturally pairs with joint surrogates (ctmGP, QQmGP).

#' Expected Improvement Matrix (EIM) acquisition.
#'
#' For each candidate, computes
#'   EIM(w) = min_j sqrt(Σ_l (EI_l^j(w))²)
#' where j indexes the current Pareto front and EI_l^j is the per-output EI
#' of candidate w over PF point j's l-th objective coordinate.  Closed-form.
#'
#' Higher EIM ⇒ more attractive candidate.  Use this OR `acq_ehvi()` per the
#' paper §3 acquisition study.
#'
#' @param mu_per_cand T × n_cand numeric matrix of predictive means.
#' @param sigma_marginal_per_cand T × n_cand numeric matrix of per-output
#'   predictive standard deviations (square root of marginal variance).
#'   Either pass directly, OR if you have the full covariance list (e.g. from
#'   `predict_ctmgp(joint = TRUE)`), call
#'   `vapply(sigma_per_cand, function(s) sqrt(diag(s)), numeric(T))`.
#' @param pareto_set n_pf × T matrix of current non-dominated outcomes.
#' @return numeric vector of EIM values, length = ncol(mu_per_cand).
#' @export
acq_eim <- function(mu_per_cand,
                    sigma_marginal_per_cand,
                    pareto_set) {
  if (!is.matrix(mu_per_cand)) mu_per_cand <- as.matrix(mu_per_cand)
  storage.mode(mu_per_cand) <- "double"
  if (!is.matrix(sigma_marginal_per_cand))
    sigma_marginal_per_cand <- as.matrix(sigma_marginal_per_cand)
  storage.mode(sigma_marginal_per_cand) <- "double"
  pareto_set <- as.matrix(pareto_set)
  storage.mode(pareto_set) <- "double"

  ctmgp_eim_engine_cpp(
    mu_per_cand              = mu_per_cand,
    sigma_marginal_per_cand  = sigma_marginal_per_cand,
    pareto_set               = pareto_set
  )
}
