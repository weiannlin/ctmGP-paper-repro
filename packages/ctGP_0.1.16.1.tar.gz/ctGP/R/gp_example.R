
.ctgp_gp_example_optimizer_controls <- function(seed, quick = TRUE) {
  if (isTRUE(quick)) {
    list(
      formula_omp = list(
        swarm_size = 48L,
        max_iter = 80L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      ),
      fmat_custom = list(
        swarm_size = 48L,
        max_iter = 80L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      )
    )
  } else {
    list(
      formula_omp = list(
        swarm_size = 64L,
        max_iter = 100L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      ),
      fmat_custom = list(
        swarm_size = 64L,
        max_iter = 100L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      )
    )
  }
}

.ctgp_gp_example_prediction_controls <- function(num_threads = 4L,
                                                 block_size = 64L,
                                                 use_nugget = FALSE) {
  list(
    use_openmp = TRUE,
    num_threads = as.integer(num_threads),
    block_size = as.integer(block_size),
    use_nugget = isTRUE(use_nugget)
  )
}

.ctgp_gp_example_metrics <- function(pred, truth) {
  mu <- as.numeric(pred$pred_mean)
  var_vec <- as.numeric(pred$pred_var)
  sd_vec <- sqrt(pmax(var_vec, 0))
  truth <- as.numeric(truth)

  data.frame(
    RMSE = sqrt(mean((mu - truth)^2)),
    MAE = mean(abs(mu - truth)),
    coverage_95 = mean(abs(mu - truth) <= 1.96 * sd_vec),
    max_abs_error = max(abs(mu - truth)),
    stringsAsFactors = FALSE
  )
}

.ctgp_gp_example_plot <- function(grid_df, truth_df, pred_df, train_df, holdout_df, title) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    return(NULL)
  }

  ggplot2::ggplot(pred_df, ggplot2::aes(x = x1, y = mean)) +
    ggplot2::geom_ribbon(
      ggplot2::aes(ymin = lower, ymax = upper),
      fill = "#7AA6DC",
      alpha = 0.22
    ) +
    ggplot2::geom_line(color = "#C0392B", linewidth = 1.0) +
    ggplot2::geom_line(
      data = truth_df,
      ggplot2::aes(x = x1, y = y_true),
      inherit.aes = FALSE,
      color = "grey30",
      linetype = "dashed",
      linewidth = 0.8
    ) +
    ggplot2::geom_point(
      data = train_df,
      ggplot2::aes(x = x1, y = y),
      inherit.aes = FALSE,
      shape = 21,
      size = 2.5,
      stroke = 0.7,
      fill = "white",
      color = "black"
    ) +
    ggplot2::geom_point(
      data = holdout_df,
      ggplot2::aes(x = x1, y = y),
      inherit.aes = FALSE,
      shape = 24,
      size = 2.8,
      stroke = 0.7,
      fill = "#4C78A8",
      color = "#1F3A5F"
    ) +
    ggplot2::labs(
      title = title,
      subtitle = "Slice through x2 with train points (circle) and holdout points (triangle)",
      x = "x1",
      y = "y"
    ) +
    ggplot2::theme_minimal(base_size = 13) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold"),
      plot.subtitle = ggplot2::element_text(color = "grey30"),
      panel.grid.minor = ggplot2::element_blank()
    )
}

gp_example <- function(seed = 123L,
                       n_train = 50L,
                       n_holdout = 20L,
                       n_grid = 151L,
                       quick = TRUE,
                       show_plot = FALSE) {
  if (n_train < 10L) stop("`n_train` must be at least 10.")
  if (n_holdout < 5L) stop("`n_holdout` must be at least 5.")
  if (n_grid < 40L) stop("`n_grid` must be at least 40.")

  seed <- as.integer(seed)
  set.seed(seed)

  controls <- .ctgp_gp_example_optimizer_controls(seed = seed, quick = quick)

  response_fun <- function(x1, x2) {
    0.8 * sin(2 * pi * x1) + 0.5 * x2 + 0.9 * x1 * x2 - 0.35 * x2^2
  }

  x1_train <- stats::runif(n_train, min = 0.05, max = 0.95)
  x2_train <- stats::runif(n_train, min = 0.05, max = 0.95)
  y_train <- response_fun(x1_train, x2_train)

  x1_holdout <- stats::runif(n_holdout, min = 0.02, max = 0.98)
  x2_holdout <- stats::runif(n_holdout, min = 0.02, max = 0.98)
  y_holdout <- response_fun(x1_holdout, x2_holdout)

  train_data <- cbind(x1 = x1_train, x2 = x2_train, y = y_train)
  holdout_data <- cbind(x1 = x1_holdout, x2 = x2_holdout, y = y_holdout)
  storage.mode(train_data) <- "double"
  storage.mode(holdout_data) <- "double"

  # grid / slice for prediction displays
  x1_grid <- seq(0, 1, length.out = n_grid)
  x2_slice <- median(train_data[, "x2"])
  grid_data <- cbind(x1 = x1_grid, x2 = rep(x2_slice, n_grid))
  storage.mode(grid_data) <- "double"

  truth_grid <- data.frame(
    x1 = x1_grid,
    x2 = x2_slice,
    y_true = response_fun(x1_grid, x2_slice)
  )

  # ------------------------------------------------------------------
  # Example 1: default everything
  # ------------------------------------------------------------------
  fit_default <- fit_gp(train_data)

  pred_holdout_default <- predict_gp(
    fit_default,
    holdout_data[, c("x1", "x2"), drop = FALSE]
  )

  pred_grid_default <- predict_gp(
    fit_default,
    grid_data,
    indep = TRUE
  )

  case_default <- list(
    description = "Default GP fit with default constant mean (~1) and default optimizer/prediction settings.",
    fit = fit_default,
    prediction_holdout = pred_holdout_default,
    prediction_grid = pred_grid_default,
    diagnostics = .ctgp_gp_example_metrics(pred_holdout_default, holdout_data[, "y"])
  )

  # ------------------------------------------------------------------
  # Example 2: OMP + mean_formula with interaction
  # ------------------------------------------------------------------
  fit_formula_omp <- fit_gp(
    train_data,
    mean_formula = ~ x1 * x2,
    optimizer_control = controls$formula_omp
  )

  pred_holdout_formula_full <- predict_gp(
    fit_formula_omp,
    holdout_data[, c("x1", "x2"), drop = FALSE],
    indep = FALSE,
    prediction_control = .ctgp_gp_example_prediction_controls(
      num_threads = controls$formula_omp$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = TRUE
    )
  )

  pred_grid_formula_fast <- predict_gp(
    fit_formula_omp,
    grid_data,
    indep = TRUE,
    prediction_control = .ctgp_gp_example_prediction_controls(
      num_threads = controls$formula_omp$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = TRUE
    )
  )

  case_formula_omp <- list(
    description = paste(
      "OMP-enabled GP fit using mean_formula = ~ x1 * x2.",
      "Prediction demonstrates both default full-covariance output (indep = FALSE)",
      "and faster variance-only output (indep = TRUE)."
    ),
    fit = fit_formula_omp,
    prediction_holdout = pred_holdout_formula_full,
    prediction_grid_fast = pred_grid_formula_fast,
    diagnostics = .ctgp_gp_example_metrics(pred_holdout_formula_full, holdout_data[, "y"])
  )

  # ------------------------------------------------------------------
  # Example 3: custom f_matrix + explicit prediction f_matrix + seed
  # ------------------------------------------------------------------
  train_df <- data.frame(
    x1 = train_data[, "x1"],
    x2 = train_data[, "x2"]
  )
  holdout_df <- data.frame(
    x1 = holdout_data[, "x1"],
    x2 = holdout_data[, "x2"]
  )
  grid_df <- data.frame(
    x1 = grid_data[, "x1"],
    x2 = grid_data[, "x2"]
  )

  F_train_custom <- stats::model.matrix(~ x1 * x2, data = train_df)
  F_holdout_custom <- stats::model.matrix(~ x1 * x2, data = holdout_df)
  F_grid_custom <- stats::model.matrix(~ x1 * x2, data = grid_df)

  fit_fmat_custom <- fit_gp(
    train_data,
    f_matrix = F_train_custom,
    optimizer_control = controls$fmat_custom
  )

  pred_holdout_fmat <- predict_gp(
    fit_fmat_custom,
    holdout_data[, c("x1", "x2"), drop = FALSE],
    f_matrix = F_holdout_custom,
    indep = FALSE,
    prediction_control = .ctgp_gp_example_prediction_controls(
      num_threads = controls$fmat_custom$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = TRUE
    )
  )

  pred_grid_fmat_nugget <- predict_gp(
    fit_fmat_custom,
    grid_data,
    f_matrix = F_grid_custom,
    indep = TRUE,
    prediction_control = .ctgp_gp_example_prediction_controls(
      num_threads = controls$fmat_custom$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = TRUE
    )
  )

  case_fmat_custom <- list(
    description = paste(
      "Custom f_matrix GP fit using the same basis (~ x1 * x2) but provided explicitly.",
      "This case demonstrates optimizer_control$seed and explicit prediction f_matrix.",
      "Prediction also shows use_nugget = TRUE."
    ),
    fit = fit_fmat_custom,
    prediction_holdout = pred_holdout_fmat,
    prediction_grid_nugget = pred_grid_fmat_nugget,
    diagnostics = .ctgp_gp_example_metrics(pred_holdout_fmat, holdout_data[, "y"]),
    equivalence_with_formula = list(
      same_train_f_matrix = isTRUE(all.equal(
        unname(fit_formula_omp$f_matrix),
        unname(fit_fmat_custom$f_matrix)
      )),
      max_abs_diff_fi = max(abs(as.numeric(fit_formula_omp$fi) - as.numeric(fit_fmat_custom$fi))),
      max_abs_diff_beta = max(abs(as.numeric(fit_formula_omp$beta_vec) - as.numeric(fit_fmat_custom$beta_vec))),
      max_abs_diff_pred_mean = max(abs(
        as.numeric(pred_holdout_formula_full$pred_mean) -
          as.numeric(pred_holdout_fmat$pred_mean)
      )),
      max_abs_diff_pred_var = max(abs(
        as.numeric(pred_holdout_formula_full$pred_var) -
          as.numeric(pred_holdout_fmat$pred_var)
      ))
    )
  )


  # ------------------------------------------------------------------
  # Example 4: GP regression with estimated nugget
  # ------------------------------------------------------------------
  y_train_reg <- response_fun(x1_train, x2_train) + stats::rnorm(n_train, sd = 0.05)
  y_holdout_reg <- response_fun(x1_holdout, x2_holdout) + stats::rnorm(n_holdout, sd = 0.05)

  train_data_reg <- cbind(x1 = x1_train, x2 = x2_train, y = y_train_reg)
  holdout_data_reg <- cbind(x1 = x1_holdout, x2 = x2_holdout, y = y_holdout_reg)
  storage.mode(train_data_reg) <- 'double'
  storage.mode(holdout_data_reg) <- 'double'

  fit_regression <- fit_gp_regression(
    train_data_reg,
    mean_formula = ~ x1 * x2,
    nugget_range = c(1e-6, 0.5),
    optimizer_control = controls$formula_omp
  )

  pred_holdout_reg <- predict_gp(
    fit_regression,
    holdout_data_reg[, c('x1', 'x2'), drop = FALSE],
    indep = FALSE,
    prediction_control = list(
      use_openmp = TRUE,
      num_threads = controls$formula_omp$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L
    )
  )

  case_regression <- list(
    description = paste(
      'GP regression fit with homogeneous estimated nugget.',
      'Prediction uses the same high-level predict_gp() dispatch as deterministic GP.'
    ),
    fit = fit_regression,
    prediction_holdout = pred_holdout_reg,
    diagnostics = .ctgp_gp_example_metrics(pred_holdout_reg, holdout_data_reg[, 'y'])
  )

  summary_table <- data.frame(
    example = c("default", "formula_omp", "custom_fmat", "regression"),
    fit_time = c(
      fit_default$timing$elapsed,
      fit_formula_omp$timing$elapsed,
      fit_fmat_custom$timing$elapsed,
      fit_regression$timing$elapsed
    ),
    holdout_pred_time = c(
      pred_holdout_default$timing$elapsed,
      pred_holdout_formula_full$timing$elapsed,
      pred_holdout_fmat$timing$elapsed,
      pred_holdout_reg$timing$elapsed
    ),
    RMSE = c(
      case_default$diagnostics$RMSE,
      case_formula_omp$diagnostics$RMSE,
      case_fmat_custom$diagnostics$RMSE,
      case_regression$diagnostics$RMSE
    ),
    MAE = c(
      case_default$diagnostics$MAE,
      case_formula_omp$diagnostics$MAE,
      case_fmat_custom$diagnostics$MAE,
      case_regression$diagnostics$MAE
    ),
    stringsAsFactors = FALSE
  )

  plot_list <- list()
  if (requireNamespace("ggplot2", quietly = TRUE)) {
    pred_df_formula <- data.frame(
      x1 = grid_data[, "x1"],
      mean = as.numeric(pred_grid_formula_fast$pred_mean),
      sd = sqrt(pmax(pred_grid_formula_fast$pred_var, 0))
    )
    pred_df_formula$lower <- pred_df_formula$mean - 1.96 * pred_df_formula$sd
    pred_df_formula$upper <- pred_df_formula$mean + 1.96 * pred_df_formula$sd

    train_plot_df <- data.frame(
      x1 = train_data[, "x1"],
      x2 = train_data[, "x2"],
      y = train_data[, "y"]
    )
    holdout_plot_df <- data.frame(
      x1 = holdout_data[, "x1"],
      x2 = holdout_data[, "x2"],
      y = holdout_data[, "y"]
    )

    plot_list$formula_omp <- .ctgp_gp_example_plot(
      grid_df = grid_df,
      truth_df = truth_grid,
      pred_df = pred_df_formula,
      train_df = train_plot_df,
      holdout_df = holdout_plot_df,
      title = "GP example: mean_formula = ~ x1 * x2"
    )

    pred_df_fmat <- data.frame(
      x1 = grid_data[, "x1"],
      mean = as.numeric(pred_grid_fmat_nugget$pred_mean),
      sd = sqrt(pmax(pred_grid_fmat_nugget$pred_var, 0))
    )
    pred_df_fmat$lower <- pred_df_fmat$mean - 1.96 * pred_df_fmat$sd
    pred_df_fmat$upper <- pred_df_fmat$mean + 1.96 * pred_df_fmat$sd

    plot_list$custom_fmat <- .ctgp_gp_example_plot(
      grid_df = grid_df,
      truth_df = truth_grid,
      pred_df = pred_df_fmat,
      train_df = train_plot_df,
      holdout_df = holdout_plot_df,
      title = "GP example: custom f_matrix with explicit prediction f_matrix"
    )

    if (isTRUE(show_plot)) {
      print(plot_list$formula_omp)
      print(plot_list$custom_fmat)
    }
  }

  out <- list(
    seed = seed,
    response_fun = response_fun,
    data = list(
      train = train_data,
      holdout = holdout_data,
      grid = grid_data,
      truth_grid = truth_grid
    ),
    controls = controls,
    cases = list(
      default = case_default,
      formula_omp = case_formula_omp,
      custom_fmat = case_fmat_custom,
      regression = case_regression
    ),
    summary = summary_table,
    plots = plot_list
  )

  class(out) <- c("gp_example_result", class(out))
  out
}
