# Internal helper: build a standardized timing slot from a proc.time() delta.
# Used by every public fit_*/predict_* entry point to attach a uniform
# timing record to its return object.
#
# Schema:
#   wall_sec : real elapsed wall-clock seconds
#   cpu_sec  : total CPU seconds = user_self + sys_self
#              (sums across threads when OpenMP is active, so this CAN
#              exceed wall_sec under parallel execution)
#   user_sec : user-mode CPU seconds
#   sys_sec  : kernel-mode CPU seconds
.ctgp_make_timing <- function(t_start) {
  d <- proc.time() - t_start
  list(
    wall_sec = unname(d["elapsed"]),
    cpu_sec  = unname(d["user.self"] + d["sys.self"]),
    user_sec = unname(d["user.self"]),
    sys_sec  = unname(d["sys.self"])
  )
}
