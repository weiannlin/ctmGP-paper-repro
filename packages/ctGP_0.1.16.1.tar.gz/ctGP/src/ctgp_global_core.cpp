#include "ctgp_global_core.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <limits>
#include <map>
#include <random>
#include <sstream>
#include <string>
#include <vector>

#include "gp_model.h"
#include "optimizer_pso.h"

#ifdef _OPENMP
#include <omp.h>
#endif

namespace {

Rcpp::List default_fi_bounds_global_impl(const arma::mat& design) {
  const int n = static_cast<int>(design.n_rows);
  const int d = static_cast<int>(design.n_cols);

  double max_sum_sqdiff = 0.0;
  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        const double diff = design(i, k) - design(j, k);
        s += diff * diff;
      }
      if (s > max_sum_sqdiff) {
        max_sum_sqdiff = s;
      }
    }
  }

  if (max_sum_sqdiff <= 0.0) {
    max_sum_sqdiff = 1.0;
  }

  const double upper = std::log10(-std::log(0.2) / max_sum_sqdiff);
  const double lower = std::log10(-std::log(0.8) / max_sum_sqdiff);

  arma::vec lower_bound(d);
  arma::vec upper_bound(d);
  lower_bound.fill(lower);
  upper_bound.fill(upper);

  return Rcpp::List::create(
    Rcpp::Named("lower") = lower_bound,
    Rcpp::Named("upper") = upper_bound
  );
}

arma::mat add_diag(const arma::mat& x, double val) {

  arma::mat out = x;
  if (std::isfinite(val) && val > 0.0) {
    out.diag() += val;
  }
  return out;
}

arma::mat solve_sympd_chol(const arma::mat& A) {
  arma::mat L;
  if (!arma::chol(L, 0.5 * (A + A.t()), "lower")) {
    return arma::mat();
  }
  arma::mat I = arma::eye<arma::mat>(A.n_rows, A.n_cols);
  return arma::solve(arma::trimatu(L.t()), arma::solve(arma::trimatl(L), I));
}

int ctgp_effective_threads(bool use_openmp, int requested, int n_tasks) {
  return ctgp_openmp_resolve_threads(use_openmp, requested, n_tasks);
}

arma::mat ctgp_gp_cross_corr_matrix(
    const arma::mat& Xnew,
    const arma::mat& Xtrain,
    const arma::vec& theta,
    bool use_openmp,
    int num_threads
) {
  const int m = static_cast<int>(Xnew.n_rows);
  const int n = static_cast<int>(Xtrain.n_rows);
  const int d = static_cast<int>(Xtrain.n_cols);

  arma::mat R(m, n, arma::fill::zeros);
  const int n_threads = ctgp_effective_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    for (int j = 0; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        const double diff = Xnew(i, k) - Xtrain(j, k);
        s += theta(k) * diff * diff;
      }
      R(i, j) = std::exp(-s);
    }
  }

  return R;
}

arma::mat ctgp_gp_self_corr_matrix(
    const arma::mat& Xnew,
    const arma::vec& theta,
    bool use_nugget,
    double effective_nugget,
    bool use_openmp,
    int num_threads
) {
  const int m = static_cast<int>(Xnew.n_rows);
  const int d = static_cast<int>(Xnew.n_cols);

  arma::mat S(m, m, arma::fill::eye);
  const int n_threads = ctgp_effective_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    for (int j = i + 1; j < m; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        const double diff = Xnew(i, k) - Xnew(j, k);
        s += theta(k) * diff * diff;
      }
      const double val = std::exp(-s);
      S(i, j) = val;
      S(j, i) = val;
    }
  }

  if (use_nugget && std::isfinite(effective_nugget) && effective_nugget > 0.0) {
    S.diag() += effective_nugget;
  }

  return S;
}

bool build_H_with_tb_nugget(
    const arma::mat& design,
    const arma::vec& fi,
    bool nugget_provided,
    double nugget_value,
    arma::mat& H_base,
    arma::mat& H_effective,
    double& effective_nugget,
    double& rcond_h,
    arma::mat& H_inv,
    std::string& message
) {
  H_base = build_corr_matrix(design, fi, 0.0);
  effective_nugget = nugget_provided ? nugget_value : ctgp_compute_nugget_tb(H_base, 1e8);
  H_effective = add_diag(H_base, effective_nugget);
  H_effective = 0.5 * (H_effective + H_effective.t());
  rcond_h = arma::rcond(H_effective);

  H_inv = solve_sympd_chol(H_effective);
  if (H_inv.n_elem == 0) {
    message = "Failed to invert H matrix under ctGP global-stage nugget rules.";
    return false;
  }

  return true;
}

ctgp_bcd_state ctgp_update_tau_given_h_inv(
    const arma::mat& H_base,
    const arma::mat& H_effective,
    const arma::mat& H_inv,
    const arma::mat& y_matrix,
    double h_nugget,
    double scale_divisor,
    const std::string& regime
) {
  ctgp_bcd_state out;
  out.H_base = H_base;
  out.H_effective = H_effective;
  out.H_inv = H_inv;
  out.h_nugget = h_nugget;
  out.rcond_h = arma::rcond(H_effective);
  out.regime = regime;
  out.y_matrix = y_matrix;

  const int n = static_cast<int>(y_matrix.n_rows);
  const int m = static_cast<int>(y_matrix.n_cols);
  const double denom_scale = (std::isfinite(scale_divisor) && scale_divisor > 0.0)
    ? scale_divisor
    : static_cast<double>(n);
  out.scale_divisor = denom_scale;

  arma::vec one_vec(n, arma::fill::ones);
  const double denom = arma::as_scalar(one_vec.t() * H_inv * one_vec);
  if (!std::isfinite(denom) || std::abs(denom) <= std::numeric_limits<double>::epsilon()) {
    out.message = "Degenerate denominator in ctGP mu update.";
    return out;
  }

  arma::rowvec mu_row = (one_vec.t() * H_inv * y_matrix) / denom;
  out.mu = mu_row.t();

  arma::mat mu_matrix(n, m, arma::fill::zeros);
  for (int j = 0; j < m; ++j) {
    mu_matrix.col(j).fill(out.mu(j));
  }

  arma::mat tau_cov = (y_matrix - mu_matrix).t() * H_inv * (y_matrix - mu_matrix) / denom_scale;
  tau_cov = 0.5 * (tau_cov + tau_cov.t());
  out.tau_cov_base = tau_cov;

  const double tau_nugget = ctgp_compute_nugget_tb(tau_cov, 1e8);
  out.t_nugget = tau_nugget;
  out.tau_cov_effective = add_diag(tau_cov, tau_nugget);
  out.tau_cov_effective = 0.5 * (out.tau_cov_effective + out.tau_cov_effective.t());
  out.rcond_t = arma::rcond(out.tau_cov_effective);
  out.tau_corr = ctgp_cov2cor_sym(out.tau_cov_effective);
  out.success = true;
  return out;
}

double negloglik_from_state(
    const arma::mat& y_matrix,
    const arma::mat& H_effective,
    const arma::mat& H_inv,
    const arma::vec& mu,
    const arma::mat& tau_cov_effective
) {
  const int n = static_cast<int>(H_effective.n_rows);
  const int m = static_cast<int>(tau_cov_effective.n_rows);

  arma::mat T_eff = 0.5 * (tau_cov_effective + tau_cov_effective.t());
  arma::mat T_inv = solve_sympd_chol(T_eff);
  if (T_inv.n_elem == 0) {
    return arma::datum::inf;
  }

  arma::mat mu_matrix(n, m, arma::fill::zeros);
  for (int j = 0; j < m; ++j) {
    mu_matrix.col(j).fill(mu(j));
  }
  arma::mat Yc = y_matrix - mu_matrix;

  arma::mat L_H;
  if (!arma::chol(L_H, 0.5 * (H_effective + H_effective.t()), "lower")) {
    return arma::datum::inf;
  }
  arma::mat L_T;
  if (!arma::chol(L_T, T_eff, "lower")) {
    return arma::datum::inf;
  }

  const double first_term = static_cast<double>(n) * (2.0 * arma::sum(arma::log(L_T.diag())));
  const double second_term = static_cast<double>(m) * (2.0 * arma::sum(arma::log(L_H.diag())));
  const double third_term = arma::trace(T_inv * Yc.t() * H_inv * Yc);

  return 0.5 * (first_term + second_term + third_term);
}

std::vector<int> sorted_unique_levels(const arma::vec& level_vec) {
  std::vector<int> out;
  out.reserve(level_vec.n_elem);
  for (arma::uword i = 0; i < level_vec.n_elem; ++i) {
    out.push_back(static_cast<int>(std::llround(level_vec(i))));
  }
  std::sort(out.begin(), out.end());
  out.erase(std::unique(out.begin(), out.end()), out.end());
  return out;
}

struct ctgp_union_level_prediction {
  arma::vec fi;
  arma::vec mean;
  arma::mat cov;
  arma::vec observed_mean;
  arma::uvec observed_rows;
  bool used_fallback;
  bool success;
  std::string message;

  ctgp_union_level_prediction()
    : used_fallback(false), success(false), message("") {}
};

// Mvtnorm-equivalent eigen factorization for MC-imputation sampling.
//
// Paper's `treeFit.corrMat` uses `mvtnorm::rmvnorm(method = "eigen")` to
// draw imputations from the per-level predictive distribution.  In a BO
// loop the predictive Σ at OBSERVED training x's is rank-deficient (kriging
// interpolates → ~0 variance there), so a strict Cholesky factorization
// fails or even nugget-stabilization can't restore positivity when the
// problematic block is exactly zero.  The eigen path symmetrizes Σ, takes
// the eigendecomposition Σ = V diag(λ) V', clamps λ to be non-negative,
// and returns B = V diag(sqrt(λ_+)).  Then `B z` (z ~ N(0, I)) is a draw
// from N(0, Σ_+) with Σ_+ = V diag(λ_+) V', matching mvtnorm's behavior
// (zero-variance directions just collapse to the mean).  No Cholesky step
// downstream — `factor` IS the sampling factor.
bool stabilize_covariance_for_sampling(const arma::mat& cov,
                                       arma::mat& factor,
                                       double& added_nugget) {
  added_nugget = 0.0;
  arma::mat sym = 0.5 * (cov + cov.t());
  arma::vec eigval;
  arma::mat eigvec;
  if (!arma::eig_sym(eigval, eigvec, sym)) {
    return false;
  }
  for (arma::uword i = 0; i < eigval.n_elem; ++i) {
    if (!std::isfinite(eigval(i))) {
      return false;
    }
    if (eigval(i) < 0.0) {
      eigval(i) = 0.0;
    }
  }
  factor = eigvec * arma::diagmat(arma::sqrt(eigval));
  return true;
}

arma::vec sample_mvn_once(
    const arma::vec& mean,
    const arma::mat& cov_chol,
    std::mt19937_64& rng
) {
  arma::vec z(mean.n_elem, arma::fill::zeros);
  std::normal_distribution<double> dist(0.0, 1.0);
  for (arma::uword i = 0; i < z.n_elem; ++i) {
    z(i) = dist(rng);
  }
  return mean + cov_chol * z;
}

ctgp_union_level_prediction fit_level_gp_and_predict(
    const arma::mat& union_design,
    const arma::mat& X_obs_full,
    const arma::vec& y_obs_full,
    const arma::uvec& union_rows_zero_based,
    const arma::vec& fi_init,
    const arma::vec& lower,
    const arma::vec& upper,
    bool nugget_provided,
    double nugget_value,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode,
    int kernel_mode
) {
  ctgp_union_level_prediction out;
  const arma::uword n_union = union_design.n_rows;
  out.observed_mean.set_size(n_union);
  out.observed_mean.fill(arma::datum::nan);

  std::map<arma::uword, std::pair<double, int> > acc;
  for (arma::uword i = 0; i < union_rows_zero_based.n_elem; ++i) {
    const arma::uword key = union_rows_zero_based(i);
    const double yv = y_obs_full(i);
    if (!std::isfinite(yv) || key >= n_union) {
      continue;
    }
    if (acc.find(key) == acc.end()) {
      acc[key] = std::make_pair(yv, 1);
    } else {
      acc[key].first += yv;
      acc[key].second += 1;
    }
  }

  if (acc.empty()) {
    out.message = "No valid observed rows available for a union-design combined level.";
    return out;
  }

  const arma::uword n_unique = static_cast<arma::uword>(acc.size());
  arma::uvec obs_rows(n_unique);
  arma::vec y_train(n_unique);
  arma::mat X_train(n_unique, union_design.n_cols, arma::fill::zeros);

  arma::uword pos = 0;
  for (std::map<arma::uword, std::pair<double, int> >::const_iterator it = acc.begin(); it != acc.end(); ++it, ++pos) {
    obs_rows(pos) = it->first;
    const double ybar = it->second.first / static_cast<double>(it->second.second);
    y_train(pos) = ybar;
    X_train.row(pos) = union_design.row(it->first);
    out.observed_mean(it->first) = ybar;
  }
  out.observed_rows = obs_rows;

  if (n_unique < 2) {
    out.used_fallback = true;
    out.fi = fi_init;
    out.mean = arma::vec(n_union);
    out.mean.fill(y_train(0));
    out.cov = arma::eye<arma::mat>(n_union, n_union) * 1e-8;
    out.success = true;
    out.message = "Level-specific union imputation fell back to a constant predictor because only one unique quantitative row was observed.";
    return out;
  }

  pso_control control;
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;
  control.kernel_mode = kernel_mode;

  gp_likelihood_objective obj(
    X_train,
    y_train,
    arma::ones<arma::mat>(X_train.n_rows, 1),
    nugget_value,
    nugget_provided
  );

  pso_optimizer optimizer(control);
  optim_result res = optimizer.minimize(obj, lower, upper, fi_init);

  arma::vec fi_fit = fi_init;
  if (res.best_par.n_elem == fi_init.n_elem && std::isfinite(res.best_value)) {
    fi_fit = res.best_par;
  }

  gp_profile_result fit = gp_profile_fit(
    X_train,
    y_train,
    fi_fit,
    arma::ones<arma::mat>(X_train.n_rows, 1),
    nugget_value,
    nugget_provided
  );

  if (!fit.success) {
    fit = gp_profile_fit(
      X_train,
      y_train,
      fi_init,
      arma::ones<arma::mat>(X_train.n_rows, 1),
      nugget_value,
      nugget_provided
    );
    fi_fit = fi_init;
  }

  if (!fit.success) {
    out.used_fallback = true;
    out.fi = fi_init;
    const double grand_mean = arma::mean(y_train);
    out.mean = arma::vec(n_union);
    out.mean.fill(grand_mean);
    out.cov = arma::eye<arma::mat>(n_union, n_union) * std::max(1e-8, arma::var(y_train));
    out.success = true;
    out.message = "Level-specific union imputation fell back to a constant predictor because the GP fit was numerically unstable.";
    return out;
  }

  const arma::vec theta = arma::exp(fi_fit * std::log(10.0));
  const arma::mat r_matrix = ctgp_gp_cross_corr_matrix(union_design, X_train, theta, use_openmp, num_threads);
  const arma::mat SXX = ctgp_gp_self_corr_matrix(union_design, theta, true, fit.effective_nugget, use_openmp, num_threads);
  const arma::mat U = arma::solve(arma::trimatl(fit.l_matrix), r_matrix.t());

  out.fi = fi_fit;
  out.mean = arma::ones<arma::vec>(n_union) * fit.beta_vec(0) + r_matrix * fit.alpha_vec;
  out.cov = fit.sigma_sq * (SXX - U.t() * U);
  out.cov = 0.5 * (out.cov + out.cov.t());
  arma::vec diagv = out.cov.diag();
  for (arma::uword i = 0; i < diagv.n_elem; ++i) {
    if (!std::isfinite(diagv(i))) {
      out.message = "Union-design predictive covariance contains non-finite diagonal entries.";
      return out;
    }
    diagv(i) = std::max(0.0, diagv(i));
  }
  out.cov.diag() = diagv;
  out.success = true;
  return out;
}

Rcpp::LogicalMatrix wrap_missing_mask(const arma::umat& mask) {
  Rcpp::LogicalMatrix out(mask.n_rows, mask.n_cols);
  for (arma::uword j = 0; j < mask.n_cols; ++j) {
    for (arma::uword i = 0; i < mask.n_rows; ++i) {
      out(i, j) = (mask(i, j) != 0u);
    }
  }
  return out;
}

}  // namespace

double ctgp_compute_nugget_tb(const arma::mat& mat, double condition_target) {
  arma::mat sym = 0.5 * (mat + mat.t());
  arma::vec eigval;
  const bool ok = arma::eig_sym(eigval, sym);
  if (!ok || eigval.n_elem == 0) {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }
  const double lam_min = eigval.min();
  const double lam_max = eigval.max();
  if (!std::isfinite(lam_min) || !std::isfinite(lam_max)) {
    return std::sqrt(std::numeric_limits<double>::epsilon());
  }
  const double check_cond = std::abs(lam_max) - condition_target * std::abs(lam_min);
  if (check_cond >= 0.0) {
    return check_cond / (condition_target - 1.0);
  }
  return std::sqrt(std::numeric_limits<double>::epsilon());
}

arma::mat ctgp_cov2cor_sym(const arma::mat& cov) {
  arma::mat out = 0.5 * (cov + cov.t());
  arma::vec diagv = out.diag();
  arma::vec invsd(diagv.n_elem, arma::fill::zeros);
  for (arma::uword i = 0; i < diagv.n_elem; ++i) {
    if (diagv(i) > 0.0 && std::isfinite(diagv(i))) {
      invsd(i) = 1.0 / std::sqrt(diagv(i));
    }
  }
  out = arma::diagmat(invsd) * out * arma::diagmat(invsd);
  out.diag().ones();
  return 0.5 * (out + out.t());
}

Rcpp::List ctgp_default_global_bounds(const arma::mat& design) {
  return default_fi_bounds_global_impl(design);
}

ctgp_global_gp_objective::ctgp_global_gp_objective(
    const std::vector<arma::mat>& design_list,
    const std::vector<arma::vec>& y_list,
    bool nugget_provided,
    double nugget_value,
    bool use_openmp,
    int num_threads,
    int objective_mode
) : design_list_(design_list),
    y_list_(y_list),
    nugget_provided_(nugget_provided),
    nugget_value_(nugget_value),
    use_openmp_(use_openmp),
    num_threads_(num_threads),
    objective_mode_(gp_resolve_objective_mode_int(objective_mode)) {}

double ctgp_global_gp_objective::eval(const arma::vec& par) {
  double total = 0.0;
  const int n_tasks = static_cast<int>(design_list_.size());
#ifndef _OPENMP
  (void)use_openmp_;
  (void)num_threads_;
#endif

#ifdef _OPENMP
  const int n_threads = ctgp_effective_threads(use_openmp_, num_threads_, n_tasks);
  if (n_threads > 1) {
    std::atomic<bool> bad(false);
#pragma omp parallel for schedule(static) reduction(+:total) num_threads(n_threads)
    for (int idx = 0; idx < n_tasks; ++idx) {
      if (bad.load(std::memory_order_relaxed)) {
        continue;
      }
      const arma::mat& X = design_list_[idx];
      const arma::vec& y = y_list_[idx];
      gp_profile_result fit = gp_profile_fit(
        X,
        y,
        par,
        arma::ones<arma::mat>(X.n_rows, 1),
        nugget_value_,
        nugget_provided_,
        objective_mode_
      );
      if (!fit.success || !std::isfinite(fit.neg_log_lik)) {
        bad.store(true, std::memory_order_relaxed);
      } else {
        total += fit.neg_log_lik;
      }
    }
    if (bad.load(std::memory_order_relaxed)) {
      return arma::datum::inf;
    }
    return total;
  }
#endif

  for (int idx = 0; idx < n_tasks; ++idx) {
    const arma::mat& X = design_list_[idx];
    const arma::vec& y = y_list_[idx];

    gp_profile_result fit = gp_profile_fit(
      X,
      y,
      par,
      arma::ones<arma::mat>(X.n_rows, 1),
      nugget_value_,
      nugget_provided_,
      objective_mode_
    );
    if (!fit.success || !std::isfinite(fit.neg_log_lik)) {
      return arma::datum::inf;
    }

    total += fit.neg_log_lik;
  }

  return total;
}

ctgp_bcd_objective::ctgp_bcd_objective(
    const arma::mat& design,
    const arma::mat& y_matrix,
    const arma::mat& tau_cov_current,
    bool nugget_provided,
    double nugget_value
) : design_(design),
    y_matrix_(y_matrix),
    tau_cov_current_(tau_cov_current),
    nugget_provided_(nugget_provided),
    nugget_value_(nugget_value) {}

double ctgp_bcd_objective::eval(const arma::vec& fi) {
  arma::mat H_base, H_effective, H_inv;
  double h_nugget = 0.0, rcond_h = NA_REAL;
  std::string message;
  if (!build_H_with_tb_nugget(design_, fi, nugget_provided_, nugget_value_, H_base, H_effective, h_nugget, rcond_h, H_inv, message)) {
    return arma::datum::inf;
  }

  arma::vec one_vec(y_matrix_.n_rows, arma::fill::ones);
  const double denom = arma::as_scalar(one_vec.t() * H_inv * one_vec);
  if (!std::isfinite(denom) || std::abs(denom) <= std::numeric_limits<double>::epsilon()) {
    return arma::datum::inf;
  }
  const arma::rowvec mu_row = (one_vec.t() * H_inv * y_matrix_) / denom;
  arma::vec mu = mu_row.t();

  arma::mat tau_effective = 0.5 * (tau_cov_current_ + tau_cov_current_.t());
  const double extra_t_nugget = ctgp_compute_nugget_tb(tau_effective, 1e8);
  tau_effective = add_diag(tau_effective, extra_t_nugget);
  tau_effective = 0.5 * (tau_effective + tau_effective.t());

  return negloglik_from_state(y_matrix_, H_effective, H_inv, mu, tau_effective);
}

ctgp_global_gp_fit_result ctgp_global_gp_fit_core(
    const arma::mat& coerce_data,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode
) {
  ctgp_global_gp_fit_result out;
  if (coerce_data.n_cols < 3) {
    out.message = "coerce_data must contain at least one x column, c.T, and Y.";
    return out;
  }

  const int d = static_cast<int>(coerce_data.n_cols) - 2;
  const arma::mat X_all = coerce_data.cols(0, d - 1);
  const arma::vec level_vec = coerce_data.col(d);
  const arma::vec y_all = coerce_data.col(d + 1);

  const std::vector<int> level_ids = sorted_unique_levels(level_vec);
  std::vector<arma::mat> design_list;
  std::vector<arma::vec> y_list;
  design_list.reserve(level_ids.size());
  y_list.reserve(level_ids.size());

  for (std::size_t i = 0; i < level_ids.size(); ++i) {
    const arma::uvec idx = arma::find(arma::abs(level_vec - static_cast<double>(level_ids[i])) < 0.5);
    design_list.push_back(X_all.rows(idx));
    y_list.push_back(y_all.elem(idx));
  }

  ctgp_global_gp_objective obj(design_list, y_list, nugget_provided, nugget_value, use_openmp, num_threads, objective_mode);
  pso_control control;
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;

  pso_optimizer optimizer(control);
  optim_result res = optimizer.minimize(obj, lower, upper, init);

  out.fi = res.best_par;
  out.lower = lower;
  out.upper = upper;
  out.init = init;
  out.objective = res.best_value;
  out.n_eval = res.n_eval;
  out.converged = res.converged;
  out.success = res.best_par.n_elem == static_cast<arma::uword>(d) && std::isfinite(res.best_value);
  out.message = out.success ? "" : "PSO failed to find a finite ctGP global GP optimum.";
  out.h_nugget = nugget_provided ? nugget_value : NA_REAL;
  out.objective_mode = gp_resolve_objective_mode_int(objective_mode);
  return out;
}

ctgp_bcd_state ctgp_bcd_update_given_fi(
    const arma::vec& fi,
    const arma::mat& design,
    const arma::mat& y_matrix,
    bool nugget_provided,
    double nugget_value
) {
  ctgp_bcd_state out;

  arma::mat H_base, H_effective, H_inv;
  double h_nugget = 0.0, rcond_h = NA_REAL;
  std::string message;
  if (!build_H_with_tb_nugget(design, fi, nugget_provided, nugget_value, H_base, H_effective, h_nugget, rcond_h, H_inv, message)) {
    out.message = message;
    return out;
  }

  out = ctgp_update_tau_given_h_inv(H_base, H_effective, H_inv, y_matrix, h_nugget, static_cast<double>(y_matrix.n_rows), "common");
  if (!out.success) {
    return out;
  }

  out.neg_lik = negloglik_from_state(y_matrix, out.H_effective, out.H_inv, out.mu, out.tau_cov_effective);
  if (!std::isfinite(out.neg_lik)) {
    out.success = false;
    out.message = "Failed to evaluate the ctGP BCD negative log-likelihood.";
  }
  return out;
}

ctgp_bcd_state ctgp_bcd_union_update_given_fi(
    const arma::vec& fi,
    const arma::mat& coerce_data,
    const arma::mat& union_design,
    const std::vector<int>& level_ids,
    const std::vector<arma::uvec>& group_union_index,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    int union_mcmc_samples,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode
) {
  ctgp_bcd_state out;
  out.regime = "union";

  if (coerce_data.n_cols < 3) {
    out.message = "coerce_data must contain x columns, c.T, and Y for union-design BCD.";
    return out;
  }

  arma::mat H_base, H_effective, H_inv;
  double h_nugget = 0.0, rcond_h = NA_REAL;
  std::string message;
  if (!build_H_with_tb_nugget(union_design, fi, nugget_provided, nugget_value, H_base, H_effective, h_nugget, rcond_h, H_inv, message)) {
    out.message = message;
    return out;
  }

  const int d = static_cast<int>(coerce_data.n_cols) - 2;
  const arma::vec level_vec = coerce_data.col(d);
  const arma::vec y_all = coerce_data.col(d + 1);
  const arma::mat X_all = coerce_data.cols(0, d - 1);
  const int n_levels = static_cast<int>(level_ids.size());
  const int n_union = static_cast<int>(union_design.n_rows);
  const int mc_samples = std::max(1, union_mcmc_samples);
  const double scale_divisor = static_cast<double>(coerce_data.n_rows) / static_cast<double>(std::max(1, n_levels));

  arma::mat y_obs(n_union, n_levels);
  y_obs.fill(arma::datum::nan);
  arma::umat missing_mask(n_union, n_levels, arma::fill::ones);
  arma::mat y_working(n_union, n_levels, arma::fill::zeros);
  arma::mat level_fi_mat(n_levels, fi.n_elem, arma::fill::zeros);
  std::vector<arma::mat> level_cov_list(n_levels);
  std::vector<std::string> level_messages(n_levels);
  std::atomic<bool> had_error(false);
  std::string error_message;

  // Resolve the hidden optimizer kernel mode once on the main thread.
  // Calling back into R (e.g. getOption()) from an OpenMP worker thread is unsafe.
  const int resolved_kernel_mode = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);

  // Do not parallelize across levels here. Each level-wise GP fit invokes LAPACK/Armadillo
  // kernels and an optimizer; on macOS/Accelerate this outer parallelism is prone to
  // native instability. We still keep OpenMP enabled inside the level-wise kernels/optimizer.
  for (int j = 0; j < n_levels; ++j) {
    if (had_error.load(std::memory_order_relaxed)) {
      continue;
    }
    try {
      const int lev = level_ids[j];
      const arma::uvec obs_idx = arma::find(arma::abs(level_vec - static_cast<double>(lev)) < 0.5);
      if (obs_idx.n_elem == 0) {
#ifdef _OPENMP
#pragma omp critical(ctgp_union_error)
#endif
        {
          if (!had_error.load(std::memory_order_relaxed)) {
            error_message = "A combined level in union-design BCD has no observed rows.";
            had_error.store(true, std::memory_order_relaxed);
          }
        }
        continue;
      }
      if (static_cast<std::size_t>(j) >= group_union_index.size() || group_union_index[j].n_elem != obs_idx.n_elem) {
#ifdef _OPENMP
#pragma omp critical(ctgp_union_error)
#endif
        {
          if (!had_error.load(std::memory_order_relaxed)) {
            error_message = "group_union_index is inconsistent with the original coerce_data ordering.";
            had_error.store(true, std::memory_order_relaxed);
          }
        }
        continue;
      }

      const arma::mat X_obs = X_all.rows(obs_idx);
      const arma::vec y_obs_level = y_all.elem(obs_idx);
      arma::uvec union_rows = group_union_index[j];

      pso_control local_control;
      local_control.swarm_size = swarm_size;
      local_control.max_iter = max_iter;
      local_control.c1 = c1;
      local_control.c2 = c2;
      local_control.w = w;
      local_control.tol = tol;
      local_control.use_openmp = use_openmp;
      local_control.num_threads = num_threads;
      local_control.seed = (seed >= 0) ? (seed + 7919 * (j + 1)) : -1;
      local_control.kernel_mode = resolved_kernel_mode;

      ctgp_union_level_prediction pred = fit_level_gp_and_predict(
        union_design,
        X_obs,
        y_obs_level,
        union_rows,
        fi,
        lower,
        upper,
        nugget_provided,
        nugget_value,
        local_control.swarm_size,
        local_control.max_iter,
        local_control.c1,
        local_control.c2,
        local_control.w,
        local_control.tol,
        local_control.use_openmp,
        local_control.num_threads,
        local_control.seed,
        objective_mode,
        local_control.kernel_mode
      );

      if (!pred.success) {
#ifdef _OPENMP
#pragma omp critical(ctgp_union_error)
#endif
        {
          if (!had_error.load(std::memory_order_relaxed)) {
            error_message = pred.message;
            had_error.store(true, std::memory_order_relaxed);
          }
        }
        continue;
      }

      y_working.col(j) = pred.mean;
      level_cov_list[j] = pred.cov;
      level_fi_mat.row(j) = pred.fi.t();
      y_obs.col(j) = pred.observed_mean;
      for (arma::uword ii = 0; ii < pred.observed_rows.n_elem; ++ii) {
        missing_mask(pred.observed_rows(ii), j) = 0u;
      }
      level_messages[j] = pred.message;
    } catch (const std::exception& e) {
#ifdef _OPENMP
#pragma omp critical(ctgp_union_error)
#endif
      {
        if (!had_error.load(std::memory_order_relaxed)) {
          error_message = e.what();
          had_error.store(true, std::memory_order_relaxed);
        }
      }
    } catch (...) {
#ifdef _OPENMP
#pragma omp critical(ctgp_union_error)
#endif
      {
        if (!had_error.load(std::memory_order_relaxed)) {
          error_message = "Unknown exception in union-design BCD level-wise GP update.";
          had_error.store(true, std::memory_order_relaxed);
        }
      }
    }
  }

  if (had_error.load(std::memory_order_relaxed)) {
    out.message = error_message;
    return out;
  }

  std::vector<arma::mat> sample_factor_list(n_levels);
  std::vector<double> added_cov_nugget(n_levels, 0.0);
  for (int j = 0; j < n_levels; ++j) {
    const arma::mat& cov = level_cov_list[j];
    if (cov.n_elem == 0) {
      out.message = "A union-design level returned an empty predictive covariance matrix.";
      return out;
    }
    arma::mat factor;
    if (!stabilize_covariance_for_sampling(cov, factor, added_cov_nugget[j])) {
      out.message = "Failed to factorize a union-design predictive covariance matrix for Monte Carlo sampling.";
      return out;
    }
    sample_factor_list[j] = std::move(factor);
  }

  arma::mat sum_cov_base(n_levels, n_levels, arma::fill::zeros);
  arma::mat sum_cov_eff(n_levels, n_levels, arma::fill::zeros);
  arma::mat sum_corr(n_levels, n_levels, arma::fill::zeros);
  double sum_t_nugget = 0.0;

  std::mt19937_64 rng;
  if (seed >= 0) {
    rng.seed(static_cast<std::mt19937_64::result_type>(seed + 2027));
  } else {
    std::random_device rd;
    rng.seed(static_cast<std::mt19937_64::result_type>(rd()));
  }

  for (int s = 0; s < mc_samples; ++s) {
    arma::mat y_draw(n_union, n_levels, arma::fill::zeros);
    for (int j = 0; j < n_levels; ++j) {
      y_draw.col(j) = sample_mvn_once(y_working.col(j), sample_factor_list[j], rng);
    }

    ctgp_bcd_state draw_state = ctgp_update_tau_given_h_inv(
      H_base,
      H_effective,
      H_inv,
      y_draw,
      h_nugget,
      scale_divisor,
      "union"
    );
    if (!draw_state.success) {
      out.message = draw_state.message;
      return out;
    }

    sum_cov_base += draw_state.tau_cov_base;
    sum_cov_eff += draw_state.tau_cov_effective;
    sum_corr += draw_state.tau_corr;
    sum_t_nugget += draw_state.t_nugget;
  }

  ctgp_bcd_state mean_state = ctgp_update_tau_given_h_inv(
    H_base,
    H_effective,
    H_inv,
    y_working,
    h_nugget,
    scale_divisor,
    "union"
  );
  if (!mean_state.success) {
    return mean_state;
  }

  out = mean_state;
  out.regime = "union";
  out.y_matrix = y_working;
  out.y_matrix_observed = y_obs;
  out.missing_mask = missing_mask;
  out.level_fi = level_fi_mat;
  out.used_monte_carlo = true;
  out.mc_samples = mc_samples;
  out.scale_divisor = scale_divisor;
  out.tau_cov_base = sum_cov_base / static_cast<double>(mc_samples);
  out.tau_cov_effective = sum_cov_eff / static_cast<double>(mc_samples);
  out.tau_cov_effective = 0.5 * (out.tau_cov_effective + out.tau_cov_effective.t());
  out.tau_corr = sum_corr / static_cast<double>(mc_samples);
  out.tau_corr = 0.5 * (out.tau_corr + out.tau_corr.t());
  out.t_nugget = sum_t_nugget / static_cast<double>(mc_samples);
  out.rcond_t = arma::rcond(out.tau_cov_effective);
  out.neg_lik = negloglik_from_state(y_working, H_effective, H_inv, out.mu, out.tau_cov_effective);
  out.success = std::isfinite(out.neg_lik);

  std::ostringstream oss;
  bool has_msg = false;
  for (int j = 0; j < n_levels; ++j) {
    if (!level_messages[j].empty()) {
      if (has_msg) {
        oss << " | ";
      }
      oss << "level " << level_ids[j] << ": " << level_messages[j];
      has_msg = true;
    }
  }
  out.message = oss.str();
  if (!out.success && out.message.empty()) {
    out.message = "Failed to evaluate the union-design ctGP BCD negative log-likelihood.";
  }
  return out;
}

Rcpp::List ctgp_bcd_loop_core(
    const std::string& regime,
    const arma::mat& coerce_data,
    const arma::mat& design,
    const arma::mat& y_matrix,
    const arma::mat& union_design,
    const std::vector<int>& level_ids,
    const std::vector<arma::uvec>& group_union_index,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    bool init_provided,
    int bcd_loops,
    double bcd_tol,
    int union_mcmc_samples,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode
) {
  if (bcd_loops < 1) {
    Rcpp::stop("bcd_loops must be positive.");
  }

  const bool is_union = (regime == "union");
  if (is_union) {
    if (union_design.n_elem == 0 || level_ids.empty() || group_union_index.empty()) {
      Rcpp::stop("Union-design ctGP BCD requires union_design, level_ids, and group_union_index.");
    }
  } else {
    if (design.n_elem == 0 || y_matrix.n_elem == 0) {
      Rcpp::stop("Common-design ctGP BCD requires design and y_matrix.");
    }
  }

  arma::vec fi_current;
  arma::vec initial_fi;
  double initial_objective = NA_REAL;
  int initial_n_eval = 0;
  bool initial_converged = false;
  std::string initial_source;

  if (init_provided) {
    fi_current = init;
    initial_fi = fi_current;
    initial_source = "user_init_param";
  } else {
    ctgp_global_gp_fit_result init_fit = ctgp_global_gp_fit_core(
      coerce_data,
      nugget_provided,
      nugget_value,
      lower,
      upper,
      init,
      swarm_size,
      max_iter,
      c1,
      c2,
      w,
      tol,
      use_openmp,
      num_threads,
      seed,
      objective_mode
    );
    if (!init_fit.success) {
      Rcpp::stop(init_fit.message);
    }
    fi_current = init_fit.fi;
    initial_fi = fi_current;
    initial_objective = init_fit.objective;
    initial_n_eval = init_fit.n_eval;
    initial_converged = init_fit.converged;
    initial_source = "global_gp";
  }

  ctgp_bcd_state state = is_union
    ? ctgp_bcd_union_update_given_fi(
        fi_current,
        coerce_data,
        union_design,
        level_ids,
        group_union_index,
        nugget_provided,
        nugget_value,
        lower,
        upper,
        union_mcmc_samples,
        swarm_size,
        max_iter,
        c1,
        c2,
        w,
        tol,
        use_openmp,
        num_threads,
        seed
      )
    : ctgp_bcd_update_given_fi(fi_current, design, y_matrix, nugget_provided, nugget_value);

  if (!state.success) {
    Rcpp::stop(state.message);
  }

  if (!std::isfinite(state.neg_lik)) {
    state.neg_lik = negloglik_from_state(state.y_matrix, state.H_effective, state.H_inv, state.mu, state.tau_cov_effective);
  }
  if (std::isfinite(state.neg_lik) && !std::isfinite(initial_objective)) {
    initial_objective = state.neg_lik;
  }
  if (initial_fi.n_elem == 0) {
    initial_fi = fi_current;
  }

  Rcpp::List trace(bcd_loops);
  trace[0] = Rcpp::List::create(
    Rcpp::Named("iter") = 0,
    Rcpp::Named("stage") = "initial",
    Rcpp::Named("regime") = regime,
    Rcpp::Named("objective") = state.neg_lik,
    Rcpp::Named("rcond_h") = state.rcond_h,
    Rcpp::Named("rcond_t") = state.rcond_t,
    Rcpp::Named("h_nugget") = state.h_nugget,
    Rcpp::Named("t_nugget") = state.t_nugget,
    Rcpp::Named("fi") = fi_current,
    Rcpp::Named("mu") = state.mu,
    Rcpp::Named("delta_fi") = NA_REAL,
    Rcpp::Named("delta_mu") = NA_REAL,
    Rcpp::Named("delta_t") = NA_REAL,
    Rcpp::Named("stopped") = false,
    Rcpp::Named("used_monte_carlo") = state.used_monte_carlo,
    Rcpp::Named("mc_samples") = state.mc_samples
  );

  int iter_used = 1;
  const arma::mat& objective_design = is_union ? union_design : design;

  for (int iter = 1; iter < bcd_loops; ++iter) {
    const arma::vec prev_fi = fi_current;
    const arma::vec prev_mu = state.mu;
    const arma::mat prev_T = state.tau_cov_effective;

    ctgp_bcd_objective obj(objective_design, state.y_matrix, prev_T, nugget_provided, nugget_value);
    pso_control control;
    control.swarm_size = swarm_size;
    control.max_iter = max_iter;
    control.c1 = c1;
    control.c2 = c2;
    control.w = w;
    control.tol = tol;
    control.use_openmp = use_openmp;
    control.num_threads = num_threads;
    control.seed = (seed >= 0) ? (seed + 104729 * iter) : -1;

    pso_optimizer optimizer(control);
    optim_result opt = optimizer.minimize(obj, lower, upper, prev_fi);
    fi_current = (opt.best_par.n_elem == prev_fi.n_elem) ? opt.best_par : prev_fi;

    state = is_union
      ? ctgp_bcd_union_update_given_fi(
          fi_current,
          coerce_data,
          union_design,
          level_ids,
          group_union_index,
          nugget_provided,
          nugget_value,
          lower,
          upper,
          union_mcmc_samples,
          swarm_size,
          max_iter,
          c1,
          c2,
          w,
          tol,
          use_openmp,
          num_threads,
          (seed >= 0) ? (seed + 130363 * iter) : -1
        )
      : ctgp_bcd_update_given_fi(fi_current, design, y_matrix, nugget_provided, nugget_value);

    if (!state.success) {
      Rcpp::stop(state.message);
    }

    const double delta_fi = arma::abs(fi_current - prev_fi).max();
    const double delta_mu = arma::abs(state.mu - prev_mu).max();
    const double delta_t = arma::abs(state.tau_cov_effective - prev_T).max();
    const double delta_max = std::max(delta_fi, std::max(delta_mu, delta_t));

    bool stopped = false;
    if (std::isfinite(delta_max) && delta_max <= bcd_tol) {
      stopped = true;
    }

    trace[iter] = Rcpp::List::create(
      Rcpp::Named("iter") = iter,
      Rcpp::Named("stage") = "BCD",
      Rcpp::Named("regime") = regime,
      Rcpp::Named("objective") = state.neg_lik,
      Rcpp::Named("rcond_h") = state.rcond_h,
      Rcpp::Named("rcond_t") = state.rcond_t,
      Rcpp::Named("h_nugget") = state.h_nugget,
      Rcpp::Named("t_nugget") = state.t_nugget,
      Rcpp::Named("fi") = fi_current,
      Rcpp::Named("mu") = state.mu,
      Rcpp::Named("delta_fi") = delta_fi,
      Rcpp::Named("delta_mu") = delta_mu,
      Rcpp::Named("delta_t") = delta_t,
      Rcpp::Named("stopped") = stopped,
      Rcpp::Named("used_monte_carlo") = state.used_monte_carlo,
      Rcpp::Named("mc_samples") = state.mc_samples
    );

    iter_used = iter + 1;
    if (stopped) {
      break;
    }
  }

  Rcpp::List trace_used(iter_used);
  for (int i = 0; i < iter_used; ++i) {
    trace_used[i] = trace[i];
  }

  SEXP y_matrix_observed_sexp = R_NilValue;
  SEXP missing_mask_sexp = R_NilValue;
  SEXP level_fi_sexp = R_NilValue;
  SEXP nugget_sexp = R_NilValue;
  if (is_union) {
    y_matrix_observed_sexp = Rcpp::wrap(state.y_matrix_observed);
    missing_mask_sexp = Rcpp::wrap(wrap_missing_mask(state.missing_mask));
    level_fi_sexp = Rcpp::wrap(state.level_fi);
  }
  if (nugget_provided) {
    nugget_sexp = Rcpp::wrap(nugget_value);
  }

  return Rcpp::List::create(
    Rcpp::Named("regime") = regime,
    Rcpp::Named("fi") = fi_current,
    Rcpp::Named("bound") = arma::join_cols(lower, upper),
    Rcpp::Named("common_r_matrix") = state.H_effective,
    Rcpp::Named("common_r_matrix_base") = state.H_base,
    Rcpp::Named("mu_vec") = state.mu,
    Rcpp::Named("tau_cov_matrix") = state.tau_cov_effective,
    Rcpp::Named("tau_cov_matrix_base") = state.tau_cov_base,
    Rcpp::Named("tau_matrix") = state.tau_corr,
    Rcpp::Named("trace") = trace_used,
    Rcpp::Named("h_nugget") = state.h_nugget,
    Rcpp::Named("t_nugget") = state.t_nugget,
    Rcpp::Named("rcond_h") = state.rcond_h,
    Rcpp::Named("rcond_t") = state.rcond_t,
    Rcpp::Named("objective") = state.neg_lik,
    Rcpp::Named("n_bcd_iter_used") = iter_used,
    Rcpp::Named("bcd_tol") = bcd_tol,
    Rcpp::Named("initial_source") = initial_source,
    Rcpp::Named("initial_objective") = initial_objective,
    Rcpp::Named("initial_fi") = initial_fi,
    Rcpp::Named("initial_n_eval") = initial_n_eval,
    Rcpp::Named("initial_converged") = initial_converged,
    Rcpp::Named("used_monte_carlo") = state.used_monte_carlo,
    Rcpp::Named("mc_samples") = state.mc_samples,
    Rcpp::Named("scale_divisor") = state.scale_divisor,
    Rcpp::Named("y_matrix") = state.y_matrix,
    Rcpp::Named("y_matrix_observed") = y_matrix_observed_sexp,
    Rcpp::Named("missing_mask") = missing_mask_sexp,
    Rcpp::Named("level_fi_matrix") = level_fi_sexp,
    Rcpp::Named("nugget") = nugget_sexp,
    Rcpp::Named("message") = state.message
  );
}

Rcpp::List ctgp_bcd_common_loop_core(
    const arma::mat& coerce_data,
    const arma::mat& design,
    const arma::mat& y_matrix,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    bool init_provided,
    int bcd_loops,
    double bcd_tol,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode
) {
  std::vector<int> level_ids;
  std::vector<arma::uvec> group_union_index;
  arma::mat empty_mat;
  return ctgp_bcd_loop_core(
    "common",
    coerce_data,
    design,
    y_matrix,
    empty_mat,
    level_ids,
    group_union_index,
    nugget_provided,
    nugget_value,
    lower,
    upper,
    init,
    init_provided,
    bcd_loops,
    bcd_tol,
    1,
    swarm_size,
    max_iter,
    c1,
    c2,
    w,
    tol,
    use_openmp,
    num_threads,
    seed
  );
}
