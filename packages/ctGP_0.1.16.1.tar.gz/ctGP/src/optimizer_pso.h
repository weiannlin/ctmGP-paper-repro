#ifndef OPTIMIZER_PSO_H
#define OPTIMIZER_PSO_H

#include <RcppArmadillo.h>
#include <random>
#include <string>
#include "objective_base.h"

// Lightweight OpenMP query helpers used by the R interface.
bool ctgp_openmp_compiled();
int ctgp_openmp_max_threads_runtime();
int ctgp_openmp_resolve_threads(bool use_openmp, int requested_threads, int n_tasks);
int ctgp_openmp_recommended_threads(int n_tasks);

enum pso_kernel_mode_code {
  PSO_KERNEL_STABLE = 0,
  PSO_KERNEL_GLOBPSO_EXACT = 1
};

int ctgp_internal_pso_kernel_mode_from_option(int fallback = PSO_KERNEL_STABLE);
std::string ctgp_internal_pso_kernel_mode_label(int mode);

struct pso_control {
  int swarm_size;
  int max_iter;
  double c1;
  double c2;
  double w;
  double tol;
  bool use_openmp;
  int num_threads;  // <= 0 means runtime default
  int seed;         // < 0 means do not force deterministic seed

  // Legacy-compatible globpso/QPSO settings.
  bool quantum;
  double free_run;
  double w0;
  double w1;
  double w_var;
  double vk;
  int q_center_type;
  double q_a0;
  double q_a1;
  double q_a_var;

  // Internal-only kernel mode. Leave at -1 to resolve from
  // getOption("ctGP.internal.debug.optimizer_mode", "qpso").
  int kernel_mode;

  pso_control()
    : swarm_size(64), max_iter(200),
      c1(2.05), c2(2.05), w(0.7), tol(1e-6),
      use_openmp(true), num_threads(0), seed(-1),
      quantum(true), free_run(1.0),
      w0(1.2), w1(0.2), w_var(0.8), vk(4.0),
      q_center_type(1), q_a0(1.7), q_a1(0.7), q_a_var(0.8),
      kernel_mode(-1) {}
};

struct optim_result {
  arma::vec best_par;
  double best_value;
  arma::vec history;
  int n_eval;
  bool converged;

  optim_result()
    : best_value(arma::datum::inf), n_eval(0), converged(false) {}
};

class pso_optimizer {
public:
  explicit pso_optimizer(const pso_control& control);

  optim_result minimize(
      objective_base& obj,
      const arma::vec& lower,
      const arma::vec& upper,
      const arma::vec& init_center = arma::vec()
  );

private:
  pso_control control_;
  bool use_internal_seed_;
  std::mt19937_64 rng_;

  arma::mat initialize_swarm(
      int n_particles,
      int dim,
      const arma::vec& lower,
      const arma::vec& upper,
      const arma::vec& init_center
  );

  arma::mat initialize_velocity(
      int n_particles,
      int dim,
      const arma::vec& lower,
      const arma::vec& upper
  );

  void clamp_particles(
      arma::mat& swarm,
      const arma::vec& lower,
      const arma::vec& upper
  );

  arma::vec clamp_vector(
      const arma::vec& x,
      const arma::vec& lower,
      const arma::vec& upper
  ) const;

  void evaluate_swarm(
      objective_base& obj,
      const arma::mat& swarm,
      arma::vec& values
  ) const;

  optim_result minimize_globpso_exact(
      objective_base& obj,
      const arma::vec& lower,
      const arma::vec& upper,
      const arma::vec& init_center
  );

  int effective_num_threads(int n_tasks) const;
  arma::mat random_uniform_matrix(int n_rows, int n_cols);
  arma::vec random_uniform_vector(int n);
  double random_uniform_scalar();
};

#endif
