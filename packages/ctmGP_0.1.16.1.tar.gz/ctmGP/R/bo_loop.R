# ctmGP — multi-objective Bayesian optimization driver.
#
# Sequential MOBO loop for the AoAS paper §4.3 + §5 setups.  Backed by the
# unified surrogate adapters (fit_qqigp / fit_ctmgp / fit_qqmgp) and the
# unified acquisition engines (acq_ehvi / acq_eim).
#
# Two selection strategies (paper §4.3.1):
#   "single_config"     : per iter, evaluate exactly one (x*, w*) — argmax of acq.
#   "categorical_batch" : per iter, pick argmax to set x*, then evaluate at the
#                         FULL set {(x*, w) : w ∈ W_grid} — augmenting the design
#                         with one observation per categorical-level combination.
#
# Candidate set per iter: cross-product of a uniform grid over continuous vars
# (default cont_grid_n = 40 per dim, paper §4.3.3 default) × the full grid of
# categorical levels.  User can also pass an explicit `cont_grid` list for
# anisotropic discretisation (paper §5 cooling case uses 5×10×10 cont grid).
#
# CSV output is INCREMENTAL: per-iter row(s) appended on completion so an
# early-stopped run still leaves a complete partial trace
# (per feedback_benchmark_incremental_output.md).

#' Multi-objective Bayesian optimization loop.
#'
#' @param objective_fn function taking a data.frame of `x_cols + w_cols` rows
#'   and returning an `n × T` numeric matrix of objective evaluations.
#' @param init_data data.frame containing the initial design + responses
#'   (must have all of `x_cols`, `w_cols`, `y_cols`).
#' @param x_cols character vector of continuous-input column names.
#' @param w_cols character vector of categorical-input column names (may be empty).
#' @param y_cols character vector of response column names (length T ≥ 2).
#' @param x_bounds named list `x_col -> c(lower, upper)` for the continuous
#'   search range (one entry per `x_cols` element).
#' @param w_levels named list `w_col -> levels` defining the full categorical
#'   grid (one entry per `w_cols` element).  May be omitted if `w_cols` empty.
#' @param surrogate one of `"qqigp"` / `"ctmgp"` / `"qqmgp"`.
#' @param acquisition one of `"ehvi"` / `"eim"`.
#' @param strategy one of `"single_config"` / `"categorical_batch"`.
#' @param budget number of BO iterations.
#' @param cont_grid_n integer; equally spaced grid points per continuous
#'   dimension (used when `cont_grid` is NULL).  Default 40 (paper §4.3.3).
#' @param cont_grid optional named list `x_col -> numeric vector` overriding
#'   the per-dim grid (e.g., paper §5 cooling: 5/10/10).  Trumps `cont_grid_n`.
#' @param ref_point optional length-T reference point for HV / EHVI.  If NULL,
#'   re-derived from current PF per iter (`max + 0.1 * range`).
#' @param surrogate_control list of arguments forwarded to the surrogate fit
#'   (e.g., `optimizer_control`, `nugget`, `theta_range`).
#' @param ehvi_control list with optional `mc_samples` and `seed` for EHVI.
#' @param true_pf optional `n_PF × T` matrix of the true Pareto frontier — if
#'   provided, IGD+ is logged per iter (paper §4.3.2 metric).
#' @param output_csv optional path for incremental per-iter CSV output.
#' @param verbose logical; print per-iter summary lines.
#' @param seed integer; controls candidate-grid sub-sampling RNG (when grid
#'   exceeds `max_candidates`).
#' @param max_candidates integer; if the cross-product grid exceeds this,
#'   sub-sample uniformly to keep memory bounded.  Default 50000.
#' @return list with
#'   - `history`: data.frame, one row per evaluated point (≥1 per iter
#'     depending on `strategy`)
#'   - `final_data`: full data.frame including all evaluated points
#'   - `final_fit`: the final surrogate fit
#'   - `total_wall_sec`: wall time of the entire loop
#' @export
bo_loop <- function(objective_fn,
                    init_data,
                    x_cols, w_cols = character(0), y_cols,
                    x_bounds, w_levels = list(),
                    surrogate    = c("qqigp", "ctmgp", "qqmgp"),
                    acquisition  = c("ehvi", "eim"),
                    strategy     = c("single_config", "categorical_batch"),
                    budget       = 30L,
                    cont_grid_n  = 40L,
                    cont_grid    = NULL,
                    ref_point    = NULL,
                    surrogate_control = list(),
                    ehvi_control = list(mc_samples = 5000L, seed = 1L),
                    true_pf      = NULL,
                    output_csv   = NULL,
                    verbose      = TRUE,
                    seed         = 1L,
                    max_candidates = 50000L) {
  surrogate   <- match.arg(surrogate)
  acquisition <- match.arg(acquisition)
  strategy    <- match.arg(strategy)
  T_ <- length(y_cols)
  if (T_ < 2L) stop("bo_loop: y_cols must have length ≥ 2 for multi-objective BO.")

  # --- Build the candidate cross-product grid -------------------------------
  if (is.null(cont_grid)) {
    cont_grid <- lapply(x_cols, function(nm) {
      b <- x_bounds[[nm]]
      if (is.null(b) || length(b) != 2L)
        stop(sprintf("x_bounds[['%s']] must be length-2 (lower, upper).", nm))
      seq(b[1], b[2], length.out = cont_grid_n)
    })
    names(cont_grid) <- x_cols
  } else {
    miss <- setdiff(x_cols, names(cont_grid))
    if (length(miss)) stop("cont_grid missing entries: ", paste(miss, collapse=","), ".")
  }
  if (length(w_cols)) {
    miss <- setdiff(w_cols, names(w_levels))
    if (length(miss)) stop("w_levels missing entries: ", paste(miss, collapse=","), ".")
  }
  full_grid <- do.call(expand.grid,
                        c(cont_grid, w_levels[w_cols], stringsAsFactors = FALSE))

  # Subsample if grid too big
  set.seed(seed)
  if (nrow(full_grid) > max_candidates) {
    if (verbose) cat(sprintf(
      "[bo_loop] candidate grid has %d rows; sub-sampling to %d.\n",
      nrow(full_grid), max_candidates))
    full_grid <- full_grid[sample.int(nrow(full_grid), max_candidates), ,
                            drop = FALSE]
  }
  rownames(full_grid) <- NULL

  # --- Helpers --------------------------------------------------------------
  fit_call <- function(d) {
    args <- c(list(data = d, x_cols = x_cols, w_cols = w_cols, y_cols = y_cols),
              surrogate_control)
    do.call(switch(surrogate,
                   qqigp = fit_qqigp,
                   ctmgp = fit_ctmgp,
                   qqmgp = fit_qqmgp), args)
  }
  predict_call <- function(fit, newdata, joint) {
    do.call(switch(surrogate,
                   qqigp = predict_qqigp,
                   ctmgp = predict_ctmgp,
                   qqmgp = predict_qqmgp),
            list(fit = fit, newdata = newdata, joint = joint))
  }
  acq_call <- function(pred, pf, ref) {
    if (acquisition == "ehvi") {
      acq_ehvi(pred$mu, pred$sigma, pf, ref,
               block_indices = pred$blocks,
               mc_samples    = as.integer(ehvi_control$mc_samples %||% 5000L),
               seed          = as.integer(ehvi_control$seed %||% 1L))
    } else {
      acq_eim(pred$mu, pred$sigma_marginal, pf)
    }
  }

  # --- Initial state --------------------------------------------------------
  data_now <- as.data.frame(init_data, stringsAsFactors = FALSE,
                             check.names = FALSE)
  n_init <- nrow(data_now)
  Y_init <- as.matrix(data_now[, y_cols, drop = FALSE])
  pf_now <- pareto_front(Y_init)
  if (is.null(ref_point)) {
    ref_now <- ctmgp_default_ref_point(pf_now)
    auto_ref <- TRUE
  } else {
    ref_now <- as.numeric(ref_point); auto_ref <- FALSE
  }
  hv_init <- hypervolume(pf_now, ref_now)

  # --- CSV header (write once) ----------------------------------------------
  pred_mu_cols  <- paste0("pred_mu_",  y_cols)
  pred_sd_cols  <- paste0("pred_sd_",  y_cols)
  pred_err_cols <- paste0("pred_err_", y_cols)
  hist_cols <- c("iter", "obs_within_iter",
                  x_cols, w_cols, y_cols,
                  pred_mu_cols, pred_sd_cols, pred_err_cols,
                  "pred_rmse_iter",
                  "hv_after",
                  if (!is.null(true_pf)) "igd_plus_after",
                  "fit_wall_sec", "fit_cpu_sec",
                  "predict_wall_sec", "predict_cpu_sec",
                  "acq_wall_sec", "acq_cpu_sec",
                  "pred_eval_wall_sec", "pred_eval_cpu_sec",
                  "iter_wall_sec", "iter_cpu_sec",
                  "total_wall_sec", "total_cpu_sec")
  history <- data.frame(matrix(NA_real_, nrow = 0L, ncol = length(hist_cols)),
                         stringsAsFactors = FALSE)
  names(history) <- hist_cols

  if (!is.null(output_csv)) {
    write.table(history, file = output_csv, sep = ",", row.names = FALSE,
                col.names = TRUE, quote = FALSE)
  }

  # Write iter=0 baseline row (init-only state, no chosen point yet) so that
  # downstream trace plots have a starting anchor.  All chosen-point columns
  # (x, w, y, pred_*) are NA; only hv_after / igd_plus_after carry meaning.
  igd_plus_init <- if (!is.null(true_pf)) igd_plus(pf_now, true_pf) else NA_real_
  baseline_row <- as.data.frame(matrix(NA, nrow = 1L, ncol = length(hist_cols)),
                                  stringsAsFactors = FALSE)
  names(baseline_row) <- hist_cols
  baseline_row$iter <- 0L
  baseline_row$obs_within_iter <- 0L
  baseline_row$hv_after <- hv_init
  if (!is.null(true_pf)) baseline_row$igd_plus_after <- igd_plus_init
  for (cn in c("fit_wall_sec", "fit_cpu_sec",
                "predict_wall_sec", "predict_cpu_sec",
                "acq_wall_sec", "acq_cpu_sec",
                "pred_eval_wall_sec", "pred_eval_cpu_sec",
                "iter_wall_sec", "iter_cpu_sec",
                "total_wall_sec", "total_cpu_sec"))
    baseline_row[[cn]] <- 0
  history <- rbind(history, baseline_row)
  if (!is.null(output_csv)) {
    write.table(baseline_row, file = output_csv, sep = ",",
                row.names = FALSE, col.names = FALSE, quote = FALSE,
                append = TRUE)
  }

  if (verbose) {
    cat(sprintf("[bo_loop] %s + %s + %s | T=%d | n_init=%d | budget=%d | candidates=%d\n",
                surrogate, acquisition, strategy, T_, n_init, budget,
                nrow(full_grid)))
    cat(sprintf("[bo_loop] init HV = %.6f, ref = (%s)\n", hv_init,
                paste(sprintf("%.4g", ref_now), collapse=", ")))
  }

  # Helper: extract (wall, cpu) elapsed since t_start
  proc_delta <- function(t_start) {
    d <- proc.time() - t_start
    list(wall = as.numeric(d["elapsed"]),
         cpu  = as.numeric(d["user.self"] + d["sys.self"]))
  }

  total_t_start <- proc.time()
  final_fit <- NULL

  for (it in seq_len(budget)) {
    iter_t_start <- proc.time()

    # 1. Refresh ref + PF
    pf_now <- pareto_front(as.matrix(data_now[, y_cols, drop = FALSE]))
    if (auto_ref) ref_now <- ctmgp_default_ref_point(pf_now)

    # 2. Fit surrogate
    fit_t <- proc.time()
    fit <- fit_call(data_now)
    fit_d <- proc_delta(fit_t)

    # 3. Predict at all candidates
    pred_t <- proc.time()
    cand_in_required <- full_grid[, c(x_cols, w_cols), drop = FALSE]
    pred <- predict_call(fit, cand_in_required, joint = (acquisition == "ehvi"))
    pred_d <- proc_delta(pred_t)

    # 4. Acquisition
    acq_t <- proc.time()
    score <- acq_call(pred, pf_now, ref_now)
    # Mask out grid candidates that have already been evaluated.  Defensive
    # for grid-based BO: EHVI/EIM at observed points should be 0, but if the
    # leaf fit silently fails (e.g. near-singular K from same-x-different-w
    # cat_batch obs), σ stays at prior level and acq picks the same x again.
    # Excluding observed grid rows breaks that loop.
    if (nrow(data_now) > 0L) {
      key_cols <- c(x_cols, w_cols)
      cand_keys <- do.call(paste, c(full_grid[, key_cols, drop = FALSE], sep = "\x1f"))
      seen_keys <- do.call(paste, c(data_now[, key_cols, drop = FALSE],  sep = "\x1f"))
      seen_mask <- cand_keys %in% seen_keys
      if (any(seen_mask)) score[seen_mask] <- -Inf
    }
    acq_d <- proc_delta(acq_t)

    # 5. Pick argmax → eval set
    best_idx <- which.max(score)
    best_row <- full_grid[best_idx, , drop = FALSE]
    if (strategy == "single_config" || length(w_cols) == 0L) {
      eval_set <- best_row[, c(x_cols, w_cols), drop = FALSE]
    } else {
      # categorical_batch: same x*, all w-levels
      eval_set <- do.call(expand.grid,
                           c(as.list(best_row[, x_cols, drop = FALSE]),
                             w_levels[w_cols],
                             stringsAsFactors = FALSE))
    }
    rownames(eval_set) <- NULL
    n_in_iter <- nrow(eval_set)

    # 5b. Re-predict on the small eval_set to capture exact (μ, σ_marginal) at
    # the points we're about to evaluate (so we can log per-point pred error).
    pred_eval_t <- proc.time()
    pred_eval <- predict_call(fit, eval_set, joint = FALSE)
    pred_eval_d <- proc_delta(pred_eval_t)

    # 6. Evaluate objective
    Y_new <- as.matrix(objective_fn(eval_set))
    if (nrow(Y_new) != n_in_iter)
      stop(sprintf("objective_fn returned %d rows, expected %d.",
                   nrow(Y_new), n_in_iter))
    if (ncol(Y_new) != T_)
      stop(sprintf("objective_fn returned %d cols, expected %d (T).",
                   ncol(Y_new), T_))

    # 6b. Per-point pred error + per-iter RMSE
    mu_eval <- pred_eval$mu                              # T × n_in_iter
    sd_eval <- pred_eval$sigma_marginal                  # T × n_in_iter
    err_eval <- t(Y_new) - mu_eval                       # T × n_in_iter
    pred_rmse_iter <- sqrt(mean(err_eval^2))             # scalar over all (l, k)

    # 7. Append
    new_rows <- cbind(eval_set,
                       setNames(as.data.frame(Y_new), y_cols),
                       stringsAsFactors = FALSE)
    data_now <- rbind(data_now, new_rows)
    pf_after <- pareto_front(as.matrix(data_now[, y_cols, drop = FALSE]))
    hv_after <- hypervolume(pf_after, ref_now)
    igd_plus_after <- if (!is.null(true_pf)) igd_plus(pf_after, true_pf) else NA_real_

    iter_d  <- proc_delta(iter_t_start)
    total_d <- proc_delta(total_t_start)

    # 8. Log per-evaluated-point row(s)
    for (k in seq_len(n_in_iter)) {
      row <- list(iter = it, obs_within_iter = k)
      for (cn in c(x_cols, w_cols)) row[[cn]] <- eval_set[k, cn]
      for (j in seq_along(y_cols)) {
        row[[y_cols[j]]]       <- Y_new[k, j]
        row[[pred_mu_cols[j]]] <- mu_eval[j, k]
        row[[pred_sd_cols[j]]] <- sd_eval[j, k]
        row[[pred_err_cols[j]]] <- err_eval[j, k]
      }
      row$pred_rmse_iter <- pred_rmse_iter
      row$hv_after <- hv_after
      if (!is.null(true_pf)) row$igd_plus_after <- igd_plus_after
      row$fit_wall_sec        <- fit_d$wall
      row$fit_cpu_sec         <- fit_d$cpu
      row$predict_wall_sec    <- pred_d$wall
      row$predict_cpu_sec     <- pred_d$cpu
      row$acq_wall_sec        <- acq_d$wall
      row$acq_cpu_sec         <- acq_d$cpu
      row$pred_eval_wall_sec  <- pred_eval_d$wall
      row$pred_eval_cpu_sec   <- pred_eval_d$cpu
      row$iter_wall_sec       <- iter_d$wall
      row$iter_cpu_sec        <- iter_d$cpu
      row$total_wall_sec      <- total_d$wall
      row$total_cpu_sec       <- total_d$cpu
      row_df <- as.data.frame(row, stringsAsFactors = FALSE,
                                check.names = FALSE)[, hist_cols, drop = FALSE]
      history <- rbind(history, row_df)
      if (!is.null(output_csv)) {
        write.table(row_df, file = output_csv, sep = ",",
                    row.names = FALSE, col.names = FALSE, quote = FALSE,
                    append = TRUE)
      }
    }

    if (verbose) {
      msg <- sprintf("[iter %3d/%d] |D|=%d  HV=%.6f  RMSE=%.4f  fit/pred/acq=%.2fs/%.2fs/%.2fs",
                      it, budget, nrow(data_now), hv_after, pred_rmse_iter,
                      fit_d$wall, pred_d$wall, acq_d$wall)
      if (!is.null(true_pf))
        msg <- paste0(msg, sprintf("  IGD+=%.4e", igd_plus_after))
      cat(msg, "\n")
    }
    final_fit <- fit
  }

  list(
    history        = history,
    final_data     = data_now,
    final_fit      = final_fit,
    total_wall_sec = as.numeric(proc.time()[3] - total_t_start[3])
  )
}

`%||%` <- function(a, b) if (is.null(a)) b else a
