// ctmGP — IGD+ (Inverted Generational Distance Plus) — Ishibuchi et al. 2015,
// AoAS paper §4.3.2 / eq 4.1.
//
//   IGD+(A, PF) = (1/|PF|) * Σ_{p ∈ PF} d+(p, A)
//   d+(p, A)    = min_{a ∈ A} sqrt(Σ_i max(a_i - p_i, 0)²)
//
// OpenMP-parallel over true_pf rows (each independent reduction).

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <cmath>
#include <limits>
#ifdef _OPENMP
#include <omp.h>
#endif

using namespace Rcpp;

//' IGD+ (Inverted Generational Distance Plus) — paper §4.3.2 / eq 4.1.
//'
//' For each true PF point p (row of `true_pf`), finds the minimum
//' positive-deviation Euclidean distance to any point in `predicted_pf`, then
//' averages over true PF rows.
//'
//' @param predicted_pf n_A × T numeric matrix.
//' @param true_pf n_PF × T numeric matrix.
//' @return non-negative scalar.
// [[Rcpp::export]]
double ctmgp_igd_plus_cpp(const arma::mat& predicted_pf,
                            const arma::mat& true_pf) {
  if (predicted_pf.n_cols != true_pf.n_cols)
    Rcpp::stop("predicted_pf and true_pf must have the same number of columns.");
  if (true_pf.n_rows == 0)
    Rcpp::stop("true_pf must contain at least one point.");
  if (predicted_pf.n_rows == 0)
    return std::numeric_limits<double>::infinity();

  const arma::uword n_pf = true_pf.n_rows;
  const arma::uword n_a  = predicted_pf.n_rows;
  const arma::uword T_   = true_pf.n_cols;

  double sum_d = 0.0;
#ifdef _OPENMP
  #pragma omp parallel for reduction(+:sum_d) schedule(static)
#endif
  for (arma::sword j = 0; j < static_cast<arma::sword>(n_pf); ++j) {
    double best = std::numeric_limits<double>::infinity();
    for (arma::uword i = 0; i < n_a; ++i) {
      double sq = 0.0;
      for (arma::uword k = 0; k < T_; ++k) {
        const double diff = predicted_pf(i, k) - true_pf(j, k);
        if (diff > 0.0) sq += diff * diff;
      }
      if (sq < best) best = sq;
    }
    sum_d += std::sqrt(best);
  }
  return sum_d / static_cast<double>(n_pf);
}
