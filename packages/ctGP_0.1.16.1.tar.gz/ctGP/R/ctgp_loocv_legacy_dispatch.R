.ctgp_loocv_dispatch_level_ids <- function(bcd_object) {
  if (!is.null(bcd_object$loocv_dispatch) && !is.null(bcd_object$loocv_dispatch$level_ids)) {
    return(as.integer(bcd_object$loocv_dispatch$level_ids))
  }
  if (!is.null(bcd_object$common_index) && !is.null(bcd_object$common_index$level_ids)) {
    return(as.integer(bcd_object$common_index$level_ids))
  }
  if (!is.null(bcd_object$union_index) && !is.null(bcd_object$union_index$level_ids)) {
    return(as.integer(bcd_object$union_index$level_ids))
  }
  stop("The supplied ctGP BCD object does not contain level_ids needed for LOOCV dispatch.")
}

.ctgp_build_loocv_dispatch_data <- function(bcd_object) {
  if (is.null(bcd_object$coerce_union_data) && !is.null(bcd_object$prepared)) {
    bcd_object <- .ctgp_attach_legacy_loocv_state(bcd_object, prepped = bcd_object$prepared)
  }
  if (!is.null(bcd_object$coerce_union_data)) {
    out <- as.data.frame(bcd_object$coerce_union_data, stringsAsFactors = FALSE, check.names = FALSE)
    out$c.T <- as.integer(out$c.T)
    out$Y <- as.numeric(out$Y)
    return(out)
  }
  if (!is.null(bcd_object$loocv_dispatch) && !is.null(bcd_object$loocv_dispatch$coerce_union_data)) {
    out <- as.data.frame(bcd_object$loocv_dispatch$coerce_union_data, stringsAsFactors = FALSE, check.names = FALSE)
    out$c.T <- as.integer(out$c.T)
    out$Y <- as.numeric(out$Y)
    return(out)
  }

  level_ids <- .ctgp_loocv_dispatch_level_ids(bcd_object)
  cont_names <- if (!is.null(bcd_object$schema$continuous_columns)) bcd_object$schema$continuous_columns else NULL

  if (!is.null(bcd_object$coerce_data)) {
    out <- as.data.frame(bcd_object$coerce_data, stringsAsFactors = FALSE, check.names = FALSE)
    if (is.null(cont_names) || length(cont_names) != (ncol(out) - 2L)) {
      cont_names <- paste0("x.", seq_len(ncol(out) - 2L))
    }
    names(out) <- c(cont_names, "c.T", "Y")
    out$c.T <- as.integer(out$c.T)
    out$Y <- as.numeric(out$Y)
    return(out)
  }

  if (!is.null(bcd_object$common_index) && !is.null(bcd_object$common_index$common_design) && !is.null(bcd_object$common_index$y_matrix)) {
    common_design <- as.matrix(bcd_object$common_index$common_design)
    y_matrix <- as.matrix(bcd_object$common_index$y_matrix)
    if (nrow(y_matrix) != nrow(common_design) || ncol(y_matrix) != length(level_ids)) {
      stop("common_design / y_matrix / level_ids dimensions are inconsistent for LOOCV dispatch.")
    }
    x_rep <- common_design[rep(seq_len(nrow(common_design)), times = length(level_ids)), , drop = FALSE]
    out <- as.data.frame(x_rep, stringsAsFactors = FALSE, check.names = FALSE)
    if (is.null(cont_names) || length(cont_names) != ncol(out)) {
      cont_names <- paste0("x.", seq_len(ncol(out)))
    }
    names(out) <- cont_names
    out$c.T <- rep(level_ids, each = nrow(common_design))
    out$Y <- as.numeric(as.vector(y_matrix))
    return(out)
  }

  stop("Failed to locate row-level LOOCV dispatch data on the supplied BCD object.")
}

.ctgp_compute_nugget_tb_r <- function(mat, kappa = 1e8) {
  mat <- 0.5 * (mat + t(mat))
  eig <- eigen(mat, symmetric = TRUE, only.values = TRUE)$values
  max_ev <- abs(max(eig))
  min_ev <- abs(min(eig))
  check_cond <- max_ev - kappa * min_ev
  if (is.finite(check_cond) && check_cond >= 0) {
    return(check_cond / (kappa - 1))
  }
  sqrt(.Machine$double.eps)
}

.ctgp_corr_matrix_r <- function(design, fi) {
  design <- as.matrix(design)
  fi <- as.numeric(fi)
  n <- nrow(design)
  h <- matrix(1, n, n)
  if (n <= 1L) return(h)
  ten_pow_fi <- 10 ^ fi
  for (i in seq_len(n - 1L)) {
    for (j in (i + 1L):n) {
      diff_sq <- (design[i, , drop = FALSE] - design[j, , drop = FALSE])^2
      expo <- sum(ten_pow_fi * as.numeric(diff_sq))
      val <- exp(-expo)
      h[i, j] <- val
      h[j, i] <- val
    }
  }
  h
}

.ctgp_loocv_node_state_r <- function(data,
                                    fi,
                                    mu_hat,
                                    tau_matrix = NULL,
                                    return_components = FALSE) {
  data <- as.matrix(data)
  storage.mode(data) <- "double"
  fi <- as.numeric(fi)
  mu_hat <- as.numeric(mu_hat)
  conti_dim <- ncol(data) - 1L
  y_vec <- as.numeric(data[, conti_dim + 1L])
  tau_eff <- NULL
  tau_inv <- NULL
  tau_input <- NULL

  if (is.null(tau_matrix)) {
    kernel_dim <- nrow(data)
    design_block <- data[, seq_len(conti_dim), drop = FALSE]
    h_matrix <- .ctgp_corr_matrix_r(design_block, fi)
    h_nugget <- .ctgp_compute_nugget_tb_r(h_matrix)
    h_matrix <- h_matrix + diag(h_nugget, kernel_dim)
    h_inv <- solve(h_matrix)
    inv_kernel <- h_inv
    mu_vec_hat <- rep(mu_hat[[1L]], kernel_dim)
    t_nugget <- 0
    used_tau <- FALSE
    tau_dim <- 1L
  } else {
    tau_input <- as.matrix(tau_matrix)
    storage.mode(tau_input) <- "double"
    kernel_dim <- nrow(data) / nrow(tau_input)
    if (!is.finite(kernel_dim) || kernel_dim < 1L || abs(kernel_dim - round(kernel_dim)) > 0) {
      stop("kernelDim is not a positive integer in LOOCV slow reference backend.")
    }
    kernel_dim <- as.integer(round(kernel_dim))
    design_block <- data[seq_len(kernel_dim), seq_len(conti_dim), drop = FALSE]
    h_matrix <- .ctgp_corr_matrix_r(design_block, fi)
    h_nugget <- .ctgp_compute_nugget_tb_r(h_matrix)
    h_matrix <- h_matrix + diag(h_nugget, kernel_dim)
    tau_nugget <- .ctgp_compute_nugget_tb_r(tau_input)
    tau_eff <- tau_input + diag(tau_nugget, nrow(tau_input))
    h_inv <- solve(h_matrix)
    tau_inv <- solve(tau_eff)
    inv_kernel <- kronecker(tau_inv, h_inv)
    mu_vec_hat <- rep(mu_hat, each = kernel_dim)
    t_nugget <- tau_nugget
    used_tau <- TRUE
    tau_dim <- nrow(tau_input)
  }

  centered_y <- as.numeric(y_vec - mu_vec_hat)
  diag_inv <- as.numeric(diag(inv_kernel))
  score <- as.numeric(inv_kernel %*% centered_y)
  loocv_vec <- as.numeric(score) / diag_inv

  out <- list(
    loocv_sse = sum(loocv_vec ^ 2),
    loocv_vec = loocv_vec,
    kernel_dim = kernel_dim,
    used_tau = used_tau,
    tau_dim = tau_dim,
    h_nugget = h_nugget,
    t_nugget = t_nugget
  )

  if (!isTRUE(return_components)) {
    return(out)
  }

  out$data <- unname(data)
  out$design_block <- unname(design_block)
  out$y_vec <- y_vec
  out$fi <- fi
  out$mu_hat <- mu_hat
  out$mu_vec_hat <- mu_vec_hat
  out$h_matrix <- unname(h_matrix)
  out$h_inv <- unname(h_inv)
  out$tau_matrix <- if (is.null(tau_input)) NULL else unname(tau_input)
  out$tau_eff <- if (is.null(tau_eff)) NULL else unname(tau_eff)
  out$tau_inv <- if (is.null(tau_inv)) NULL else unname(tau_inv)
  out$inv_kernel <- unname(inv_kernel)
  out$centered_y <- centered_y
  out$score <- score
  out$diag_inv <- diag_inv
  out
}

.ctgp_node_state_payload <- function(node, bcd_object, prepped = NULL) {
  level_ids <- .ctgp_loocv_dispatch_level_ids(bcd_object)
  node_ids <- sort(as.integer(node$combined_ids))
  col_idx <- match(node_ids, level_ids)
  if (anyNA(col_idx)) {
    stop("Failed to map one or more node combined_ids into the BCD level_ids.")
  }

  dispatch_data <- .ctgp_build_loocv_dispatch_data(bcd_object)
  row_mask <- dispatch_data$c.T %in% node_ids
  data_sub <- dispatch_data[row_mask, , drop = FALSE]
  if (nrow(data_sub) < 1L) {
    stop("LOOCV dispatch produced an empty node subset.")
  }

  x_cols <- grep('^x\\.', names(data_sub))
  if (length(x_cols) < 1L) {
    stop("LOOCV dispatch data must contain quantitative columns named x.*")
  }
  data_mat <- as.matrix(data_sub[, c(x_cols, ncol(data_sub)), drop = FALSE])
  storage.mode(data_mat) <- "double"

  tau_sub <- NULL
  if (length(col_idx) > 1L) {
    tau_sub <- as.matrix(bcd_object$tau_matrix[col_idx, col_idx, drop = FALSE])
  }

  list(
    data = unname(data_mat),
    fi = as.numeric(bcd_object$fi),
    mu_hat = as.numeric(bcd_object$mu_vec[col_idx]),
    tau_matrix = tau_sub,
    combined_ids = node_ids,
    column_index = as.integer(col_idx),
    dispatch_level_ids = as.integer(data_sub$c.T),
    dispatch_regime = if (inherits(bcd_object, "ctgp_bcd_union")) "union_imputed" else "common"
  )
}

.ctgp_legacy_node_payload <- function(node, bcd_object) {
  level_ids <- .ctgp_loocv_dispatch_level_ids(bcd_object)
  node_ids <- sort(as.integer(node$combined_ids))
  col_idx <- match(node_ids, level_ids)
  if (anyNA(col_idx)) {
    stop("Failed to map one or more node combined_ids into the BCD level_ids.")
  }

  dispatch_data <- .ctgp_build_loocv_dispatch_data(bcd_object)
  row_mask <- dispatch_data$c.T %in% node_ids
  data_sub <- dispatch_data[row_mask, , drop = FALSE]
  if (nrow(data_sub) < 1L) {
    stop("Legacy-style LOOCV dispatch produced an empty node subset.")
  }

  x_cols <- grep('^x\\.', names(data_sub))
  if (length(x_cols) < 1L) {
    stop("LOOCV dispatch data must contain quantitative columns named x.*")
  }
  data_mat <- as.matrix(data_sub[, c(x_cols, ncol(data_sub)), drop = FALSE])
  storage.mode(data_mat) <- "double"

  tau_sub <- NULL
  if (length(col_idx) > 1L) {
    tau_sub <- as.matrix(bcd_object$tau_matrix[col_idx, col_idx, drop = FALSE])
  }

  list(
    data = unname(data_mat),
    fi = as.numeric(bcd_object$fi),
    mu_hat = as.numeric(bcd_object$mu_vec[col_idx]),
    tau_matrix = tau_sub,
    combined_ids = node_ids,
    column_index = as.integer(col_idx),
    dispatch_regime = if (!is.null(bcd_object$loocv_dispatch$regime)) bcd_object$loocv_dispatch$regime else if (inherits(bcd_object, "ctgp_bcd_union")) "union-imputed" else "common-observed"
  )
}

.ctgp_tree_node_loocv_legacy <- function(node, bcd_object) {
  payload <- .ctgp_legacy_node_payload(node, bcd_object)
  out <- ctgp_loocv_legacy_cpp(
    data = payload$data,
    fi = payload$fi,
    mu_hat = payload$mu_hat,
    tau_matrix = payload$tau_matrix
  )
  data.frame(
    node_id = as.integer(node$node_id),
    parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
    depth = as.integer(node$depth),
    is_leaf = isTRUE(node$is_leaf),
    n_rows = as.integer(node$n_rows),
    n_combined = as.integer(length(node$combined_ids)),
    loocv_value = as.numeric(out$loocv_sse),
    h_nugget = as.numeric(out$h_nugget),
    t_nugget = as.numeric(out$t_nugget),
    used_tau = isTRUE(out$used_tau),
    tau_dim = as.integer(out$tau_dim),
    dispatch_regime = payload$dispatch_regime,
    stringsAsFactors = FALSE
  )
}

.ctgp_loocv_summary_legacy <- function(tree, bcd_object) {
  rows <- list()
  rec <- function(node) {
    rows[[length(rows) + 1L]] <<- .ctgp_tree_node_loocv_legacy(node, bcd_object)
    if (!isTRUE(node$is_leaf)) {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out <- do.call(rbind, rows)
  out <- out[order(out$depth, out$node_id), , drop = FALSE]
  rownames(out) <- NULL
  attr(out, "named_vector") <- stats::setNames(out$loocv_value, out$node_id)
  class(out) <- c("ctgp_loocv_summary", class(out))
  out
}

.ctgp_tree_node_loocv_cpp <- function(node, bcd_object) {
  payload <- .ctgp_node_state_payload(node, bcd_object)
  out <- ctgp_loocv_legacy_cpp(
    data = payload$data,
    fi = payload$fi,
    mu_hat = payload$mu_hat,
    tau_matrix = payload$tau_matrix
  )
  list(
    node_id = as.integer(node$node_id),
    parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
    depth = as.integer(node$depth),
    is_leaf = isTRUE(node$is_leaf),
    n_rows = as.integer(node$n_rows),
    n_combined = as.integer(length(node$combined_ids)),
    loocv_value = as.numeric(out$loocv_sse),
    h_nugget = as.numeric(out$h_nugget),
    t_nugget = as.numeric(out$t_nugget),
    used_tau = isTRUE(out$used_tau),
    tau_dim = as.integer(out$tau_dim)
  )
}

.ctgp_tree_node_loocv_slow_exact <- function(node, bcd_object) {
  payload <- .ctgp_node_state_payload(node, bcd_object)
  out <- .ctgp_loocv_node_state_r(
    data = payload$data,
    fi = payload$fi,
    mu_hat = payload$mu_hat,
    tau_matrix = payload$tau_matrix
  )
  list(
    node_id = as.integer(node$node_id),
    parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
    depth = as.integer(node$depth),
    is_leaf = isTRUE(node$is_leaf),
    n_rows = as.integer(node$n_rows),
    n_combined = as.integer(length(node$combined_ids)),
    loocv_value = as.numeric(out$loocv_sse),
    h_nugget = as.numeric(out$h_nugget),
    t_nugget = as.numeric(out$t_nugget),
    used_tau = isTRUE(out$used_tau),
    tau_dim = as.integer(out$tau_dim)
  )
}

.ctgp_loocv_summary_cpp <- function(tree, bcd_object, use_openmp = TRUE, num_threads = 0L) {
  rows <- list()
  rec <- function(node) {
    info <- .ctgp_tree_node_loocv_cpp(node, bcd_object)
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = info$node_id,
      parent_id = info$parent_id,
      depth = info$depth,
      is_leaf = info$is_leaf,
      n_rows = info$n_rows,
      n_combined = info$n_combined,
      loocv_value = info$loocv_value,
      h_nugget = info$h_nugget,
      t_nugget = info$t_nugget,
      used_tau = info$used_tau,
      tau_dim = info$tau_dim,
      stringsAsFactors = FALSE
    )
    if (!isTRUE(node$is_leaf)) {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out <- do.call(rbind, rows)
  out <- out[order(out$depth, out$node_id), , drop = FALSE]
  rownames(out) <- NULL
  attr(out, "named_vector") <- stats::setNames(out$loocv_value, out$node_id)
  class(out) <- c("ctgp_loocv_summary", class(out))
  out
}

.ctgp_loocv_summary_slow <- function(tree, bcd_object) {
  rows <- list()
  rec <- function(node) {
    info <- .ctgp_tree_node_loocv_slow_exact(node, bcd_object)
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = info$node_id,
      parent_id = info$parent_id,
      depth = info$depth,
      is_leaf = info$is_leaf,
      n_rows = info$n_rows,
      n_combined = info$n_combined,
      loocv_value = info$loocv_value,
      h_nugget = info$h_nugget,
      t_nugget = info$t_nugget,
      used_tau = info$used_tau,
      tau_dim = info$tau_dim,
      stringsAsFactors = FALSE
    )
    if (!isTRUE(node$is_leaf)) {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out <- do.call(rbind, rows)
  out <- out[order(out$depth, out$node_id), , drop = FALSE]
  rownames(out) <- NULL
  attr(out, "named_vector") <- stats::setNames(out$loocv_value, out$node_id)
  class(out) <- c("ctgp_loocv_summary", class(out))
  out
}
