
.ctgp_match_by_names_or_values <- function(data, design) {
  data <- as.data.frame(data, check.names = FALSE, stringsAsFactors = FALSE)

  if (is.character(design)) {
    dn <- make.names(design, unique = TRUE)
    xn <- colnames(data)
    if (!is.null(xn)) {
      xn <- make.names(xn, unique = TRUE)
      if (all(dn %in% xn)) {
        return(match(dn, xn))
      }
    }
  }

  design <- as.data.frame(design, check.names = FALSE, stringsAsFactors = FALSE)

  if (nrow(data) != nrow(design)) {
    stop("`data` and `design` must have the same number of rows.")
  }

  dn <- colnames(design)
  xn <- colnames(data)
  if (!is.null(dn) && length(dn) == ncol(design) &&
      all(!is.na(dn)) && all(nzchar(dn)) &&
      !is.null(xn) && all(dn %in% xn)) {
    return(match(dn, xn))
  }

  d <- ncol(design)
  if (d <= ncol(data)) {
    candidate <- data[, seq_len(d), drop = FALSE]
    if (isTRUE(all.equal(as.matrix(candidate), as.matrix(design), tolerance = sqrt(.Machine$double.eps)))) {
      return(seq_len(d))
    }
  }

  NULL
}

.ctgp_normalize_names <- function(x, prefix) {
  nm <- names(x)
  if (is.null(nm) || any(!nzchar(nm))) {
    nm <- paste0(prefix, seq_along(x))
  }
  make.names(nm, unique = TRUE)
}

.ctgp_prepare_data <- function(data,
                               design = NULL,
                               response = NULL,
                               quantitative = NULL,
                               qualitative = NULL) {
  if (missing(data)) stop("`data` must be provided.")

  data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  if (nrow(data) < 1L || ncol(data) < 3L) {
    stop("`data` must contain quantitative columns, at least one qualitative column, and one response column.")
  }

  if (!is.null(response)) {
    if (is.character(response)) {
      response_idx <- match(response, names(data))
      if (is.na(response_idx)) stop("`response` name not found in `data`.")
    } else {
      response_idx <- as.integer(response)[1L]
    }
  } else {
    aliases <- c("y", "response", "output")
    xn <- names(data)
    response_idx <- integer(0)
    if (!is.null(xn)) {
      hit <- which(tolower(xn) %in% aliases)
      if (length(hit) >= 1L) {
        response_idx <- hit[1L]
      }
    }
    if (length(response_idx) == 0L) {
      response_idx <- ncol(data)
    }
  }

  if (!is.finite(response_idx) || response_idx < 1L || response_idx > ncol(data)) {
    stop("Could not resolve a valid response column.")
  }

  if (!is.null(qualitative)) {
    if (is.character(qualitative)) {
      qual_idx <- match(qualitative, names(data))
      if (anyNA(qual_idx)) stop("Some `qualitative` names were not found in `data`.")
    } else {
      qual_idx <- as.integer(qualitative)
    }
  } else {
    qual_idx <- which(vapply(data, function(z) is.factor(z) || is.character(z) || is.logical(z), logical(1)))
    qual_idx <- setdiff(qual_idx, response_idx)
  }

  if (!is.null(quantitative)) {
    if (is.character(quantitative)) {
      cont_idx <- match(quantitative, names(data))
      if (anyNA(cont_idx)) stop("Some `quantitative` names were not found in `data`.")
    } else {
      cont_idx <- as.integer(quantitative)
    }
  } else if (!is.null(design)) {
    if (is.character(design) && is.null(dim(design))) {
      cont_idx <- match(design, names(data))
      if (anyNA(cont_idx)) stop("Some `design` names were not found in `data`.")
    } else if (is.numeric(design) && is.null(dim(design)) && all(is.finite(design)) && all(design == as.integer(design))) {
      cont_idx <- as.integer(design)
      if (any(cont_idx < 1L | cont_idx > ncol(data))) stop("`design` indices are out of bounds for `data`.")
    } else {
      cont_idx <- .ctgp_match_by_names_or_values(data, design)
      if (is.null(cont_idx)) {
        cont_idx <- setdiff(seq_len(ncol(data)), c(response_idx, qual_idx))
        if (ncol(as.data.frame(design)) <= length(cont_idx)) {
          cont_idx <- cont_idx[seq_len(ncol(as.data.frame(design)))]
        }
      }
    }
  } else {
    cont_idx <- setdiff(seq_len(ncol(data)), c(response_idx, qual_idx))
  }

  cont_idx <- setdiff(unique(cont_idx), response_idx)
  qual_idx <- setdiff(unique(qual_idx), c(response_idx, cont_idx))

  if (length(cont_idx) < 1L) stop("No quantitative columns could be identified.")
  if (length(qual_idx) < 1L) stop("No qualitative columns could be identified.")

  cont_df <- data[, cont_idx, drop = FALSE]
  qual_df <- data[, qual_idx, drop = FALSE]
  y_vec <- as.numeric(data[[response_idx]])
  if (any(!is.finite(y_vec))) stop("Response column contains non-finite values.")

  names(cont_df) <- .ctgp_normalize_names(cont_df, "x")
  cont_df[] <- lapply(cont_df, function(z) {
    znum <- as.numeric(z)
    if (any(!is.finite(znum))) stop("Quantitative columns must be coercible to finite numeric values.")
    znum
  })

  names(qual_df) <- .ctgp_normalize_names(qual_df, "c")
  qual_df[] <- lapply(qual_df, function(z) {
    if (is.factor(z)) z else factor(z)
  })

  y_name <- names(data)[response_idx]
  if (is.null(y_name) || !nzchar(y_name)) y_name <- "Y"
  y_name <- make.names(y_name, unique = TRUE)

  data_reordered <- cbind(cont_df, qual_df, stats::setNames(data.frame(Y = y_vec), y_name))
  names(data_reordered)[ncol(data_reordered)] <- y_name

  coerce_data <- coerce_fun(data_reordered, cont_df, include_sub_cate = TRUE)
  colnames(coerce_data) <- c(names(cont_df), "c.T", "Y")

  out <- list(
    data = data_reordered,
    design = as.matrix(cont_df),
    continuous_data = cont_df,
    qualitative_data = qual_df,
    y = y_vec,
    response_name = y_name,
    coerce_data = coerce_data,
    combined_id = coerce_data[, "c.T"],
    combined_key = attr(coerce_data, "level_key"),
    schema = list(
      continuous_columns = names(cont_df),
      qualitative_columns = names(qual_df),
      response_column = y_name,
      conti_dim = ncol(cont_df),
      cate_num = ncol(qual_df),
      level_num = length(unique(coerce_data[, "c.T"]))
    )
  )
  class(out) <- c("ctgp_prepared_data", "list")
  out
}

.ctgp_sort_rows <- function(mat) {
  mat <- as.matrix(mat)
  if (nrow(mat) <= 1L) return(mat)
  ord <- do.call(order, as.data.frame(mat, check.names = FALSE, stringsAsFactors = FALSE))
  mat[ord, , drop = FALSE]
}

.ctgp_detect_design_regime <- function(prepped, tol = sqrt(.Machine$double.eps)) {
  if (is.null(prepped$combined_id)) stop("`prepped` must contain `combined_id`.")
  design <- as.matrix(prepped$design)
  ids <- prepped$combined_id
  level_ids <- sort(unique(ids))

  group_rows <- lapply(level_ids, function(id) which(ids == id))
  names(group_rows) <- as.character(level_ids)

  group_designs <- lapply(group_rows, function(idx) .ctgp_sort_rows(design[idx, , drop = FALSE]))

  same_n <- vapply(group_designs, nrow, integer(1))
  if (length(unique(same_n)) != 1L) {
    return(list(
      regime = "union",
      level_ids = level_ids,
      group_rows = group_rows,
      group_designs = group_designs,
      common_design = NULL,
      is_common = FALSE,
      reason = "different number of quantitative design rows across combined categories"
    ))
  }

  ref <- group_designs[[1L]]
  is_common <- TRUE
  for (k in seq_along(group_designs)[-1L]) {
    cmp <- group_designs[[k]]
    if (!isTRUE(all.equal(ref, cmp, tolerance = tol, check.attributes = FALSE))) {
      is_common <- FALSE
      break
    }
  }

  list(
    regime = if (is_common) "common" else "union",
    level_ids = level_ids,
    group_rows = group_rows,
    group_designs = group_designs,
    common_design = if (is_common) ref else NULL,
    is_common = is_common,
    reason = if (is_common) "all combined categories share the same quantitative design" else "combined categories use different quantitative designs"
  )
}

.ctgp_build_common_index <- function(prepped, regime = NULL, tol = sqrt(.Machine$double.eps)) {
  if (is.null(regime)) regime <- .ctgp_detect_design_regime(prepped, tol = tol)
  if (!isTRUE(regime$is_common)) stop("Design regime is not common; cannot build common-design index.")

  y <- as.numeric(prepped$y)
  level_ids <- regime$level_ids
  n_common <- nrow(regime$common_design)
  n_levels <- length(level_ids)
  y_matrix <- matrix(NA_real_, nrow = n_common, ncol = n_levels)
  colnames(y_matrix) <- paste0("cT", level_ids)

  row_order <- vector("list", n_levels)
  names(row_order) <- as.character(level_ids)

  for (j in seq_along(level_ids)) {
    idx <- regime$group_rows[[j]]
    block_design <- as.matrix(prepped$design[idx, , drop = FALSE])
    ord <- if (nrow(block_design) <= 1L) seq_len(nrow(block_design)) else do.call(order, as.data.frame(block_design))
    row_order[[j]] <- idx[ord]
    sorted_block <- block_design[ord, , drop = FALSE]
    if (!isTRUE(all.equal(sorted_block, regime$common_design, tolerance = tol, check.attributes = FALSE))) {
      stop("Internal mismatch while building common-design index.")
    }
    y_matrix[, j] <- y[idx[ord]]
  }

  list(
    common_design = regime$common_design,
    y_matrix = y_matrix,
    level_ids = level_ids,
    row_order = row_order,
    n_common = n_common,
    n_levels = n_levels,
    regime = "common"
  )
}

.ctgp_build_union_index <- function(prepped) {
  design_df <- as.data.frame(prepped$continuous_data, check.names = FALSE, stringsAsFactors = FALSE)
  design_key <- apply(signif(as.matrix(design_df), 15), 1, function(z) paste(z, collapse = "||"))
  union_key <- unique(design_key)
  union_idx <- match(design_key, union_key)
  union_design <- design_df[match(union_key, design_key), , drop = FALSE]
  rownames(union_design) <- NULL

  ids <- prepped$combined_id
  level_ids <- sort(unique(ids))
  group_union_index <- lapply(level_ids, function(id) union_idx[ids == id])
  names(group_union_index) <- as.character(level_ids)

  list(
    union_design = as.matrix(union_design),
    level_ids = level_ids,
    union_index = union_idx,
    group_union_index = group_union_index,
    n_union = nrow(union_design),
    regime = "union"
  )
}
