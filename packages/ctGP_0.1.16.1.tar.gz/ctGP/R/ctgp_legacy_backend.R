.ctgp_legacy_backend_cache <- new.env(parent = emptyenv())

.ctgp_legacy_required_packages <- function() {
  c(
    "AdequacyModel",
    "globpso",
    "RcppArmadillo",
    "plgp",
    "foreach",
    "doParallel",
    "mvtnorm",
    "dplyr",
    "ggplot2",
    "abind"
  )
}

.ctgp_find_legacy_tbgp_file <- function() {
  candidates <- unique(c(
    file.path(getwd(), "TBGP.R"),
    file.path(getwd(), "legacy", "core", "TBGP.R"),
    system.file("legacy", "TBGP.R", package = "ctGP"),
    file.path(dirname(getwd()), "TBGP.R")
  ))
  hit <- candidates[nzchar(candidates) & file.exists(candidates)]
  if (length(hit) < 1L) return(NULL)
  normalizePath(hit[[1L]], winslash = "/", mustWork = FALSE)
}

.ctgp_legacy_backend_available <- function() {
  tbgp_path <- .ctgp_find_legacy_tbgp_file()
  if (is.null(tbgp_path) || !nzchar(tbgp_path) || !file.exists(tbgp_path)) {
    return(FALSE)
  }
  pkgs <- .ctgp_legacy_required_packages()
  all(vapply(pkgs, requireNamespace, logical(1), quietly = TRUE))
}

.ctgp_load_legacy_env <- function(force_reload = FALSE) {
  if (!isTRUE(force_reload) && exists("env", envir = .ctgp_legacy_backend_cache, inherits = FALSE)) {
    return(get("env", envir = .ctgp_legacy_backend_cache, inherits = FALSE))
  }

  tbgp_path <- .ctgp_find_legacy_tbgp_file()
  if (is.null(tbgp_path) || !nzchar(tbgp_path) || !file.exists(tbgp_path)) {
    stop(
      "Legacy ctGP backend could not locate `TBGP.R`. Expected it in legacy/core, an older installed-package legacy copy, or the current working directory.",
      call. = FALSE
    )
  }

  pkgs <- .ctgp_legacy_required_packages()
  missing_pkgs <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing_pkgs) > 0L) {
    stop(
      "Legacy ctGP backend requires the following packages to reproduce `TBGP.R`: ",
      paste(missing_pkgs, collapse = ", "),
      call. = FALSE
    )
  }

  legacy_env <- new.env(parent = globalenv())
  sys.source(tbgp_path, envir = legacy_env)
  assign("env", legacy_env, envir = .ctgp_legacy_backend_cache)
  assign("path", tbgp_path, envir = .ctgp_legacy_backend_cache)
  legacy_env
}

.ctgp_make_legacy_data <- function(prepped) {
  stopifnot(inherits(prepped, "ctgp_prepared_data"))
  cont_df <- as.data.frame(prepped$continuous_data, stringsAsFactors = FALSE, check.names = FALSE)
  qual_df <- as.data.frame(prepped$qualitative_data, stringsAsFactors = TRUE, check.names = FALSE)
  names(cont_df) <- paste0("x.", seq_len(ncol(cont_df)))
  names(qual_df) <- paste0("c.", seq_len(ncol(qual_df)))
  for (j in seq_len(ncol(qual_df))) {
    qual_df[[j]] <- if (is.factor(qual_df[[j]])) qual_df[[j]] else factor(qual_df[[j]])
  }
  out <- data.frame(cont_df, qual_df, Y = as.numeric(prepped$y),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  for (j in seq_len(ncol(qual_df))) out[[ncol(cont_df) + j]] <- factor(out[[ncol(cont_df) + j]])
  rownames(out) <- NULL
  out
}

.ctgp_legacy_treefit <- function(prepped,
                                 range = NULL,
                                 nugget = NULL,
                                 bcd_control = list(),
                                 imputation_control = list(),
                                 legacy_parallel = FALSE) {
  legacy_env <- .ctgp_load_legacy_env()
  legacy_data <- .ctgp_make_legacy_data(prepped)
  bcd_loops <- .ctgp_bcd_control_defaults(bcd_control)$max_iter
  imp_ctrl <- .ctgp_imputation_control_defaults(imputation_control, optimizer_control = list())
  mc_samples <- imp_ctrl$mcmc_samples

  timing <- system.time({
    legacy_tree_big <- legacy_env$treeFit.corrMat(
      data = legacy_data,
      initRange = range,
      parallel = isTRUE(legacy_parallel),
      BCDloopNum = as.integer(bcd_loops),
      mcmcIterNum = as.integer(mc_samples),
      nugget = nugget
    )
  })

  list(
    legacy_tree_big = legacy_tree_big,
    legacy_data = legacy_data,
    timing = as.list(timing),
    path = get("path", envir = .ctgp_legacy_backend_cache, inherits = FALSE)
  )
}

.ctgp_legacy_level_ids <- function(legacy_tree_big) {
  ids <- unique(as.integer(legacy_tree_big$coerceUnionData$c.T))
  as.integer(ids)
}

.ctgp_legacy_y_matrix <- function(legacy_tree_big, level_ids = NULL) {
  if (is.null(level_ids)) level_ids <- .ctgp_legacy_level_ids(legacy_tree_big)
  matrix(
    as.numeric(legacy_tree_big$unionData$Y),
    ncol = length(level_ids)
  )
}

.ctgp_legacy_dispatch_from_tree <- function(prepped, legacy_tree_big, regime_name) {
  level_ids <- .ctgp_legacy_level_ids(legacy_tree_big)
  list(
    regime = if (identical(regime_name, "union")) "union-imputed" else "common-observed",
    level_ids = level_ids,
    level_table = unique(legacy_tree_big$unionData[, paste0("c.", seq_len(prepped$schema$cate_num)), drop = FALSE]),
    union_data = legacy_tree_big$unionData,
    coerce_union_data = legacy_tree_big$coerceUnionData
  )
}

.ctgp_legacy_bcd_from_tree <- function(prepped,
                                       legacy_tree_big,
                                       regime,
                                       range = NULL,
                                       nugget = NULL,
                                       bcd_control = list(),
                                       imputation_control = list()) {
  regime_name <- if (is.character(regime)) as.character(regime[[1L]]) else regime$regime
  if (!identical(regime_name, "common") && !identical(regime_name, "union")) {
    stop("`regime` must resolve to either 'common' or 'union'.")
  }

  level_ids <- .ctgp_legacy_level_ids(legacy_tree_big)
  common_design <- as.matrix(legacy_tree_big$unionDesign)
  y_matrix <- .ctgp_legacy_y_matrix(legacy_tree_big, level_ids = level_ids)
  dispatch <- .ctgp_legacy_dispatch_from_tree(prepped, legacy_tree_big, regime_name = regime_name)

  common_index <- list(
    common_design = common_design,
    y_matrix = y_matrix,
    n_common = nrow(common_design),
    n_levels = length(level_ids),
    level_ids = level_ids,
    row_order = NULL,
    regime = if (identical(regime_name, "union")) "union-imputed" else "common"
  )

  out <- list(
    regime = regime_name,
    fi = as.numeric(legacy_tree_big$fiParams),
    bound = legacy_tree_big$initGPRange,
    common_r_matrix = NULL,
    common_r_matrix_base = NULL,
    mu_vec = as.numeric(legacy_tree_big$muVec),
    tau_cov_matrix = as.matrix(legacy_tree_big$tauCovMatrix),
    tau_cov_matrix_base = as.matrix(legacy_tree_big$tauCovMatrix),
    tau_matrix = as.matrix(legacy_tree_big$tauMatrix),
    trace = NULL,
    h_nugget = if (is.null(nugget)) sqrt(.Machine$double.eps) else nugget,
    t_nugget = sqrt(.Machine$double.eps),
    rcond_h = NA_real_,
    rcond_t = NA_real_,
    objective = NA_real_,
    n_bcd_iter_used = .ctgp_bcd_control_defaults(bcd_control)$max_iter,
    bcd_tol = .ctgp_bcd_control_defaults(bcd_control)$tol,
    initial_source = "legacy_treeFit.corrMat",
    initial_objective = NA_real_,
    initial_fi = as.numeric(legacy_tree_big$fiParams),
    initial_n_eval = NA_integer_,
    initial_converged = NA,
    used_monte_carlo = identical(regime_name, "union"),
    mc_samples = .ctgp_imputation_control_defaults(imputation_control, optimizer_control = list())$mcmc_samples,
    scale_divisor = nrow(common_design),
    y_matrix = y_matrix,
    y_matrix_observed = if (identical(regime_name, "union")) y_matrix else NULL,
    missing_mask = NULL,
    level_fi_matrix = NULL,
    nugget = nugget,
    message = "legacy TBGP.R backend",
    optimizer_control = NULL,
    optimizer_mode = "legacy_r",
    objective_mode = "legacy_exact",
    search_objective_mode = "legacy_exact",
    imputation_variance_mode = if (identical(regime_name, "union")) "legacy_plugin_gp" else NA_character_,
    bcd_control = .ctgp_bcd_control_defaults(bcd_control),
    imputation_control = .ctgp_imputation_control_defaults(imputation_control, optimizer_control = list()),
    schema = prepped$schema,
    combined_key = prepped$combined_key,
    combined_id = prepped$combined_id,
    data = prepped$data,
    design = prepped$design,
    continuous_data = prepped$continuous_data,
    qualitative_data = prepped$qualitative_data,
    y = prepped$y,
    coerce_data = prepped$coerce_data,
    common_index = common_index,
    union_index = if (identical(regime_name, "union")) .ctgp_build_union_index(prepped) else NULL,
    loocv_dispatch = dispatch,
    union_data = dispatch$union_data,
    coerce_union_data = dispatch$coerce_union_data,
    level_table = dispatch$level_table,
    legacy_tree_big = legacy_tree_big,
    legacy_backend = TRUE,
    prepared = prepped
  )

  class(out) <- c(
    if (identical(regime_name, "union")) "ctgp_bcd_union" else "ctgp_bcd_common",
    "ctgp_bcd_legacy",
    "list"
  )
  out
}

.ctgp_global_stage_legacy <- function(prepped,
                                      init_param = NULL,
                                      range = NULL,
                                      nugget = NULL,
                                      optimizer_control = list(),
                                      bcd_control = list(),
                                      imputation_control = list(),
                                      allow_union_imputation = TRUE,
                                      tol = sqrt(.Machine$double.eps),
                                      legacy_parallel = FALSE) {
  regime <- .ctgp_detect_design_regime(prepped, tol = tol)
  if (identical(regime$regime, "union") && !isTRUE(allow_union_imputation)) {
    return(list(
      prepared = prepped,
      regime = regime,
      global_gp = NULL,
      common_index = NULL,
      union_index = .ctgp_build_union_index(prepped),
      union_imputation = NULL,
      bcd = NULL,
      success = TRUE,
      message = "union-design detected; legacy treeFit backend was disabled because allow_union_imputation = FALSE"
    ))
  }

  legacy_fit <- .ctgp_legacy_treefit(
    prepped = prepped,
    range = range,
    nugget = nugget,
    bcd_control = bcd_control,
    imputation_control = imputation_control,
    legacy_parallel = legacy_parallel
  )

  bcd <- .ctgp_legacy_bcd_from_tree(
    prepped = prepped,
    legacy_tree_big = legacy_fit$legacy_tree_big,
    regime = regime,
    range = range,
    nugget = nugget,
    bcd_control = bcd_control,
    imputation_control = imputation_control
  )

  stage <- list(
    prepared = prepped,
    regime = regime,
    global_gp = list(
      fi = as.numeric(bcd$fi),
      lower = if (is.null(range)) NULL else as.numeric(range[seq_len(length(range) / 2)]),
      upper = if (is.null(range)) NULL else as.numeric(range[(length(range) / 2 + 1):length(range)]),
      init_param = init_param,
      objective = NA_real_,
      n_eval = NA_integer_,
      converged = NA,
      nugget = nugget,
      backend = "legacy"
    ),
    common_index = bcd$common_index,
    union_index = bcd$union_index,
    union_imputation = if (identical(regime$regime, "union")) {
      list(
        union_design = bcd$common_index$common_design,
        level_ids = bcd$common_index$level_ids,
        y_matrix_observed = bcd$y_matrix_observed,
        y_matrix = bcd$y_matrix,
        missing_mask = bcd$missing_mask,
        n_imputed = if (is.null(bcd$missing_mask)) NA_integer_ else sum(bcd$missing_mask),
        group_union_index = if (is.null(bcd$union_index)) NULL else bcd$union_index$group_union_index,
        optimizer_control = optimizer_control,
        imputation_control = imputation_control,
        timing = legacy_fit$timing,
        mc_samples = bcd$mc_samples,
        level_fi_matrix = bcd$level_fi_matrix,
        bcd_object = bcd
      )
    } else {
      NULL
    },
    bcd = bcd,
    success = TRUE,
    message = "legacy TBGP.R global stage completed",
    legacy_tree_big = legacy_fit$legacy_tree_big,
    timing = legacy_fit$timing
  )

  stage
}

.ctgp_split_levels_from_legacy_label <- function(label) {
  if (is.null(label) || length(label) < 1L || is.na(label[[1L]]) || identical(label[[1L]], "root")) {
    return(character(0))
  }
  strsplit(as.character(label[[1L]]), " or ", fixed = TRUE)[[1L]]
}

.ctgp_tree_from_legacy_big_tree <- function(prepped, legacy_tree_big) {
  stopifnot(inherits(prepped, "ctgp_prepared_data"))
  node_pos <- as.integer(legacy_tree_big$nodePosition)
  node_split_var <- as.character(legacy_tree_big$nodeSplitVar)
  node_score <- as.numeric(legacy_tree_big$nodeMinMaxCorr)
  parent_split_logic <- legacy_tree_big$parentSplitLogic
  parent_split_level <- as.character(legacy_tree_big$parentSplitLevel)
  coerce_data <- as.data.frame(legacy_tree_big$coerceData, stringsAsFactors = FALSE, check.names = FALSE)
  names(coerce_data) <- c(paste0("x.", seq_len(prepped$schema$conti_dim)), "c.T", "Y")

  rec <- function(pos) {
    idx <- match(as.integer(pos), node_pos)
    if (is.na(idx)) return(NULL)
    row_mask <- as.logical(parent_split_logic[[idx]])
    combined_ids <- unique(as.integer(coerce_data$c.T[row_mask]))
    node <- list(
      node_id = as.integer(pos),
      parent_id = if (pos == 1L) NULL else as.integer(floor(pos / 2L)),
      depth = if (pos == 1L) 0L else as.integer(floor(log(pos, base = 2))),
      row_mask = row_mask,
      combined_ids = combined_ids,
      n_rows = sum(row_mask),
      is_leaf = identical(node_split_var[[idx]], "leaf")
    )

    if (isTRUE(node$is_leaf)) {
      node$reason <- if (length(combined_ids) <= 1L) "single combined category" else "legacy_leaf"
      return(node)
    }

    node$split_var <- as.character(node_split_var[[idx]])
    node$score <- as.numeric(node_score[[idx]])
    node$left_levels <- .ctgp_split_levels_from_legacy_label(parent_split_level[match(2L * pos, node_pos)])
    node$right_levels <- .ctgp_split_levels_from_legacy_label(parent_split_level[match(2L * pos + 1L, node_pos)])
    node$left <- rec(2L * pos)
    node$right <- rec(2L * pos + 1L)
    node
  }

  rec(1L)
}
