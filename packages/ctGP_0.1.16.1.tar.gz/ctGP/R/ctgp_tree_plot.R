.ctgp_tree_is_pruned <- function(tree) {
  isTRUE(tree$is_pruned) ||
    isTRUE(attr(tree, "is_pruned")) ||
    identical(attr(tree, "tree_stage"), "pruned")
}

.ctgp_tree_branch_label <- function(values, max_levels = 8L, wrap_width = 28L) {
  if (is.null(values) || length(values) == 0L) {
    return("")
  }
  values_chr <- as.character(values)
  if (length(values_chr) > max_levels) {
    values_chr <- c(values_chr[seq_len(max_levels)], "...")
  }
  raw <- paste(values_chr, collapse = " or ")
  paste(strwrap(raw, width = wrap_width), collapse = "\n")
}

.ctgp_tree_plot_rows <- function(tree) {
  rows <- list()

  rec <- function(node, edge_label = "") {
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = as.integer(node$node_id),
      parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
      depth = as.integer(node$depth),
      is_leaf = isTRUE(node$is_leaf),
      split_var = if (is.null(node$split_var)) NA_character_ else as.character(node$split_var),
      score = if (is.null(node$score)) NA_real_ else as.numeric(node$score),
      n_rows = if (is.null(node$n_rows)) NA_integer_ else as.integer(node$n_rows),
      n_combined = if (is.null(node$combined_ids)) NA_integer_ else as.integer(length(node$combined_ids)),
      reason = if (is.null(node$reason)) NA_character_ else as.character(node$reason),
      leaf_model = if (is.null(node$leaf_model)) NA_character_ else as.character(node$leaf_model),
      edge_label = as.character(edge_label),
      stringsAsFactors = FALSE
    )

    if (!isTRUE(node$is_leaf)) {
      rec(node$left, edge_label = .ctgp_tree_branch_label(node$left_levels))
      rec(node$right, edge_label = .ctgp_tree_branch_label(node$right_levels))
    }
  }

  rec(tree)
  out <- do.call(rbind, rows)
  out[order(out$depth, out$node_id), , drop = FALSE]
}

.ctgp_tree_layout_compact <- function(tree,
                                      leaf_gap = 3.2,
                                      vertical_gap = 3.1,
                                      parent_position = c("weighted", "midpoint")) {
  parent_position <- match.arg(parent_position)
  rows <- list()

  rec <- function(node, next_leaf_slot = 0L, edge_label = "") {
    depth <- as.integer(node$depth)
    y_center <- -as.numeric(depth) * vertical_gap

    if (isTRUE(node$is_leaf)) {
      x_center <- as.numeric(next_leaf_slot) * leaf_gap
      rows[[length(rows) + 1L]] <<- data.frame(
        node_id = as.integer(node$node_id),
        parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
        depth = depth,
        is_leaf = TRUE,
        split_var = NA_character_,
        score = NA_real_,
        n_rows = if (is.null(node$n_rows)) NA_integer_ else as.integer(node$n_rows),
        n_combined = if (is.null(node$combined_ids)) NA_integer_ else as.integer(length(node$combined_ids)),
        reason = if (is.null(node$reason)) NA_character_ else as.character(node$reason),
        leaf_model = if (is.null(node$leaf_model)) NA_character_ else as.character(node$leaf_model),
        edge_label = as.character(edge_label),
        x_center = x_center,
        y_center = y_center,
        subtree_leaf_count = 1L,
        stringsAsFactors = FALSE
      )
      return(list(x_center = x_center, next_leaf_slot = next_leaf_slot + 1L, subtree_leaf_count = 1L))
    }

    left_res <- rec(node$left, next_leaf_slot = next_leaf_slot, edge_label = .ctgp_tree_branch_label(node$left_levels))
    right_res <- rec(node$right, next_leaf_slot = left_res$next_leaf_slot, edge_label = .ctgp_tree_branch_label(node$right_levels))

    if (identical(parent_position, "weighted")) {
      left_w <- sqrt(left_res$subtree_leaf_count)
      right_w <- sqrt(right_res$subtree_leaf_count)
      x_center <- (left_res$x_center * left_w + right_res$x_center * right_w) / (left_w + right_w)
    } else {
      x_center <- (left_res$x_center + right_res$x_center) / 2
    }

    subtree_leaf_count <- left_res$subtree_leaf_count + right_res$subtree_leaf_count
    rows[[length(rows) + 1L]] <<- data.frame(
      node_id = as.integer(node$node_id),
      parent_id = if (is.null(node$parent_id)) NA_integer_ else as.integer(node$parent_id),
      depth = depth,
      is_leaf = FALSE,
      split_var = if (is.null(node$split_var)) NA_character_ else as.character(node$split_var),
      score = if (is.null(node$score)) NA_real_ else as.numeric(node$score),
      n_rows = if (is.null(node$n_rows)) NA_integer_ else as.integer(node$n_rows),
      n_combined = if (is.null(node$combined_ids)) NA_integer_ else as.integer(length(node$combined_ids)),
      reason = if (is.null(node$reason)) NA_character_ else as.character(node$reason),
      leaf_model = NA_character_,
      edge_label = as.character(edge_label),
      x_center = x_center,
      y_center = y_center,
      subtree_leaf_count = as.integer(subtree_leaf_count),
      stringsAsFactors = FALSE
    )

    list(x_center = x_center, next_leaf_slot = right_res$next_leaf_slot, subtree_leaf_count = subtree_leaf_count)
  }

  rec(tree, next_leaf_slot = 0L, edge_label = "")
  layout_tbl <- do.call(rbind, rows)
  layout_tbl <- layout_tbl[order(layout_tbl$depth, layout_tbl$node_id), , drop = FALSE]

  parent_match <- match(layout_tbl$parent_id, layout_tbl$node_id)
  layout_tbl$x_parent <- layout_tbl$x_center[parent_match]
  layout_tbl$y_parent <- layout_tbl$y_center[parent_match]
  root_idx <- is.na(layout_tbl$parent_id)
  layout_tbl$x_parent[root_idx] <- layout_tbl$x_center[root_idx]
  layout_tbl$y_parent[root_idx] <- layout_tbl$y_center[root_idx]
  layout_tbl
}

.ctgp_tree_leaf_model_label <- function(node_row) {
  explicit <- node_row$leaf_model[[1L]]
  if (!is.null(explicit) && !is.na(explicit) && nzchar(explicit)) {
    return(toupper(as.character(explicit)))
  }
  ""
}

.ctgp_tree_internal_label_parts <- function(node_row,
                                            digits = 2L,
                                            show_node_id = TRUE,
                                            node_id_style = c("paren", "word")) {
  node_id_style <- match.arg(node_id_style)
  id_label <- ""
  if (isTRUE(show_node_id)) {
    id_label <- if (identical(node_id_style, "paren")) paste0("(", node_row$node_id[[1L]], ")") else paste0("node ", node_row$node_id[[1L]])
  }
  corr_text <- if (is.finite(node_row$score[[1L]])) paste0("r = ", format(round(node_row$score[[1L]], digits), nsmall = digits)) else "r = NA"
  list(id = id_label, split = node_row$split_var[[1L]], corr = corr_text)
}

.ctgp_loocv_map <- function(loocv_values) {
  if (is.null(loocv_values)) {
    return(NULL)
  }
  if (is.numeric(loocv_values) && !is.null(names(loocv_values))) {
    return(loocv_values)
  }
  if (is.data.frame(loocv_values) && all(c("node_id", "loocv_value") %in% names(loocv_values))) {
    return(stats::setNames(as.numeric(loocv_values$loocv_value), loocv_values$node_id))
  }
  stop("loocv_values must be either a named numeric vector or a data.frame with columns node_id and loocv_value.")
}

.ctgp_tree_leaf_model_status <- function(tree) {
  rows <- .ctgp_tree_plot_rows(tree)
  leaf_rows <- rows[rows$is_leaf, , drop = FALSE]
  if (nrow(leaf_rows) == 0L) {
    return("leaf fitting: none")
  }
  has_model <- !is.na(leaf_rows$leaf_model) & nzchar(leaf_rows$leaf_model)
  n_fit <- sum(has_model)
  n_leaf <- nrow(leaf_rows)
  if (n_fit == 0L) {
    return("leaf fitting: none")
  }
  if (n_fit == n_leaf) {
    return(paste0("leaf fitting: yes (", n_fit, "/", n_leaf, ")"))
  }
  paste0("leaf fitting: partial (", n_fit, "/", n_leaf, ")")
}

.ctgp_tree_info_text <- function(tree, show_tree_info = TRUE, show_data_info = FALSE) {
  lines <- character(0)
  if (isTRUE(show_tree_info)) {
    split_rule <- attr(tree, "split_rule", exact = TRUE)
    if (is.null(split_rule) || !nzchar(split_rule)) {
      split_rule <- "recursive splitting to the bottom"
    }
    lines <- c(
      lines,
      paste0("splitting rule: ", split_rule),
      paste0("pruned: ", if (.ctgp_tree_is_pruned(tree)) "yes" else "no"),
      .ctgp_tree_leaf_model_status(tree)
    )
  }
  if (isTRUE(show_data_info)) {
    info <- attr(tree, "data_summary", exact = TRUE)
    if (is.list(info) && length(info) > 0L) {
      lines <- c(
        lines,
        paste0("n = ", info$n),
        paste0("qualitative factors = ", info$qualitative_count),
        paste0("total combinations = ", info$combined_count)
      )
    }
  }
  if (length(lines) == 0L) return(NULL)
  paste(lines, collapse = "\n")
}

.ctgp_tree_info_spec <- function(info_text, single_root = FALSE) {
  if (is.null(info_text) || !nzchar(info_text)) return(NULL)
  lines <- strsplit(info_text, "\n", fixed = TRUE)[[1L]]
  max_chars <- max(nchar(lines, type = "width"), 1L)
  n_lines <- length(lines)
  if (single_root) {
    width <- max(1.30, 0.058 * max_chars + 0.00)
    height <- max(0.40, 0.100 * n_lines + 0.00)
    pad_x <- 0.006
    pad_top <- 0.008
    line_step <- (height - 2 * pad_top) / max(n_lines - 0.10, 1)
    anchor_width <- width
  } else {
    anchor_width <- max(2.54, 0.118 * max_chars + 0.04)
    width <- max(2.34, 0.102 * max_chars + 0.00)
    height <- max(0.94, 0.192 * n_lines + 0.00)
    pad_x <- 0.010
    pad_top <- 0.014
    line_step <- (height - 2 * pad_top) / max(n_lines - 0.10, 1)
  }
  list(lines = lines, width = width, height = height, pad_x = pad_x, pad_top = pad_top, line_step = line_step, anchor_width = anchor_width)
}

.ctgp_tree_choose_regular_info <- function(layout_tbl, tree_bbox, info_spec, position) {
  if (is.null(info_spec)) return(NULL)
  if (position == "auto") {
    position <- "top_right"
  }
  gap_x <- 0.24
  gap_y <- 0.04
  root_x <- layout_tbl$x_center[is.na(layout_tbl$parent_id)][1L]
  anchor_w <- if (!is.null(info_spec$anchor_width)) info_spec$anchor_width else info_spec$width
  if (position == "top_right") {
    x_right <- root_x + 1.42 + anchor_w
    x_center <- x_right - info_spec$width / 2
    y_top <- tree_bbox$top - gap_y
    y_center <- y_top - info_spec$height / 2
  } else if (position == "top_left") {
    x_left <- root_x - 1.42 - anchor_w
    x_center <- x_left + info_spec$width / 2
    y_top <- tree_bbox$top - gap_y
    y_center <- y_top - info_spec$height / 2
  } else if (position == "bottom_right") {
    x_right <- root_x + 1.66 + anchor_w
    x_center <- x_right - info_spec$width / 2
    y_bottom <- tree_bbox$bottom + gap_y
    y_center <- y_bottom + info_spec$height / 2
  } else {
    x_left <- root_x - 1.42 - anchor_w
    x_center <- x_left + info_spec$width / 2
    y_bottom <- tree_bbox$bottom + gap_y
    y_center <- y_bottom + info_spec$height / 2
  }
  data.frame(
    position = position,
    x_center = x_center,
    y_center = y_center,
    width = info_spec$width,
    height = info_spec$height,
    x_left = x_center - info_spec$width / 2,
    x_right = x_center + info_spec$width / 2,
    y_top = y_center + info_spec$height / 2,
    y_bottom = y_center - info_spec$height / 2,
    label = paste(info_spec$lines, collapse = "\n"),
    stringsAsFactors = FALSE
  )
}


.ctgp_tree_finalize_layout <- function(layout_tbl, split_rows, leaf_rows) {
  out <- layout_tbl
  if (!"node_label" %in% names(out)) out$node_label <- NA_character_
  if (!"id_label" %in% names(out)) out$id_label <- NA_character_
  if (!"box_half_w" %in% names(out)) out$box_half_w <- NA_real_
  if (!"box_half_h" %in% names(out)) out$box_half_h <- NA_real_
  if (!"leaf_radius" %in% names(out)) out$leaf_radius <- NA_real_
  if (!"loocv_y" %in% names(out)) out$loocv_y <- NA_real_
  if (!"loocv_value" %in% names(out)) out$loocv_value <- NA_real_
  if (!"loocv_label" %in% names(out)) out$loocv_label <- NA_character_

  if (nrow(split_rows) > 0L) {
    idx <- match(split_rows$node_id, out$node_id)
    out$node_label[idx] <- split_rows$node_label
    out$id_label[idx] <- split_rows$id_label
    out$box_half_w[idx] <- split_rows$box_half_w
    out$box_half_h[idx] <- split_rows$box_half_h
  }
  if (nrow(leaf_rows) > 0L) {
    idx <- match(leaf_rows$node_id, out$node_id)
    out$node_label[idx] <- leaf_rows$node_label
    out$id_label[idx] <- leaf_rows$id_label
    out$leaf_radius[idx] <- leaf_rows$leaf_radius
  }
  out
}

.ctgp_tree_bbox_regular <- function(split_rows, leaf_rows, root_stub, loocv_rows) {
  x_left <- c(split_rows$x_center - split_rows$box_half_w, leaf_rows$x_center - leaf_rows$leaf_radius)
  x_right <- c(split_rows$x_center + split_rows$box_half_w, leaf_rows$x_center + leaf_rows$leaf_radius)
  y_top <- c(root_stub$y_top, split_rows$y_center + split_rows$box_half_h, leaf_rows$y_center + leaf_rows$leaf_radius)
  y_bottom <- c(split_rows$y_center - split_rows$box_half_h, leaf_rows$y_center - leaf_rows$leaf_radius)
  if (nrow(loocv_rows) > 0L) y_bottom <- c(y_bottom, loocv_rows$loocv_y)
  list(left = min(x_left, na.rm = TRUE), right = max(x_right, na.rm = TRUE), top = max(y_top, na.rm = TRUE), bottom = min(y_bottom, na.rm = TRUE))
}

.ctgp_tree_prepare_regular <- function(tree,
                                       layout_tbl,
                                       digits,
                                       node_cex,
                                       leaf_cex,
                                       show_node_id,
                                       node_id_style,
                                       edge_cex,
                                       show_loocv,
                                       loocv_digits,
                                       show_tree_info,
                                       show_data_info,
                                       tree_info_position) {
  split_rows <- layout_tbl[!layout_tbl$is_leaf, , drop = FALSE]
  leaf_rows <- layout_tbl[layout_tbl$is_leaf, , drop = FALSE]
  single_root_leaf <- nrow(layout_tbl) == 1L && isTRUE(layout_tbl$is_leaf[[1L]])

  if (nrow(split_rows) > 0L) {
    parts <- lapply(seq_len(nrow(split_rows)), function(i) .ctgp_tree_internal_label_parts(split_rows[i, , drop = FALSE], digits = digits, show_node_id = show_node_id, node_id_style = node_id_style))
    split_rows$id_label <- vapply(parts, function(x) x$id, character(1))
    split_rows$split_label <- vapply(parts, function(x) x$split, character(1))
    split_rows$corr_label <- vapply(parts, function(x) x$corr, character(1))
    split_rows$node_label <- paste(split_rows$id_label, split_rows$split_label, split_rows$corr_label, sep = "\n")
    max_chars <- pmax(nchar(split_rows$id_label, type = "width"), nchar(split_rows$split_label, type = "width"), nchar(split_rows$corr_label, type = "width"))
    split_rows$box_half_w <- pmax(0.66, 0.090 * max_chars + 0.24)
    split_rows$box_half_h <- 0.70 + 0.04 * (node_cex - 1)
    split_rows$line_gap <- 0.44
    split_rows$id_y <- split_rows$y_center + split_rows$line_gap
    split_rows$split_y <- split_rows$y_center
    split_rows$corr_y <- split_rows$y_center - split_rows$line_gap
  } else {
    split_rows$id_label <- character(0)
    split_rows$split_label <- character(0)
    split_rows$corr_label <- character(0)
    split_rows$node_label <- character(0)
    split_rows$box_half_w <- numeric(0)
    split_rows$box_half_h <- numeric(0)
  }

  if (nrow(leaf_rows) > 0L) {
    leaf_rows$id_label <- if (isTRUE(show_node_id)) if (identical(node_id_style, "paren")) paste0("(", leaf_rows$node_id, ")") else paste0("node ", leaf_rows$node_id) else ""
    leaf_rows$leaf_label <- "leaf"
    leaf_rows$model_label <- vapply(seq_len(nrow(leaf_rows)), function(i) .ctgp_tree_leaf_model_label(leaf_rows[i, , drop = FALSE]), character(1))
    leaf_rows$has_model <- nzchar(leaf_rows$model_label)
    leaf_rows$leaf_radius <- ifelse(leaf_rows$has_model, 0.77, 0.74)
    leaf_rows$node_label <- ifelse(leaf_rows$has_model, paste(leaf_rows$id_label, leaf_rows$leaf_label, leaf_rows$model_label, sep = "\n"), paste(leaf_rows$id_label, leaf_rows$leaf_label, sep = "\n"))
    leaf_rows$id_y <- ifelse(leaf_rows$has_model, leaf_rows$y_center + 0.52 * leaf_rows$leaf_radius, leaf_rows$y_center + 0.38 * leaf_rows$leaf_radius)
    leaf_rows$leaf_y <- ifelse(leaf_rows$has_model, leaf_rows$y_center + 0.02 * leaf_rows$leaf_radius, leaf_rows$y_center - 0.16 * leaf_rows$leaf_radius)
    leaf_rows$model_y <- ifelse(leaf_rows$has_model, leaf_rows$y_center - 0.42 * leaf_rows$leaf_radius, NA_real_)
  }

  loocv_gap <- 0.20
  layout_tbl$loocv_y <- NA_real_
  if (isTRUE(show_loocv)) {
    if (nrow(split_rows) > 0L) {
      idx <- match(split_rows$node_id, layout_tbl$node_id)
      layout_tbl$loocv_y[idx] <- split_rows$y_center - split_rows$box_half_h - loocv_gap
    }
    if (nrow(leaf_rows) > 0L) {
      idx <- match(leaf_rows$node_id, layout_tbl$node_id)
      layout_tbl$loocv_y[idx] <- leaf_rows$y_center - leaf_rows$leaf_radius - loocv_gap
    }
  }

  root_row <- layout_tbl[is.na(layout_tbl$parent_id), , drop = FALSE]
  root_box_half_h <- split_rows$box_half_h[match(root_row$node_id, split_rows$node_id)]
  root_visible_start <- root_row$y_center[[1L]] + root_box_half_h
  root_visible_len <- 0.92
  root_top <- root_visible_start + root_visible_len
  root_stub <- data.frame(
    x_center = root_row$x_center,
    y_start = root_row$y_center[[1L]],
    y_top = root_top,
    label_x = root_row$x_center,
    label_y = root_top - 0.40 * root_visible_len,
    edge_label = "root",
    stringsAsFactors = FALSE
  )

  edge_rows <- layout_tbl[!is.na(layout_tbl$parent_id), , drop = FALSE]
  if (nrow(edge_rows) > 0L) {
    parent_rows <- layout_tbl[match(edge_rows$parent_id, layout_tbl$node_id), , drop = FALSE]
    edge_rows$parent_junction_y <- parent_rows$y_center
    edge_rows$child_center_y <- edge_rows$y_center
    edge_rows$edge_y <- parent_rows$y_center
    child_top <- ifelse(edge_rows$is_leaf,
      leaf_rows$y_center[match(edge_rows$node_id, leaf_rows$node_id)] + leaf_rows$leaf_radius[match(edge_rows$node_id, leaf_rows$node_id)],
      split_rows$y_center[match(edge_rows$node_id, split_rows$node_id)] + split_rows$box_half_h[match(edge_rows$node_id, split_rows$node_id)]
    )
    edge_rows$child_top_y <- child_top
    edge_rows$label_x <- edge_rows$x_center
    parent_half_h <- split_rows$box_half_h[match(edge_rows$parent_id, split_rows$node_id)]
    edge_rows$parent_box_bottom <- edge_rows$parent_junction_y - parent_half_h
    edge_rows$label_y <- (edge_rows$parent_box_bottom + edge_rows$child_top_y) / 2 + 0.10
  }

  loocv_rows <- layout_tbl[is.finite(layout_tbl$loocv_y) & !is.na(layout_tbl$loocv_label) & nzchar(layout_tbl$loocv_label), , drop = FALSE]
  tree_bbox <- .ctgp_tree_bbox_regular(split_rows, leaf_rows, root_stub, loocv_rows)

  info_text <- .ctgp_tree_info_text(tree, show_tree_info = show_tree_info, show_data_info = show_data_info)
  info_spec <- .ctgp_tree_info_spec(info_text, single_root = FALSE)
  info_box <- .ctgp_tree_choose_regular_info(layout_tbl, tree_bbox, info_spec, position = tree_info_position)

  x_left <- tree_bbox$left
  x_right <- tree_bbox$right
  y_top <- tree_bbox$top
  y_bottom <- tree_bbox$bottom
  if (!is.null(info_box)) {
    x_left <- min(x_left, info_box$x_left)
    x_right <- max(x_right, info_box$x_right)
    y_top <- max(y_top, info_box$y_top)
    y_bottom <- min(y_bottom, info_box$y_bottom)
  }

  pad_x <- 0.65
  pad_y <- 0.45
  xlim <- c(x_left - pad_x, x_right + pad_x)
  ylim <- c(y_bottom - pad_y, y_top + pad_y)

  leaf_count <- sum(layout_tbl$is_leaf)
  depth_max <- max(layout_tbl$depth)
  plot_width_in <- min(9.6, max(7.2, 1.02 * leaf_count + if (is.null(info_box)) 2.8 else 3.6))
  plot_height_in <- min(6.8, max(5.0, 1.08 * (depth_max + 1L) + 1.80))

  layout_tbl <- .ctgp_tree_finalize_layout(layout_tbl, split_rows, leaf_rows)

  list(
    type = "regular",
    layout_tbl = layout_tbl,
    split_rows = split_rows,
    leaf_rows = leaf_rows,
    edge_rows = edge_rows,
    root_stub = root_stub,
    loocv_rows = loocv_rows,
    info_text = info_text,
    info_spec = info_spec,
    info_box = info_box,
    xlim = xlim,
    ylim = ylim,
    plot_width_in = plot_width_in,
    plot_height_in = plot_height_in,
    tree_bbox = tree_bbox,
    node_cex = node_cex,
    edge_cex = edge_cex,
    leaf_cex = leaf_cex
  )
}

.ctgp_tree_prepare_degenerated <- function(tree,
                                           layout_tbl,
                                           leaf_cex,
                                           edge_cex,
                                           show_node_id,
                                           node_id_style,
                                           show_loocv,
                                           show_tree_info,
                                           show_data_info,
                                           tree_info_position) {
  leaf_row <- layout_tbl[1L, , drop = FALSE]
  leaf_row$id_label <- if (isTRUE(show_node_id)) if (identical(node_id_style, "paren")) paste0("(", leaf_row$node_id, ")") else paste0("node ", leaf_row$node_id) else ""
  leaf_row$leaf_label <- "leaf"
  leaf_row$model_label <- .ctgp_tree_leaf_model_label(leaf_row)
  leaf_row$has_model <- nzchar(leaf_row$model_label)
  leaf_row$leaf_radius <- if (leaf_row$has_model) 0.35 else 0.33
  leaf_row$node_label <- if (leaf_row$has_model) paste(leaf_row$id_label, leaf_row$leaf_label, leaf_row$model_label, sep = "\n") else paste(leaf_row$id_label, leaf_row$leaf_label, sep = "\n")

  info_text <- .ctgp_tree_info_text(tree, show_tree_info = show_tree_info, show_data_info = show_data_info)
  info_spec <- .ctgp_tree_info_spec(info_text, single_root = TRUE)

  if (is.null(info_spec)) {
    info_spec <- list(lines = character(0), width = 0, height = 0, pad_x = 0.10, pad_top = 0.08, line_step = 0.22)
  }

  side <- if (tree_info_position %in% c("top_left", "bottom_left")) "left" else "right"
  if (identical(tree_info_position, "auto")) side <- "right"

  gap_info <- if (nzchar(info_text %||% "")) 1.8 else 0
  loocv_gap <- if (leaf_row$has_model) -0.25 else -0.23
  stub_len <- if (leaf_row$has_model) 0.07 else 0.06
  circle_center_y <- (loocv_gap - stub_len) / 2
  leaf_row$y_center <- circle_center_y
  leaf_row$id_y <- if (leaf_row$has_model) circle_center_y + 0.12 * leaf_row$leaf_radius else circle_center_y + 0.09 * leaf_row$leaf_radius
  leaf_row$leaf_y <- if (leaf_row$has_model) circle_center_y + 0.013 * leaf_row$leaf_radius else circle_center_y - 0.06 * leaf_row$leaf_radius
  leaf_row$model_y <- if (leaf_row$has_model) circle_center_y - 0.078 * leaf_row$leaf_radius else NA_real_

  layout_tbl$loocv_y <- NA_real_
  loocv_rows <- layout_tbl[0L, , drop = FALSE]
  if (isTRUE(show_loocv) && !is.na(layout_tbl$loocv_label[[1L]]) && nzchar(layout_tbl$loocv_label[[1L]])) {
    layout_tbl$loocv_y[[1L]] <- leaf_row$y_center - leaf_row$leaf_radius - loocv_gap
    loocv_rows <- layout_tbl[1L, , drop = FALSE]
  }

  root_visible_start <- leaf_row$y_center + leaf_row$leaf_radius
  root_top <- root_visible_start + stub_len - 0.2
  root_stub <- data.frame(
    x_center = 0,
    y_start = leaf_row$y_center,
    y_top = root_top,
    label_x = 0,
    label_y = root_top - 1.1 * stub_len,
    edge_label = "root",
    stringsAsFactors = FALSE
  )

  total_w <- 2 * leaf_row$leaf_radius + gap_info + info_spec$width
  if (identical(side, "right")) {
    circle_left <- -total_w / 2
    leaf_row$x_center <- circle_left + leaf_row$leaf_radius
    circle_right <- leaf_row$x_center + leaf_row$leaf_radius
    info_inner <- circle_right + gap_info
    info_left <- info_inner
    info_right <- info_left + info_spec$width
    info_center_x <- info_left + info_spec$width / 2
  } else {
    info_left <- -total_w / 2
    info_right <- info_left + info_spec$width
    info_inner <- info_right
    circle_left <- info_right + gap_info
    leaf_row$x_center <- circle_left + leaf_row$leaf_radius
    info_center_x <- info_left + info_spec$width / 2
  }
  root_stub$x_center <- leaf_row$x_center
  root_stub$label_x <- leaf_row$x_center

  content_top <- root_stub$y_top
  content_bottom <- if (nrow(loocv_rows) > 0L) loocv_rows$loocv_y[[1L]] - 0.0010 else leaf_row$y_center - leaf_row$leaf_radius
  info_center_y <- (content_top + content_bottom) / 2
  info_box <- if (nzchar(info_text %||% "")) data.frame(
    position = if (identical(side, "right")) "top_right" else "top_left",
    x_center = info_center_x,
    x_inner = info_inner,
    y_center = info_center_y,
    width = info_spec$width,
    height = info_spec$height,
    x_left = info_left,
    x_right = info_right,
    y_top = info_center_y + info_spec$height / 2,
    y_bottom = info_center_y - info_spec$height / 2,
    label = info_text,
    stringsAsFactors = FALSE
  ) else NULL

  tree_left <- leaf_row$x_center - leaf_row$leaf_radius
  tree_right <- leaf_row$x_center + leaf_row$leaf_radius
  x_left <- if (is.null(info_box)) tree_left else min(tree_left, info_box$x_left)
  x_right <- if (is.null(info_box)) tree_right else max(tree_right, info_box$x_right)
  y_top <- if (is.null(info_box)) root_stub$y_top else max(root_stub$y_top, info_box$y_top)
  y_bottom <- if (is.null(info_box)) content_bottom else min(content_bottom, info_box$y_bottom)

  xlim <- c(x_left - 1.3, x_right + 1.3)
  ylim <- c(y_bottom - 0.14, y_top + 0.14)

  plot_width_in <- if (is.null(info_box)) 3.4 else 5.6
  plot_height_in <- if (is.null(info_box)) 2.8 else 3.1

  layout_tbl <- .ctgp_tree_finalize_layout(layout_tbl, layout_tbl[0L, , drop = FALSE], leaf_row)

  list(
    type = "degenerated",
    layout_tbl = layout_tbl,
    split_rows = layout_tbl[0L, , drop = FALSE],
    leaf_rows = leaf_row,
    edge_rows = layout_tbl[0L, , drop = FALSE],
    root_stub = root_stub,
    loocv_rows = loocv_rows,
    info_text = info_text,
    info_spec = info_spec,
    info_box = info_box,
    xlim = xlim,
    ylim = ylim,
    plot_width_in = plot_width_in,
    plot_height_in = plot_height_in,
    tree_bbox = list(left = tree_left, right = tree_right, top = root_stub$y_top, bottom = content_bottom),
    node_cex = 1,
    edge_cex = edge_cex,
    leaf_cex = leaf_cex
  )
}

`%||%` <- function(x, y) if (is.null(x)) y else x

.ctgp_tree_build_plot <- function(tree,
                                  layout_tbl,
                                  digits,
                                  node_cex,
                                  leaf_cex,
                                  edge_cex,
                                  show_node_id,
                                  node_id_style,
                                  show_loocv,
                                  loocv_digits,
                                  show_tree_info,
                                  show_data_info,
                                  tree_info_position) {
  single_root_leaf <- nrow(layout_tbl) == 1L && isTRUE(layout_tbl$is_leaf[[1L]])
  if (single_root_leaf) {
    .ctgp_tree_prepare_degenerated(
      tree = tree,
      layout_tbl = layout_tbl,
      leaf_cex = leaf_cex,
      edge_cex = edge_cex,
      show_node_id = show_node_id,
      node_id_style = node_id_style,
      show_loocv = show_loocv,
      show_tree_info = show_tree_info,
      show_data_info = show_data_info,
      tree_info_position = tree_info_position
    )
  } else {
    .ctgp_tree_prepare_regular(
      tree = tree,
      layout_tbl = layout_tbl,
      digits = digits,
      node_cex = node_cex,
      leaf_cex = leaf_cex,
      show_node_id = show_node_id,
      node_id_style = node_id_style,
      edge_cex = edge_cex,
      show_loocv = show_loocv,
      loocv_digits = loocv_digits,
      show_tree_info = show_tree_info,
      show_data_info = show_data_info,
      tree_info_position = tree_info_position
    )
  }
}

.ctgp_tree_text_fs <- function(base_size, scale = 1) {
  base_size * scale
}

.ctgp_tree_draw_multiline_text <- function(lines, x, y_top, line_step, fontsize, fontface = 1) {
  if (length(lines) == 0L) return(invisible(NULL))
  for (i in seq_along(lines)) {
    grid::grid.text(
      label = lines[[i]],
      x = grid::unit(x, "native"),
      y = grid::unit(y_top - (i - 1) * line_step, "native"),
      just = c("left", "top"),
      gp = grid::gpar(fontsize = fontsize, fontface = fontface)
    )
  }
}

.ctgp_tree_draw_branch_label <- function(label, x, y, fontsize, lwd = 0, pad_x_mm = 2.6, pad_y_mm = 1.6) {
  if (is.null(label) || !nzchar(label)) return(invisible(NULL))
  tg <- grid::textGrob(label, gp = grid::gpar(fontsize = fontsize))
  w <- grid::convertWidth(grid::grobWidth(tg) + grid::unit(pad_x_mm, "mm"), "native", valueOnly = TRUE)
  h <- grid::convertHeight(grid::grobHeight(tg) + grid::unit(pad_y_mm, "mm"), "native", valueOnly = TRUE)
  grid::grid.rect(
    x = grid::unit(x, "native"),
    y = grid::unit(y, "native"),
    width = grid::unit(w, "native"),
    height = grid::unit(h, "native"),
    just = "center",
    gp = grid::gpar(fill = "white", col = NA, lwd = lwd)
  )
  grid::grid.text(
    label = label,
    x = grid::unit(x, "native"),
    y = grid::unit(y, "native"),
    just = c("center", "center"),
    gp = grid::gpar(fontsize = fontsize)
  )
}

.ctgp_tree_draw_info_box <- function(info_box,
                                     info_spec,
                                     fontsize,
                                     lineheight = 1.04,
                                     border_lwd = 1.5,
                                     pad_left_mm = 0.50,
                                     pad_right_mm = 0.50,
                                     pad_top_mm = 0.50,
                                     pad_bottom_mm = 0.50) {
  if (is.null(info_box) || is.null(info_spec) || !nzchar(info_box$label[[1L]])) return(invisible(NULL))
  txt <- grid::textGrob(
    label = paste(info_spec$lines, collapse = "\n"),
    x = grid::unit(0, "npc"),
    y = grid::unit(1, "npc"),
    just = c("left", "top"),
    gp = grid::gpar(fontsize = fontsize, lineheight = lineheight)
  )
  pad_left <- grid::convertWidth(grid::unit(pad_left_mm, "mm"), "native", valueOnly = TRUE)
  pad_right <- grid::convertWidth(grid::unit(pad_right_mm, "mm"), "native", valueOnly = TRUE)
  pad_top <- grid::convertHeight(grid::unit(pad_top_mm, "mm"), "native", valueOnly = TRUE)
  pad_bottom <- grid::convertHeight(grid::unit(pad_bottom_mm, "mm"), "native", valueOnly = TRUE)
  text_w <- grid::convertWidth(grid::grobWidth(txt), "native", valueOnly = TRUE)
  text_h <- grid::convertHeight(grid::grobHeight(txt), "native", valueOnly = TRUE)
  box_w <- text_w + pad_left + pad_right
  box_h <- text_h + pad_top + pad_bottom
  pos <- if (!is.null(info_box$position[[1L]])) as.character(info_box$position[[1L]]) else "top_right"
  x_inner <- if (!is.null(info_box$x_inner[[1L]]) && is.finite(info_box$x_inner[[1L]])) info_box$x_inner[[1L]] else NA_real_
  if (grepl("right$", pos)) {
    if (is.finite(x_inner)) {
      x_left <- x_inner
      x_right <- x_left + box_w
    } else {
      x_right <- info_box$x_right[[1L]]
      x_left <- x_right - box_w
    }
  } else {
    if (is.finite(x_inner)) {
      x_right <- x_inner
      x_left <- x_right - box_w
    } else {
      x_left <- info_box$x_left[[1L]]
      x_right <- x_left + box_w
    }
  }
  y_center <- if (!is.null(info_box$y_center[[1L]]) && is.finite(info_box$y_center[[1L]])) info_box$y_center[[1L]] else (info_box$y_top[[1L]] + info_box$y_bottom[[1L]]) / 2
  y_top <- y_center + box_h / 2
  y_bottom <- y_center - box_h / 2
  grid::grid.rect(
    x = grid::unit((x_left + x_right) / 2, "native"),
    y = grid::unit((y_top + y_bottom) / 2, "native"),
    width = grid::unit(box_w, "native"),
    height = grid::unit(box_h, "native"),
    just = "center",
    gp = grid::gpar(fill = "white", lwd = border_lwd)
  )
  .ctgp_tree_draw_multiline_text(
    lines = info_spec$lines,
    x = x_left + pad_left,
    y_top = y_top - pad_top,
    line_step = (text_h / max(length(info_spec$lines) - 0.02, 1)),
    fontsize = fontsize,
    fontface = 1
  )
}

.ctgp_tree_draw_regular <- function(obj) {
  split_rows <- obj$split_rows
  leaf_rows <- obj$leaf_rows
  edge_rows <- obj$edge_rows
  root_stub <- obj$root_stub
  loocv_rows <- obj$loocv_rows
  info_box <- obj$info_box
  info_spec <- obj$info_spec

  line_lwd <- obj$edge_linewidth * obj$render_scale * 2.4
  box_lwd <- obj$node_box_linewidth * obj$render_scale * 2.2

  if (nrow(edge_rows) > 0L) {
    for (i in seq_len(nrow(edge_rows))) {
      er <- edge_rows[i, , drop = FALSE]
      grid::grid.lines(
        x = grid::unit(c(er$x_center, er$x_center), "native"),
        y = grid::unit(c(er$child_center_y, er$edge_y), "native"),
        gp = grid::gpar(lwd = line_lwd, lineend = "square")
      )
      grid::grid.lines(
        x = grid::unit(c(er$x_parent, er$x_center), "native"),
        y = grid::unit(c(er$edge_y, er$edge_y), "native"),
        gp = grid::gpar(lwd = line_lwd, lineend = "square")
      )
      if (nzchar(er$edge_label[[1L]])) {
        .ctgp_tree_draw_branch_label(
          label = er$edge_label[[1L]],
          x = er$label_x,
          y = er$label_y,
          fontsize = .ctgp_tree_text_fs(11.0, obj$edge_cex * obj$render_scale)
        )
      }
    }
  }

  grid::grid.lines(
    x = grid::unit(c(root_stub$x_center, root_stub$x_center), "native"),
    y = grid::unit(c(root_stub$y_start, root_stub$y_top), "native"),
    gp = grid::gpar(lwd = line_lwd, lineend = "square")
  )
  .ctgp_tree_draw_branch_label(
    label = root_stub$edge_label[[1L]],
    x = root_stub$label_x,
    y = root_stub$label_y,
    fontsize = .ctgp_tree_text_fs(11.4, obj$edge_cex * obj$render_scale),
    pad_x_mm = 3.2,
    pad_y_mm = 2.0
  )

  if (nrow(split_rows) > 0L) {
    for (i in seq_len(nrow(split_rows))) {
      sr <- split_rows[i, , drop = FALSE]
      grid::grid.rect(
        x = grid::unit(sr$x_center, "native"),
        y = grid::unit(sr$y_center, "native"),
        width = grid::unit(2 * sr$box_half_w, "native"),
        height = grid::unit(2 * sr$box_half_h, "native"),
        just = "center",
        gp = grid::gpar(fill = "white", lwd = box_lwd)
      )
      grid::grid.text(sr$id_label[[1L]], x = grid::unit(sr$x_center, "native"), y = grid::unit(sr$id_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(11.2, obj$node_cex * obj$render_scale)))
      grid::grid.text(sr$split_label[[1L]], x = grid::unit(sr$x_center, "native"), y = grid::unit(sr$split_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(11.8, obj$node_cex * obj$render_scale)))
      grid::grid.text(sr$corr_label[[1L]], x = grid::unit(sr$x_center, "native"), y = grid::unit(sr$corr_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(11.2, obj$node_cex * obj$render_scale)))
    }
  }

  if (nrow(leaf_rows) > 0L) {
    for (i in seq_len(nrow(leaf_rows))) {
      lr <- leaf_rows[i, , drop = FALSE]
      grid::grid.circle(
        x = grid::unit(lr$x_center, "native"),
        y = grid::unit(lr$y_center, "native"),
        r = grid::unit(lr$leaf_radius, "native"),
        gp = grid::gpar(fill = "white", lwd = box_lwd)
      )
      grid::grid.text(lr$id_label[[1L]], x = grid::unit(lr$x_center, "native"), y = grid::unit(lr$id_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(11.8, obj$leaf_cex * obj$render_scale)))
      grid::grid.text(lr$leaf_label[[1L]], x = grid::unit(lr$x_center, "native"), y = grid::unit(lr$leaf_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(12.4, obj$leaf_cex * obj$render_scale)))
      if (isTRUE(lr$has_model[[1L]])) {
        model_fs <- if (nchar(lr$model_label[[1L]], type = "width") > 5L) .ctgp_tree_text_fs(9.6, obj$leaf_cex * obj$render_scale) else .ctgp_tree_text_fs(10.6, obj$leaf_cex * obj$render_scale)
        grid::grid.text(lr$model_label[[1L]], x = grid::unit(lr$x_center, "native"), y = grid::unit(lr$model_y, "native"), gp = grid::gpar(fontsize = model_fs))
      }
    }
  }

  if (nrow(loocv_rows) > 0L) {
    for (i in seq_len(nrow(loocv_rows))) {
      rr <- loocv_rows[i, , drop = FALSE]
      grid::grid.text(rr$loocv_label[[1L]], x = grid::unit(rr$x_center, "native"), y = grid::unit(rr$loocv_y, "native"), gp = grid::gpar(fontsize = 8.6 * obj$render_scale))
    }
  }

  if (!is.null(info_box) && !is.null(info_spec) && nzchar(info_box$label[[1L]])) {
    .ctgp_tree_draw_info_box(
      info_box = info_box,
      info_spec = info_spec,
      fontsize = 7.4 * obj$render_scale,
      lineheight = 1.00,
      border_lwd = 1.8 * obj$render_scale,
      pad_left_mm = 0.50,
      pad_right_mm = 0.50,
      pad_top_mm = 0.50,
      pad_bottom_mm = 0.50
    )
  }
}

.ctgp_tree_draw_degenerated <- function(obj) {
  leaf_row <- obj$leaf_rows
  root_stub <- obj$root_stub
  loocv_rows <- obj$loocv_rows
  info_box <- obj$info_box
  info_spec <- obj$info_spec

  line_lwd <- obj$edge_linewidth * obj$render_scale * 1.15
  box_lwd <- obj$node_box_linewidth * obj$render_scale * 1.35

  grid::grid.lines(
    x = grid::unit(c(root_stub$x_center, root_stub$x_center), "native"),
    y = grid::unit(c(root_stub$y_start, root_stub$y_top), "native"),
    gp = grid::gpar(lwd = line_lwd, lineend = "square")
  )
  .ctgp_tree_draw_branch_label(
    label = root_stub$edge_label[[1L]],
    x = root_stub$label_x,
    y = root_stub$label_y,
    fontsize = .ctgp_tree_text_fs(10.8, obj$edge_cex * obj$render_scale),
    pad_x_mm = 3.0,
    pad_y_mm = 1.8
  )

  grid::grid.circle(
    x = grid::unit(leaf_row$x_center, "native"),
    y = grid::unit(leaf_row$y_center, "native"),
    r = grid::unit(leaf_row$leaf_radius, "native"),
    gp = grid::gpar(fill = "white", lwd = box_lwd)
  )
  grid::grid.text(leaf_row$id_label[[1L]], x = grid::unit(leaf_row$x_center, "native"), y = grid::unit(leaf_row$id_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(10.6, obj$leaf_cex * obj$render_scale)))
  grid::grid.text(leaf_row$leaf_label[[1L]], x = grid::unit(leaf_row$x_center, "native"), y = grid::unit(leaf_row$leaf_y, "native"), gp = grid::gpar(fontsize = .ctgp_tree_text_fs(11.4, obj$leaf_cex * obj$render_scale)))
  if (isTRUE(leaf_row$has_model[[1L]])) {
    model_fs <- if (nchar(leaf_row$model_label[[1L]], type = "width") > 5L) .ctgp_tree_text_fs(7.6, obj$leaf_cex * obj$render_scale) else .ctgp_tree_text_fs(8.2, obj$leaf_cex * obj$render_scale)
    grid::grid.text(leaf_row$model_label[[1L]], x = grid::unit(leaf_row$x_center, "native"), y = grid::unit(leaf_row$model_y, "native"), gp = grid::gpar(fontsize = model_fs))
  }

  if (nrow(loocv_rows) > 0L) {
    grid::grid.text(loocv_rows$loocv_label[[1L]], x = grid::unit(leaf_row$x_center, "native"), y = grid::unit(loocv_rows$loocv_y[[1L]], "native"), gp = grid::gpar(fontsize = 9.4 * obj$render_scale))
  }

  if (!is.null(info_box) && nzchar(info_box$label[[1L]])) {
    .ctgp_tree_draw_info_box(
      info_box = info_box,
      info_spec = info_spec,
      fontsize = 6.8 * obj$render_scale,
      lineheight = 0.98,
      border_lwd = 1.8 * obj$render_scale,
      pad_left_mm = 0.50,
      pad_right_mm = 0.50,
      pad_top_mm = 0.50,
      pad_bottom_mm = 0.50
    )
  }
}

plot_ctgp_tree <- function(tree,
                           main = NULL,
                           digits = 2L,
                           node_cex = 1,
                           edge_cex = 1,
                           leaf_cex = 0.95,
                           show_node_id = TRUE,
                           node_id_style = c("paren", "word"),
                           parent_position = c("weighted", "midpoint"),
                           leaf_gap = 3.2,
                           vertical_gap = 3.1,
                           edge_linewidth = 1.55,
                           node_box_linewidth = 1.55,
                           branch_label_padding = 0.10,
                           node_label_padding = 0.46,
                           margin = c(10, 14, 8, 10),
                           show_loocv = FALSE,
                           loocv_values = NULL,
                           loocv_context = NULL,
                           loocv_digits = 4L,
                           show_tree_info = TRUE,
                           show_data_info = FALSE,
                           tree_info_position = c("auto", "top_right", "top_left", "bottom_right", "bottom_left"),
                           leaf_marker_size = 22,
                           ...) {
  if (!is.list(tree) || is.null(tree$node_id) || is.null(tree$depth) || is.null(tree$is_leaf)) {
    stop("plot_ctgp_tree() expects a tree object returned by ctgp_grow_tree().")
  }
  node_id_style <- match.arg(node_id_style)
  parent_position <- match.arg(parent_position)
  tree_info_position <- match.arg(tree_info_position)

  layout_tbl <- .ctgp_tree_layout_compact(tree, leaf_gap = leaf_gap, vertical_gap = vertical_gap, parent_position = parent_position)

  if (isTRUE(show_loocv)) {
    if (is.null(loocv_values)) loocv_values <- attr(tree, "loocv_summary", exact = TRUE)
    if (is.null(loocv_values) && !is.null(loocv_context)) loocv_values <- ctgp_loocv_summary(tree, loocv_context)
    if (is.null(loocv_values)) stop("show_loocv = TRUE requires loocv_values, loocv_context, or an attached attr(tree, 'loocv_summary').")
    loocv_map <- .ctgp_loocv_map(loocv_values)
    key <- as.character(layout_tbl$node_id)
    vals <- unname(loocv_map[key])
    layout_tbl$loocv_value <- vals
    layout_tbl$loocv_label <- ifelse(is.finite(vals), format(signif(vals, loocv_digits), digits = loocv_digits), NA_character_)
  } else {
    layout_tbl$loocv_value <- NA_real_
    layout_tbl$loocv_label <- NA_character_
  }

  obj <- .ctgp_tree_build_plot(
    tree = tree,
    layout_tbl = layout_tbl,
    digits = digits,
    node_cex = node_cex,
    leaf_cex = leaf_cex,
    edge_cex = edge_cex,
    show_node_id = show_node_id,
    node_id_style = node_id_style,
    show_loocv = show_loocv,
    loocv_digits = loocv_digits,
    show_tree_info = show_tree_info,
    show_data_info = show_data_info,
    tree_info_position = tree_info_position
  )

  obj$main <- main
  obj$edge_linewidth <- edge_linewidth
  obj$node_box_linewidth <- node_box_linewidth
  obj$branch_label_padding <- branch_label_padding
  obj$node_label_padding <- node_label_padding
  obj$margin <- margin
  obj$leaf_marker_size <- leaf_marker_size
  obj$render_scale <- 1
  obj$tree <- tree
  class(obj) <- "ctgp_tree_plot"
  attr(obj, "ctgp_tree_layout") <- obj$layout_tbl
  attr(obj, "ctgp_tree_root_stub") <- obj$root_stub
  attr(obj, "ctgp_tree_info") <- obj$info_box
  obj
}

#' @export
print.ctgp_tree_plot <- function(x, ..., newpage = NULL) {
  if (is.null(newpage)) newpage <- grDevices::dev.interactive()
  page_w <- grid::convertWidth(grid::unit(0.96, "npc"), "in", valueOnly = TRUE)
  page_h <- grid::convertHeight(grid::unit(0.94, "npc"), "in", valueOnly = TRUE)
  scale <- min(page_w / x$plot_width_in, page_h / x$plot_height_in)
  vp_w <- x$plot_width_in * scale
  vp_h <- x$plot_height_in * scale
  x$render_scale <- scale

  if (isTRUE(newpage)) grid::grid.newpage()
  if (!is.null(x$main) && nzchar(x$main)) {
    grid::grid.text(x$main, x = grid::unit(0.5, "npc"), y = grid::unit(0.98, "npc"), gp = grid::gpar(fontsize = 13, fontface = 1))
  }

  grid::pushViewport(grid::viewport(
    x = 0.5,
    y = 0.5,
    width = grid::unit(vp_w, "in"),
    height = grid::unit(vp_h, "in"),
    just = c("center", "center"),
    xscale = x$xlim,
    yscale = x$ylim,
    clip = "off"
  ))

  if (identical(x$type, "degenerated")) {
    .ctgp_tree_draw_degenerated(x)
  } else {
    .ctgp_tree_draw_regular(x)
  }

  grid::popViewport()
  invisible(x)
}
