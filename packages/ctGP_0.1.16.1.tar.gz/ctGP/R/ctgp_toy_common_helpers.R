.ctgp_toy_response <- function(x, z_1, z_2) {
  if (z_1 == 1L && z_2 == 1L) {
    cos(3.5 * pi * x) * exp(-2 * x)
  } else if (z_1 == 1L && z_2 == 2L) {
    cos(3.5 * pi * x) * exp(-0.5 * x)
  } else if (z_1 == 2L && z_2 == 1L) {
    x - 0.5
  } else {
    2 * x - 1
  }
}

.ctgp_collect_leaf_groups <- function(tree) {
  leaves <- .ctgp_collect_leaf_nodes(tree)
  lapply(leaves, function(node) sort(as.integer(node$combined_ids)))
}

.ctgp_collect_root_child_groups <- function(tree) {
  if (is.null(tree)) {
    return(list())
  }
  if (isTRUE(tree$is_leaf) || is.null(tree$left) || is.null(tree$right)) {
    ids <- tree$combined_ids
    if (is.null(ids)) return(list())
    return(list(sort(as.integer(ids))))
  }
  list(
    sort(as.integer(tree$left$combined_ids)),
    sort(as.integer(tree$right$combined_ids))
  )
}

.ctgp_grouping_matches <- function(groups, expected_groups) {
  if (length(groups) != length(expected_groups)) return(FALSE)
  normalize <- function(x) paste(sort(as.integer(x)), collapse = "|")
  identical(sort(vapply(groups, normalize, character(1))), sort(vapply(expected_groups, normalize, character(1))))
}

.ctgp_toy_make_rows_with_response_name <- function(x_vec, response_name = "Y") {
  x_vec <- as.numeric(x_vec)
  build_block <- function(z1, z2) {
    y <- vapply(x_vec, function(x) .ctgp_toy_response(x, z_1 = z1, z_2 = z2), numeric(1))
    out <- data.frame(
      x.1 = x_vec,
      c.1 = factor(paste0("c1.", z1), levels = c("c1.1", "c1.2")),
      c.2 = factor(paste0("c2.", z2), levels = c("c2.1", "c2.2")),
      stringsAsFactors = TRUE
    )
    out[[response_name]] <- y
    out
  }

  out <- do.call(rbind, list(
    build_block(1L, 1L),
    build_block(1L, 2L),
    build_block(2L, 1L),
    build_block(2L, 2L)
  ))
  rownames(out) <- NULL
  out
}

.ctgp_toy_split_level_key <- function(key_vec) {
  out <- strsplit(as.character(key_vec), "\\|\\|", fixed = FALSE)
  mat <- do.call(rbind, lapply(out, function(z) {
    z <- as.character(z)
    if (length(z) < 2L) z <- c(z, rep(NA_character_, 2L - length(z)))
    z[seq_len(2L)]
  }))
  data.frame(
    combined_id = seq_along(key_vec),
    c_1 = mat[, 1L],
    c_2 = mat[, 2L],
    stringsAsFactors = FALSE
  )
}

.ctgp_toy_leaf_group_signature <- function(tree) {
  groups <- .ctgp_collect_leaf_groups(tree)
  if (!length(groups)) return(character())
  groups <- lapply(groups, function(ids) paste(sort(as.integer(ids)), collapse = "|"))
  paste(sort(unlist(groups, use.names = FALSE)), collapse = " ; ")
}

.ctgp_toy_root_groups_match_curve_line <- function(tree, prepped) {
  root_groups <- .ctgp_collect_root_child_groups(tree)
  if (length(root_groups) != 2L) return(FALSE)
  key_tbl <- .ctgp_toy_split_level_key(prepped$combined_key)
  curve_ids <- sort(key_tbl$combined_id[key_tbl$c_1 == "c1.1"])
  line_ids <- sort(key_tbl$combined_id[key_tbl$c_1 == "c1.2"])
  .ctgp_grouping_matches(root_groups, list(curve_ids, line_ids))
}

.ctgp_toy_leaf_groups_separated_curve_line <- function(tree, prepped) {
  groups <- .ctgp_collect_leaf_groups(tree)
  if (length(groups) < 1L) return(FALSE)
  key_tbl <- .ctgp_toy_split_level_key(prepped$combined_key)
  curve_ids <- sort(key_tbl$combined_id[key_tbl$c_1 == "c1.1"])
  line_ids <- sort(key_tbl$combined_id[key_tbl$c_1 == "c1.2"])
  all(vapply(groups, function(ids) {
    ids <- sort(as.integer(ids))
    all(ids %in% curve_ids) || all(ids %in% line_ids)
  }, logical(1)))
}
