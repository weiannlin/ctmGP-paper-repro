
.ctgp_qqgp_example_optimizer_controls <- function(seed, quick = TRUE) {
  if (isTRUE(quick)) {
    list(
      formula_omp = list(
        swarm_size = 48L,
        max_iter = 80L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      ),
      fmat_custom = list(
        swarm_size = 48L,
        max_iter = 80L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      ),
      fixed_t = list(
        swarm_size = 40L,
        max_iter = 60L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      )
    )
  } else {
    list(
      formula_omp = list(
        swarm_size = 64L,
        max_iter = 100L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      ),
      fmat_custom = list(
        swarm_size = 64L,
        max_iter = 100L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      ),
      fixed_t = list(
        swarm_size = 56L,
        max_iter = 80L,
        use_openmp = TRUE,
        num_threads = 4L,
        seed = as.integer(seed)
      )
    )
  }
}

.ctgp_qqgp_example_prediction_controls <- function(num_threads = 4L,
                                                   block_size = 64L,
                                                   use_nugget = FALSE) {
  list(
    use_openmp = TRUE,
    num_threads = as.integer(num_threads),
    block_size = as.integer(block_size),
    use_nugget = isTRUE(use_nugget)
  )
}

.ctgp_qqgp_example_build_level_map <- function(raw_df, coerced_df) {
  tmp <- unique(data.frame(
    material = raw_df$material,
    process = raw_df$process,
    c.T = coerced_df$c.T,
    stringsAsFactors = FALSE
  ))
  tmp[order(tmp$c.T), , drop = FALSE]
}

.ctgp_qqgp_example_metrics <- function(pred, truth) {
  mu <- as.numeric(pred$pred_mean)
  var_vec <- as.numeric(pred$pred_var)
  sd_vec <- sqrt(pmax(var_vec, 0))
  truth <- as.numeric(truth)

  data.frame(
    RMSE = sqrt(mean((mu - truth)^2)),
    MAE = mean(abs(mu - truth)),
    coverage_95 = mean(abs(mu - truth) <= 1.96 * sd_vec),
    max_abs_error = max(abs(mu - truth)),
    stringsAsFactors = FALSE
  )
}

.ctgp_qqgp_example_plot <- function(pred_grid_df, truth_grid_df, train_df, holdout_df, title) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    return(NULL)
  }

  ggplot2::ggplot(pred_grid_df, ggplot2::aes(x = x1, y = mean)) +
    ggplot2::geom_ribbon(
      ggplot2::aes(ymin = lower, ymax = upper),
      fill = "#7AA6DC",
      alpha = 0.22
    ) +
    ggplot2::geom_line(color = "#C0392B", linewidth = 1.0) +
    ggplot2::geom_line(
      data = truth_grid_df,
      ggplot2::aes(x = x1, y = y_true),
      inherit.aes = FALSE,
      color = "grey30",
      linetype = "dashed",
      linewidth = 0.8
    ) +
    ggplot2::geom_point(
      data = train_df,
      ggplot2::aes(x = x1, y = y),
      inherit.aes = FALSE,
      shape = 21,
      size = 2.4,
      stroke = 0.7,
      fill = "white",
      color = "black"
    ) +
    ggplot2::geom_point(
      data = holdout_df,
      ggplot2::aes(x = x1, y = y),
      inherit.aes = FALSE,
      shape = 24,
      size = 2.8,
      stroke = 0.7,
      fill = "#4C78A8",
      color = "#1F3A5F"
    ) +
    ggplot2::facet_grid(material ~ process) +
    ggplot2::labs(
      title = title,
      subtitle = "QQGP prediction by category combination",
      x = "x1",
      y = "y"
    ) +
    ggplot2::theme_minimal(base_size = 13) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold"),
      plot.subtitle = ggplot2::element_text(color = "grey30"),
      panel.grid.minor = ggplot2::element_blank(),
      strip.text = ggplot2::element_text(face = "bold")
    )
}

qqgp_example <- function(seed = 123L,
                         n_train_per_level = 8L,
                         n_holdout_per_level = 4L,
                         n_grid = 121L,
                         quick = TRUE,
                         include_fixed_t = TRUE,
                         show_plot = FALSE) {
  if (n_train_per_level < 4L) stop("`n_train_per_level` must be at least 4.")
  if (n_holdout_per_level < 2L) stop("`n_holdout_per_level` must be at least 2.")
  if (n_grid < 40L) stop("`n_grid` must be at least 40.")

  seed <- as.integer(seed)
  set.seed(seed)

  controls <- .ctgp_qqgp_example_optimizer_controls(seed = seed, quick = quick)

  combos <- expand.grid(
    material = c("M1", "M2"),
    process = c("P1", "P2"),
    stringsAsFactors = FALSE
  )

  response_fun <- function(x, material, process) {
    base <- if (material == "M1") {
      0.6 * sin(2 * pi * x)
    } else {
      0.4 * cos(2 * pi * x)
    }

    proc_shift <- if (process == "P1") 0.2 else -0.2
    slope <- if (material == "M1" && process == "P1") 0.6 else
      if (material == "M1" && process == "P2") 0.3 else
        if (material == "M2" && process == "P1") -0.1 else 0.5

    base + proc_shift + slope * x + 0.15 * x^2
  }

  make_block <- function(x_vec, material, process) {
    data.frame(
      x1 = x_vec,
      material = material,
      process = process,
      y = response_fun(x_vec, material, process),
      stringsAsFactors = FALSE
    )
  }

  # shared x across all category combinations
  x_train <- sort(stats::runif(n_train_per_level, min = 0.05, max = 0.95))
  x_holdout <- sort(stats::runif(n_holdout_per_level, min = 0.02, max = 0.98))
  x_grid <- seq(0, 1, length.out = n_grid)

  raw_train <- do.call(rbind, lapply(seq_len(nrow(combos)), function(i) {
    make_block(x_train, combos$material[i], combos$process[i])
  }))
  raw_holdout <- do.call(rbind, lapply(seq_len(nrow(combos)), function(i) {
    make_block(x_holdout, combos$material[i], combos$process[i])
  }))
  raw_grid <- do.call(rbind, lapply(seq_len(nrow(combos)), function(i) {
    make_block(x_grid, combos$material[i], combos$process[i])
  }))

  # Use coerce_fun on combined data so c.T is consistent across train/holdout/grid
  all_raw <- rbind(raw_train, raw_holdout, raw_grid)
  all_coerced <- coerce_fun(
    data = all_raw,
    design = all_raw[, "x1", drop = FALSE],
    include_sub_cate = TRUE
  )

  n_train_total <- nrow(raw_train)
  n_holdout_total <- nrow(raw_holdout)
  n_grid_total <- nrow(raw_grid)

  idx_train <- seq_len(n_train_total)
  idx_holdout <- n_train_total + seq_len(n_holdout_total)
  idx_grid <- n_train_total + n_holdout_total + seq_len(n_grid_total)

  train_coerced <- all_coerced[idx_train, , drop = FALSE]
  holdout_coerced <- all_coerced[idx_holdout, , drop = FALSE]
  grid_coerced <- all_coerced[idx_grid, , drop = FALSE]

  level_map <- .ctgp_qqgp_example_build_level_map(all_raw, all_coerced)

  design_train <- as.matrix(train_coerced[, "x1", drop = FALSE])
  data_train <- as.matrix(train_coerced[, c("x1", "c.T", "Y"), drop = FALSE])
  new_holdout <- as.matrix(holdout_coerced[, c("x1", "c.T"), drop = FALSE])
  new_grid <- as.matrix(grid_coerced[, c("x1", "c.T"), drop = FALSE])

  storage.mode(design_train) <- "double"
  storage.mode(data_train) <- "double"
  storage.mode(new_holdout) <- "double"
  storage.mode(new_grid) <- "double"

  holdout_truth <- holdout_coerced[, "Y"]
  grid_truth <- data.frame(
    x1 = grid_coerced[, "x1"],
    c.T = grid_coerced[, "c.T"],
    material = raw_grid$material,
    process = raw_grid$process,
    y_true = raw_grid$y,
    stringsAsFactors = FALSE
  )

  # ------------------------------------------------------------------
  # Example 1: default everything (default mean = ~1 + level)
  # ------------------------------------------------------------------
  fit_default <- fit_qqgp(
    design = design_train,
    data = data_train,
    init_param = NULL
  )

  pred_holdout_default <- predict_qqgp(
    fit_default,
    new_holdout
  )

  pred_grid_default <- predict_qqgp(
    fit_default,
    new_grid,
    indep = TRUE
  )

  case_default <- list(
    description = paste(
      "Default QQGP fit using coerce_fun()-generated level indices.",
      "The default mean is ~ 1 + level."
    ),
    fit = fit_default,
    prediction_holdout = pred_holdout_default,
    prediction_grid = pred_grid_default,
    diagnostics = .ctgp_qqgp_example_metrics(pred_holdout_default, holdout_truth)
  )

  # ------------------------------------------------------------------
  # Example 2: OMP + mean_formula with level interaction
  # ------------------------------------------------------------------
  fit_formula_omp <- fit_qqgp(
    design = design_train,
    data = data_train,
    init_param = NULL,
    mean_formula = ~ level * (x1 + I(x1^2)),
    optimizer_control = controls$formula_omp
  )

  pred_holdout_formula_full <- predict_qqgp(
    fit_formula_omp,
    new_holdout,
    indep = FALSE,
    prediction_control = .ctgp_qqgp_example_prediction_controls(
      num_threads = controls$formula_omp$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = FALSE
    )
  )

  pred_grid_formula_fast <- predict_qqgp(
    fit_formula_omp,
    new_grid,
    indep = TRUE,
    prediction_control = .ctgp_qqgp_example_prediction_controls(
      num_threads = controls$formula_omp$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = FALSE
    )
  )

  case_formula_omp <- list(
    description = paste(
      "OMP-enabled QQGP fit using mean_formula = ~ level * (x1 + I(x1^2)).",
      "Prediction demonstrates both full covariance (indep = FALSE)",
      "and faster variance-only output (indep = TRUE)."
    ),
    fit = fit_formula_omp,
    prediction_holdout = pred_holdout_formula_full,
    prediction_grid_fast = pred_grid_formula_fast,
    diagnostics = .ctgp_qqgp_example_metrics(pred_holdout_formula_full, holdout_truth)
  )

  # ------------------------------------------------------------------
  # Example 3: custom f_matrix + explicit prediction f_matrix + seed + theta_range
  # ------------------------------------------------------------------
  level_fac_train <- factor(train_coerced$c.T, levels = fit_formula_omp$level_levels_used)
  level_fac_holdout <- factor(holdout_coerced$c.T, levels = fit_formula_omp$level_levels_used)
  level_fac_grid <- factor(grid_coerced$c.T, levels = fit_formula_omp$level_levels_used)

  train_df_custom <- data.frame(x1 = train_coerced$x1, level = level_fac_train)
  holdout_df_custom <- data.frame(x1 = holdout_coerced$x1, level = level_fac_holdout)
  grid_df_custom <- data.frame(x1 = grid_coerced$x1, level = level_fac_grid)

  F_train_custom <- stats::model.matrix(~ level * (x1 + I(x1^2)), data = train_df_custom)
  F_holdout_custom <- stats::model.matrix(~ level * (x1 + I(x1^2)), data = holdout_df_custom)
  F_grid_custom <- stats::model.matrix(~ level * (x1 + I(x1^2)), data = grid_df_custom)

  fit_fmat_custom <- fit_qqgp(
    design = design_train,
    data = data_train,
    init_param = NULL,
    f_matrix = F_train_custom,
    theta_range = c(1e-6, pi - 1e-6),
    optimizer_control = controls$fmat_custom
  )

  pred_holdout_fmat <- predict_qqgp(
    fit_fmat_custom,
    new_holdout,
    f_matrix = F_holdout_custom,
    indep = FALSE,
    prediction_control = .ctgp_qqgp_example_prediction_controls(
      num_threads = controls$fmat_custom$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = FALSE
    )
  )

  pred_grid_fmat_nugget <- predict_qqgp(
    fit_fmat_custom,
    new_grid,
    f_matrix = F_grid_custom,
    indep = TRUE,
    prediction_control = .ctgp_qqgp_example_prediction_controls(
      num_threads = controls$fmat_custom$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L,
      use_nugget = TRUE
    )
  )

  case_fmat_custom <- list(
    description = paste(
      "Custom f_matrix QQGP fit using an explicit model.matrix build.",
      "This case demonstrates seed, theta_range, explicit prediction f_matrix,",
      "and prediction with use_nugget = TRUE."
    ),
    fit = fit_fmat_custom,
    prediction_holdout = pred_holdout_fmat,
    prediction_grid_nugget = pred_grid_fmat_nugget,
    diagnostics = .ctgp_qqgp_example_metrics(pred_holdout_fmat, holdout_truth),
    equivalence_with_formula = list(
      same_train_f_matrix = isTRUE(all.equal(
        unname(fit_formula_omp$f_matrix),
        unname(fit_fmat_custom$f_matrix)
      )),
      max_abs_diff_fi = max(abs(as.numeric(fit_formula_omp$fi) - as.numeric(fit_fmat_custom$fi))),
      max_abs_diff_theta = max(abs(as.numeric(fit_formula_omp$theta) - as.numeric(fit_fmat_custom$theta))),
      max_abs_diff_beta = max(abs(as.numeric(fit_formula_omp$beta_vec) - as.numeric(fit_fmat_custom$beta_vec))),
      max_abs_diff_pred_mean = max(abs(
        as.numeric(pred_holdout_formula_full$pred_mean) -
          as.numeric(pred_holdout_fmat$pred_mean)
      )),
      max_abs_diff_pred_var = max(abs(
        as.numeric(pred_holdout_formula_full$pred_var) -
          as.numeric(pred_holdout_fmat$pred_var)
      ))
    )
  )

  # ------------------------------------------------------------------
  # Example 4: fixed T matrix
  # ------------------------------------------------------------------
  case_fixed_t <- NULL
  if (isTRUE(include_fixed_t)) {
    T_fixed <- matrix(
      c(1.0, 0.30, 0.15, 0.10,
        0.30, 1.0, 0.20, 0.15,
        0.15, 0.20, 1.0, 0.35,
        0.10, 0.15, 0.35, 1.0),
      nrow = 4, byrow = TRUE
    )

    fit_fixed_t <- fit_qqgp(
      design = design_train,
      data = data_train,
      init_param = NULL,
      t_matrix = T_fixed,
      optimizer_control = controls$fixed_t
    )

    pred_holdout_fixed_t <- predict_qqgp(
      fit_fixed_t,
      new_holdout,
      indep = FALSE,
      prediction_control = .ctgp_qqgp_example_prediction_controls(
        num_threads = controls$fixed_t$num_threads,
        block_size = if (isTRUE(quick)) 32L else 64L,
        use_nugget = FALSE
      )
    )

    case_fixed_t <- list(
      description = paste(
        "QQGP fit with a user-supplied fixed t_matrix.",
        "This demonstrates bypassing theta optimisation."
      ),
      fit = fit_fixed_t,
      prediction_holdout = pred_holdout_fixed_t,
      diagnostics = .ctgp_qqgp_example_metrics(pred_holdout_fixed_t, holdout_truth),
      t_matrix_fixed = T_fixed
    )
  }


  # ------------------------------------------------------------------
  # Example 5: QQGP regression with estimated nugget
  # ------------------------------------------------------------------
  y_train_reg <- raw_train$y + stats::rnorm(nrow(raw_train), sd = 0.05)
  y_holdout_reg <- raw_holdout$y + stats::rnorm(nrow(raw_holdout), sd = 0.05)

  data_train_reg <- cbind(train_coerced[, 'x1', drop = FALSE], c.T = train_coerced$c.T, y = y_train_reg)
  data_holdout_reg <- cbind(holdout_coerced[, 'x1', drop = FALSE], c.T = holdout_coerced$c.T, y = y_holdout_reg)
  storage.mode(data_train_reg) <- 'double'
  storage.mode(data_holdout_reg) <- 'double'

  fit_regression <- fit_qqgp_regression(
    design = design_train,
    data = data_train_reg,
    init_param = NULL,
    mean_formula = ~ level * (x1 + I(x1^2)),
    nugget_range = c(1e-6, 0.5),
    optimizer_control = controls$formula_omp
  )

  pred_holdout_reg <- predict_qqgp(
    fit_regression,
    new_holdout,
    indep = FALSE,
    prediction_control = list(
      use_openmp = TRUE,
      num_threads = controls$formula_omp$num_threads,
      block_size = if (isTRUE(quick)) 32L else 64L
    )
  )

  case_regression <- list(
    description = paste(
      'QQGP regression fit with homogeneous estimated nugget.',
      'Prediction uses the same high-level predict_qqgp() dispatch as deterministic QQGP.'
    ),
    fit = fit_regression,
    prediction_holdout = pred_holdout_reg,
    diagnostics = .ctgp_qqgp_example_metrics(pred_holdout_reg, y_holdout_reg)
  )

  summary_table <- data.frame(
    example = c("default", "formula_omp", "custom_fmat", if (isTRUE(include_fixed_t)) "fixed_t", "regression"),
    fit_time = c(
      fit_default$timing$elapsed,
      fit_formula_omp$timing$elapsed,
      fit_fmat_custom$timing$elapsed,
      if (isTRUE(include_fixed_t)) case_fixed_t$fit$timing$elapsed,
      fit_regression$timing$elapsed
    ),
    holdout_pred_time = c(
      pred_holdout_default$timing$elapsed,
      pred_holdout_formula_full$timing$elapsed,
      pred_holdout_fmat$timing$elapsed,
      if (isTRUE(include_fixed_t)) case_fixed_t$prediction_holdout$timing$elapsed,
      pred_holdout_reg$timing$elapsed
    ),
    RMSE = c(
      case_default$diagnostics$RMSE,
      case_formula_omp$diagnostics$RMSE,
      case_fmat_custom$diagnostics$RMSE,
      if (isTRUE(include_fixed_t)) case_fixed_t$diagnostics$RMSE,
      case_regression$diagnostics$RMSE
    ),
    MAE = c(
      case_default$diagnostics$MAE,
      case_formula_omp$diagnostics$MAE,
      case_fmat_custom$diagnostics$MAE,
      if (isTRUE(include_fixed_t)) case_fixed_t$diagnostics$MAE,
      case_regression$diagnostics$MAE
    ),
    stringsAsFactors = FALSE
  )

  plot_list <- list()
  if (requireNamespace("ggplot2", quietly = TRUE)) {
    pred_grid_formula_df <- data.frame(
      x1 = grid_coerced$x1,
      c.T = grid_coerced$c.T,
      material = raw_grid$material,
      process = raw_grid$process,
      mean = as.numeric(pred_grid_formula_fast$pred_mean),
      sd = sqrt(pmax(pred_grid_formula_fast$pred_var, 0)),
      stringsAsFactors = FALSE
    )
    pred_grid_formula_df$lower <- pred_grid_formula_df$mean - 1.96 * pred_grid_formula_df$sd
    pred_grid_formula_df$upper <- pred_grid_formula_df$mean + 1.96 * pred_grid_formula_df$sd

    train_plot_df <- data.frame(
      x1 = train_coerced$x1,
      material = raw_train$material,
      process = raw_train$process,
      y = train_coerced$Y,
      stringsAsFactors = FALSE
    )
    holdout_plot_df <- data.frame(
      x1 = holdout_coerced$x1,
      material = raw_holdout$material,
      process = raw_holdout$process,
      y = holdout_coerced$Y,
      stringsAsFactors = FALSE
    )

    plot_list$formula_omp <- .ctgp_qqgp_example_plot(
      pred_grid_df = pred_grid_formula_df,
      truth_grid_df = grid_truth,
      train_df = train_plot_df,
      holdout_df = holdout_plot_df,
      title = "QQGP example: mean_formula = ~ level * (x1 + I(x1^2))"
    )

    pred_grid_fmat_df <- data.frame(
      x1 = grid_coerced$x1,
      c.T = grid_coerced$c.T,
      material = raw_grid$material,
      process = raw_grid$process,
      mean = as.numeric(pred_grid_fmat_nugget$pred_mean),
      sd = sqrt(pmax(pred_grid_fmat_nugget$pred_var, 0)),
      stringsAsFactors = FALSE
    )
    pred_grid_fmat_df$lower <- pred_grid_fmat_df$mean - 1.96 * pred_grid_fmat_df$sd
    pred_grid_fmat_df$upper <- pred_grid_fmat_df$mean + 1.96 * pred_grid_fmat_df$sd

    plot_list$custom_fmat <- .ctgp_qqgp_example_plot(
      pred_grid_df = pred_grid_fmat_df,
      truth_grid_df = grid_truth,
      train_df = train_plot_df,
      holdout_df = holdout_plot_df,
      title = "QQGP example: custom f_matrix with explicit prediction f_matrix"
    )

    if (isTRUE(show_plot)) {
      print(plot_list$formula_omp)
      print(plot_list$custom_fmat)
    }
  }

  cases <- list(
    default = case_default,
    formula_omp = case_formula_omp,
    custom_fmat = case_fmat_custom
  )
  if (isTRUE(include_fixed_t)) {
    cases$fixed_t <- case_fixed_t
  }
  cases$regression <- case_regression

  out <- list(
    seed = seed,
    response_fun = response_fun,
    raw_data = list(
      train = raw_train,
      holdout = raw_holdout,
      grid = raw_grid
    ),
    coerce = list(
      all = all_coerced,
      train = train_coerced,
      holdout = holdout_coerced,
      grid = grid_coerced,
      level_map = level_map,
      continuous_columns = attr(all_coerced, "continuous_columns"),
      categorical_columns = attr(all_coerced, "categorical_columns"),
      response_column = attr(all_coerced, "response_column"),
      level_key = attr(all_coerced, "level_key")
    ),
    controls = controls,
    cases = cases,
    summary = summary_table,
    plots = plot_list
  )

  class(out) <- c("qqgp_example_result", class(out))
  out
}
