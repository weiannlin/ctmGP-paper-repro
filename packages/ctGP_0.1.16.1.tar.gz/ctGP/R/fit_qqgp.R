if (!exists('.ctgp_resolve_optimizer_control', mode = 'function')) {
  .ctgp_resolve_optimizer_control <- function(optimizer_control) {
    defaults <- list(
      swarm_size = 64L,
      max_iter = 200L,
      c1 = 2.05,
      c2 = 2.05,
      w = 0.7,
      tol = 1e-6,
      use_openmp = TRUE,
      num_threads = 0L,
      seed = NULL
    )

    if (is.null(optimizer_control)) {
      optimizer_control <- list()
    }

    if (!is.list(optimizer_control)) {
      stop('optimizer_control must be a list.')
    }

    unknown <- setdiff(names(optimizer_control), names(defaults))
    if (length(unknown) > 0L) {
      stop(
        'Unknown entries in optimizer_control: ',
        paste(unknown, collapse = ', '),
        '.'
      )
    }

    control <- defaults
    if (length(optimizer_control) > 0L) {
      control[names(optimizer_control)] <- optimizer_control
    }

    control$swarm_size <- as.integer(control$swarm_size)
    control$max_iter <- as.integer(control$max_iter)
    control$c1 <- as.numeric(control$c1)
    control$c2 <- as.numeric(control$c2)
    control$w <- as.numeric(control$w)
    control$tol <- as.numeric(control$tol)
    control$use_openmp <- isTRUE(control$use_openmp)
    control$num_threads <- as.integer(control$num_threads)
    if (!is.null(control$seed)) {
      control$seed <- as.integer(control$seed)
    }

    if (length(control$swarm_size) != 1L || is.na(control$swarm_size) || control$swarm_size < 1L) {
      stop('optimizer_control$swarm_size must be a positive integer scalar.')
    }
    if (length(control$max_iter) != 1L || is.na(control$max_iter) || control$max_iter < 1L) {
      stop('optimizer_control$max_iter must be a positive integer scalar.')
    }
    if (length(control$c1) != 1L || !is.finite(control$c1)) {
      stop('optimizer_control$c1 must be a finite numeric scalar.')
    }
    if (length(control$c2) != 1L || !is.finite(control$c2)) {
      stop('optimizer_control$c2 must be a finite numeric scalar.')
    }
    if (length(control$w) != 1L || !is.finite(control$w)) {
      stop('optimizer_control$w must be a finite numeric scalar.')
    }
    if (length(control$tol) != 1L || !is.finite(control$tol) || control$tol < 0) {
      stop('optimizer_control$tol must be a finite nonnegative numeric scalar.')
    }
    if (length(control$num_threads) != 1L || is.na(control$num_threads)) {
      stop('optimizer_control$num_threads must be an integer scalar.')
    }
    if (!is.null(control$seed)) {
      if (length(control$seed) != 1L || is.na(control$seed)) {
        stop('optimizer_control$seed must be NULL or an integer scalar.')
      }
    }

    control
  }
}

if (!exists('.ctgp_collect_omp_info', mode = 'function')) {
  .ctgp_collect_omp_info <- function(control) {
    compiled <- FALSE
    runtime_max <- NA_integer_

    compiled <- tryCatch(
      isTRUE(ctgp_openmp_enabled_cpp()),
      error = function(e) FALSE
    )

    runtime_max <- tryCatch(
      as.integer(ctgp_openmp_max_threads_cpp()),
      error = function(e) NA_integer_
    )

    list(
      compiled = compiled,
      use_openmp = control$use_openmp,
      num_threads_requested = control$num_threads,
      num_threads_runtime_max = runtime_max
    )
  }
}

.ctgp_default_fi_bounds_qqgp <- function(design) {
  design <- as.matrix(design)
  n <- nrow(design)
  d <- ncol(design)

  max_sum_sqdiff <- 0
  if (n >= 2L) {
    for (i in 1:(n - 1L)) {
      diffs <- sweep(design[(i + 1L):n, , drop = FALSE], 2L, design[i, ], '-')
      ss <- rowSums(diffs^2)
      local_max <- max(ss)
      if (is.finite(local_max) && local_max > max_sum_sqdiff) {
        max_sum_sqdiff <- local_max
      }
    }
  }

  if (!is.finite(max_sum_sqdiff) || max_sum_sqdiff <= 0) {
    max_sum_sqdiff <- 1
  }

  corr <- .ctgp_default_corr_bounds()
  lower <- rep(log10(-log(corr[2L]) / max_sum_sqdiff), d)
  upper <- rep(log10(-log(corr[1L]) / max_sum_sqdiff), d)

  list(lower = lower, upper = upper)
}


.ctgp_qqgp_cont_names <- function(design, data) {
  d <- ncol(design)

  nm <- colnames(design)
  if (is.null(nm) || length(nm) != d) {
    if (!is.null(colnames(data)) && length(colnames(data)) >= d) {
      nm <- colnames(data)[seq_len(d)]
    }
  }

  if (is.null(nm) || any(is.na(nm)) || any(nm == '')) {
    nm <- paste0('x', seq_len(d))
  }

  nm <- make.names(nm, unique = TRUE)
  if ('level' %in% nm) {
    stop(
      "A continuous variable is named 'level'. Please rename that input column before using mean_formula in fit_qqgp(), because 'level' is reserved for the categorical factor."
    )
  }

  nm
}

.ctgp_formula_rhs <- function(formula_like) {
  if (is.character(formula_like)) {
    formula_like <- stats::as.formula(formula_like)
  }
  if (!inherits(formula_like, 'formula')) {
    stop('mean_formula must be NULL, a formula, or a character string that can be converted to a formula.')
  }

  trm <- stats::delete.response(stats::terms(formula_like))
  stats::formula(trm)
}

.ctgp_formula_text <- function(formula_obj) {
  paste(deparse(formula_obj), collapse = '')
}

.ctgp_validate_user_f_matrix <- function(f_matrix, n) {
  f_matrix <- as.matrix(f_matrix)
  storage.mode(f_matrix) <- 'double'

  if (nrow(f_matrix) != n) {
    stop('f_matrix must have the same number of rows as data.')
  }
  if (ncol(f_matrix) < 1L) {
    stop('f_matrix must have at least one column.')
  }
  if (any(!is.finite(f_matrix))) {
    stop('f_matrix must contain only finite values.')
  }

  qrF <- qr(f_matrix)
  if (qrF$rank < ncol(f_matrix)) {
    stop('f_matrix is rank-deficient. Please remove linearly dependent columns.')
  }

  cn <- colnames(f_matrix)
  if (is.null(cn) || any(is.na(cn)) || any(cn == '')) {
    cn <- paste0('f', seq_len(ncol(f_matrix)))
  }
  colnames(f_matrix) <- make.names(cn, unique = TRUE)

  f_matrix
}

.ctgp_build_qqgp_f_matrix <- function(design, data, f_matrix = NULL, mean_formula = NULL) {
  n <- nrow(data)
  d <- ncol(design)
  cont_names <- .ctgp_qqgp_cont_names(design, data)
  level_levels_used <- levels(factor(data[, d + 1L]))

  if (!is.null(f_matrix) && !is.null(mean_formula)) {
    stop('Please provide at most one of f_matrix or mean_formula.')
  }

  if (!is.null(f_matrix)) {
    f_matrix_use <- .ctgp_validate_user_f_matrix(f_matrix, n)
    return(list(
      f_matrix = f_matrix_use,
      mean_source = 'f_matrix',
      mean_structure = sprintf('custom f_matrix (%d terms)', ncol(f_matrix_use)),
      mean_formula = NULL,
      mean_terms = colnames(f_matrix_use),
      x_colnames_used = cont_names,
      level_levels_used = level_levels_used
    ))
  }

  mean_data <- as.data.frame(design, stringsAsFactors = FALSE)
  names(mean_data) <- cont_names
  mean_data$level <- factor(data[, d + 1L])

  if (is.null(mean_formula)) {
    rhs_formula <- stats::as.formula('~ 1 + level')
  } else {
    rhs_formula <- .ctgp_formula_rhs(mean_formula)
  }

  f_matrix_use <- stats::model.matrix(rhs_formula, data = mean_data)
  storage.mode(f_matrix_use) <- 'double'

  qrF <- qr(f_matrix_use)
  if (qrF$rank < ncol(f_matrix_use)) {
    stop('mean_formula produced a rank-deficient f_matrix. Please revise the formula.')
  }

  formula_text <- .ctgp_formula_text(rhs_formula)
  default_formula <- identical(gsub('\\s+', '', formula_text), '~1+level')

  list(
    f_matrix = f_matrix_use,
    mean_source = if (default_formula) 'default' else 'formula',
    mean_structure = paste0('formula: ', formula_text),
    mean_formula = formula_text,
    mean_terms = colnames(f_matrix_use),
    x_colnames_used = cont_names,
    level_levels_used = level_levels_used
  )
}

fit_qqgp <- function(design,
                     data,
                     init_param = NULL,
                     fi_range = NULL,
                     theta_range = NULL,
                     t_matrix = NULL,
                     nugget = NULL,
                     f_matrix = NULL,
                     mean_formula = NULL,
                     normalization = "none",
                     normalize_response = FALSE,
                     optimizer_control = list()) {
  design <- as.matrix(design)
  data <- as.matrix(data)

  storage.mode(design) <- 'double'
  storage.mode(data) <- 'double'

  if (ncol(data) < 3L) {
    stop('data must contain continuous columns, one categorical level column, and one response column.')
  }

  if (ncol(data) != ncol(design) + 2L) {
    stop('For QQGP, data must have continuous columns plus one categorical level column plus one response column.')
  }

  d <- ncol(design)
  normalization <- .ctgp_resolve_normalization_method(normalization)

  input_normalizer <- NULL
  response_normalizer <- NULL
  design_fit <- design
  data_fit <- data
  if (!identical(normalization, "none")) {
    x_norm <- .ctgp_normalize_training_matrix(design, normalization = normalization)
    design_fit <- as.matrix(x_norm$x)
    input_normalizer <- x_norm$normalizer
    data_fit[, seq_len(d)] <- design_fit
  }
  if (isTRUE(normalize_response) && !identical(normalization, "none")) {
    y_norm <- .ctgp_normalize_response_vector(data_fit[, ncol(data_fit)], normalization = normalization)
    data_fit[, ncol(data_fit)] <- y_norm$y
    response_normalizer <- y_norm$normalizer
  }

  if (!is.null(init_param)) {
    init_param <- as.numeric(init_param)
    if (length(init_param) != d) {
      stop('init_param must have length equal to the number of continuous variables in design.')
    }
  }

  fi_range_requested <- fi_range
  if (!is.null(fi_range)) {
    fi_range <- .ctgp_expand_fi_range(fi_range, d = d, arg_name = 'fi_range')
  }

  control <- .ctgp_resolve_optimizer_control(optimizer_control)
  kernel_mode <- .ctgp_resolve_pso_kernel_mode()

  theta_range_requested <- theta_range
  theta_range_sanitized <- FALSE
  if (!is.null(theta_range)) {
    theta_range <- .ctgp_prepare_theta_range_current(theta_range, arg_name = 'theta_range')
    theta_range_sanitized <- isTRUE(attr(theta_range, 'sanitized'))
  }

  if (!is.null(t_matrix)) {
    t_matrix <- as.matrix(t_matrix)
    storage.mode(t_matrix) <- 'double'
    if (nrow(t_matrix) != ncol(t_matrix)) {
      stop('t_matrix must be square.')
    }
  }

  if (!is.null(nugget)) {
    if (length(nugget) != 1L || !is.numeric(nugget) || !is.finite(nugget)) {
      stop('nugget must be NULL or a finite numeric scalar.')
    }
    if (nugget < 0) {
      stop('nugget must be nonnegative.')
    }
    nugget <- as.numeric(nugget)
  }

  mean_info <- .ctgp_build_qqgp_f_matrix(
    design = design_fit,
    data = data_fit,
    f_matrix = f_matrix,
    mean_formula = mean_formula
  )

  if (is.null(init_param)) {
    if (!is.null(fi_range)) {
      lower <- fi_range[seq_len(d)]
      upper <- fi_range[d + seq_len(d)]
    } else {
      bds <- .ctgp_default_fi_bounds_qqgp(design_fit)
      lower <- bds$lower
      upper <- bds$upper
    }
    init_param <- 0.2 * lower + 0.8 * upper
  }

  objective_mode <- .ctgp_resolve_qqgp_objective_mode()
  finalize_mode <- .ctgp_resolve_qqgp_finalize_mode(objective_mode)
  fixed_t_input <- !is.null(t_matrix)
  t_matrix_input_dim <- if (is.null(t_matrix)) c(0L, 0L) else as.integer(dim(t_matrix))

  t_start <- proc.time()

  seed_cpp <- if (is.null(control$seed)) -1L else control$seed
  if (identical(kernel_mode, 'globpso_exact') && !is.null(control$seed)) {
    set.seed(control$seed)
    seed_cpp <- -1L
  }

  fit <- fit_qqgp_cpp(
    design = design_fit,
    data = data_fit,
    init_param = init_param,
    fi_range = fi_range,
    theta_range = theta_range,
    t_matrix = t_matrix,
    f_matrix = mean_info$f_matrix,
    nugget = nugget,
    swarm_size = control$swarm_size,
    max_iter = control$max_iter,
    c1 = control$c1,
    c2 = control$c2,
    w = control$w,
    tol = control$tol,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    seed = seed_cpp,
    objective_mode = if (identical(objective_mode, 'legacy_exact')) 1L else 0L,
    finalize_mode = if (identical(finalize_mode, 'match_search')) 1L else 0L
  )

  elapsed <- proc.time() - t_start

  fit$f_matrix <- mean_info$f_matrix
  fit$mean_source <- mean_info$mean_source
  fit$mean_structure <- mean_info$mean_structure
  fit$mean_formula <- mean_info$mean_formula
  fit$mean_terms <- mean_info$mean_terms
  fit$x_colnames_used <- mean_info$x_colnames_used
  fit$level_levels_used <- mean_info$level_levels_used

  if (!is.null(fit$f_matrix)) {
    fit$f_matrix <- as.matrix(fit$f_matrix)
    colnames(fit$f_matrix) <- mean_info$mean_terms
  }

  if (!is.null(fit$beta_vec)) {
    fit$beta_vec <- as.matrix(fit$beta_vec)
    rownames(fit$beta_vec) <- mean_info$mean_terms
  }

  fit$timing <- list(
    wall_sec  = unname(elapsed['elapsed']),
    cpu_sec   = unname(elapsed['user.self'] + elapsed['sys.self']),
    user_sec  = unname(elapsed['user.self']),
    sys_sec   = unname(elapsed['sys.self']),
    elapsed   = unname(elapsed['elapsed']),
    user_self = unname(elapsed['user.self']),
    sys_self  = unname(elapsed['sys.self'])
  )
  fit$optimizer_control <- control
  fit$optimizer_mode <- kernel_mode
  fit$objective_mode <- objective_mode
  fit$search_objective_mode <- objective_mode
  fit$finalize_objective_mode <- if (identical(finalize_mode, 'match_search')) objective_mode else 'stable'
  fit$qqgp_finalize_mode <- finalize_mode
  fit$omp <- .ctgp_collect_omp_info(control)
  fit$fi_range_requested <- fi_range_requested
  fit$fi_range_used <- if (!is.null(fit$lower) && !is.null(fit$upper)) c(as.numeric(fit$lower[seq_len(d)]), as.numeric(fit$upper[seq_len(d)])) else fi_range
  fit$theta_range_requested <- theta_range_requested
  fit$theta_range_used <- theta_range
  fit$theta_range_sanitized <- isTRUE(theta_range_sanitized)
  fit$fixed_t <- isTRUE(fixed_t_input)
  fit$t_matrix_input_dim <- t_matrix_input_dim
  fit$seed_requested <- control$seed
  fit$seed_cpp_used <- seed_cpp
  fit$r_seed_set_before_cpp <- identical(kernel_mode, 'globpso_exact') && !is.null(control$seed)
  fit$normalization <- normalization
  fit$normalize_response <- isTRUE(normalize_response)
  fit$input_normalizer <- input_normalizer
  fit$response_normalizer <- response_normalizer
  fit$training_data_original <- data

  class(fit) <- c('qqgp_fit', class(fit))
  fit$diagnostics <- ctgp_diagnostics(fit)
  fit
}
