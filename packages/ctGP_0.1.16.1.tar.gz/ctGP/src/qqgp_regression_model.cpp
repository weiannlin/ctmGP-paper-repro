#include "qqgp_regression_model.h"
#include <cmath>
#include <limits>
#include <algorithm>

namespace {

static qqgp_regression_profile_result qqgpreg_profile_fit_core(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::mat& t_matrix,
    const arma::vec& fi,
    double nugget,
    const arma::mat& f_matrix
) {
  qqgp_regression_profile_result out;

  if (!(std::isfinite(nugget) && nugget > 0.0)) {
    return out;
  }

  int n = static_cast<int>(design.n_rows);
  if ((int)f_matrix.n_rows != n || f_matrix.n_cols < 1) {
    return out;
  }

  arma::mat h_matrix = qqgp_build_h_matrix(design, fi);
  arma::mat r_matrix = qqgp_build_r_matrix(h_matrix, t_matrix, level_index);
  arma::mat R_work = r_matrix;
  R_work.diag() += nugget;

  double stabilization_jitter = 0.0;
  double rc = arma::rcond(R_work);
  bool bad_rcond = (!std::isfinite(rc) || rc <= 1e-10);

  arma::mat L;
  bool chol_ok = false;
  if (!bad_rcond) {
    chol_ok = arma::chol(L, R_work, "lower");
  }
  if (!chol_ok) {
    stabilization_jitter = compute_nugget_from_eigen(R_work, 1e12);
    if (!(std::isfinite(stabilization_jitter) && stabilization_jitter > 0.0)) {
      return out;
    }
    R_work.diag() += stabilization_jitter;
    chol_ok = arma::chol(L, R_work, "lower");
    if (!chol_ok) {
      return out;
    }
  }

  arma::mat r_inv_f = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), f_matrix)
  );

  arma::vec r_invy = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), y)
  );

  arma::mat ft_r_inv_f = f_matrix.t() * r_inv_f;
  ft_r_inv_f = 0.5 * (ft_r_inv_f + ft_r_inv_f.t());

  arma::vec rhs = f_matrix.t() * r_invy;
  arma::vec beta_vec;
  bool beta_ok = arma::solve(beta_vec, ft_r_inv_f, rhs, arma::solve_opts::fast + arma::solve_opts::likely_sympd);
  if (!beta_ok) {
    beta_ok = arma::solve(beta_vec, ft_r_inv_f, rhs);
  }
  if (!beta_ok || !beta_vec.is_finite()) {
    return out;
  }

  arma::vec resid = y - f_matrix * beta_vec;
  arma::vec alpha_vec = arma::solve(
    arma::trimatu(L.t()),
    arma::solve(arma::trimatl(L), resid)
  );

  double sigma_sq = arma::dot(resid, alpha_vec) / static_cast<double>(n);
  if (!std::isfinite(sigma_sq) || sigma_sq <= 0.0) {
    return out;
  }

  double logdet_r = 2.0 * arma::sum(arma::log(L.diag()));
  double neg_log_lik = static_cast<double>(n) * std::log(sigma_sq) + logdet_r;

  out.h_matrix = h_matrix;
  out.t_matrix = t_matrix;
  out.r_matrix = R_work;
  out.l_matrix = L;
  out.alpha_vec = alpha_vec;
  out.f_matrix = f_matrix;
  out.beta_vec = beta_vec;
  out.sigma_sq = sigma_sq;
  out.nugget = nugget;
  out.log10_nugget = std::log10(nugget);
  out.stabilization_jitter = stabilization_jitter;
  out.effective_nugget = nugget + stabilization_jitter;
  out.neg_log_lik = neg_log_lik;
  out.success = true;

  return out;
}

} // anonymous namespace

Rcpp::List qqgpreg_default_nugget_spec(const arma::vec& y) {
  double y_var = arma::var(y);
  if (!std::isfinite(y_var) || y_var <= 0.0) {
    y_var = 1.0;
  }

  double lower = std::max(1e-8 * y_var, 1e-12);
  double upper = std::max(y_var, lower * 1e4);
  double init = std::sqrt(lower * upper);

  return Rcpp::List::create(
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper,
    Rcpp::Named("init") = init
  );
}

qqgp_regression_profile_result qqgpreg_profile_fit(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::vec& theta,
    double nugget,
    const arma::mat& f_matrix
) {
  int level_num = arma::max(level_index);
  arma::mat t_matrix = qqgp_build_t_matrix(theta, level_num);
  return qqgpreg_profile_fit_core(design, level_index, y, t_matrix, fi, nugget, f_matrix);
}

qqgp_regression_profile_result qqgpreg_profile_fit_fixed_t(
    const arma::mat& design,
    const arma::uvec& level_index,
    const arma::vec& y,
    const arma::vec& fi,
    const arma::mat& t_matrix,
    double nugget,
    const arma::mat& f_matrix
) {
  return qqgpreg_profile_fit_core(design, level_index, y, t_matrix, fi, nugget, f_matrix);
}

double qqgp_regression_likelihood_objective::eval(const arma::vec& par) {
  int d = static_cast<int>(design_.n_cols);
  int theta_dim = level_num_ * (level_num_ - 1) / 2;

  if (!fixed_t_) {
    if ((int)par.n_elem != d + theta_dim + 1) {
      return arma::datum::inf;
    }
    arma::vec fi = par.subvec(0, d - 1);
    arma::vec theta(theta_dim, arma::fill::zeros);
    if (theta_dim > 0) {
      theta = par.subvec(d, d + theta_dim - 1);
    }
    double nugget = std::pow(10.0, par(d + theta_dim));
    if (!(std::isfinite(nugget) && nugget > 0.0)) {
      return arma::datum::inf;
    }
    qqgp_regression_profile_result fit = qqgpreg_profile_fit(design_, level_index_, y_, fi, theta, nugget, f_matrix_);
    if (!fit.success || !std::isfinite(fit.neg_log_lik)) {
      return arma::datum::inf;
    }
    return fit.neg_log_lik;
  }

  if ((int)par.n_elem != d + 1) {
    return arma::datum::inf;
  }
  arma::vec fi = par.subvec(0, d - 1);
  double nugget = std::pow(10.0, par(d));
  if (!(std::isfinite(nugget) && nugget > 0.0)) {
    return arma::datum::inf;
  }
  qqgp_regression_profile_result fit = qqgpreg_profile_fit_fixed_t(design_, level_index_, y_, fi, fixed_t_matrix_, nugget, f_matrix_);
  if (!fit.success || !std::isfinite(fit.neg_log_lik)) {
    return arma::datum::inf;
  }
  return fit.neg_log_lik;
}
