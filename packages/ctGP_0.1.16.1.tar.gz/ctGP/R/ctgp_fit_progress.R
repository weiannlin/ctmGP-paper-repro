.ctgp_fit_progress_null <- function(x, y) {
  if (is.null(x) || length(x) == 0L) return(y)
  if (length(x) == 1L && is.na(x)) return(y)
  x
}

.ctgp_fit_progress_fmt_seconds <- function(x) {
  if (is.null(x) || length(x) < 1L || !is.finite(as.numeric(x[[1L]]))) return("NA")
  x <- max(0, as.numeric(x[[1L]]))
  h <- floor(x / 3600)
  m <- floor((x - 3600 * h) / 60)
  s <- floor(x - 3600 * h - 60 * m)
  if (h > 0L) {
    sprintf("%02dh:%02dm:%02ds", h, m, s)
  } else {
    sprintf("%02dm:%02ds", m, s)
  }
}

.ctgp_fit_progress_is_rstudio_console <- function() {
  nzchar(Sys.getenv("RSTUDIO")) ||
    nzchar(Sys.getenv("RSTUDIO_SESSION_PORT")) ||
    identical(Sys.getenv("TERM_PROGRAM"), "RStudio")
}

.ctgp_fit_progress_detect_mode <- function(mode = c("auto", "bar", "plain", "none")) {
  mode <- match.arg(mode)
  if (!identical(mode, "auto")) return(mode)
  opt_mode <- getOption("ctgp.fit.progress.mode", getOption("ctgp.progress.mode", NULL))
  if (!is.null(opt_mode) && is.character(opt_mode) && nzchar(opt_mode[[1L]])) {
    return(match.arg(opt_mode[[1L]], choices = c("bar", "plain", "none")))
  }
  if (!interactive()) return("plain")
  if (sink.number(type = "output") > 0L) return("plain")
  "bar"
}

.ctgp_fit_progress_make_bar <- function(done, total, width = 32L) {
  total <- max(1, as.numeric(total))
  width <- max(12L, as.integer(width))
  frac <- min(1, max(0, as.numeric(done) / total))
  filled <- as.integer(floor(width * frac))
  if (frac > 0 && filled < width) filled <- max(1L, filled)
  paste0(
    "[",
    paste0(c(rep("=", filled), rep("-", width - filled)), collapse = ""),
    "]"
  )
}

.ctgp_fit_progress_new <- function(total_steps,
                                    enabled = TRUE,
                                    mode = c("auto", "bar", "plain", "none"),
                                    title = "fit_ctgp",
                                    bar_width = getOption("ctgp.fit.progress.width", 32L)) {
  env <- new.env(parent = emptyenv())
  env$enabled <- isTRUE(enabled)
  env$total_steps <- max(1L, as.integer(total_steps))
  env$title <- as.character(.ctgp_fit_progress_null(title, "fit_ctgp"))
  env$started_at <- Sys.time()
  env$mode <- if (!env$enabled) "none" else .ctgp_fit_progress_detect_mode(match.arg(mode))
  env$bar_width <- max(12L, as.integer(bar_width))
  env$last_width <- 0L
  env$last_done_units <- 0
  env$last_line <- NULL
  env
}

.ctgp_fit_progress_render_bar <- function(progress_env, line) {
  pad <- max(0L, as.integer(progress_env$last_width) - nchar(line, type = "width"))
  cat("\r", line, paste(rep(" ", pad), collapse = ""), sep = "")
  flush.console()
  progress_env$last_width <- nchar(line, type = "width")
  progress_env$last_line <- line
  invisible(progress_env)
}

.ctgp_fit_progress_render_plain <- function(progress_env, line) {
  cat(line, "\n", sep = "")
  flush.console()
  progress_env$last_line <- line
  invisible(progress_env)
}

.ctgp_fit_progress_set <- function(progress_env,
                                   done_units,
                                   step_index = NA_integer_,
                                   step_label = NULL,
                                   detail = NULL) {
  if (is.null(progress_env) || !isTRUE(progress_env$enabled) || identical(progress_env$mode, "none")) {
    return(invisible(progress_env))
  }
  total <- as.numeric(progress_env$total_steps)
  done_units <- min(total, max(0, as.numeric(done_units)))
  elapsed <- as.numeric(difftime(Sys.time(), progress_env$started_at, units = "secs"))
  eta <- if (done_units > 0 && done_units < total) {
    elapsed / done_units * (total - done_units)
  } else if (done_units >= total) {
    0
  } else {
    NA_real_
  }
  pct <- 100 * done_units / total
  bar <- .ctgp_fit_progress_make_bar(done_units, total, width = progress_env$bar_width)
  step_txt <- if (is.finite(step_index)) {
    sprintf("step %d/%d %s", as.integer(step_index), as.integer(total), as.character(.ctgp_fit_progress_null(step_label, "")))
  } else {
    as.character(.ctgp_fit_progress_null(step_label, ""))
  }
  detail_txt <- if (is.null(detail) || !nzchar(as.character(detail))) {
    NULL
  } else {
    as.character(detail)
  }
  pieces <- c(
    progress_env$title,
    bar,
    sprintf("%5.1f%%", pct),
    if (nzchar(step_txt)) paste0("| ", step_txt) else NULL,
    if (!is.null(detail_txt)) paste0("| ", detail_txt) else NULL,
    paste0("| elapsed ", .ctgp_fit_progress_fmt_seconds(elapsed)),
    paste0("| eta ", .ctgp_fit_progress_fmt_seconds(eta))
  )
  line <- paste(pieces, collapse = " ")
  if (identical(progress_env$mode, "bar")) {
    .ctgp_fit_progress_render_bar(progress_env, line)
  } else {
    .ctgp_fit_progress_render_plain(progress_env, line)
  }
  progress_env$last_done_units <- done_units
  invisible(progress_env)
}

.ctgp_fit_progress_close <- function(progress_env) {
  if (is.null(progress_env) || !isTRUE(progress_env$enabled) || identical(progress_env$mode, "none")) {
    return(invisible(TRUE))
  }
  cat("\n")
  flush.console()
  invisible(TRUE)
}

.ctgp_tree_leaf_count <- function(tree) {
  if (is.null(tree)) return(0L)
  if (isTRUE(tree$is_leaf)) return(1L)
  as.integer(.ctgp_tree_leaf_count(tree$left) + .ctgp_tree_leaf_count(tree$right))
}

.ctgp_fit_progress_tree_brief <- function(tree) {
  flat <- tryCatch(ctgp_flatten_tree(tree), error = function(e) NULL)
  if (is.null(flat) || !nrow(flat)) return("nodes=0 | leaves=0")
  leaves <- sum(flat$is_leaf)
  paste0("nodes=", nrow(flat), " | leaves=", as.integer(leaves))
}

.ctgp_fit_progress_stage_hint <- function(union_mode,
                                          optimizer_control = list(),
                                          bcd_control = list(),
                                          imputation_control = list()) {
  mode_label <- .ctgp_fit_progress_null(union_mode, "fullgrid_exported")
  max_iter <- as.integer(.ctgp_fit_progress_null(optimizer_control$max_iter, 200L))
  bcd_loops <- as.integer(.ctgp_fit_progress_null(bcd_control$max_iter, 3L))
  mc_samples <- as.integer(.ctgp_fit_progress_null(imputation_control$mcmc_samples, .ctgp_fit_progress_null(imputation_control$mc_samples, 50L)))
  paste0(
    "mode=", as.character(mode_label),
    " | bcd_loops<=", bcd_loops,
    " | pso_max_iter<=", max_iter,
    " | mc=", mc_samples
  )
}
