// ctmGP — anchor box decomposition helpers shared between
// ctmgp_box_decompose.cpp (which defines them) and ctmgp_ehvi_engine.cpp
// (which consumes them inside the per-candidate loop).
//
// Both functions write the (lower, upper) corner matrices for the anchor
// boxes of a Yang-2019-style decomposition.  Conventions:
//   - minimization
//   - PF rows are mutually non-dominated (call ctmgp_pareto_extract_cpp first)
//   - ref must componentwise strictly dominate every PF row
//   - For T=2: out_l, out_u become 2 × n_boxes with n_boxes = (n+1)(n+2)/2
//   - For T=3: 3 × n_boxes; n_boxes = Σ_{i=1..n+1} (s_i+1)(s_i+2)/2 where
//     s_i = size of cumulative 2D staircase from {p_1, ..., p_{i-1}} sorted by z

#ifndef CTMGP_ANCHOR_H
#define CTMGP_ANCHOR_H

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

void ctmgp_anchor_decompose_2d_impl(const arma::mat& pf, const arma::vec& ref,
                                      arma::mat& out_l, arma::mat& out_u);

void ctmgp_anchor_decompose_3d_impl(const arma::mat& pf, const arma::vec& ref,
                                      arma::mat& out_l, arma::mat& out_u);

#endif  // CTMGP_ANCHOR_H
