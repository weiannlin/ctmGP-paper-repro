# ctmGP — Expected Hypervolume Improvement (EHVI) acquisition.
#
# Unified engine: Yang 2019 anchor-box decomposition + per-leaf dispatcher.
# Surrogate-agnostic — works for QQiGP (diagonal Σ), ctmGP (block-diagonal Σ),
# QQmGP (dense Σ) with the same code path; speed difference comes from Σ
# structure feeding into the per-block kernel cost.
#
# Auto mode performs recursive sub-block detection: a "dense" leaf block whose
# Σ is itself block-diagonal across sub-leaves (off-diag zero between two index
# groups) is automatically split into independent sub-blocks, each dispatched
# to the cheapest valid kernel.

#' Expected Hypervolume Improvement for a batch of candidates.
#'
#' Supports T = 2 (Hupkens-Yang triangular enumeration) and T = 3 (slab
#' construction over z-sorted PF).  T ≥ 4 not in paper scope.
#'
#' @param mu_per_cand T × n_cand numeric matrix of predictive means.
#' @param sigma_per_cand list of n_cand T×T predictive covariance matrices,
#'   OR a single T×T matrix (replicated across candidates).
#' @param pareto_set current non-dominated outcomes; n × T matrix.
#' @param ref_point length-T reference point; if NULL, auto-derived from
#'   `pareto_set`.
#' @param block_indices list of integer vectors (1-indexed) partitioning
#'   {1,...,T} into independence blocks.  Defaults:
#'   - QQiGP / "force_independent": `as.list(seq_len(T))` (each output its own block)
#'   - QQmGP / dense surrogate: `list(seq_len(T))` (one big block)
#'   - ctmGP: derived from the tree structure (one block per leaf)
#'   When NULL, defaults to `list(seq_len(T))` (one big block — most general).
#' @param block_methods character vector specifying the moment-kernel method
#'   per block.  One of `"auto"` (default; dispatcher picks the cheapest valid
#'   kernel and recurses on sub-block structure if Σ is block-diagonal),
#'   `"cf_1d"` (1-D closed form; only for size-1 blocks), `"diag_prod"`
#'   (product of 1-D closed forms using sqrt(diag(Σ)) only — drops off-diag),
#'   `"dense_mc"` (block-aware MC over the joint Gaussian).  Length 1 is
#'   recycled across all blocks; otherwise length must equal the block count.
#' @param mc_samples MC samples per dense-block call (default 10000).
#' @param seed integer RNG seed (default 1).
#' @return numeric vector of EHVI per candidate.
#' @export
acq_ehvi <- function(mu_per_cand,
                     sigma_per_cand,
                     pareto_set,
                     ref_point      = NULL,
                     block_indices  = NULL,
                     block_methods  = "auto",
                     mc_samples     = 10000L,
                     seed           = 1L) {
  if (!is.matrix(mu_per_cand)) mu_per_cand <- as.matrix(mu_per_cand)
  storage.mode(mu_per_cand) <- "double"
  t_dim  <- nrow(mu_per_cand)
  n_cand <- ncol(mu_per_cand)

  # Accept either a list of T×T or a single T×T (replicated)
  if (is.matrix(sigma_per_cand)) {
    sigma_per_cand <- replicate(n_cand, sigma_per_cand, simplify = FALSE)
  }
  if (!is.list(sigma_per_cand) || length(sigma_per_cand) != n_cand)
    stop("sigma_per_cand must be a list of length ncol(mu_per_cand) ",
         "(or a single T×T matrix).")

  pareto_set <- as.matrix(pareto_set)
  storage.mode(pareto_set) <- "double"

  if (is.null(ref_point)) ref_point <- ctmgp_default_ref_point(pareto_set)
  ref_point <- as.numeric(ref_point)

  # Default block partition: one big block (most general — uses full T×T Σ)
  if (is.null(block_indices)) {
    block_indices <- list(seq_len(t_dim))
  } else {
    if (!is.list(block_indices))
      stop("block_indices must be a list of integer vectors (each one block).")
    all_idx <- unlist(block_indices)
    if (length(all_idx) != t_dim || !setequal(all_idx, seq_len(t_dim)))
      stop("block_indices must partition {1,...,T} exactly.")
  }
  n_blocks <- length(block_indices)

  # Resolve block_methods → integer codes
  valid_methods <- c("auto", "cf_1d", "diag_prod", "dense_mc")
  if (!is.character(block_methods))
    stop("block_methods must be a character vector.")
  bad <- setdiff(block_methods, valid_methods)
  if (length(bad) > 0L)
    stop("Unknown block_methods value(s): ",
         paste(shQuote(bad), collapse = ", "),
         ".  Valid: ", paste(shQuote(valid_methods), collapse = ", "), ".")
  if (length(block_methods) == 1L) {
    block_methods <- rep(block_methods, n_blocks)
  } else if (length(block_methods) != n_blocks) {
    stop(sprintf("block_methods length (%d) must be 1 or equal block_indices length (%d).",
                 length(block_methods), n_blocks))
  }
  codes <- ctmgp_method_codes()
  block_method_codes <- as.integer(unname(codes[block_methods]))

  ctmgp_ehvi_engine_cpp(
    mu_per_cand     = mu_per_cand,
    sigma_per_cand  = sigma_per_cand,
    pareto_set      = pareto_set,
    ref_point       = ref_point,
    block_indices_r = block_indices,
    block_methods_r = block_method_codes,
    mc_samples      = as.integer(mc_samples),
    seed            = as.integer(seed)
  )
}
