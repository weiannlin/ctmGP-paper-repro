#include <RcppArmadillo.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <limits>
#include <map>
#include <random>
#include <sstream>
#include <string>
#include <vector>
// [[Rcpp::depends(RcppArmadillo)]]

#include "ctgp_global_core.h"
#include "ctgp_version.h"
#include "ctgp_rcpp_utils.h"
#include "optimizer_pso.h"

namespace {

void resolve_nugget_spec_local(SEXP nuggetSEXP, bool& nugget_provided, double& nugget_value) {
  nugget_provided = !sexp_is_null(nuggetSEXP);
  nugget_value = 0.0;
  if (nugget_provided) {
    nugget_value = Rcpp::as<double>(nuggetSEXP);
    if (!std::isfinite(nugget_value) || nugget_value < 0.0) {
      Rcpp::stop("nugget must be NULL or a finite nonnegative scalar.");
    }
  }
}

Rcpp::List resolve_global_bounds_local(
    const arma::mat& design,
    Rcpp::Nullable<arma::vec> range,
    int d
) {
  if (nullable_is_not_null(range)) {
    arma::vec range_vec = Rcpp::as<arma::vec>(range);
    if ((int)range_vec.n_elem != 2 * d) {
      Rcpp::stop("range must have length 2 * conti_dim.");
    }
    return Rcpp::List::create(
      Rcpp::Named("lower") = range_vec.subvec(0, d - 1),
      Rcpp::Named("upper") = range_vec.subvec(d, 2 * d - 1)
    );
  }
  return ctgp_default_global_bounds(design);
}

arma::vec resolve_init_param_local(
    Rcpp::Nullable<arma::vec> init_param,
    const arma::vec& lower,
    const arma::vec& upper,
    int d
) {
  arma::vec init;
  if (nullable_is_not_null(init_param)) {
    init = Rcpp::as<arma::vec>(init_param);
    if ((int)init.n_elem != d) {
      Rcpp::stop("init_param must have length conti_dim.");
    }
  } else {
    init = 0.8 * upper + 0.2 * lower;
  }

  for (int j = 0; j < d; ++j) {
    if (init(j) < lower(j)) init(j) = lower(j);
    if (init(j) > upper(j)) init(j) = upper(j);
  }
  return init;
}

std::vector<int> parse_level_ids_local(SEXP level_idsSEXP) {
  std::vector<int> out;
  if (sexp_is_null(level_idsSEXP)) {
    return out;
  }
  Rcpp::IntegerVector ids(level_idsSEXP);
  out.reserve(ids.size());
  for (int i = 0; i < ids.size(); ++i) {
    out.push_back(ids[i]);
  }
  return out;
}

std::vector<arma::uvec> parse_group_union_index_local(SEXP group_union_indexSEXP) {
  std::vector<arma::uvec> out;
  if (sexp_is_null(group_union_indexSEXP)) {
    return out;
  }
  Rcpp::List idx_list(group_union_indexSEXP);
  out.reserve(idx_list.size());
  for (int i = 0; i < idx_list.size(); ++i) {
    Rcpp::IntegerVector idx_i = idx_list[i];
    arma::uvec ui(idx_i.size());
    for (int j = 0; j < idx_i.size(); ++j) {
      if (idx_i[j] < 1) {
        Rcpp::stop("group_union_index must be a list of 1-based positive integer vectors.");
      }
      ui(j) = static_cast<arma::uword>(idx_i[j] - 1);
    }
    out.push_back(ui);
  }
  return out;
}

bool ctgp_union_mode_is_shadow(const std::string& mode, const std::string& conditioning_mode) {
  return (mode == "fullgrid_exported" && conditioning_mode == "fullgrid");
}

bool ctgp_union_mode_is_missing_only(const std::string& mode, const std::string& conditioning_mode) {
  return (mode == "conditional_missing_only" && conditioning_mode == "missing_only");
}

std::string ctgp_union_effective_backend_label(const std::string& mode, const std::string& conditioning_mode) {
  if (ctgp_union_mode_is_shadow(mode, conditioning_mode)) {
    return std::string("ctgp_union_shadow_cpp");
  }
  return std::string("ctgp_union_candidate_cpp");
}

Rcpp::List ctgp_union_capabilities_local() {
  return Rcpp::List::create(
    Rcpp::Named("backend") = "ctgp_union_cpp",
    Rcpp::Named("shadow_backend") = "ctgp_union_shadow_cpp",
    Rcpp::Named("candidate_backend") = "ctgp_union_candidate_cpp",
    Rcpp::Named("backend_shadow_of") = "ctgp_bcd_loop_core(regime = 'union')",
    Rcpp::Named("supported_modes") = Rcpp::CharacterVector::create(
      "fullgrid_exported",
      "conditional_missing_only"
    ),
    Rcpp::Named("supported_conditioning_modes") = Rcpp::CharacterVector::create(
      "fullgrid",
      "missing_only"
    ),
    Rcpp::Named("supported_level_fi_policy") = Rcpp::CharacterVector::create("fit_per_level"),
    Rcpp::Named("planned_level_fi_policy") = Rcpp::CharacterVector::create(
      "shared_global",
      "fit_per_level_warm_cached"
    ),
    Rcpp::Named("supported_duplicate_policy") = Rcpp::CharacterVector::create("mean"),
    Rcpp::Named("supported_parallel_mode") = Rcpp::CharacterVector::create("inner_only"),
    Rcpp::Named("planned_parallel_mode") = Rcpp::CharacterVector::create("sample_outer")
  );
}

arma::mat ctgp_union_add_diag(const arma::mat& x, double val) {
  arma::mat out = x;
  if (std::isfinite(val) && val > 0.0) {
    out.diag() += val;
  }
  return out;
}

arma::mat ctgp_union_solve_sympd_chol(const arma::mat& A) {
  arma::mat L;
  if (!arma::chol(L, 0.5 * (A + A.t()), "lower")) {
    return arma::mat();
  }
  arma::mat I = arma::eye<arma::mat>(A.n_rows, A.n_cols);
  return arma::solve(arma::trimatu(L.t()), arma::solve(arma::trimatl(L), I));
}

int ctgp_union_effective_threads(bool use_openmp, int requested, int n_tasks) {
  return ctgp_openmp_resolve_threads(use_openmp, requested, n_tasks);
}

arma::mat ctgp_union_gp_cross_corr_matrix(
    const arma::mat& Xnew,
    const arma::mat& Xtrain,
    const arma::vec& theta,
    bool use_openmp,
    int num_threads
) {
  const int m = static_cast<int>(Xnew.n_rows);
  const int n = static_cast<int>(Xtrain.n_rows);
  const int d = static_cast<int>(Xtrain.n_cols);

  arma::mat R(m, n, arma::fill::zeros);
  const int n_threads = ctgp_union_effective_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    for (int j = 0; j < n; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        const double diff = Xnew(i, k) - Xtrain(j, k);
        s += theta(k) * diff * diff;
      }
      R(i, j) = std::exp(-s);
    }
  }

  return R;
}

arma::mat ctgp_union_gp_self_corr_matrix(
    const arma::mat& Xnew,
    const arma::vec& theta,
    bool use_nugget,
    double effective_nugget,
    bool use_openmp,
    int num_threads
) {
  const int m = static_cast<int>(Xnew.n_rows);
  const int d = static_cast<int>(Xnew.n_cols);

  arma::mat S(m, m, arma::fill::eye);
  const int n_threads = ctgp_union_effective_threads(use_openmp, num_threads, m);
#ifndef _OPENMP
  (void)n_threads;
#endif

#ifdef _OPENMP
#pragma omp parallel for if(n_threads > 1) schedule(static) num_threads(n_threads)
#endif
  for (int i = 0; i < m; ++i) {
    for (int j = i + 1; j < m; ++j) {
      double s = 0.0;
      for (int k = 0; k < d; ++k) {
        const double diff = Xnew(i, k) - Xnew(j, k);
        s += theta(k) * diff * diff;
      }
      const double val = std::exp(-s);
      S(i, j) = val;
      S(j, i) = val;
    }
  }

  if (use_nugget && std::isfinite(effective_nugget) && effective_nugget > 0.0) {
    S.diag() += effective_nugget;
  }

  return S;
}

bool ctgp_union_build_H_with_tb_nugget(
    const arma::mat& design,
    const arma::vec& fi,
    bool nugget_provided,
    double nugget_value,
    arma::mat& H_base,
    arma::mat& H_effective,
    double& effective_nugget,
    double& rcond_h,
    arma::mat& H_inv,
    std::string& message
) {
  H_base = build_corr_matrix(design, fi, 0.0);
  effective_nugget = nugget_provided ? nugget_value : ctgp_compute_nugget_tb(H_base, 1e8);
  H_effective = ctgp_union_add_diag(H_base, effective_nugget);
  H_effective = 0.5 * (H_effective + H_effective.t());
  rcond_h = arma::rcond(H_effective);

  H_inv = ctgp_union_solve_sympd_chol(H_effective);
  if (H_inv.n_elem == 0) {
    message = "Failed to invert H matrix under ctGP13 union missing-only nugget rules.";
    return false;
  }

  return true;
}

ctgp_bcd_state ctgp_union_update_tau_given_h_inv(
    const arma::mat& H_base,
    const arma::mat& H_effective,
    const arma::mat& H_inv,
    const arma::mat& y_matrix,
    double h_nugget,
    double scale_divisor,
    const std::string& regime
) {
  ctgp_bcd_state out;
  out.H_base = H_base;
  out.H_effective = H_effective;
  out.H_inv = H_inv;
  out.h_nugget = h_nugget;
  out.rcond_h = arma::rcond(H_effective);
  out.regime = regime;
  out.y_matrix = y_matrix;

  const int n = static_cast<int>(y_matrix.n_rows);
  const int m = static_cast<int>(y_matrix.n_cols);
  const double denom_scale = (std::isfinite(scale_divisor) && scale_divisor > 0.0)
    ? scale_divisor
    : static_cast<double>(n);
  out.scale_divisor = denom_scale;

  arma::vec one_vec(n, arma::fill::ones);
  const double denom = arma::as_scalar(one_vec.t() * H_inv * one_vec);
  if (!std::isfinite(denom) || std::abs(denom) <= std::numeric_limits<double>::epsilon()) {
    out.message = "Degenerate denominator in ctGP13 union mu update.";
    return out;
  }

  arma::rowvec mu_row = (one_vec.t() * H_inv * y_matrix) / denom;
  out.mu = mu_row.t();

  arma::mat mu_matrix(n, m, arma::fill::zeros);
  for (int j = 0; j < m; ++j) {
    mu_matrix.col(j).fill(out.mu(j));
  }

  arma::mat tau_cov = (y_matrix - mu_matrix).t() * H_inv * (y_matrix - mu_matrix) / denom_scale;
  tau_cov = 0.5 * (tau_cov + tau_cov.t());
  out.tau_cov_base = tau_cov;

  const double tau_nugget = ctgp_compute_nugget_tb(tau_cov, 1e8);
  out.t_nugget = tau_nugget;
  out.tau_cov_effective = ctgp_union_add_diag(tau_cov, tau_nugget);
  out.tau_cov_effective = 0.5 * (out.tau_cov_effective + out.tau_cov_effective.t());
  out.rcond_t = arma::rcond(out.tau_cov_effective);
  out.tau_corr = ctgp_cov2cor_sym(out.tau_cov_effective);
  out.success = true;
  return out;
}

double ctgp_union_negloglik_from_state(
    const arma::mat& y_matrix,
    const arma::mat& H_effective,
    const arma::mat& H_inv,
    const arma::vec& mu,
    const arma::mat& tau_cov_effective
) {
  const int n = static_cast<int>(H_effective.n_rows);
  const int m = static_cast<int>(tau_cov_effective.n_rows);

  arma::mat T_eff = 0.5 * (tau_cov_effective + tau_cov_effective.t());
  arma::mat T_inv = ctgp_union_solve_sympd_chol(T_eff);
  if (T_inv.n_elem == 0) {
    return arma::datum::inf;
  }

  arma::mat mu_matrix(n, m, arma::fill::zeros);
  for (int j = 0; j < m; ++j) {
    mu_matrix.col(j).fill(mu(j));
  }
  arma::mat Yc = y_matrix - mu_matrix;

  arma::mat L_H;
  if (!arma::chol(L_H, 0.5 * (H_effective + H_effective.t()), "lower")) {
    return arma::datum::inf;
  }
  arma::mat L_T;
  if (!arma::chol(L_T, T_eff, "lower")) {
    return arma::datum::inf;
  }

  const double first_term = static_cast<double>(n) * (2.0 * arma::sum(arma::log(L_T.diag())));
  const double second_term = static_cast<double>(m) * (2.0 * arma::sum(arma::log(L_H.diag())));
  const double third_term = arma::trace(T_inv * Yc.t() * H_inv * Yc);

  return 0.5 * (first_term + second_term + third_term);
}

// Mvtnorm-equivalent eigen factorization for the conditional missing-only
// MC imputation path.  See ctgp_global_core.cpp for the full rationale —
// briefly, paper's `treeFit.corrMat` uses `mvtnorm::rmvnorm(method="eigen")`,
// which is robust to the rank-deficient predictive Σ that BO loops generate
// when an acquired x lies near an existing training x.  Cholesky is not.
bool ctgp_union_stabilize_covariance_for_sampling(const arma::mat& cov,
                                                  arma::mat& factor,
                                                  double& added_nugget) {
  added_nugget = 0.0;
  arma::mat sym = 0.5 * (cov + cov.t());
  arma::vec eigval;
  arma::mat eigvec;
  if (!arma::eig_sym(eigval, eigvec, sym)) {
    return false;
  }
  for (arma::uword i = 0; i < eigval.n_elem; ++i) {
    if (!std::isfinite(eigval(i))) {
      return false;
    }
    if (eigval(i) < 0.0) {
      eigval(i) = 0.0;
    }
  }
  factor = eigvec * arma::diagmat(arma::sqrt(eigval));
  return true;
}

arma::vec ctgp_union_sample_mvn_once(
    const arma::vec& mean,
    const arma::mat& cov_chol,
    std::mt19937_64& rng
) {
  arma::vec z(mean.n_elem, arma::fill::zeros);
  std::normal_distribution<double> dist(0.0, 1.0);
  for (arma::uword i = 0; i < z.n_elem; ++i) {
    z(i) = dist(rng);
  }
  return mean + cov_chol * z;
}

Rcpp::LogicalMatrix ctgp_union_wrap_missing_mask(const arma::umat& mask) {
  Rcpp::LogicalMatrix out(mask.n_rows, mask.n_cols);
  for (arma::uword j = 0; j < mask.n_cols; ++j) {
    for (arma::uword i = 0; i < mask.n_rows; ++i) {
      out(i, j) = (mask(i, j) != 0u);
    }
  }
  return out;
}

struct ctgp_union_level_prediction {
  arma::vec fi;
  arma::vec mean_full;
  arma::vec mean_completed;
  arma::mat missing_cov;
  arma::uvec missing_rows;
  arma::vec observed_mean;
  arma::uvec observed_rows;
  bool used_fallback;
  bool success;
  std::string message;

  ctgp_union_level_prediction()
    : used_fallback(false), success(false), message("") {}
};

ctgp_union_level_prediction fit_level_gp_missing_only(
    const arma::mat& union_design,
    const arma::mat& X_obs_full,
    const arma::vec& y_obs_full,
    const arma::uvec& union_rows_zero_based,
    const arma::vec& fi_init,
    const arma::vec& lower,
    const arma::vec& upper,
    bool nugget_provided,
    double nugget_value,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode,
    int kernel_mode,
    bool fit_per_level
) {
  ctgp_union_level_prediction out;
  const arma::uword n_union = union_design.n_rows;
  out.observed_mean.set_size(n_union);
  out.observed_mean.fill(arma::datum::nan);

  std::map<arma::uword, std::pair<double, int> > acc;
  for (arma::uword i = 0; i < union_rows_zero_based.n_elem; ++i) {
    const arma::uword key = union_rows_zero_based(i);
    const double yv = y_obs_full(i);
    if (!std::isfinite(yv) || key >= n_union) {
      continue;
    }
    if (acc.find(key) == acc.end()) {
      acc[key] = std::make_pair(yv, 1);
    } else {
      acc[key].first += yv;
      acc[key].second += 1;
    }
  }

  if (acc.empty()) {
    out.message = "No valid observed rows available for a ctgp union combined level.";
    return out;
  }

  const arma::uword n_unique = static_cast<arma::uword>(acc.size());
  arma::uvec obs_rows(n_unique);
  arma::vec y_train(n_unique);
  arma::mat X_train(n_unique, union_design.n_cols, arma::fill::zeros);

  arma::uword pos = 0;
  for (std::map<arma::uword, std::pair<double, int> >::const_iterator it = acc.begin(); it != acc.end(); ++it, ++pos) {
    obs_rows(pos) = it->first;
    const double ybar = it->second.first / static_cast<double>(it->second.second);
    y_train(pos) = ybar;
    X_train.row(pos) = union_design.row(it->first);
    out.observed_mean(it->first) = ybar;
  }
  out.observed_rows = obs_rows;

  arma::uvec obs_flag(n_union, arma::fill::zeros);
  for (arma::uword i = 0; i < obs_rows.n_elem; ++i) {
    obs_flag(obs_rows(i)) = 1u;
  }
  out.missing_rows = arma::find(obs_flag == 0u);

  if (n_unique < 2) {
    out.used_fallback = true;
    out.fi = fi_init;
    out.mean_full = arma::vec(n_union);
    out.mean_full.fill(y_train(0));
    out.mean_completed = out.mean_full;
    out.mean_completed.elem(obs_rows) = y_train;
    out.missing_cov = arma::mat(out.missing_rows.n_elem, out.missing_rows.n_elem, arma::fill::zeros);
    out.success = true;
    out.message = "Level-specific ctgp union imputation fell back to a constant predictor because only one unique quantitative row was observed.";
    return out;
  }

  arma::vec fi_fit = fi_init;
  if (fit_per_level) {
    pso_control control;
    control.swarm_size = swarm_size;
    control.max_iter = max_iter;
    control.c1 = c1;
    control.c2 = c2;
    control.w = w;
    control.tol = tol;
    control.use_openmp = use_openmp;
    control.num_threads = num_threads;
    control.seed = seed;
    control.kernel_mode = kernel_mode;

    gp_likelihood_objective obj(
      X_train,
      y_train,
      arma::ones<arma::mat>(X_train.n_rows, 1),
      nugget_value,
      nugget_provided,
      objective_mode
    );

    pso_optimizer optimizer(control);
    optim_result res = optimizer.minimize(obj, lower, upper, fi_init);
    if (res.best_par.n_elem == fi_init.n_elem && std::isfinite(res.best_value)) {
      fi_fit = res.best_par;
    }
  }

  gp_profile_result fit = gp_profile_fit(
    X_train,
    y_train,
    fi_fit,
    arma::ones<arma::mat>(X_train.n_rows, 1),
    nugget_value,
    nugget_provided,
    objective_mode
  );

  if (!fit.success && fit_per_level) {
    fit = gp_profile_fit(
      X_train,
      y_train,
      fi_init,
      arma::ones<arma::mat>(X_train.n_rows, 1),
      nugget_value,
      nugget_provided,
      objective_mode
    );
    fi_fit = fi_init;
  }

  if (!fit.success) {
    out.used_fallback = true;
    out.fi = fi_init;
    const double grand_mean = arma::mean(y_train);
    out.mean_full = arma::vec(n_union);
    out.mean_full.fill(grand_mean);
    out.mean_completed = out.mean_full;
    out.mean_completed.elem(obs_rows) = y_train;
    out.missing_cov = arma::mat(out.missing_rows.n_elem, out.missing_rows.n_elem, arma::fill::zeros);
    out.success = true;
    out.message = "Level-specific ctgp union imputation fell back to a constant predictor because the GP fit was numerically unstable.";
    return out;
  }

  const arma::vec theta = arma::exp(fi_fit * std::log(10.0));
  const arma::mat r_matrix = ctgp_union_gp_cross_corr_matrix(union_design, X_train, theta, use_openmp, num_threads);
  const arma::mat SXX = ctgp_union_gp_self_corr_matrix(union_design, theta, false, 0.0, use_openmp, num_threads);
  const arma::mat U = arma::solve(arma::trimatl(fit.l_matrix), r_matrix.t());

  out.fi = fi_fit;
  out.mean_full = arma::ones<arma::vec>(n_union) * fit.beta_vec(0) + r_matrix * fit.alpha_vec;
  out.mean_completed = out.mean_full;
  out.mean_completed.elem(obs_rows) = y_train;

  arma::mat pred_cov = fit.sigma_sq * (SXX - U.t() * U);
  pred_cov = 0.5 * (pred_cov + pred_cov.t());
  arma::vec diagv = pred_cov.diag();
  for (arma::uword i = 0; i < diagv.n_elem; ++i) {
    if (!std::isfinite(diagv(i))) {
      out.message = "ctgp union predictive covariance contains non-finite diagonal entries.";
      return out;
    }
    diagv(i) = std::max(0.0, diagv(i));
  }
  pred_cov.diag() = diagv;

  if (out.missing_rows.n_elem > 0) {
    out.missing_cov = pred_cov.submat(out.missing_rows, out.missing_rows);
    out.missing_cov = 0.5 * (out.missing_cov + out.missing_cov.t());
    arma::vec miss_diag = out.missing_cov.diag();
    for (arma::uword i = 0; i < miss_diag.n_elem; ++i) {
      if (!std::isfinite(miss_diag(i))) {
        out.message = "ctgp union missing-only predictive covariance contains non-finite diagonal entries.";
        return out;
      }
      miss_diag(i) = std::max(0.0, miss_diag(i));
    }
    out.missing_cov.diag() = miss_diag;
  } else {
    out.missing_cov = arma::mat(0, 0);
  }

  out.success = true;
  return out;
}

ctgp_bcd_state ctgp_union_update_given_fi_missing_only(
    const arma::vec& fi,
    const arma::mat& coerce_data,
    const arma::mat& union_design,
    const std::vector<int>& level_ids,
    const std::vector<arma::uvec>& group_union_index,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const std::string& mode,
    const std::string& level_fi_policy,
    int union_mcmc_samples,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode
) {
  ctgp_bcd_state out;
  out.regime = "union";

  if (coerce_data.n_cols < 3) {
    out.message = "coerce_data must contain x columns, c.T, and Y for ctgp union BCD.";
    return out;
  }

  arma::mat H_base, H_effective, H_inv;
  double h_nugget = 0.0, rcond_h = NA_REAL;
  std::string message;
  if (!ctgp_union_build_H_with_tb_nugget(union_design, fi, nugget_provided, nugget_value, H_base, H_effective, h_nugget, rcond_h, H_inv, message)) {
    out.message = message;
    return out;
  }

  const int d = static_cast<int>(coerce_data.n_cols) - 2;
  const arma::vec level_vec = coerce_data.col(d);
  const arma::vec y_all = coerce_data.col(d + 1);
  const arma::mat X_all = coerce_data.cols(0, d - 1);
  const int n_levels = static_cast<int>(level_ids.size());
  const int n_union = static_cast<int>(union_design.n_rows);
  const int mc_samples = std::max(1, union_mcmc_samples);
  const double scale_divisor = static_cast<double>(coerce_data.n_rows) / static_cast<double>(std::max(1, n_levels));
  const bool fit_per_level = (level_fi_policy == "fit_per_level");

  arma::mat y_obs(n_union, n_levels);
  y_obs.fill(arma::datum::nan);
  arma::umat missing_mask(n_union, n_levels, arma::fill::ones);
  arma::mat y_mean(n_union, n_levels, arma::fill::zeros);
  arma::mat level_fi_mat(n_levels, fi.n_elem, arma::fill::zeros);
  std::vector<arma::uvec> missing_rows_list(n_levels);
  std::vector<arma::mat> missing_cov_list(n_levels);
  std::vector<arma::vec> missing_mean_list(n_levels);
  std::vector<std::string> level_messages(n_levels);
  std::atomic<bool> had_error(false);
  std::string error_message;

  const int resolved_kernel_mode = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);

  for (int j = 0; j < n_levels; ++j) {
    if (had_error.load(std::memory_order_relaxed)) {
      continue;
    }
    try {
      const int lev = level_ids[j];
      const arma::uvec obs_idx = arma::find(arma::abs(level_vec - static_cast<double>(lev)) < 0.5);
      if (obs_idx.n_elem == 0) {
        error_message = "A combined level in ctgp union BCD has no observed rows.";
        had_error.store(true, std::memory_order_relaxed);
        continue;
      }
      if (static_cast<std::size_t>(j) >= group_union_index.size() || group_union_index[j].n_elem != obs_idx.n_elem) {
        error_message = "group_union_index is inconsistent with the original coerce_data ordering.";
        had_error.store(true, std::memory_order_relaxed);
        continue;
      }

      const arma::mat X_obs = X_all.rows(obs_idx);
      const arma::vec y_obs_level = y_all.elem(obs_idx);
      const arma::uvec union_rows = group_union_index[j];
      const int level_seed = (seed >= 0) ? (seed + 7919 * (j + 1)) : -1;

      ctgp_union_level_prediction pred = fit_level_gp_missing_only(
        union_design,
        X_obs,
        y_obs_level,
        union_rows,
        fi,
        lower,
        upper,
        nugget_provided,
        nugget_value,
        swarm_size,
        max_iter,
        c1,
        c2,
        w,
        tol,
        use_openmp,
        num_threads,
        level_seed,
        objective_mode,
        resolved_kernel_mode,
        fit_per_level
      );

      if (!pred.success) {
        error_message = pred.message;
        had_error.store(true, std::memory_order_relaxed);
        continue;
      }

      y_mean.col(j) = pred.mean_completed;
      level_fi_mat.row(j) = pred.fi.t();
      y_obs.col(j) = pred.observed_mean;
      missing_rows_list[j] = pred.missing_rows;
      if (pred.missing_rows.n_elem > 0) {
        missing_cov_list[j] = pred.missing_cov;
        missing_mean_list[j] = pred.mean_full.elem(pred.missing_rows);
      } else {
        missing_cov_list[j] = arma::mat(0, 0);
        missing_mean_list[j] = arma::vec();
      }
      for (arma::uword ii = 0; ii < pred.observed_rows.n_elem; ++ii) {
        missing_mask(pred.observed_rows(ii), j) = 0u;
      }
      level_messages[j] = pred.message;
    } catch (const std::exception& e) {
      error_message = e.what();
      had_error.store(true, std::memory_order_relaxed);
    } catch (...) {
      error_message = "Unknown exception in ctgp union missing-only level-wise GP update.";
      had_error.store(true, std::memory_order_relaxed);
    }
  }

  if (had_error.load(std::memory_order_relaxed)) {
    out.message = error_message;
    return out;
  }

  ctgp_bcd_state mean_state = ctgp_union_update_tau_given_h_inv(
    H_base,
    H_effective,
    H_inv,
    y_mean,
    h_nugget,
    scale_divisor,
    "union"
  );
  if (!mean_state.success) {
    return mean_state;
  }

  out = mean_state;
  out.regime = "union";
  out.y_matrix = y_mean;
  out.y_matrix_observed = y_obs;
  out.missing_mask = missing_mask;
  out.level_fi = level_fi_mat;
  out.scale_divisor = scale_divisor;

      bool has_any_missing = false;
    std::vector<arma::mat> sample_factor_list(n_levels);
    for (int j = 0; j < n_levels; ++j) {
      if (missing_rows_list[j].n_elem < 1) {
        continue;
      }
      has_any_missing = true;
      const arma::mat& cov = missing_cov_list[j];
      double added_cov_nugget = 0.0;
      arma::mat factor;
      if (!ctgp_union_stabilize_covariance_for_sampling(cov, factor, added_cov_nugget)) {
        out.message = "Failed to factorize a ctgp union missing-only predictive covariance matrix for Monte Carlo sampling.";
        out.success = false;
        return out;
      }
      sample_factor_list[j] = std::move(factor);
    }

    if (!has_any_missing) {
      out.used_monte_carlo = false;
      out.mc_samples = 0;
      out.neg_lik = ctgp_union_negloglik_from_state(y_mean, H_effective, H_inv, out.mu, out.tau_cov_effective);
    } else {
      arma::mat sum_cov_base(n_levels, n_levels, arma::fill::zeros);
      arma::mat sum_cov_eff(n_levels, n_levels, arma::fill::zeros);
      arma::mat sum_corr(n_levels, n_levels, arma::fill::zeros);
      double sum_t_nugget = 0.0;

      std::mt19937_64 rng;
      if (seed >= 0) {
        rng.seed(static_cast<std::mt19937_64::result_type>(seed + 2027));
      } else {
        std::random_device rd;
        rng.seed(static_cast<std::mt19937_64::result_type>(rd()));
      }

      for (int s = 0; s < mc_samples; ++s) {
        arma::mat y_draw = y_mean;
        for (int j = 0; j < n_levels; ++j) {
          if (missing_rows_list[j].n_elem < 1) {
            continue;
          }
          const arma::vec draw_missing = ctgp_union_sample_mvn_once(
            missing_mean_list[j],
            sample_factor_list[j],
            rng
          );
          for (arma::uword ii = 0; ii < missing_rows_list[j].n_elem; ++ii) {
            y_draw(missing_rows_list[j](ii), j) = draw_missing(ii);
          }
        }

        ctgp_bcd_state draw_state = ctgp_union_update_tau_given_h_inv(
          H_base,
          H_effective,
          H_inv,
          y_draw,
          h_nugget,
          scale_divisor,
          "union"
        );
        if (!draw_state.success) {
          out.message = draw_state.message;
          out.success = false;
          return out;
        }

        sum_cov_base += draw_state.tau_cov_base;
        sum_cov_eff += draw_state.tau_cov_effective;
        sum_corr += draw_state.tau_corr;
        sum_t_nugget += draw_state.t_nugget;
      }

      out.used_monte_carlo = true;
      out.mc_samples = mc_samples;
      out.tau_cov_base = sum_cov_base / static_cast<double>(mc_samples);
      out.tau_cov_effective = sum_cov_eff / static_cast<double>(mc_samples);
      out.tau_cov_effective = 0.5 * (out.tau_cov_effective + out.tau_cov_effective.t());
      out.tau_corr = sum_corr / static_cast<double>(mc_samples);
      out.tau_corr = 0.5 * (out.tau_corr + out.tau_corr.t());
      out.t_nugget = sum_t_nugget / static_cast<double>(mc_samples);
      out.rcond_t = arma::rcond(out.tau_cov_effective);
      out.neg_lik = ctgp_union_negloglik_from_state(y_mean, H_effective, H_inv, out.mu, out.tau_cov_effective);
    }

  out.success = std::isfinite(out.neg_lik);

  std::ostringstream oss;
  bool has_msg = false;
  for (int j = 0; j < n_levels; ++j) {
    if (!level_messages[j].empty()) {
      if (has_msg) {
        oss << " | ";
      }
      oss << "level " << level_ids[j] << ": " << level_messages[j];
      has_msg = true;
    }
  }
  out.message = oss.str();
  if (!out.success && out.message.empty()) {
    out.message = "Failed to evaluate the ctgp union missing-only BCD negative log-likelihood.";
  }
  return out;
}

Rcpp::List ctgp_union_bcd_loop_core_missing_only(
    const arma::mat& coerce_data,
    const arma::mat& union_design,
    const std::vector<int>& level_ids,
    const std::vector<arma::uvec>& group_union_index,
    bool nugget_provided,
    double nugget_value,
    const arma::vec& lower,
    const arma::vec& upper,
    const arma::vec& init,
    bool init_provided,
    const std::string& mode,
    const std::string& conditioning_mode,
    const std::string& level_fi_policy,
    int bcd_loops,
    double bcd_tol,
    int union_mcmc_samples,
    int swarm_size,
    int max_iter,
    double c1,
    double c2,
    double w,
    double tol,
    bool use_openmp,
    int num_threads,
    int seed,
    int objective_mode
) {
  if (bcd_loops < 1) {
    Rcpp::stop("bcd_loops must be positive.");
  }
  if (union_design.n_elem == 0 || level_ids.empty() || group_union_index.empty()) {
    Rcpp::stop("ctgp union missing-only BCD requires union_design, level_ids, and group_union_index.");
  }

  arma::vec fi_current;
  arma::vec initial_fi;
  double initial_objective = NA_REAL;
  int initial_n_eval = 0;
  bool initial_converged = false;
  std::string initial_source;

  if (init_provided) {
    fi_current = init;
    initial_fi = fi_current;
    initial_source = "user_init_param";
  } else {
    ctgp_global_gp_fit_result init_fit = ctgp_global_gp_fit_core(
      coerce_data,
      nugget_provided,
      nugget_value,
      lower,
      upper,
      init,
      swarm_size,
      max_iter,
      c1,
      c2,
      w,
      tol,
      use_openmp,
      num_threads,
      seed,
      objective_mode
    );
    if (!init_fit.success) {
      Rcpp::stop(init_fit.message);
    }
    fi_current = init_fit.fi;
    initial_fi = fi_current;
    initial_objective = init_fit.objective;
    initial_n_eval = init_fit.n_eval;
    initial_converged = init_fit.converged;
    initial_source = "global_gp";
  }

  ctgp_bcd_state state = ctgp_union_update_given_fi_missing_only(
    fi_current,
    coerce_data,
    union_design,
    level_ids,
    group_union_index,
    nugget_provided,
    nugget_value,
    lower,
    upper,
    mode,
    level_fi_policy,
    union_mcmc_samples,
    swarm_size,
    max_iter,
    c1,
    c2,
    w,
    tol,
    use_openmp,
    num_threads,
    seed,
    objective_mode
  );

  if (!state.success) {
    Rcpp::stop(state.message);
  }

  if (!std::isfinite(state.neg_lik)) {
    state.neg_lik = ctgp_union_negloglik_from_state(state.y_matrix, state.H_effective, state.H_inv, state.mu, state.tau_cov_effective);
  }
  if (std::isfinite(state.neg_lik) && !std::isfinite(initial_objective)) {
    initial_objective = state.neg_lik;
  }
  if (initial_fi.n_elem == 0) {
    initial_fi = fi_current;
  }

  Rcpp::List trace(bcd_loops);
  trace[0] = Rcpp::List::create(
    Rcpp::Named("iter") = 0,
    Rcpp::Named("stage") = "initial",
    Rcpp::Named("regime") = "union",
    Rcpp::Named("objective") = state.neg_lik,
    Rcpp::Named("rcond_h") = state.rcond_h,
    Rcpp::Named("rcond_t") = state.rcond_t,
    Rcpp::Named("h_nugget") = state.h_nugget,
    Rcpp::Named("t_nugget") = state.t_nugget,
    Rcpp::Named("fi") = fi_current,
    Rcpp::Named("mu") = state.mu,
    Rcpp::Named("delta_fi") = NA_REAL,
    Rcpp::Named("delta_mu") = NA_REAL,
    Rcpp::Named("delta_t") = NA_REAL,
    Rcpp::Named("stopped") = false,
    Rcpp::Named("used_monte_carlo") = state.used_monte_carlo,
    Rcpp::Named("mc_samples") = state.mc_samples
  );

  int iter_used = 1;

  for (int iter = 1; iter < bcd_loops; ++iter) {
    const arma::vec prev_fi = fi_current;
    const arma::vec prev_mu = state.mu;
    const arma::mat prev_T = state.tau_cov_effective;

    ctgp_bcd_objective obj(union_design, state.y_matrix, prev_T, nugget_provided, nugget_value);
    pso_control control;
    control.swarm_size = swarm_size;
    control.max_iter = max_iter;
    control.c1 = c1;
    control.c2 = c2;
    control.w = w;
    control.tol = tol;
    control.use_openmp = use_openmp;
    control.num_threads = num_threads;
    control.seed = (seed >= 0) ? (seed + 104729 * iter) : -1;
    control.kernel_mode = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);

    pso_optimizer optimizer(control);
    optim_result opt = optimizer.minimize(obj, lower, upper, prev_fi);
    fi_current = (opt.best_par.n_elem == prev_fi.n_elem) ? opt.best_par : prev_fi;

    state = ctgp_union_update_given_fi_missing_only(
      fi_current,
      coerce_data,
      union_design,
      level_ids,
      group_union_index,
      nugget_provided,
      nugget_value,
      lower,
      upper,
      mode,
      level_fi_policy,
      union_mcmc_samples,
      swarm_size,
      max_iter,
      c1,
      c2,
      w,
      tol,
      use_openmp,
      num_threads,
      (seed >= 0) ? (seed + 130363 * iter) : -1,
      objective_mode
    );

    if (!state.success) {
      Rcpp::stop(state.message);
    }

    const double delta_fi = arma::abs(fi_current - prev_fi).max();
    const double delta_mu = arma::abs(state.mu - prev_mu).max();
    const double delta_t = arma::abs(state.tau_cov_effective - prev_T).max();
    const double delta_max = std::max(delta_fi, std::max(delta_mu, delta_t));

    bool stopped = false;
    if (std::isfinite(delta_max) && delta_max <= bcd_tol) {
      stopped = true;
    }

    trace[iter] = Rcpp::List::create(
      Rcpp::Named("iter") = iter,
      Rcpp::Named("stage") = "BCD",
      Rcpp::Named("regime") = "union",
      Rcpp::Named("objective") = state.neg_lik,
      Rcpp::Named("rcond_h") = state.rcond_h,
      Rcpp::Named("rcond_t") = state.rcond_t,
      Rcpp::Named("h_nugget") = state.h_nugget,
      Rcpp::Named("t_nugget") = state.t_nugget,
      Rcpp::Named("fi") = fi_current,
      Rcpp::Named("mu") = state.mu,
      Rcpp::Named("delta_fi") = delta_fi,
      Rcpp::Named("delta_mu") = delta_mu,
      Rcpp::Named("delta_t") = delta_t,
      Rcpp::Named("stopped") = stopped,
      Rcpp::Named("used_monte_carlo") = state.used_monte_carlo,
      Rcpp::Named("mc_samples") = state.mc_samples
    );

    iter_used = iter + 1;
    if (stopped) {
      break;
    }
  }

  Rcpp::List trace_used(iter_used);
  for (int i = 0; i < iter_used; ++i) {
    trace_used[i] = trace[i];
  }

  SEXP nugget_sexp = nugget_provided ? Rcpp::wrap(nugget_value) : R_NilValue;

  return Rcpp::List::create(
    Rcpp::Named("regime") = std::string("union"),
    Rcpp::Named("fi") = fi_current,
    Rcpp::Named("bound") = arma::join_cols(lower, upper),
    Rcpp::Named("common_r_matrix") = state.H_effective,
    Rcpp::Named("common_r_matrix_base") = state.H_base,
    Rcpp::Named("mu_vec") = state.mu,
    Rcpp::Named("tau_cov_matrix") = state.tau_cov_effective,
    Rcpp::Named("tau_cov_matrix_base") = state.tau_cov_base,
    Rcpp::Named("tau_matrix") = state.tau_corr,
    Rcpp::Named("trace") = trace_used,
    Rcpp::Named("h_nugget") = state.h_nugget,
    Rcpp::Named("t_nugget") = state.t_nugget,
    Rcpp::Named("rcond_h") = state.rcond_h,
    Rcpp::Named("rcond_t") = state.rcond_t,
    Rcpp::Named("objective") = state.neg_lik,
    Rcpp::Named("n_bcd_iter_used") = iter_used,
    Rcpp::Named("bcd_tol") = bcd_tol,
    Rcpp::Named("initial_source") = initial_source,
    Rcpp::Named("initial_objective") = initial_objective,
    Rcpp::Named("initial_fi") = initial_fi,
    Rcpp::Named("initial_n_eval") = initial_n_eval,
    Rcpp::Named("initial_converged") = initial_converged,
    Rcpp::Named("used_monte_carlo") = state.used_monte_carlo,
    Rcpp::Named("mc_samples") = state.mc_samples,
    Rcpp::Named("scale_divisor") = state.scale_divisor,
    Rcpp::Named("y_matrix") = state.y_matrix,
    Rcpp::Named("y_matrix_observed") = Rcpp::wrap(state.y_matrix_observed),
    Rcpp::Named("missing_mask") = Rcpp::wrap(ctgp_union_wrap_missing_mask(state.missing_mask)),
    Rcpp::Named("level_fi_matrix") = state.level_fi,
    Rcpp::Named("nugget") = nugget_sexp,
    Rcpp::Named("message") = state.message
  );
}

}  // namespace

// [[Rcpp::export]]
Rcpp::List ctgp_union_backend_capabilities_cpp() {
  Rcpp::List out = ctgp_union_capabilities_local();
  out["backend_version"] = Rcpp::wrap(std::string(CTGP_PACKAGE_VERSION));
  out["candidate_modes_ready"] = Rcpp::wrap(true);
  out["shadow_mode_ready"] = Rcpp::wrap(true);
  return out;
}

// [[Rcpp::export]]
Rcpp::List ctgp_union_bcd_cpp(
    const arma::mat& coerce_data,
    const arma::mat& union_design,
    SEXP level_ids = R_NilValue,
    SEXP group_union_index = R_NilValue,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> range = R_NilValue,
    SEXP nugget = R_NilValue,
    std::string mode = "fullgrid_exported",
    std::string conditioning_mode = "fullgrid",
    std::string level_fi_policy = "fit_per_level",
    int bcd_loops = 3,
    double bcd_tol = 1e-6,
    int union_mcmc_samples = 50,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1,
    int objective_mode = 1
) {
  const bool shadow_mode = ctgp_union_mode_is_shadow(mode, conditioning_mode);
  const bool missing_only_mode = ctgp_union_mode_is_missing_only(mode, conditioning_mode);
  if (!shadow_mode && !missing_only_mode) {
    Rcpp::stop(
      std::string("ctgp_union_bcd_cpp() in version ") + CTGP_PACKAGE_VERSION +
      " supports only either (mode = 'fullgrid_exported', conditioning_mode = 'fullgrid') or " +
      "missing-only candidate pair (mode = 'conditional_missing_only', conditioning_mode = 'missing_only')."
    );
  }
  if (level_fi_policy != "fit_per_level") {
    Rcpp::stop(std::string("ctgp_union_bcd_cpp() in version ") + CTGP_PACKAGE_VERSION + " currently supports only level_fi_policy = 'fit_per_level'.");
  }
  if (coerce_data.n_cols < 3) {
    Rcpp::stop("coerce_data must contain at least one x column, c.T, and Y.");
  }
  if (union_design.n_rows < 1 || union_design.n_cols < 1) {
    Rcpp::stop("union_design must be a non-empty numeric matrix.");
  }

  const int d = static_cast<int>(coerce_data.n_cols) - 2;
  if (static_cast<int>(union_design.n_cols) != d) {
    Rcpp::stop("union_design must have the same number of columns as the quantitative design in coerce_data.");
  }

  std::vector<int> level_ids_vec = parse_level_ids_local(level_ids);
  std::vector<arma::uvec> group_union_index_vec = parse_group_union_index_local(group_union_index);
  if (level_ids_vec.empty() || group_union_index_vec.empty()) {
    Rcpp::stop("level_ids and group_union_index are required for ctgp_union_bcd_cpp().");
  }
  if (level_ids_vec.size() != group_union_index_vec.size()) {
    Rcpp::stop("level_ids and group_union_index must have the same length.");
  }

  bool nugget_provided = false;
  double nugget_value = 0.0;
  resolve_nugget_spec_local(nugget, nugget_provided, nugget_value);

  Rcpp::List bounds = resolve_global_bounds_local(union_design, range, d);
  arma::vec lower = bounds["lower"];
  arma::vec upper = bounds["upper"];
  arma::vec init = resolve_init_param_local(init_param, lower, upper, d);

  Rcpp::List out;
  if (shadow_mode) {
    out = ctgp_bcd_loop_core(
      "union",
      coerce_data,
      arma::mat(),
      arma::mat(),
      union_design,
      level_ids_vec,
      group_union_index_vec,
      nugget_provided,
      nugget_value,
      lower,
      upper,
      init,
      nullable_is_not_null(init_param),
      bcd_loops,
      bcd_tol,
      union_mcmc_samples,
      swarm_size,
      max_iter,
      c1,
      c2,
      w,
      tol,
      use_openmp,
      num_threads,
      seed,
      objective_mode
    );
  } else {
    out = ctgp_union_bcd_loop_core_missing_only(
      coerce_data,
      union_design,
      level_ids_vec,
      group_union_index_vec,
      nugget_provided,
      nugget_value,
      lower,
      upper,
      init,
      nullable_is_not_null(init_param),
      mode,
      conditioning_mode,
      level_fi_policy,
      bcd_loops,
      bcd_tol,
      union_mcmc_samples,
      swarm_size,
      max_iter,
      c1,
      c2,
      w,
      tol,
      use_openmp,
      num_threads,
      seed,
      objective_mode
    );
  }

  const std::string effective_backend = ctgp_union_effective_backend_label(mode, conditioning_mode);
  out["experimental_backend"] = Rcpp::wrap(effective_backend);
  if (shadow_mode) {
    out["backend_shadow_of"] = Rcpp::wrap(std::string("ctgp_bcd_loop_core(regime = 'union')"));
    out["candidate_family"] = R_NilValue;
    out["imputation_route"] = Rcpp::wrap(std::string("fullgrid_plugin_gp"));
    out["prediction_target"] = Rcpp::wrap(std::string("legacy_plugin_gp"));
  } else {
    out["backend_shadow_of"] = R_NilValue;
    out["candidate_family"] = Rcpp::wrap(std::string("observed_clamped_missing_only"));
    out["imputation_route"] = Rcpp::wrap(std::string("conditional_missing_only"));
    out["prediction_target"] = Rcpp::wrap(std::string("latent_function_missing_only"));
  }
  out["mode"] = Rcpp::wrap(mode);
  out["conditioning_mode"] = Rcpp::wrap(conditioning_mode);
  out["level_fi_policy"] = Rcpp::wrap(level_fi_policy);
  out["backend_capabilities"] = ctgp_union_capabilities_local();
  out["backend_version"] = Rcpp::wrap(std::string(CTGP_PACKAGE_VERSION));
  return out;
}
