ctgp_union_stage <- function(prepped,
                             init_param = NULL,
                             range = NULL,
                             nugget = NULL,
                             optimizer_control = list(),
                             bcd_control = list(),
                             union_control = list(),
                             imputation_control = NULL,
                             preprocessing_tol = 1e-8,
                             global_fit = NULL) {
  verified <- .ctgp_union_assert_prepped(prepped, preprocessing_tol = preprocessing_tol)
  prepped <- verified$prepped
  regime <- verified$regime

  if (is.null(global_fit)) {
    global_fit <- .ctgp_global_gp(
      prepped,
      init_param = init_param,
      range = range,
      nugget = nugget,
      optimizer_control = optimizer_control
    )
  }

  union_index <- .ctgp_build_union_index(prepped)
  bcd <- ctgp_union_bcd(
    prepped = prepped,
    union_index = union_index,
    init_param = global_fit$fi,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = bcd_control,
    union_control = union_control,
    imputation_control = imputation_control,
    preprocessing_tol = preprocessing_tol
  )

  union_imputation <- list(
    union_design = union_index$union_design,
    level_ids = union_index$level_ids,
    y_matrix_observed = bcd$y_matrix_observed,
    y_matrix = bcd$y_matrix,
    missing_mask = bcd$missing_mask,
    n_imputed = if (is.null(bcd$missing_mask)) 0L else sum(bcd$missing_mask),
    group_union_index = union_index$group_union_index,
    optimizer_control = bcd$optimizer_control,
    union_control = bcd$union_control,
    imputation_control = bcd$imputation_control,
    timing = bcd$timing,
    mc_samples = bcd$mc_samples,
    level_fi_matrix = bcd$level_fi_matrix,
    experimental_backend = bcd$experimental_backend,
    backend_version = bcd$backend_version,
    bcd_object = bcd
  )

  out <- list(
    prepared = prepped,
    regime = regime,
    global_gp = global_fit,
    common_index = bcd$common_index,
    union_index = union_index,
    union_imputation = union_imputation,
    bcd = bcd,
    success = TRUE,
    union_mode_selected = if (identical(bcd$backend_stage, "shadow")) "fullgrid_exported" else "conditional_missing_only",
    deterministic_route = if (identical(bcd$backend_stage, "shadow")) {
      .ctgp_union_deterministic_route("fullgrid_exported")
    } else {
      .ctgp_union_deterministic_route("conditional_missing_only")
    },
    workflow_family = "deterministic",
    experimental_backend = bcd$experimental_backend,
    backend_version = bcd$backend_version,
    message = if (identical(bcd$backend_stage, "shadow")) {
      paste0(
        "ctgp_union full-grid shadow backend completed. ",
        "This route remains available as the exported full-grid reference option."
      )
    } else {
      paste0(
        "ctgp_union conditional missing-only backend completed. ",
        "Observed rows were clamped and only missing rows were imputed."
      )
    }
  )
  class(out) <- c("ctgp_union_stage", "list")
  out
}
