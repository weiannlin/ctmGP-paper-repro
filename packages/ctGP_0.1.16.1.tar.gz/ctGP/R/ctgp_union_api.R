.ctgp_union_assert_prepped <- function(prepped, preprocessing_tol = 1e-8) {
  regime <- .ctgp_detect_design_regime(prepped, tol = preprocessing_tol)
  if (!identical(regime$regime, "union")) {
    stop(
      "ctgp_union_* is a union-design workflow. Supply prepared data whose detected regime is 'union'.",
      call. = FALSE
    )
  }
  list(prepped = prepped, regime = regime)
}

.ctgp_union_make_requested_optimizer <- function(optimizer_control, union_control) {
  ctrl <- .ctgp_optimizer_control_defaults(optimizer_control)
  ctrl$use_openmp <- isTRUE(union_control$use_openmp)
  ctrl$num_threads <- as.integer(union_control$num_threads)
  ctrl$seed <- if (is.null(union_control$seed)) ctrl$seed else as.integer(union_control$seed)
  ctrl
}

.ctgp_union_make_effective_controls <- function(optimizer_control, union_control) {
  requested_optimizer <- .ctgp_union_make_requested_optimizer(optimizer_control, union_control)
  requested_union <- union_control
  requested_union$parallel_mode_effective <- requested_union$parallel_mode

  union_policy <- .ctgp_union_bcd_optimizer_control(
    requested_optimizer,
    imputation_control = list(
      mcmc_samples = requested_union$mc_samples,
      use_openmp = requested_union$use_openmp,
      num_threads = requested_union$num_threads,
      seed = requested_union$seed
    )
  )

  effective_optimizer <- union_policy$optimizer_control
  effective_union <- requested_union
  effective_union$use_openmp <- isTRUE(effective_optimizer$use_openmp)
  effective_union$num_threads <- as.integer(effective_optimizer$num_threads)
  effective_union$seed <- if (is.null(requested_union$seed)) {
    if (effective_optimizer$seed < 0L) NULL else as.integer(effective_optimizer$seed)
  } else {
    as.integer(requested_union$seed)
  }
  effective_union$union_omp_forced_serial <- isTRUE(effective_optimizer$union_omp_forced_serial)
  effective_union$parallel_mode_effective <- "inner_only"

  list(
    optimizer_requested = requested_optimizer,
    optimizer_effective = effective_optimizer,
    union_requested = requested_union,
    union_effective = effective_union
  )
}

.ctgp_union_imputation_variance_mode <- function(union_control) {
  if (isTRUE(union_control$is_shadow_mode) || identical(union_control$mode, "fullgrid_exported")) {
    return("fullgrid_exported_plugin_gp")
  }
  if (identical(union_control$mode, "conditional_missing_only")) {
    return("conditional_missing_only")
  }
  NA_character_
}

.ctgp_union_backend_stage_label <- function(union_control) {
  if (isTRUE(union_control$is_shadow_mode) || identical(union_control$mode, "fullgrid_exported")) {
    return("shadow")
  }
  "candidate"
}

ctgp_union_backend_capabilities <- function() {
  caps <- ctgp_union_backend_capabilities_cpp()
  caps$package_version <- as.character(utils::packageVersion("ctGP"))
  caps
}

.ctgp_union_require_runtime_capability <- function(mode, conditioning_mode) {
  caps <- tryCatch(
    ctgp_union_backend_capabilities_cpp(),
    error = function(e) {
      stop(
        paste0(
          "ctgp_union runtime capability probe failed before launching the C++ backend. ",
          "This usually means an older ctGP DLL is still loaded in the current R session. ",
          "Restart R, reinstall ctGP from a clean session, and try again.\n",
          "Underlying error: ", conditionMessage(e)
        ),
        call. = FALSE
      )
    }
  )

  pkg_ver <- as.character(utils::packageVersion("ctGP"))
  backend_ver <- if (is.null(caps$backend_version) || length(caps$backend_version) < 1L) NA_character_ else as.character(caps$backend_version[[1L]])
  if (!is.na(backend_ver) && nzchar(backend_ver) && !identical(backend_ver, pkg_ver)) {
    stop(
      sprintf(
        paste0(
          "ctgp_union runtime/backend version mismatch detected: packageVersion('ctGP') = %s but ",
          "the loaded C++ backend reports %s. This usually means an older ctGP DLL is still loaded. ",
          "Restart R and reinstall from a clean session."
        ),
        pkg_ver,
        backend_ver
      ),
      call. = FALSE
    )
  }

  supported_modes <- if (is.null(caps$supported_modes)) character() else as.character(caps$supported_modes)
  supported_conditioning <- if (is.null(caps$supported_conditioning_modes)) character() else as.character(caps$supported_conditioning_modes)
  if (!mode %in% supported_modes || !conditioning_mode %in% supported_conditioning) {
    stop(
      sprintf(
        paste0(
          "The loaded ctgp_union runtime does not advertise the requested mode pair (%s, %s). ",
          "Supported modes: %s. Supported conditioning modes: %s."
        ),
        mode,
        conditioning_mode,
        paste(supported_modes, collapse = ", "),
        paste(supported_conditioning, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  invisible(caps)
}

ctgp_union_bcd <- function(prepped,
                           union_index = NULL,
                           init_param = NULL,
                           range = NULL,
                           nugget = NULL,
                           optimizer_control = list(),
                           bcd_control = list(),
                           union_control = list(),
                           imputation_control = NULL,
                           preprocessing_tol = 1e-8) {
  verified <- .ctgp_union_assert_prepped(prepped, preprocessing_tol = preprocessing_tol)
  prepped <- verified$prepped

  if (is.null(union_index)) {
    union_index <- .ctgp_build_union_index(prepped)
  }

  bcd <- .ctgp_bcd_control_defaults(bcd_control)
  union_requested <- ctgp_union_control_defaults(
    union_control = union_control,
    optimizer_control = optimizer_control,
    imputation_control = imputation_control
  )
  control_pack <- .ctgp_union_make_effective_controls(optimizer_control, union_requested)

  .ctgp_union_require_runtime_capability(
    mode = control_pack$union_effective$mode,
    conditioning_mode = control_pack$union_effective$conditioning_mode
  )

  timing <- system.time({
    out <- ctgp_union_bcd_cpp(
      coerce_data = as.matrix(prepped$coerce_data),
      union_design = as.matrix(union_index$union_design),
      level_ids = as.integer(union_index$level_ids),
      group_union_index = union_index$group_union_index,
      init_param = init_param,
      range = range,
      nugget = nugget,
      mode = control_pack$union_effective$mode,
      conditioning_mode = control_pack$union_effective$conditioning_mode,
      level_fi_policy = control_pack$union_effective$level_fi_policy,
      bcd_loops = bcd$max_iter,
      bcd_tol = bcd$tol,
      union_mcmc_samples = control_pack$union_effective$mc_samples,
      swarm_size = control_pack$optimizer_effective$swarm_size,
      max_iter = control_pack$optimizer_effective$max_iter,
      c1 = control_pack$optimizer_effective$c1,
      c2 = control_pack$optimizer_effective$c2,
      w = control_pack$optimizer_effective$w,
      tol = control_pack$optimizer_effective$tol,
      use_openmp = control_pack$optimizer_effective$use_openmp,
      num_threads = control_pack$optimizer_effective$num_threads,
      seed = control_pack$optimizer_effective$seed,
      objective_mode = 1L
    )
  })

  out$timing <- as.list(timing)
  out$optimizer_control <- control_pack$optimizer_effective
  out$optimizer_control_requested <- control_pack$optimizer_requested
  out$optimizer_mode <- if (exists(".ctgp_resolve_pso_kernel_mode", mode = "function")) .ctgp_resolve_pso_kernel_mode() else "qpso"
  out$objective_mode <- "legacy_exact"
  out$search_objective_mode <- "legacy_exact"
  out$imputation_variance_mode <- .ctgp_union_imputation_variance_mode(control_pack$union_effective)
  out$union_omp_forced_serial <- isTRUE(control_pack$optimizer_effective$union_omp_forced_serial)
  out$bcd_control <- bcd
  out$union_control <- control_pack$union_effective
  out$union_control_requested <- control_pack$union_requested
  out$imputation_control <- list(
    mcmc_samples = control_pack$union_effective$mc_samples,
    use_openmp = control_pack$union_effective$use_openmp,
    num_threads = control_pack$union_effective$num_threads,
    seed = control_pack$union_effective$seed,
    union_omp_forced_serial = control_pack$union_effective$union_omp_forced_serial,
    mode = control_pack$union_effective$mode,
    conditioning_mode = control_pack$union_effective$conditioning_mode,
    level_fi_policy = control_pack$union_effective$level_fi_policy
  )
  out$schema <- prepped$schema
  out$combined_key <- prepped$combined_key
  out$combined_id <- prepped$combined_id
  out$data <- prepped$data
  out$design <- prepped$design
  out$continuous_data <- prepped$continuous_data
  out$qualitative_data <- prepped$qualitative_data
  out$y <- prepped$y
  out$coerce_data <- prepped$coerce_data
  out$common_index <- list(
    common_design = union_index$union_design,
    y_matrix = out$y_matrix,
    n_common = nrow(union_index$union_design),
    n_levels = length(union_index$level_ids),
    level_ids = union_index$level_ids,
    row_order = NULL,
    regime = "union-imputed"
  )
  out$union_index <- union_index
  out$backend_stage <- .ctgp_union_backend_stage_label(control_pack$union_effective)
  out$orchestration_compatibility <- if (identical(out$backend_stage, "shadow")) "ctgp_bcd_union" else "ctgp_bcd_union (candidate missing-only)"
  out$backend_version <- if (!is.null(out$backend_version)) out$backend_version else as.character(utils::packageVersion("ctGP"))
  out <- .ctgp_attach_legacy_loocv_state(out, prepped)
  class(out) <- c("ctgp_union_bcd", "ctgp_bcd_union", "list")
  out
}

ctgp_union_impute <- function(prepped,
                              union_index = NULL,
                              init_param = NULL,
                              range = NULL,
                              nugget = NULL,
                              optimizer_control = list(),
                              union_control = list(),
                              imputation_control = NULL,
                              preprocessing_tol = 1e-8) {
  bcd_obj <- ctgp_union_bcd(
    prepped = prepped,
    union_index = union_index,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = list(max_iter = 1L, tol = 0),
    union_control = union_control,
    imputation_control = imputation_control,
    preprocessing_tol = preprocessing_tol
  )

  out <- list(
    union_design = bcd_obj$union_index$union_design,
    level_ids = bcd_obj$union_index$level_ids,
    y_matrix_observed = bcd_obj$y_matrix_observed,
    y_matrix = bcd_obj$y_matrix,
    missing_mask = bcd_obj$missing_mask,
    n_imputed = if (is.null(bcd_obj$missing_mask)) 0L else sum(bcd_obj$missing_mask),
    group_union_index = bcd_obj$union_index$group_union_index,
    optimizer_control = bcd_obj$optimizer_control,
    union_control = bcd_obj$union_control,
    imputation_control = bcd_obj$imputation_control,
    timing = bcd_obj$timing,
    mc_samples = bcd_obj$mc_samples,
    level_fi_matrix = bcd_obj$level_fi_matrix,
    experimental_backend = bcd_obj$experimental_backend,
    backend_version = bcd_obj$backend_version,
    bcd_object = bcd_obj
  )
  class(out) <- c("ctgp_union_imputation", "list")
  out
}
