.ctgp_collect_leaf_nodes <- function(tree) {
  out <- list()
  rec <- function(node) {
    if (isTRUE(node$is_leaf)) {
      out[[length(out) + 1L]] <<- node
    } else {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out
}

.ctgp_leaf_summary_table <- function(tree) {
  rows <- list()
  rec <- function(node) {
    if (isTRUE(node$is_leaf)) {
      fit <- node$leaf_fit
      rows[[length(rows) + 1L]] <<- data.frame(
        node_id = as.integer(node$node_id),
        depth = as.integer(node$depth),
        n_rows = as.integer(node$n_rows),
        n_combined = as.integer(length(node$combined_ids)),
        leaf_model = if (is.null(node$leaf_model)) NA_character_ else as.character(node$leaf_model),
        fit_class = if (is.null(fit)) NA_character_ else class(fit)[1L],
        converged = if (is.null(fit) || is.null(fit$optim_converged)) NA else isTRUE(fit$optim_converged),
        stringsAsFactors = FALSE
      )
    } else {
      rec(node$left)
      rec(node$right)
    }
  }
  rec(tree)
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

.ctgp_prepare_prediction_newdata <- function(newdata, prepped) {
  schema <- prepped$schema
  cont_names <- schema$continuous_columns
  qual_names <- schema$qualitative_columns
  response_name <- schema$response_column
  d <- length(cont_names)
  q <- length(qual_names)
  req <- d + q

  if (is.data.frame(newdata)) {
    nd <- newdata
  } else if (is.matrix(newdata)) {
    nd <- as.data.frame(newdata, stringsAsFactors = FALSE, check.names = FALSE)
  } else if (is.vector(newdata) && !is.list(newdata)) {
    if (length(newdata) != req) {
      stop(sprintf("A plain vector must have length %d (continuous + qualitative columns).", req))
    }
    nd <- as.data.frame(as.list(newdata), stringsAsFactors = FALSE, check.names = FALSE)
  } else {
    stop("newdata must be a data.frame, matrix, or a plain vector representing one point.")
  }

  nm <- names(nd)
  if (!is.null(nm)) {
    nm_clean <- make.names(nm, unique = TRUE)
    names(nd) <- nm_clean
    wanted <- c(cont_names, qual_names)
    if (all(wanted %in% nm_clean)) {
      nd <- nd[, wanted, drop = FALSE]
    } else {
      keep <- setdiff(nm_clean, response_name)
      nd2 <- nd[, keep, drop = FALSE]
      if (all(wanted %in% names(nd2))) {
        nd <- nd2[, wanted, drop = FALSE]
      }
    }
  }

  if (ncol(nd) == req + 1L && !is.null(names(nd)) && response_name %in% names(nd)) {
    nd <- nd[, setdiff(names(nd), response_name), drop = FALSE]
  }
  if (ncol(nd) != req) {
    stop(sprintf("newdata must have exactly %d columns (%d continuous + %d qualitative), optionally plus the response column.", req, d, q))
  }
  if (is.null(names(nd))) names(nd) <- c(cont_names, qual_names)
  if (!all(c(cont_names, qual_names) %in% names(nd))) {
    names(nd) <- c(cont_names, qual_names)
  } else {
    nd <- nd[, c(cont_names, qual_names), drop = FALSE]
  }

  cont_df <- nd[, cont_names, drop = FALSE]
  cont_df[] <- lapply(cont_df, function(z) {
    znum <- suppressWarnings(as.numeric(z))
    if (any(!is.finite(znum))) stop("newdata continuous columns must be coercible to finite numeric values.")
    znum
  })

  qual_df <- nd[, qual_names, drop = FALSE]
  train_qual <- prepped$qualitative_data
  qual_df[] <- Map(function(z, train_col) {
    z_chr <- as.character(z)
    lev <- levels(train_col)
    if (any(!z_chr %in% lev)) {
      bad <- unique(z_chr[!z_chr %in% lev])
      stop("newdata contains unseen qualitative levels: ", paste(bad, collapse = ", "))
    }
    factor(z_chr, levels = lev)
  }, qual_df, train_qual)

  combo_key <- apply(as.data.frame(lapply(qual_df, as.character), stringsAsFactors = FALSE), 1, function(z) paste(z, collapse = "||"))
  combined_id <- match(combo_key, prepped$combined_key)
  if (anyNA(combined_id)) {
    stop("newdata contains qualitative combinations not seen during fitting.")
  }

  list(
    data = cbind(cont_df, qual_df),
    continuous_data = cont_df,
    qualitative_data = qual_df,
    combined_id = as.integer(combined_id),
    combo_key = combo_key,
    n = nrow(cont_df)
  )
}

.ctgp_route_prediction_rows <- function(tree, qual_df, row_index = seq_len(nrow(qual_df))) {
  if (isTRUE(tree$is_leaf)) {
    return(list(list(node = tree, rows = as.integer(row_index))))
  }
  split_var <- tree$split_var
  z <- as.character(qual_df[row_index, split_var, drop = TRUE])
  left_rows <- row_index[z %in% as.character(tree$left_levels)]
  right_rows <- row_index[z %in% as.character(tree$right_levels)]
  assigned <- union(left_rows, right_rows)
  if (length(assigned) != length(row_index)) {
    missing_rows <- setdiff(row_index, assigned)
    stop("Failed to route some prediction rows through the ctGP tree at split variable `", split_var, "`. Offending row indices: ", paste(missing_rows, collapse = ", "))
  }
  out <- list()
  if (length(left_rows) > 0L) out <- c(out, .ctgp_route_prediction_rows(tree$left, qual_df, left_rows))
  if (length(right_rows) > 0L) out <- c(out, .ctgp_route_prediction_rows(tree$right, qual_df, right_rows))
  out
}

.ctgp_extract_prediction_components <- function(pred) {
  pred_mean <- pred[["pred_mean"]]
  pred_var <- pred[["pred_var"]]
  pred_sigma_sq <- pred[["pred_sigma_sq"]]

  if (is.null(pred_mean)) stop("Leaf prediction object did not contain `pred_mean`.")
  list(
    pred_mean = as.numeric(pred_mean),
    pred_var = if (is.null(pred_var)) NULL else as.numeric(pred_var),
    pred_sigma_sq = if (is.null(pred_sigma_sq)) NULL else as.matrix(pred_sigma_sq)
  )
}

.ctgp_predict_leaf_block <- function(node, prep_new, fit_object = NULL, indep = FALSE, prediction_control = list()) {
  fit <- node$leaf_fit
  if (is.null(fit)) {
    stop("Final ctGP tree does not contain leaf_fit objects. Run fit_ctgp(..., do_leaf_dispatch = TRUE) or ctgp_dispatch_leaf_models() first.")
  }
  rows <- node$.prediction_rows
  x_new <- prep_new$continuous_data[rows, , drop = FALSE]
  if (!is.null(fit_object) && !is.null(fit_object$prepared$input_normalizer)) {
    x_new <- ctgp_apply_normalizer(x_new, fit_object$prepared$input_normalizer)
  }
  leaf_model <- toupper(as.character(node$leaf_model[[1L]]))

  if (leaf_model %in% c("GP", "GPR")) {
    pred <- predict_gp(fit, x_new, indep = indep, prediction_control = prediction_control)
  } else if (leaf_model %in% c("QQGP", "QQGPR")) {
    local_level <- match(prep_new$combined_id[rows], as.integer(node$combined_ids))
    if (anyNA(local_level)) {
      stop("Prediction rows routed to a mixed leaf contain a combination id not present in that leaf.")
    }
    qq_new <- cbind(x_new, level = as.integer(local_level))
    pred <- predict_qqgp(fit, qq_new, indep = indep, prediction_control = prediction_control)
  } else {
    stop("Unsupported leaf_model on ctGP leaf: ", leaf_model)
  }

  .ctgp_extract_prediction_components(pred)
}

predict_ctgp <- function(object, ...) {
  UseMethod("predict_ctgp")
}

#' @export
predict_ctgp.ctgp_fit <- function(object,
                                  newdata,
                                  indep = FALSE,
                                  prediction_control = list(),
                                  return_leaf_assignment = TRUE,
                                  ...) {
  .t_start <- proc.time()
  final_tree <- object$final_tree
  if (is.null(final_tree)) stop("fit$final_tree is missing.")
  prep_new <- .ctgp_prepare_prediction_newdata(newdata, object$prepared)
  routed <- .ctgp_route_prediction_rows(final_tree, prep_new$qualitative_data)

  n <- prep_new$n
  pred_mean <- rep(NA_real_, n)
  pred_var <- rep(NA_real_, n)
  pred_sigma_sq <- if (isTRUE(indep)) NULL else matrix(0, nrow = n, ncol = n)
  leaf_node_id <- rep(NA_integer_, n)
  leaf_model <- rep(NA_character_, n)

  for (entry in routed) {
    node <- entry$node
    rows <- as.integer(entry$rows)
    node$.prediction_rows <- rows
    pred <- .ctgp_predict_leaf_block(node, prep_new, fit_object = object, indep = indep, prediction_control = prediction_control)
    pred_mean[rows] <- pred$pred_mean
    if (!is.null(pred$pred_var)) {
      pred_var[rows] <- pred$pred_var
    } else if (!is.null(pred$pred_sigma_sq)) {
      pred_var[rows] <- pmax(0, diag(pred$pred_sigma_sq))
    }
    if (!isTRUE(indep)) {
      if (is.null(pred$pred_sigma_sq)) {
        stop("ctGP leaf prediction did not return pred_sigma_sq in full-covariance mode.")
      }
      pred_sigma_sq[rows, rows] <- pred$pred_sigma_sq
    }
    leaf_node_id[rows] <- as.integer(node$node_id)
    leaf_model[rows] <- as.character(node$leaf_model)
  }

  if (anyNA(pred_mean)) stop("Failed to obtain ctGP predictions for one or more rows.")
  if (!is.null(object$prepared$response_normalizer)) {
    tmp_pred <- list(
      pred_mean = pred_mean,
      pred_var = pred_var,
      pred_sigma_sq = pred_sigma_sq
    )
    tmp_pred <- .ctgp_inverse_prediction_scale(tmp_pred, object$prepared$response_normalizer)
    pred_mean <- tmp_pred$pred_mean
    pred_var <- tmp_pred$pred_var
    pred_sigma_sq <- tmp_pred$pred_sigma_sq
  }

  out <- list(
    pred_mean = pred_mean,
    pred_var = pred_var,
    pred_sigma_sq = pred_sigma_sq,
    leaf_node_id = leaf_node_id,
    leaf_model = leaf_model,
    indep = isTRUE(indep),
    n_pred = n,
    prediction_control = prediction_control
  )
  if (isTRUE(return_leaf_assignment)) {
    out$leaf_assignment <- data.frame(
      row_id = seq_len(n),
      leaf_node_id = leaf_node_id,
      leaf_model = leaf_model,
      stringsAsFactors = FALSE
    )
  }
  out$timing <- .ctgp_make_timing(.t_start)
  class(out) <- c("ctgp_prediction", "list")
  out
}

#' @export
predict.ctgp_fit <- function(object, newdata, ...) {
  predict_ctgp(object = object, newdata = newdata, ...)
}

#' @export
print.ctgp_prediction <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("ctGP prediction\n\n")
  cat("Predictions      :", x$n_pred, "\n")
  cat("Independent mode :", isTRUE(x$indep), "\n")
  if (!is.null(x$leaf_assignment)) {
    tab <- table(x$leaf_assignment$leaf_model, useNA = "ifany")
    cat("Leaf models used :", paste(names(tab), tab, sep = " x ", collapse = ", "), "\n")
  }
  invisible(x)
}
