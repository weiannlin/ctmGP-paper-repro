
.ctgp_gpreg_beta_names <- function(object) {
  terms <- NULL
  if (!is.null(object$mean_terms)) {
    terms <- object$mean_terms
  } else if (!is.null(object$f_matrix) && !is.null(colnames(object$f_matrix))) {
    terms <- colnames(object$f_matrix)
  } else if (!is.null(rownames(object$beta_vec))) {
    terms <- rownames(object$beta_vec)
  }
  if (is.null(terms) || length(terms) != length(object$beta_vec)) {
    terms <- paste0("beta[", seq_along(object$beta_vec), "]")
  }
  terms
}

#' @export
print.gp_regression_fit <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("GP regression fit object

")

  data <- x$data
  n <- if (!is.null(data)) nrow(data) else NA_integer_
  p <- if (!is.null(data)) ncol(data) - 1L else NA_integer_
  mean_structure <- if (!is.null(x$mean_structure)) x$mean_structure else "formula: ~1"
  mean_terms <- .ctgp_gpreg_beta_names(x)

  cat("Data:
")
  cat("  Number of observations :", n, "
")
  cat("  Input dimension        :", p, "
")
  if (!is.null(x$x_colnames_used)) cat("  Input names            :", paste(x$x_colnames_used, collapse = ", "), "
")
  cat("
")

  cat("Model:
")
  cat("  Mean structure         :", mean_structure, "
")
  if (!is.null(x$mean_formula)) cat("  Mean formula           :", x$mean_formula, "
")
  cat("  Mean terms             :", paste(mean_terms, collapse = ", "), "
")
  cat("  Correlation            : exp(-sum_j 10^fi_j (x_j - x\'_j)^2)
")
  cat("  Noise model            : estimated nugget

")

  cat("Estimated parameters:
")
  cat("  fi                     :", paste(formatC(as.numeric(x$fi), digits = digits, format = "fg"), collapse = ", "), "
")
  cat("  nugget                 :", formatC(as.numeric(x$nugget), digits = digits, format = "fg"), "
")
  cat("  log10_nugget           :", formatC(as.numeric(x$log10_nugget), digits = digits, format = "fg"), "
")
  if (length(x$beta_vec) == 1L) {
    cat("  beta                   :", formatC(as.numeric(x$beta_vec), digits = digits, format = "fg"), "
")
  } else {
    cat("  beta_vec                :
")
    beta_df <- data.frame(term = mean_terms, estimate = formatC(as.numeric(x$beta_vec), digits = digits, format = "fg"), stringsAsFactors = FALSE)
    print(beta_df, row.names = FALSE, right = FALSE)
  }
  cat("  sigma_sq                :", formatC(as.numeric(x$sigma_sq), digits = digits, format = "fg"), "
")
  cat("  stabilization jitter   :", formatC(as.numeric(x$stabilization_jitter), digits = digits, format = "fg"), "
")
  cat("  effective nugget       :", formatC(as.numeric(x$effective_nugget), digits = digits, format = "fg"), "

")

  cat("Optimization:
")
  cat("  converged              :", x$optim_converged, "
")
  cat("  objective value        :", formatC(as.numeric(x$optim_best_value), digits = digits, format = "fg"), "
")
  cat("  final neg_log_lik        :", formatC(as.numeric(x$neg_log_lik), digits = digits, format = "fg"), "
")
  cat("  function evaluations   :", x$optim_n_eval, "
")

  if (!is.null(x$optimizer_control)) {
    control <- x$optimizer_control
    cat("
Optimizer control:
")
    cat("  swarm_size             :", control$swarm_size, "
")
    cat("  max_iter               :", control$max_iter, "
")
    cat("  c1                     :", formatC(control$c1, digits = digits, format = "fg"), "
")
    cat("  c2                     :", formatC(control$c2, digits = digits, format = "fg"), "
")
    cat("  w                      :", formatC(control$w, digits = digits, format = "fg"), "
")
    cat("  tol                    :", formatC(control$tol, digits = digits, format = "fg"), "
")
    cat("  use_openmp             :", control$use_openmp, "
")
    cat("  num_threads            :", control$num_threads, "
")
    if (!is.null(control$seed)) cat("  seed                   :", control$seed, "
")
  }

  if (!is.null(x$omp)) {
    omp <- x$omp
    cat("
Parallel:
")
    cat("  OpenMP compiled        :", omp$compiled, "
")
    cat("  OpenMP enabled         :", omp$use_openmp, "
")
    cat("  threads requested      :", omp$num_threads_requested, "
")
    cat("  runtime max threads    :", omp$num_threads_runtime_max, "
")
  }

  if (!is.null(x$timing)) {
    cat("
Timing:
")
    cat("  elapsed                :", formatC(as.numeric(x$timing$elapsed), digits = digits, format = "fg"), "seconds
")
    if (!is.null(x$timing$user_self)) cat("  user_self              :", formatC(as.numeric(x$timing$user_self), digits = digits, format = "fg"), "seconds
")
    if (!is.null(x$timing$sys_self)) cat("  sys_self               :", formatC(as.numeric(x$timing$sys_self), digits = digits, format = "fg"), "seconds
")
  }

  invisible(x)
}

#' @export
summary.gp_regression_fit <- function(object, ...) {
  data <- object$data
  n <- if (!is.null(data)) nrow(data) else NA_integer_
  p <- if (!is.null(data)) ncol(data) - 1L else NA_integer_

  out <- list(
    call = match.call(),
    n = n,
    p = p,
    x_colnames_used = object$x_colnames_used,
    mean_source = if (!is.null(object$mean_source)) object$mean_source else "default",
    mean_structure = if (!is.null(object$mean_structure)) object$mean_structure else "formula: ~1",
    mean_formula = object$mean_formula,
    mean_terms = .ctgp_gpreg_beta_names(object),
    fi = object$fi,
    nugget = object$nugget,
    log10_nugget = object$log10_nugget,
    stabilization_jitter = object$stabilization_jitter,
    effective_nugget = object$effective_nugget,
    beta_vec = as.numeric(object$beta_vec),
    sigma_sq = object$sigma_sq,
    neg_log_lik = object$neg_log_lik,
    optim_best_value = object$optim_best_value,
    optim_converged = object$optim_converged,
    optim_n_eval = object$optim_n_eval,
    lower = object$lower,
    upper = object$upper,
    init_param = object$init_param,
    nugget_range = object$nugget_range,
    nugget_init = object$nugget_init,
    timing = object$timing,
    optimizer_control = object$optimizer_control,
    omp = object$omp
  )
  class(out) <- "summary.gp_regression_fit"
  out
}

#' @export
print.summary.gp_regression_fit <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("Summary of GP regression fit

")
  cat("Data:
")
  cat("  Number of observations :", x$n, "
")
  cat("  Input dimension        :", x$p, "
")
  if (!is.null(x$x_colnames_used)) cat("  Input names            :", paste(x$x_colnames_used, collapse = ", "), "
")
  cat("
")

  cat("Model:
")
  cat("  Mean source            :", x$mean_source, "
")
  cat("  Mean structure         :", x$mean_structure, "
")
  if (!is.null(x$mean_formula)) cat("  Mean formula           :", x$mean_formula, "
")
  cat("  Noise model            : estimated nugget

")

  cat("Parameter estimates:
")
  fi_df <- data.frame(parameter = paste0("fi[", seq_along(x$fi), "]"), estimate = formatC(as.numeric(x$fi), digits = digits, format = "fg"), stringsAsFactors = FALSE)
  print(fi_df, row.names = FALSE, right = FALSE)
  cat("
")

  cat("Nugget estimate:
")
  cat("  nugget                 :", formatC(as.numeric(x$nugget), digits = digits, format = "fg"), "
")
  cat("  log10_nugget           :", formatC(as.numeric(x$log10_nugget), digits = digits, format = "fg"), "
")
  cat("  stabilization jitter   :", formatC(as.numeric(x$stabilization_jitter), digits = digits, format = "fg"), "
")
  cat("  effective nugget       :", formatC(as.numeric(x$effective_nugget), digits = digits, format = "fg"), "

")

  cat("Mean parameters:
")
  beta_df <- data.frame(parameter = x$mean_terms, estimate = formatC(as.numeric(x$beta_vec), digits = digits, format = "fg"), stringsAsFactors = FALSE)
  print(beta_df, row.names = FALSE, right = FALSE)
  cat("
")

  cat("Other estimates:
")
  other_df <- data.frame(quantity = c("sigma_sq", "neg_log_lik", "optim objective"), value = formatC(c(x$sigma_sq, x$neg_log_lik, x$optim_best_value), digits = digits, format = "fg"), stringsAsFactors = FALSE)
  print(other_df, row.names = FALSE, right = FALSE)
  cat("
")

  cat("Optimization status:
")
  cat("  converged              :", x$optim_converged, "
")
  cat("  function evaluations   :", x$optim_n_eval, "
")

  if (!is.null(x$optimizer_control)) {
    control <- x$optimizer_control
    cat("
Optimizer control:
")
    ctrl_df <- data.frame(
      setting = c("swarm_size", "max_iter", "c1", "c2", "w", "tol", "use_openmp", "num_threads", if (!is.null(control$seed)) "seed"),
      value = c(control$swarm_size, control$max_iter, control$c1, control$c2, control$w, control$tol, control$use_openmp, control$num_threads, if (!is.null(control$seed)) control$seed),
      stringsAsFactors = FALSE
    )
    print(ctrl_df, row.names = FALSE, right = FALSE)
  }

  if (!is.null(x$omp)) {
    cat("
Parallel:
")
    omp_df <- data.frame(
      setting = c("OpenMP compiled", "OpenMP enabled", "threads requested", "runtime max threads"),
      value = c(x$omp$compiled, x$omp$use_openmp, x$omp$num_threads_requested, x$omp$num_threads_runtime_max),
      stringsAsFactors = FALSE
    )
    print(omp_df, row.names = FALSE, right = FALSE)
  }

  if (!is.null(x$timing)) {
    cat("
Timing:
")
    cat("  elapsed                :", formatC(as.numeric(x$timing$elapsed), digits = digits, format = "fg"), "seconds
")
    if (!is.null(x$timing$user_self)) cat("  user_self              :", formatC(as.numeric(x$timing$user_self), digits = digits, format = "fg"), "seconds
")
    if (!is.null(x$timing$sys_self)) cat("  sys_self               :", formatC(as.numeric(x$timing$sys_self), digits = digits, format = "fg"), "seconds
")
  }

  if (!is.null(x$lower) && !is.null(x$upper) && !is.null(x$init_param)) {
    cat("
Search bounds:
")
    param_names <- c(paste0("fi[", seq_along(x$fi), "]"), "log10_nugget")
    bounds_df <- data.frame(
      parameter = param_names,
      lower = formatC(as.numeric(x$lower), digits = digits, format = "fg"),
      init = formatC(as.numeric(x$init_param), digits = digits, format = "fg"),
      upper = formatC(as.numeric(x$upper), digits = digits, format = "fg"),
      stringsAsFactors = FALSE
    )
    print(bounds_df, row.names = FALSE, right = FALSE)
  }

  invisible(x)
}

#' @export
coef.gp_regression_fit <- function(object, ...) {
  out <- as.numeric(object$beta_vec)
  names(out) <- .ctgp_gpreg_beta_names(object)
  out
}

#' @export
fitted.gp_regression_fit <- function(object, ...) {
  d <- ncol(as.matrix(object$design))
  newdata <- object$data[, seq_len(d), drop = FALSE]
  FPred <- if (!is.null(object$mean_source) && identical(object$mean_source, 'f_matrix')) object$f_matrix else NULL
  as.numeric(predict_gp(object, newdata = newdata, f_matrix = FPred, indep = TRUE)$pred_mean)
}

#' @export
residuals.gp_regression_fit <- function(object, ...) {
  y <- object$data[, ncol(object$data)]
  y - fitted.gp_regression_fit(object, ...)
}
