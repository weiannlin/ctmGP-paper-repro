.ctgp_optimizer_control_defaults <- function(optimizer_control = list()) {
  ctrl <- modifyList(list(
    swarm_size = 64L,
    max_iter = 200L,
    c1 = 2.05,
    c2 = 2.05,
    w = 0.7,
    tol = 1e-6,
    use_openmp = TRUE,
    num_threads = 0L,
    seed = NULL
  ), optimizer_control)

  ctrl$swarm_size <- as.integer(ctrl$swarm_size)
  ctrl$max_iter <- as.integer(ctrl$max_iter)
  ctrl$c1 <- as.numeric(ctrl$c1)
  ctrl$c2 <- as.numeric(ctrl$c2)
  ctrl$w <- as.numeric(ctrl$w)
  ctrl$tol <- as.numeric(ctrl$tol)
  ctrl$use_openmp <- isTRUE(ctrl$use_openmp)
  ctrl$num_threads <- as.integer(ctrl$num_threads)
  ctrl$seed <- if (is.null(ctrl$seed)) -1L else as.integer(ctrl$seed)

  if (!is.finite(ctrl$swarm_size) || ctrl$swarm_size < 1L) stop("optimizer_control$swarm_size must be a positive integer.")
  if (!is.finite(ctrl$max_iter) || ctrl$max_iter < 0L) stop("optimizer_control$max_iter must be a nonnegative integer.")
  if (!is.finite(ctrl$tol) || ctrl$tol < 0) stop("optimizer_control$tol must be a finite nonnegative scalar.")
  ctrl
}

.ctgp_bcd_control_defaults <- function(bcd_control = list()) {
  ctrl <- modifyList(list(
    max_iter = 3L,
    tol = 1e-6
  ), bcd_control)
  ctrl$max_iter <- as.integer(ctrl$max_iter)
  ctrl$tol <- as.numeric(ctrl$tol)

  if (!is.finite(ctrl$max_iter) || ctrl$max_iter < 1L) stop("bcd_control$max_iter must be a positive integer.")
  if (!is.finite(ctrl$tol) || ctrl$tol < 0) stop("bcd_control$tol must be a finite nonnegative scalar.")
  ctrl
}

.ctgp_imputation_control_defaults <- function(imputation_control = list(), optimizer_control = list()) {
  opt <- .ctgp_optimizer_control_defaults(optimizer_control)
  ctrl <- modifyList(list(
    mcmc_samples = 50L,
    use_openmp = opt$use_openmp,
    num_threads = opt$num_threads,
    seed = if (opt$seed < 0L) NULL else opt$seed
  ), imputation_control)
  ctrl$mcmc_samples <- as.integer(ctrl$mcmc_samples)
  ctrl$use_openmp <- isTRUE(ctrl$use_openmp)
  ctrl$num_threads <- as.integer(ctrl$num_threads)
  ctrl$seed <- if (is.null(ctrl$seed)) NULL else as.integer(ctrl$seed)

  if (!is.finite(ctrl$mcmc_samples) || ctrl$mcmc_samples < 1L) stop("imputation_control$mcmc_samples must be a positive integer.")
  ctrl
}


.ctgp_level_table <- function(prepped, level_ids) {
  level_ids <- as.integer(level_ids)
  idx <- match(level_ids, as.integer(prepped$combined_id))
  if (anyNA(idx)) {
    stop("Failed to map one or more level_ids into prepped$combined_id.")
  }
  prepped$qualitative_data[idx, , drop = FALSE]
}

.ctgp_build_legacy_loocv_dispatch <- function(prepped, bcd_object) {
  level_ids <- if (!is.null(bcd_object$common_index) && !is.null(bcd_object$common_index$level_ids)) {
    as.integer(bcd_object$common_index$level_ids)
  } else if (!is.null(bcd_object$union_index) && !is.null(bcd_object$union_index$level_ids)) {
    as.integer(bcd_object$union_index$level_ids)
  } else {
    sort(unique(as.integer(prepped$combined_id)))
  }

  cont_names <- prepped$schema$continuous_columns
  qual_names <- prepped$schema$qualitative_columns
  response_name <- prepped$schema$response_column

  regime_name <- if (inherits(bcd_object, "ctgp_bcd_union") || identical(bcd_object$common_index$regime, "union-imputed")) "union" else "common"

  if (identical(regime_name, "common")) {
    union_data <- prepped$data
    coerce_union_data <- as.data.frame(prepped$coerce_data, stringsAsFactors = FALSE, check.names = FALSE)
    names(coerce_union_data) <- c(cont_names, "c.T", "Y")
    coerce_union_data$c.T <- as.integer(coerce_union_data$c.T)
    coerce_union_data$Y <- as.numeric(coerce_union_data$Y)
    return(list(
      regime = "common-observed",
      level_ids = level_ids,
      level_table = .ctgp_level_table(prepped, level_ids),
      union_data = union_data,
      coerce_union_data = coerce_union_data
    ))
  }

  design_df <- as.data.frame(as.matrix(bcd_object$common_index$common_design), stringsAsFactors = FALSE, check.names = FALSE)
  names(design_df) <- cont_names
  y_matrix <- if (!is.null(bcd_object$y_matrix)) as.matrix(bcd_object$y_matrix) else as.matrix(bcd_object$common_index$y_matrix)
  if (nrow(y_matrix) != nrow(design_df) || ncol(y_matrix) != length(level_ids)) {
    stop("design_matrix / y_matrix / level_ids dimensions are inconsistent for legacy-style LOOCV dispatch.")
  }

  level_table <- .ctgp_level_table(prepped, level_ids)
  len <- nrow(design_df)
  level_num <- nrow(level_table)

  union_data <- cbind(
    design_df[rep(seq_len(len), times = level_num), , drop = FALSE],
    level_table[rep(seq_len(level_num), each = len), , drop = FALSE],
    stats::setNames(data.frame(Y = as.numeric(as.vector(y_matrix))), response_name)
  )
  rownames(union_data) <- NULL
  names(union_data) <- c(cont_names, qual_names, response_name)

  coerce_union_data <- as.data.frame(
    coerce_fun(union_data, design = union_data[, cont_names, drop = FALSE], include_sub_cate = TRUE),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  names(coerce_union_data) <- c(cont_names, "c.T", "Y")
  coerce_union_data$c.T <- as.integer(coerce_union_data$c.T)
  coerce_union_data$Y <- as.numeric(coerce_union_data$Y)

  list(
    regime = "union-imputed",
    level_ids = level_ids,
    level_table = level_table,
    union_data = union_data,
    coerce_union_data = coerce_union_data
  )
}

.ctgp_attach_legacy_loocv_state <- function(bcd_object, prepped) {
  if (!is.null(bcd_object$loocv_dispatch) && !is.null(bcd_object$loocv_dispatch$coerce_union_data)) {
    return(bcd_object)
  }
  dispatch <- .ctgp_build_legacy_loocv_dispatch(prepped, bcd_object)
  bcd_object$loocv_dispatch <- dispatch
  bcd_object$union_data <- dispatch$union_data
  bcd_object$coerce_union_data <- dispatch$coerce_union_data
  bcd_object$level_table <- dispatch$level_table
  bcd_object
}

.ctgp_make_omp_info <- function(use_openmp, num_threads, n_tasks) {
  tryCatch(
    ctgp_openmp_policy_cpp(n_tasks = n_tasks, use_openmp = use_openmp, num_threads = num_threads),
    error = function(e) list(
      omp_compiled = FALSE,
      omp_enabled = FALSE,
      omp_requested_threads = as.integer(num_threads),
      omp_auto_threads = as.integer(num_threads) <= 0L,
      omp_effective_threads = 1L,
      omp_max_threads = 1L,
      omp_recommended_threads = 1L
    )
  )
}


.ctgp_union_bcd_optimizer_control <- function(ctrl, imputation_control = NULL) {
  legacy_allow_union_openmp <- getOption("ctGP.internal.debug.union_bcd_use_openmp", NULL)
  force_union_serial <- isTRUE(getOption("ctGP.internal.force_union_bcd_serial", FALSE))
  allow_union_openmp <- if (!is.null(legacy_allow_union_openmp)) {
    isTRUE(legacy_allow_union_openmp)
  } else {
    !force_union_serial
  }

  ctrl2 <- ctrl
  ctrl2$use_openmp_requested <- isTRUE(ctrl$use_openmp)
  ctrl2$num_threads_requested <- as.integer(ctrl$num_threads)
  ctrl2$union_omp_forced_serial <- FALSE

  imp2 <- imputation_control
  if (!is.null(imp2)) {
    imp2$use_openmp_requested <- isTRUE(imp2$use_openmp)
    imp2$num_threads_requested <- as.integer(imp2$num_threads)
    imp2$union_omp_forced_serial <- FALSE
  }

  if (isTRUE(ctrl$use_openmp) && !allow_union_openmp) {
    ctrl2$use_openmp <- FALSE
    ctrl2$num_threads <- 1L
    ctrl2$union_omp_forced_serial <- TRUE
    if (!is.null(imp2)) {
      imp2$use_openmp <- FALSE
      imp2$num_threads <- 1L
      imp2$union_omp_forced_serial <- TRUE
    }
  }

  list(
    optimizer_control = ctrl2,
    imputation_control = imp2,
    allow_union_openmp = allow_union_openmp
  )
}

.ctgp_global_gp <- function(prepped,
                            init_param = NULL,
                            range = NULL,
                            nugget = NULL,
                            optimizer_control = list()) {
  stopifnot(is.list(prepped), !is.null(prepped$coerce_data))
  ctrl <- .ctgp_optimizer_control_defaults(optimizer_control)

  objective_mode <- .ctgp_resolve_global_objective_mode()
  timing <- system.time({
    out <- ctgp_global_gp_cpp(
      coerce_data = as.matrix(prepped$coerce_data),
      init_param = init_param,
      range = range,
      nugget = nugget,
      swarm_size = ctrl$swarm_size,
      max_iter = ctrl$max_iter,
      c1 = ctrl$c1,
      c2 = ctrl$c2,
      w = ctrl$w,
      tol = ctrl$tol,
      use_openmp = ctrl$use_openmp,
      num_threads = ctrl$num_threads,
      seed = ctrl$seed,
      objective_mode = if (identical(objective_mode, 'legacy_exact')) 1L else 0L
    )
  })

  out$timing <- as.list(timing)
  out$optimizer_control <- ctrl
  out$objective_mode <- objective_mode
  out$search_objective_mode <- objective_mode
  out$schema <- prepped$schema
  out$combined_key <- prepped$combined_key
  out$combined_id <- prepped$combined_id
  out$design <- prepped$design
  out$coerce_data <- prepped$coerce_data
  class(out) <- c("ctgp_global_gp", "list")
  out
}

.ctgp_bcd <- function(prepped,
                      regime = NULL,
                      common_index = NULL,
                      union_index = NULL,
                      init_param = NULL,
                      range = NULL,
                      nugget = NULL,
                      optimizer_control = list(),
                      bcd_control = list(),
                      imputation_control = list(),
                      tol = sqrt(.Machine$double.eps)) {
  stopifnot(is.list(prepped), !is.null(prepped$coerce_data))
  ctrl <- .ctgp_optimizer_control_defaults(optimizer_control)
  bcd <- .ctgp_bcd_control_defaults(bcd_control)
  imp <- .ctgp_imputation_control_defaults(imputation_control, optimizer_control = ctrl)

  if (is.null(regime)) {
    regime <- .ctgp_detect_design_regime(prepped, tol = tol)
  }
  regime_name <- if (is.character(regime)) as.character(regime[[1L]]) else regime$regime
  if (!identical(regime_name, "common") && !identical(regime_name, "union")) {
    stop("`regime` must resolve to either 'common' or 'union'.")
  }

  if (identical(regime_name, "common")) {
    if (is.null(common_index)) {
      common_index <- .ctgp_build_common_index(prepped, regime = regime, tol = tol)
    }

    timing <- system.time({
      out <- ctgp_bcd_cpp(
        coerce_data = as.matrix(prepped$coerce_data),
        regime = "common",
        design = as.matrix(common_index$common_design),
        y_matrix = as.matrix(common_index$y_matrix),
        init_param = init_param,
        range = range,
        nugget = nugget,
        bcd_loops = bcd$max_iter,
        bcd_tol = bcd$tol,
        union_mcmc_samples = imp$mcmc_samples,
        swarm_size = ctrl$swarm_size,
        max_iter = ctrl$max_iter,
        c1 = ctrl$c1,
        c2 = ctrl$c2,
        w = ctrl$w,
        tol = ctrl$tol,
        use_openmp = ctrl$use_openmp,
        num_threads = ctrl$num_threads,
        seed = ctrl$seed
      )
    })

    out$timing <- as.list(timing)
    out$optimizer_control <- ctrl
    out$optimizer_mode <- if (exists('.ctgp_resolve_pso_kernel_mode', mode = 'function')) .ctgp_resolve_pso_kernel_mode() else 'qpso'
    out$objective_mode <- 'legacy_exact'
    out$search_objective_mode <- 'legacy_exact'
    out$imputation_variance_mode <- NA_character_
    out$bcd_control <- bcd
    out$imputation_control <- imp
    out$schema <- prepped$schema
    out$combined_key <- prepped$combined_key
    out$combined_id <- prepped$combined_id
    out$coerce_data <- prepped$coerce_data
    out$common_index <- common_index
    out$union_index <- NULL
    out <- .ctgp_attach_legacy_loocv_state(out, prepped)
    class(out) <- c("ctgp_bcd_common", "list")
    return(out)
  }

  if (is.null(union_index)) {
    union_index <- .ctgp_build_union_index(prepped)
  }

  union_policy <- .ctgp_union_bcd_optimizer_control(ctrl, imputation_control = imp)
  ctrl_union <- union_policy$optimizer_control
  imp_union <- union_policy$imputation_control

  timing <- system.time({
    out <- ctgp_bcd_cpp(
      coerce_data = as.matrix(prepped$coerce_data),
      regime = "union",
      union_design = as.matrix(union_index$union_design),
      level_ids = as.integer(union_index$level_ids),
      group_union_index = union_index$group_union_index,
      init_param = init_param,
      range = range,
      nugget = nugget,
      bcd_loops = bcd$max_iter,
      bcd_tol = bcd$tol,
      union_mcmc_samples = imp_union$mcmc_samples,
      swarm_size = ctrl_union$swarm_size,
      max_iter = ctrl_union$max_iter,
      c1 = ctrl_union$c1,
      c2 = ctrl_union$c2,
      w = ctrl_union$w,
      tol = ctrl_union$tol,
      use_openmp = ctrl_union$use_openmp,
      num_threads = ctrl_union$num_threads,
      seed = ctrl_union$seed
    )
  })

  out$timing <- as.list(timing)
  out$optimizer_control <- ctrl_union
  out$optimizer_control_requested <- ctrl
  out$optimizer_mode <- if (exists('.ctgp_resolve_pso_kernel_mode', mode = 'function')) .ctgp_resolve_pso_kernel_mode() else 'qpso'
  out$objective_mode <- 'legacy_exact'
  out$search_objective_mode <- 'legacy_exact'
  out$imputation_variance_mode <- 'legacy_plugin_gp'
  out$union_omp_forced_serial <- isTRUE(ctrl_union$union_omp_forced_serial)
  out$bcd_control <- bcd
  out$imputation_control <- imp_union
  out$schema <- prepped$schema
  out$combined_key <- prepped$combined_key
  out$combined_id <- prepped$combined_id
  out$data <- prepped$data
  out$design <- prepped$design
  out$continuous_data <- prepped$continuous_data
  out$qualitative_data <- prepped$qualitative_data
  out$y <- prepped$y
  out$coerce_data <- prepped$coerce_data
  out$common_index <- list(
    common_design = union_index$union_design,
    y_matrix = out$y_matrix,
    n_common = nrow(union_index$union_design),
    n_levels = length(union_index$level_ids),
    level_ids = union_index$level_ids,
    row_order = NULL,
    regime = "union-imputed"
  )
  out$coerce_data <- prepped$coerce_data
  out$union_index <- union_index
  out <- .ctgp_attach_legacy_loocv_state(out, prepped)
  class(out) <- c("ctgp_bcd_union", "list")
  out
}

.ctgp_bcd_common <- function(prepped,
                             common_index = NULL,
                             init_param = NULL,
                             range = NULL,
                             nugget = NULL,
                             optimizer_control = list(),
                             bcd_control = list(),
                             tol = sqrt(.Machine$double.eps)) {
  if (is.null(common_index)) {
    regime <- .ctgp_detect_design_regime(prepped, tol = tol)
    common_index <- .ctgp_build_common_index(prepped, regime = regime, tol = tol)
  }
  .ctgp_bcd(
    prepped = prepped,
    regime = list(regime = "common"),
    common_index = common_index,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = bcd_control,
    imputation_control = list(),
    tol = tol
  )
}

.ctgp_impute_union <- function(prepped,
                               union_index = NULL,
                               init_param = NULL,
                               range = NULL,
                               nugget = NULL,
                               optimizer_control = list(),
                               imputation_control = list(),
                               union_control = list(),
                               union_mode = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional"),
                               tol = sqrt(.Machine$double.eps)) {
  union_mode <- .ctgp_resolve_union_mode(union_mode)
  if (identical(union_mode, "conditional_missing_only")) {
    out <- ctgp_union_impute(
      prepped = prepped,
      union_index = union_index,
      init_param = init_param,
      range = range,
      nugget = nugget,
      optimizer_control = optimizer_control,
      union_control = utils::modifyList(list(mode = "conditional_missing_only", conditioning_mode = "missing_only"), union_control),
      imputation_control = imputation_control,
      preprocessing_tol = tol
    )
    out$union_mode_selected <- "conditional_missing_only"
    out$deterministic_route <- .ctgp_union_deterministic_route("conditional_missing_only")
    out$workflow_family <- "deterministic"
    return(out)
  }

  if (is.null(union_index)) union_index <- .ctgp_build_union_index(prepped)
  ctrl <- .ctgp_optimizer_control_defaults(optimizer_control)
  imp <- .ctgp_imputation_control_defaults(imputation_control, optimizer_control = ctrl)

  bcd_obj <- .ctgp_bcd(
    prepped = prepped,
    regime = list(regime = "union"),
    union_index = union_index,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = ctrl,
    bcd_control = list(max_iter = 1L, tol = 0),
    imputation_control = imp,
    tol = tol
  )

  out <- list(
    union_design = union_index$union_design,
    level_ids = union_index$level_ids,
    y_matrix_observed = bcd_obj$y_matrix_observed,
    y_matrix = bcd_obj$y_matrix,
    missing_mask = bcd_obj$missing_mask,
    n_imputed = if (is.null(bcd_obj$missing_mask)) 0L else sum(bcd_obj$missing_mask),
    group_union_index = union_index$group_union_index,
    optimizer_control = ctrl,
    imputation_control = imp,
    timing = bcd_obj$timing,
    mc_samples = bcd_obj$mc_samples,
    level_fi_matrix = bcd_obj$level_fi_matrix,
    union_mode_selected = "fullgrid_exported",
    deterministic_route = .ctgp_union_deterministic_route("fullgrid_exported"),
    workflow_family = "deterministic",
    bcd_object = bcd_obj
  )
  class(out) <- c("ctgp_union_imputation", "list")
  out
}

.ctgp_global_stage <- function(prepped,
                               init_param = NULL,
                               range = NULL,
                               nugget = NULL,
                               optimizer_control = list(),
                               bcd_control = list(),
                               imputation_control = list(),
                               union_control = list(),
                               union_mode = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional"),
                               allow_union_imputation = TRUE,
                               tol = sqrt(.Machine$double.eps)) {
  prepped <- if (inherits(prepped, "ctgp_prepared_data")) prepped else prepped
  regime <- .ctgp_detect_design_regime(prepped, tol = tol)
  union_mode <- .ctgp_resolve_union_mode(union_mode)
  global_fit <- .ctgp_global_gp(
    prepped,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control
  )

  if (identical(regime$regime, "common")) {
    common_index <- .ctgp_build_common_index(prepped, regime = regime, tol = tol)
    bcd <- .ctgp_bcd(
      prepped,
      regime = regime,
      common_index = common_index,
      init_param = global_fit$fi,
      range = range,
      nugget = nugget,
      optimizer_control = optimizer_control,
      bcd_control = bcd_control,
      imputation_control = imputation_control,
      tol = tol
    )
    return(list(
      prepared = prepped,
      regime = regime,
      global_gp = global_fit,
      common_index = common_index,
      union_index = NULL,
      union_imputation = NULL,
      bcd = bcd,
      success = TRUE,
      union_mode_selected = NA_character_,
      deterministic_route = "common_observed",
      workflow_family = "deterministic",
      message = "common-design deterministic ctGP stage completed"
    ))
  }

  union_index <- .ctgp_build_union_index(prepped)
  if (!isTRUE(allow_union_imputation)) {
    return(list(
      prepared = prepped,
      regime = regime,
      global_gp = global_fit,
      common_index = NULL,
      union_index = union_index,
      union_imputation = NULL,
      bcd = NULL,
      success = TRUE,
      union_mode_selected = union_mode,
      deterministic_route = "union_disabled",
      workflow_family = "deterministic",
      message = "union-design detected, but deterministic union completion was disabled by allow_union_imputation = FALSE"
    ))
  }

  if (identical(union_mode, "conditional_missing_only")) {
    out <- ctgp_union_stage(
      prepped = prepped,
      init_param = init_param,
      range = range,
      nugget = nugget,
      optimizer_control = optimizer_control,
      bcd_control = bcd_control,
      union_control = utils::modifyList(list(mode = "conditional_missing_only", conditioning_mode = "missing_only"), union_control),
      imputation_control = imputation_control,
      preprocessing_tol = tol,
      global_fit = global_fit
    )
    out$union_mode_selected <- "conditional_missing_only"
    out$deterministic_route <- .ctgp_union_deterministic_route("conditional_missing_only")
    out$workflow_family <- "deterministic"
    return(out)
  }

  bcd <- .ctgp_bcd(
    prepped,
    regime = regime,
    union_index = union_index,
    init_param = global_fit$fi,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = bcd_control,
    imputation_control = imputation_control,
    tol = tol
  )

  union_imputation <- list(
    union_design = union_index$union_design,
    level_ids = union_index$level_ids,
    y_matrix_observed = bcd$y_matrix_observed,
    y_matrix = bcd$y_matrix,
    missing_mask = bcd$missing_mask,
    n_imputed = if (is.null(bcd$missing_mask)) 0L else sum(bcd$missing_mask),
    group_union_index = union_index$group_union_index,
    optimizer_control = bcd$optimizer_control,
    imputation_control = bcd$imputation_control,
    timing = bcd$timing,
    mc_samples = bcd$mc_samples,
    level_fi_matrix = bcd$level_fi_matrix,
    union_mode_selected = "fullgrid_exported",
    deterministic_route = .ctgp_union_deterministic_route("fullgrid_exported"),
    workflow_family = "deterministic",
    bcd_object = bcd
  )

  list(
    prepared = prepped,
    regime = regime,
    global_gp = global_fit,
    common_index = bcd$common_index,
    union_index = union_index,
    union_imputation = union_imputation,
    bcd = bcd,
    success = TRUE,
    union_mode_selected = "fullgrid_exported",
    deterministic_route = .ctgp_union_deterministic_route("fullgrid_exported"),
    workflow_family = "deterministic",
    message = "union-design deterministic ctGP stage completed with the exported full-grid union route"
  )
}
