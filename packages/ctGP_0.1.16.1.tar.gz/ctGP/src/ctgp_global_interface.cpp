#include <RcppArmadillo.h>
#include <cmath>
// [[Rcpp::depends(RcppArmadillo)]]

#include "ctgp_global_core.h"
#include "optimizer_pso.h"
#include "gp_model.h"
#include "ctgp_rcpp_utils.h"

namespace {

void resolve_nugget_spec(SEXP nuggetSEXP, bool& nugget_provided, double& nugget_value) {
  nugget_provided = !sexp_is_null(nuggetSEXP);
  nugget_value = 0.0;
  if (nugget_provided) {
    nugget_value = Rcpp::as<double>(nuggetSEXP);
    if (!std::isfinite(nugget_value) || nugget_value < 0.0) {
      Rcpp::stop("nugget must be NULL or a finite nonnegative scalar.");
    }
  }
}

Rcpp::List resolve_global_bounds(
    const arma::mat& design,
    Rcpp::Nullable<arma::vec> range,
    int d
) {
  if (nullable_is_not_null(range)) {
    arma::vec range_vec = Rcpp::as<arma::vec>(range);
    if ((int)range_vec.n_elem != 2 * d) {
      Rcpp::stop("range must have length 2 * conti_dim.");
    }
    return Rcpp::List::create(
      Rcpp::Named("lower") = range_vec.subvec(0, d - 1),
      Rcpp::Named("upper") = range_vec.subvec(d, 2 * d - 1)
    );
  }
  return ctgp_default_global_bounds(design);
}

arma::vec resolve_init_param(
    Rcpp::Nullable<arma::vec> init_param,
    const arma::vec& lower,
    const arma::vec& upper,
    int d
) {
  arma::vec init;
  if (nullable_is_not_null(init_param)) {
    init = Rcpp::as<arma::vec>(init_param);
    if ((int)init.n_elem != d) {
      Rcpp::stop("init_param must have length conti_dim.");
    }
  } else {
    init = 0.8 * upper + 0.2 * lower;
  }

  for (int j = 0; j < d; ++j) {
    if (init(j) < lower(j)) init(j) = lower(j);
    if (init(j) > upper(j)) init(j) = upper(j);
  }
  return init;
}

Rcpp::List make_omp_runtime_info(bool use_openmp, int requested_threads, int n_tasks) {
  const bool compiled = ctgp_openmp_compiled();
  const int max_threads = ctgp_openmp_max_threads_runtime();
  const bool auto_threads = (requested_threads <= 0);
  const int effective_threads = ctgp_openmp_resolve_threads(use_openmp, requested_threads, n_tasks);
  const int recommended_threads = ctgp_openmp_recommended_threads(n_tasks);

  return Rcpp::List::create(
    Rcpp::Named("omp_compiled") = compiled,
    Rcpp::Named("omp_enabled") = (compiled && use_openmp),
    Rcpp::Named("omp_requested_threads") = requested_threads,
    Rcpp::Named("omp_auto_threads") = auto_threads,
    Rcpp::Named("omp_effective_threads") = effective_threads,
    Rcpp::Named("omp_max_threads") = max_threads,
    Rcpp::Named("omp_recommended_threads") = recommended_threads
  );
}

std::vector<int> parse_level_ids(SEXP level_idsSEXP) {
  std::vector<int> out;
  if (sexp_is_null(level_idsSEXP)) {
    return out;
  }
  Rcpp::IntegerVector ids(level_idsSEXP);
  out.reserve(ids.size());
  for (int i = 0; i < ids.size(); ++i) {
    out.push_back(ids[i]);
  }
  return out;
}

std::vector<arma::uvec> parse_group_union_index(SEXP group_union_indexSEXP) {
  std::vector<arma::uvec> out;
  if (sexp_is_null(group_union_indexSEXP)) {
    return out;
  }
  Rcpp::List idx_list(group_union_indexSEXP);
  out.reserve(idx_list.size());
  for (int i = 0; i < idx_list.size(); ++i) {
    Rcpp::IntegerVector idx_i = idx_list[i];
    arma::uvec ui(idx_i.size());
    for (int j = 0; j < idx_i.size(); ++j) {
      if (idx_i[j] < 1) {
        Rcpp::stop("group_union_index must be a list of 1-based positive integer vectors.");
      }
      ui(j) = static_cast<arma::uword>(idx_i[j] - 1);
    }
    out.push_back(ui);
  }
  return out;
}


arma::mat add_diag_local(const arma::mat& x, double val) {
  arma::mat out = x;
  if (std::isfinite(val) && val > 0.0) {
    out.diag() += val;
  }
  return out;
}

arma::mat solve_sympd_chol_local(const arma::mat& A) {
  arma::mat L;
  arma::mat sym = 0.5 * (A + A.t());
  if (!arma::chol(L, sym, "lower")) {
    return arma::mat();
  }
  arma::mat I = arma::eye<arma::mat>(A.n_rows, A.n_cols);
  return arma::solve(arma::trimatu(L.t()), arma::solve(arma::trimatl(L), I));
}

Rcpp::List ctgp_loocv_impl(
    const arma::mat& design,
    const arma::mat& y_matrix,
    const arma::vec& fi,
    const arma::vec& mu_vec,
    Rcpp::Nullable<arma::mat> tau_matrix,
    bool nugget_provided,
    double nugget_value
) {
  if (design.n_rows < 1 || design.n_cols < 1) {
    Rcpp::stop("design must be a non-empty numeric matrix.");
  }
  if (y_matrix.n_rows != design.n_rows || y_matrix.n_cols < 1) {
    Rcpp::stop("y_matrix must have the same number of rows as design and at least one column.");
  }
  if (mu_vec.n_elem != y_matrix.n_cols) {
    Rcpp::stop("mu_vec must have length ncol(y_matrix).");
  }
  if (fi.n_elem != design.n_cols) {
    Rcpp::stop("fi must have length ncol(design).");
  }

  arma::mat H_base = build_corr_matrix(design, fi, 0.0);
  const double h_nugget = nugget_provided ? nugget_value : ctgp_compute_nugget_tb(H_base, 1e8);
  arma::mat H_effective = add_diag_local(H_base, h_nugget);
  H_effective = 0.5 * (H_effective + H_effective.t());
  arma::mat H_inv = solve_sympd_chol_local(H_effective);
  if (H_inv.n_elem == 0) {
    Rcpp::stop("Failed to invert the ctGP H matrix in ctgp_loocv_cpp().");
  }

  arma::mat mu_matrix(y_matrix.n_rows, y_matrix.n_cols, arma::fill::zeros);
  for (arma::uword j = 0; j < y_matrix.n_cols; ++j) {
    mu_matrix.col(j).fill(mu_vec(j));
  }
  arma::mat Yc = y_matrix - mu_matrix;

  bool used_tau = false;
  double t_nugget = 0.0;
  arma::mat residual_matrix(y_matrix.n_rows, y_matrix.n_cols, arma::fill::zeros);

  if (nullable_is_not_null(tau_matrix) && y_matrix.n_cols > 1) {
    arma::mat T_base = Rcpp::as<arma::mat>(tau_matrix);
    if (T_base.n_rows != y_matrix.n_cols || T_base.n_cols != y_matrix.n_cols) {
      Rcpp::stop("tau_matrix must be square with dimension ncol(y_matrix).");
    }
    T_base = 0.5 * (T_base + T_base.t());
    t_nugget = ctgp_compute_nugget_tb(T_base, 1e8);
    arma::mat T_effective = add_diag_local(T_base, t_nugget);
    T_effective = 0.5 * (T_effective + T_effective.t());
    arma::mat T_inv = solve_sympd_chol_local(T_effective);
    if (T_inv.n_elem == 0) {
      Rcpp::stop("Failed to invert the ctGP tau matrix in ctgp_loocv_cpp().");
    }

    arma::mat Z = H_inv * Yc * T_inv;
    arma::vec diag_H = H_inv.diag();
    arma::vec diag_T = T_inv.diag();
    for (arma::uword j = 0; j < y_matrix.n_cols; ++j) {
      arma::vec denom = diag_H * diag_T(j);
      for (arma::uword i = 0; i < denom.n_elem; ++i) {
        if (!std::isfinite(denom(i)) || std::abs(denom(i)) <= std::numeric_limits<double>::epsilon()) {
          Rcpp::stop("Encountered a non-finite or near-zero ctGP LOOCV denominator.");
        }
      }
      residual_matrix.col(j) = Z.col(j) / denom;
    }
    used_tau = true;
  } else {
    arma::vec diag_H = H_inv.diag();
    arma::vec z = H_inv * Yc.col(0);
    for (arma::uword i = 0; i < diag_H.n_elem; ++i) {
      if (!std::isfinite(diag_H(i)) || std::abs(diag_H(i)) <= std::numeric_limits<double>::epsilon()) {
        Rcpp::stop("Encountered a non-finite or near-zero ctGP LOOCV denominator.");
      }
    }
    residual_matrix.col(0) = z / diag_H;
  }

  const double loocv_sse = arma::accu(arma::square(residual_matrix));
  return Rcpp::List::create(
    Rcpp::Named("loocv_sse") = loocv_sse,
    Rcpp::Named("loocv_residual_matrix") = residual_matrix,
    Rcpp::Named("h_nugget") = h_nugget,
    Rcpp::Named("t_nugget") = t_nugget,
    Rcpp::Named("used_tau") = used_tau,
    Rcpp::Named("tau_dim") = static_cast<int>(y_matrix.n_cols)
  );
}

}  // namespace

// [[Rcpp::export]]
Rcpp::List ctgp_global_gp_cpp(
    const arma::mat& coerce_data,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> range = R_NilValue,
    SEXP nugget = R_NilValue,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1,
    int objective_mode = 1
) {
  if (coerce_data.n_cols < 3) {
    Rcpp::stop("coerce_data must contain x columns, c.T, and Y.");
  }
  const int d = static_cast<int>(coerce_data.n_cols) - 2;
  arma::mat design = coerce_data.cols(0, d - 1);

  bool nugget_provided = false;
  double nugget_value = 0.0;
  resolve_nugget_spec(nugget, nugget_provided, nugget_value);

  Rcpp::List bds = resolve_global_bounds(design, range, d);
  arma::vec lower = Rcpp::as<arma::vec>(bds["lower"]);
  arma::vec upper = Rcpp::as<arma::vec>(bds["upper"]);
  arma::vec init = resolve_init_param(init_param, lower, upper, d);

  const int objective_mode_resolved = gp_resolve_objective_mode_int(objective_mode);
  const std::string objective_mode_label = gp_objective_mode_label(objective_mode_resolved);
  const int optimizer_mode_resolved = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);
  const std::string optimizer_mode_label = ctgp_internal_pso_kernel_mode_label(optimizer_mode_resolved);

  ctgp_global_gp_fit_result fit = ctgp_global_gp_fit_core(
    coerce_data,
    nugget_provided,
    nugget_value,
    lower,
    upper,
    init,
    swarm_size,
    max_iter,
    c1,
    c2,
    w,
    tol,
    use_openmp,
    num_threads,
    seed,
    objective_mode_resolved
  );

  if (!fit.success) {
    Rcpp::stop(fit.message);
  }

  const int n_tasks = std::max(1, swarm_size);
  const Rcpp::List omp_info = make_omp_runtime_info(use_openmp, num_threads, n_tasks);

  return Rcpp::List::create(
    Rcpp::Named("fi") = fit.fi,
    Rcpp::Named("lower") = fit.lower,
    Rcpp::Named("upper") = fit.upper,
    Rcpp::Named("init_param") = fit.init,
    Rcpp::Named("objective") = fit.objective,
    Rcpp::Named("n_eval") = fit.n_eval,
    Rcpp::Named("converged") = fit.converged,
    Rcpp::Named("nugget") = nugget_provided ? Rcpp::wrap(nugget_value) : R_NilValue,
    Rcpp::Named("objective_mode") = objective_mode_label,
    Rcpp::Named("search_objective_mode") = objective_mode_label,
    Rcpp::Named("optimizer_mode") = optimizer_mode_label,
    Rcpp::Named("omp") = omp_info
  );
}

// [[Rcpp::export]]
Rcpp::List ctgp_bcd_cpp(
    const arma::mat& coerce_data,
    std::string regime = "common",
    Rcpp::Nullable<arma::mat> design = R_NilValue,
    Rcpp::Nullable<arma::mat> y_matrix = R_NilValue,
    Rcpp::Nullable<arma::mat> union_design = R_NilValue,
    SEXP level_ids = R_NilValue,
    SEXP group_union_index = R_NilValue,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> range = R_NilValue,
    SEXP nugget = R_NilValue,
    int bcd_loops = 3,
    double bcd_tol = 1e-6,
    int union_mcmc_samples = 50,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1
) {
  if (coerce_data.n_cols < 3) {
    Rcpp::stop("coerce_data must contain x columns, c.T, and Y.");
  }
  const bool is_union = (regime == "union");
  if (!(regime == "common" || regime == "union")) {
    Rcpp::stop("regime must be either 'common' or 'union'.");
  }

  arma::mat design_use;
  arma::mat y_use;
  arma::mat union_design_use;
  std::vector<int> level_ids_use;
  std::vector<arma::uvec> group_union_index_use;

  if (is_union) {
    if (!nullable_is_not_null(union_design)) {
      Rcpp::stop("union_design must be supplied when regime = 'union'.");
    }
    union_design_use = Rcpp::as<arma::mat>(union_design);
    if (union_design_use.n_cols < 1) {
      Rcpp::stop("union_design must have at least one quantitative column.");
    }
    level_ids_use = parse_level_ids(level_ids);
    group_union_index_use = parse_group_union_index(group_union_index);
    if (level_ids_use.empty() || group_union_index_use.empty()) {
      Rcpp::stop("level_ids and group_union_index must be supplied when regime = 'union'.");
    }
  } else {
    if (!nullable_is_not_null(design) || !nullable_is_not_null(y_matrix)) {
      Rcpp::stop("design and y_matrix must be supplied when regime = 'common'.");
    }
    design_use = Rcpp::as<arma::mat>(design);
    y_use = Rcpp::as<arma::mat>(y_matrix);
    if ((int)design_use.n_rows != (int)y_use.n_rows) {
      Rcpp::stop("design and y_matrix must have the same number of rows.");
    }
  }

  const int d = is_union ? static_cast<int>(union_design_use.n_cols) : static_cast<int>(design_use.n_cols);

  bool nugget_provided = false;
  double nugget_value = 0.0;
  resolve_nugget_spec(nugget, nugget_provided, nugget_value);

  Rcpp::List bds = resolve_global_bounds(is_union ? union_design_use : design_use, range, d);
  arma::vec lower = Rcpp::as<arma::vec>(bds["lower"]);
  arma::vec upper = Rcpp::as<arma::vec>(bds["upper"]);
  arma::vec init = resolve_init_param(init_param, lower, upper, d);
  const bool init_provided = nullable_is_not_null(init_param);

  Rcpp::List out = ctgp_bcd_loop_core(
    regime,
    coerce_data,
    design_use,
    y_use,
    union_design_use,
    level_ids_use,
    group_union_index_use,
    nugget_provided,
    nugget_value,
    lower,
    upper,
    init,
    init_provided,
    bcd_loops,
    bcd_tol,
    union_mcmc_samples,
    swarm_size,
    max_iter,
    c1,
    c2,
    w,
    tol,
    use_openmp,
    num_threads,
    seed
  );

  const int n_tasks = std::max(1, swarm_size);
  out["omp"] = make_omp_runtime_info(use_openmp, num_threads, n_tasks);
  return out;
}

// [[Rcpp::export]]
Rcpp::List ctgp_bcd_common_cpp(
    const arma::mat& coerce_data,
    const arma::mat& design,
    const arma::mat& y_matrix,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> range = R_NilValue,
    SEXP nugget = R_NilValue,
    int bcd_loops = 3,
    double bcd_tol = 1e-6,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1
) {
  if (coerce_data.n_cols < 3) {
    Rcpp::stop("coerce_data must contain x columns, c.T, and Y.");
  }
  const int d = static_cast<int>(design.n_cols);

  bool nugget_provided = false;
  double nugget_value = 0.0;
  resolve_nugget_spec(nugget, nugget_provided, nugget_value);

  Rcpp::List bds = resolve_global_bounds(design, range, d);
  arma::vec lower = Rcpp::as<arma::vec>(bds["lower"]);
  arma::vec upper = Rcpp::as<arma::vec>(bds["upper"]);
  arma::vec init = resolve_init_param(init_param, lower, upper, d);
  const bool init_provided = nullable_is_not_null(init_param);

  Rcpp::List out = ctgp_bcd_common_loop_core(
    coerce_data,
    design,
    y_matrix,
    nugget_provided,
    nugget_value,
    lower,
    upper,
    init,
    init_provided,
    bcd_loops,
    bcd_tol,
    swarm_size,
    max_iter,
    c1,
    c2,
    w,
    tol,
    use_openmp,
    num_threads,
    seed
  );

  const int n_tasks = std::max(1, swarm_size);
  out["omp"] = make_omp_runtime_info(use_openmp, num_threads, n_tasks);
  return out;
}

// [[Rcpp::export]]
Rcpp::List ctgp_loocv_cpp(
    const arma::mat& design,
    const arma::mat& y_matrix,
    const arma::vec& fi,
    const arma::vec& mu_vec,
    Rcpp::Nullable<arma::mat> tau_matrix = R_NilValue,
    SEXP nugget = R_NilValue
) {
  bool nugget_provided = false;
  double nugget_value = 0.0;
  resolve_nugget_spec(nugget, nugget_provided, nugget_value);
  return ctgp_loocv_impl(design, y_matrix, fi, mu_vec, tau_matrix, nugget_provided, nugget_value);
}
