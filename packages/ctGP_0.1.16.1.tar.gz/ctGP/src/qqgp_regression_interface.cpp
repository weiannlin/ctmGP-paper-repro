#include <RcppArmadillo.h>
#include <cmath>
// [[Rcpp::depends(RcppArmadillo)]]

#include "optimizer_pso.h"
#include "qqgp_model.h"
#include "ctgp_rcpp_utils.h"
#include "qqgp_regression_model.h"

namespace {

arma::mat qqgpreg_resolve_training_f_matrix(
    Rcpp::Nullable<arma::mat> f_matrix,
    int n_rows,
    const arma::mat& f_default,
    const char* context
) {
  arma::mat f_matrix_resolved = f_default;
  if (nullable_is_not_null(f_matrix)) {
    f_matrix_resolved = Rcpp::as<arma::mat>(f_matrix);
  }

  if ((int)f_matrix_resolved.n_rows != n_rows) {
    Rcpp::stop(std::string(context) + ": f_matrix must have the same number of rows as the training data.");
  }
  if ((int)f_matrix_resolved.n_cols < 1) {
    Rcpp::stop(std::string(context) + ": f_matrix must have at least one column.");
  }
  if (!f_matrix_resolved.is_finite()) {
    Rcpp::stop(std::string(context) + ": f_matrix must contain only finite numeric values.");
  }

  return f_matrix_resolved;
}

}

// [[Rcpp::export]]
Rcpp::List fit_qqgp_regression_cpp(
    const arma::mat& design,
    const arma::mat& data,
    Rcpp::Nullable<arma::vec> init_param = R_NilValue,
    Rcpp::Nullable<arma::vec> fi_range = R_NilValue,
    Rcpp::Nullable<arma::vec> theta_range = R_NilValue,
    Rcpp::Nullable<arma::mat> t_matrix = R_NilValue,
    Rcpp::Nullable<double> nugget_init = R_NilValue,
    Rcpp::Nullable<arma::vec> nugget_range = R_NilValue,
    Rcpp::Nullable<arma::mat> f_matrix = R_NilValue,
    int swarm_size = 64,
    int max_iter = 200,
    double c1 = 2.05,
    double c2 = 2.05,
    double w = 0.7,
    double tol = 1e-6,
    bool use_openmp = true,
    int num_threads = 0,
    int seed = -1
) {
  if (data.n_cols < 3) {
    Rcpp::stop("QQGP regression data must have continuous columns, one categorical level column, and one response column.");
  }

  const arma::uword d = design.n_cols;
  if (data.n_cols != (d + 2u)) {
    Rcpp::stop("For QQGP regression, data must have conti_dim continuous columns plus one level column plus one response column.");
  }

  arma::mat design_use = design;
  arma::uvec level_index = arma::conv_to<arma::uvec>::from(data.col(d));
  arma::vec y = data.col(d + 1);

  unsigned int level_num = arma::max(level_index);
  if (level_num < 1) {
    Rcpp::stop("Categorical level index must start from 1.");
  }

  arma::mat f_default = qqgp_build_f_matrix(level_index, static_cast<int>(level_num));
  arma::mat f_matrix_use = qqgpreg_resolve_training_f_matrix(f_matrix, data.n_rows, f_default, "fit_qqgp_regression_cpp");

  Rcpp::List default_bds = qqgp_default_bounds(design_use, level_num);
  arma::vec fi_lower = Rcpp::as<arma::vec>(default_bds["fi_lower"]);
  arma::vec fi_upper = Rcpp::as<arma::vec>(default_bds["fi_upper"]);

  arma::vec fi_low = fi_lower;
  arma::vec fi_upp = fi_upper;
  if (nullable_is_not_null(fi_range)) {
    arma::vec fi_range_vec = Rcpp::as<arma::vec>(fi_range);
    if (fi_range_vec.n_elem != (2u * d)) {
      Rcpp::stop("fi_range must have length 2 * conti_dim.");
    }
    fi_low = fi_range_vec.subvec(0, d - 1);
    fi_upp = fi_range_vec.subvec(d, 2 * d - 1);
  }

  arma::vec fi_init;
  if (nullable_is_not_null(init_param)) {
    fi_init = Rcpp::as<arma::vec>(init_param);
    if (fi_init.n_elem != d) {
      Rcpp::stop("init_param must have length conti_dim.");
    }
  } else {
    fi_init = 0.8 * fi_upp + 0.2 * fi_low;
  }

  double nugget_low;
  double nugget_upp;
  double nugget_init_val;
  if (nullable_is_not_null(nugget_range)) {
    arma::vec nr = Rcpp::as<arma::vec>(nugget_range);
    if ((int)nr.n_elem != 2) {
      Rcpp::stop("nugget_range must have length 2.");
    }
    nugget_low = nr(0);
    nugget_upp = nr(1);
  } else {
    Rcpp::List nb = qqgpreg_default_nugget_spec(y);
    nugget_low = Rcpp::as<double>(nb["lower"]);
    nugget_upp = Rcpp::as<double>(nb["upper"]);
  }
  if (!(std::isfinite(nugget_low) && std::isfinite(nugget_upp) && nugget_low > 0.0 && nugget_upp > nugget_low)) {
    Rcpp::stop("nugget_range must satisfy 0 < lower < upper.");
  }
  if (nullable_is_not_null(nugget_init)) {
    nugget_init_val = Rcpp::as<double>(nugget_init);
  } else {
    nugget_init_val = std::sqrt(nugget_low * nugget_upp);
  }
  if (!(std::isfinite(nugget_init_val) && nugget_init_val > 0.0)) {
    Rcpp::stop("nugget_init must be a positive finite scalar.");
  }
  if (nugget_init_val < nugget_low || nugget_init_val > nugget_upp) {
    Rcpp::stop("nugget_init must lie within nugget_range.");
  }

  bool fixed_t = nullable_is_not_null(t_matrix);
  int theta_dim = static_cast<int>(level_num * (level_num - 1) / 2);
  const int kernel_mode_resolved = ctgp_internal_pso_kernel_mode_from_option(PSO_KERNEL_STABLE);
  const bool globpso_exact_kernel = (kernel_mode_resolved == PSO_KERNEL_GLOBPSO_EXACT);

  arma::vec lower;
  arma::vec upper;
  arma::vec init_full;

  if (!fixed_t) {
    double theta_low = 1e-6;
    double theta_upp = arma::datum::pi - 1e-6;
    if (nullable_is_not_null(theta_range)) {
      arma::vec theta_range_vec = Rcpp::as<arma::vec>(theta_range);
      if ((int)theta_range_vec.n_elem != 2) {
        Rcpp::stop("theta_range must have length 2.");
      }
      theta_low = theta_range_vec(0);
      theta_upp = theta_range_vec(1);
      const bool theta_ok = globpso_exact_kernel
        ? (std::isfinite(theta_low) && std::isfinite(theta_upp) && theta_low >= 0.0 && theta_upp <= arma::datum::pi && theta_low < theta_upp)
        : (std::isfinite(theta_low) && std::isfinite(theta_upp) && theta_low > 0.0 && theta_upp < arma::datum::pi && theta_low < theta_upp);
      if (!theta_ok) {
        if (globpso_exact_kernel) {
          Rcpp::stop("theta_range must satisfy 0 <= lower < upper <= pi under globpso_exact mode.");
        }
        Rcpp::stop("theta_range must satisfy 0 < lower < upper < pi.");
      }
    }

    lower = arma::vec(d + theta_dim + 1, arma::fill::zeros);
    upper = arma::vec(d + theta_dim + 1, arma::fill::zeros);
    init_full = arma::vec(d + theta_dim + 1, arma::fill::zeros);

    lower.subvec(0, d - 1) = fi_low;
    upper.subvec(0, d - 1) = fi_upp;
    init_full.subvec(0, d - 1) = fi_init;

    if (theta_dim > 0) {
      lower.subvec(d, d + theta_dim - 1).fill(theta_low);
      upper.subvec(d, d + theta_dim - 1).fill(theta_upp);
      init_full.subvec(d, d + theta_dim - 1).fill(0.8 * theta_upp + 0.2 * theta_low);
    }

    lower(d + theta_dim) = std::log10(nugget_low);
    upper(d + theta_dim) = std::log10(nugget_upp);
    init_full(d + theta_dim) = std::log10(nugget_init_val);

    pso_control control;
    control.kernel_mode = kernel_mode_resolved;
    control.swarm_size = swarm_size;
    control.max_iter = max_iter;
    control.c1 = c1;
    control.c2 = c2;
    control.w = w;
    control.tol = tol;
    control.use_openmp = use_openmp;
    control.num_threads = num_threads;
    control.seed = seed;

    qqgp_regression_likelihood_objective obj(design_use, level_index, y, static_cast<int>(level_num), f_matrix_use);
    pso_optimizer optimizer(control);
    optim_result opt = optimizer.minimize(obj, lower, upper, init_full);

    arma::vec fi_hat = opt.best_par.subvec(0, d - 1);
    arma::vec theta_hat(theta_dim, arma::fill::zeros);
    if (theta_dim > 0) theta_hat = opt.best_par.subvec(d, d + theta_dim - 1);
    double nugget_hat = std::pow(10.0, opt.best_par(d + theta_dim));

    qqgp_regression_profile_result fit = qqgpreg_profile_fit(design_use, level_index, y, fi_hat, theta_hat, nugget_hat, f_matrix_use);
    if (!fit.success) {
      Rcpp::stop("Final QQGP regression fit failed. Try changing fi_range, theta_range, nugget_range, or mean design.");
    }

    return Rcpp::List::create(
      Rcpp::Named("fi") = fi_hat,
      Rcpp::Named("theta") = theta_hat,
      Rcpp::Named("log10_nugget") = opt.best_par(d + theta_dim),
      Rcpp::Named("nugget") = fit.nugget,
      Rcpp::Named("stabilization_jitter") = fit.stabilization_jitter,
      Rcpp::Named("effective_nugget") = fit.effective_nugget,
      Rcpp::Named("design") = design_use,
      Rcpp::Named("data") = data,
      Rcpp::Named("t_matrix") = fit.t_matrix,
      Rcpp::Named("l_matrix") = fit.l_matrix,
      Rcpp::Named("alpha_vec") = fit.alpha_vec,
      Rcpp::Named("f_matrix") = fit.f_matrix,
      Rcpp::Named("beta_vec") = fit.beta_vec,
      Rcpp::Named("sigma_sq") = fit.sigma_sq,
      Rcpp::Named("neg_log_lik") = fit.neg_log_lik,
      Rcpp::Named("optim_best_value") = opt.best_value,
      Rcpp::Named("optim_history") = opt.history,
      Rcpp::Named("optim_n_eval") = opt.n_eval,
      Rcpp::Named("optim_converged") = opt.converged,
      Rcpp::Named("lower") = lower,
      Rcpp::Named("upper") = upper,
      Rcpp::Named("init_param") = init_full,
      Rcpp::Named("level_num") = level_num,
      Rcpp::Named("nugget_range") = arma::vec({nugget_low, nugget_upp}),
      Rcpp::Named("nugget_init") = nugget_init_val,
      Rcpp::Named("mean_is_default") = (
        fit.f_matrix.n_cols == static_cast<arma::uword>(level_num) &&
        fit.f_matrix.n_cols >= 1
      )
    );
  }

  arma::mat t_matrix_fixed = Rcpp::as<arma::mat>(t_matrix);
  if ((int)t_matrix_fixed.n_rows != (int)level_num || (int)t_matrix_fixed.n_cols != (int)level_num) {
    Rcpp::stop("t_matrix must be a square matrix with dimension equal to the number of levels.");
  }

  lower = arma::vec(d + 1, arma::fill::zeros);
  upper = arma::vec(d + 1, arma::fill::zeros);
  init_full = arma::vec(d + 1, arma::fill::zeros);

  lower.subvec(0, d - 1) = fi_low;
  upper.subvec(0, d - 1) = fi_upp;
  init_full.subvec(0, d - 1) = fi_init;
  lower(d) = std::log10(nugget_low);
  upper(d) = std::log10(nugget_upp);
  init_full(d) = std::log10(nugget_init_val);

  pso_control control;
  control.kernel_mode = kernel_mode_resolved;
  control.swarm_size = swarm_size;
  control.max_iter = max_iter;
  control.c1 = c1;
  control.c2 = c2;
  control.w = w;
  control.tol = tol;
  control.use_openmp = use_openmp;
  control.num_threads = num_threads;
  control.seed = seed;

  qqgp_regression_likelihood_objective obj(design_use, level_index, y, static_cast<int>(level_num), f_matrix_use, t_matrix_fixed);
  pso_optimizer optimizer(control);
  optim_result opt = optimizer.minimize(obj, lower, upper, init_full);

  arma::vec fi_hat = opt.best_par.subvec(0, d - 1);
  double nugget_hat = std::pow(10.0, opt.best_par(d));

  qqgp_regression_profile_result fit = qqgpreg_profile_fit_fixed_t(design_use, level_index, y, fi_hat, t_matrix_fixed, nugget_hat, f_matrix_use);
  if (!fit.success) {
    Rcpp::stop("Final QQGP regression fit failed. Try changing fi_range, nugget_range, or mean design.");
  }

  return Rcpp::List::create(
    Rcpp::Named("fi") = fi_hat,
    Rcpp::Named("theta") = R_NilValue,
    Rcpp::Named("log10_nugget") = opt.best_par(d),
    Rcpp::Named("nugget") = fit.nugget,
    Rcpp::Named("stabilization_jitter") = fit.stabilization_jitter,
    Rcpp::Named("effective_nugget") = fit.effective_nugget,
    Rcpp::Named("design") = design_use,
    Rcpp::Named("data") = data,
    Rcpp::Named("t_matrix") = fit.t_matrix,
    Rcpp::Named("l_matrix") = fit.l_matrix,
    Rcpp::Named("alpha_vec") = fit.alpha_vec,
    Rcpp::Named("f_matrix") = fit.f_matrix,
    Rcpp::Named("beta_vec") = fit.beta_vec,
    Rcpp::Named("sigma_sq") = fit.sigma_sq,
    Rcpp::Named("neg_log_lik") = fit.neg_log_lik,
    Rcpp::Named("optim_best_value") = opt.best_value,
    Rcpp::Named("optim_history") = opt.history,
    Rcpp::Named("optim_n_eval") = opt.n_eval,
    Rcpp::Named("optim_converged") = opt.converged,
    Rcpp::Named("lower") = lower,
    Rcpp::Named("upper") = upper,
    Rcpp::Named("init_param") = init_full,
    Rcpp::Named("level_num") = level_num,
    Rcpp::Named("nugget_range") = arma::vec({nugget_low, nugget_upp}),
    Rcpp::Named("nugget_init") = nugget_init_val,
    Rcpp::Named("mean_is_default") = (
      fit.f_matrix.n_cols == static_cast<arma::uword>(level_num) &&
      fit.f_matrix.n_cols >= 1
    )
  );
}
