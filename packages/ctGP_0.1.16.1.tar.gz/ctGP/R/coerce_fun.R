coerce_fun <- function(data, design, include_sub_cate = TRUE) {
  if (missing(data) || missing(design)) {
    stop("Both `data` and `design` must be provided.")
  }

  original_data_names <- colnames(data)
  original_design_names <- colnames(design)

  data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  design <- as.data.frame(design, stringsAsFactors = FALSE, check.names = FALSE)

  if (nrow(data) != nrow(design)) {
    stop("`data` and `design` must have the same number of rows.")
  }
  if (ncol(design) < 1L) {
    stop("`design` must contain at least one continuous variable.")
  }
  if (ncol(data) < ncol(design) + 2L) {
    stop("`data` must contain continuous variables, at least one categorical column, and one response column.")
  }

  contiDim <- ncol(design)
  data_names <- names(data)
  if (is.null(data_names)) {
    data_names <- rep("", ncol(data))
  }

  design_names_clean <- NULL
  conti_idx <- NULL

  if (!is.null(original_design_names) && length(original_design_names) == contiDim &&
      all(!is.na(original_design_names)) && all(original_design_names != "")) {
    design_names_clean <- make.names(original_design_names, unique = TRUE)
    if (!is.null(original_data_names) && length(original_data_names) == ncol(data)) {
      data_names_clean <- make.names(original_data_names, unique = TRUE)
      if (all(design_names_clean %in% data_names_clean)) {
        conti_idx <- match(design_names_clean, data_names_clean)
      }
    }
  }

  if (is.null(conti_idx)) {
    conti_idx <- seq_len(contiDim)

    if (!is.null(original_design_names) && length(original_design_names) == contiDim &&
        all(!is.na(original_design_names)) && all(original_design_names != "")) {
      design_names_clean <- make.names(original_design_names, unique = TRUE)
    } else if (!is.null(original_data_names) && length(original_data_names) >= contiDim &&
               all(!is.na(original_data_names[conti_idx])) && all(original_data_names[conti_idx] != "")) {
      design_names_clean <- make.names(original_data_names[conti_idx], unique = TRUE)
    } else {
      design_names_clean <- paste0("x", seq_len(contiDim))
    }
  }

  remaining_idx <- setdiff(seq_len(ncol(data)), conti_idx)
  if (length(remaining_idx) < 2L) {
    stop("`data` must contain at least one categorical column and one response column after removing continuous columns.")
  }

  response_aliases <- c("Y", "y", "response", "Response", "output", "Output")
  response_idx <- integer(0)

  remaining_names <- if (!is.null(original_data_names)) original_data_names[remaining_idx] else data_names[remaining_idx]
  if (!is.null(remaining_names)) {
    matched_alias <- which(tolower(remaining_names) %in% tolower(response_aliases))
    if (length(matched_alias) == 1L) {
      response_idx <- remaining_idx[matched_alias]
    }
  }

  if (length(response_idx) == 0L) {
    is_cate_like <- vapply(data[remaining_idx], function(z) is.factor(z) || is.character(z), logical(1))
    numeric_like_idx <- remaining_idx[!is_cate_like]
    if (length(numeric_like_idx) >= 1L) {
      response_idx <- tail(numeric_like_idx, 1L)
    } else {
      response_idx <- tail(remaining_idx, 1L)
    }
  }

  cate_idx <- setdiff(remaining_idx, response_idx)
  if (length(cate_idx) < 1L) {
    stop("No categorical columns found in `data` after identifying the response column.")
  }

  contiData <- data[conti_idx]
  names(contiData) <- design_names_clean
  contiData[] <- lapply(contiData, function(z) as.numeric(z))
  if (any(!vapply(contiData, function(z) all(is.finite(z)), logical(1)))) {
    stop("Continuous columns contain non-finite values after coercion to numeric.")
  }

  yVec <- as.numeric(data[[response_idx]])
  if (any(!is.finite(yVec))) {
    stop("Response column contains non-finite values after coercion to numeric.")
  }

  cateData <- data[cate_idx]
  cate_names <- if (!is.null(original_data_names)) original_data_names[cate_idx] else names(cateData)
  if (is.null(cate_names) || any(is.na(cate_names)) || any(cate_names == "")) {
    cate_names <- paste0("c", seq_along(cate_idx))
  }
  cate_names <- make.names(cate_names, unique = TRUE)
  names(cateData) <- cate_names

  cateData_chr <- lapply(cateData, function(z) {
    if (is.factor(z)) {
      as.character(z)
    } else if (is.character(z)) {
      z
    } else {
      as.character(z)
    }
  })
  cateData_chr <- as.data.frame(cateData_chr, stringsAsFactors = FALSE, check.names = FALSE)

  levelKey <- apply(cateData_chr, 1, function(z) paste(z, collapse = "||"))
  levelKeyUnique <- unique(levelKey)
  levelVec <- match(levelKey, levelKeyUnique)

  returnData <- cbind(
    data.frame(contiData, check.names = FALSE),
    c.T = levelVec,
    Y = yVec
  )

  response_name <- if (!is.null(original_data_names) && length(original_data_names) >= response_idx &&
                       !is.na(original_data_names[response_idx]) && original_data_names[response_idx] != "") {
    original_data_names[response_idx]
  } else {
    "Y"
  }

  attr(returnData, "continuous_columns") <- design_names_clean
  attr(returnData, "categorical_columns") <- cate_names
  attr(returnData, "response_column") <- response_name
  attr(returnData, "level_key") <- levelKeyUnique

  if (include_sub_cate) {
    return(returnData)
  }

  list(
    returnData = returnData[, c(design_names_clean, "Y"), drop = FALSE],
    levelVec = levelVec,
    level_key = levelKeyUnique,
    categorical_columns = cate_names,
    continuous_columns = design_names_clean,
    response_column = response_name
  )
}
