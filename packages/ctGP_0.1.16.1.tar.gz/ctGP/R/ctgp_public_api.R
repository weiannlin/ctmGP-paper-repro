ctgp_prepare_data <- function(data,
                              design = NULL,
                              response = NULL,
                              quantitative = NULL,
                              qualitative = NULL) {
  .ctgp_prepare_data(
    data = data,
    design = design,
    response = response,
    quantitative = quantitative,
    qualitative = qualitative
  )
}

ctgp_detect_design_regime <- function(prepped, preprocessing_tol = 1e-8) {
  .ctgp_detect_design_regime(prepped, tol = preprocessing_tol)
}

ctgp_build_common_index <- function(prepped, regime = NULL, preprocessing_tol = 1e-8) {
  .ctgp_build_common_index(prepped, regime = regime, tol = preprocessing_tol)
}

ctgp_build_union_index <- function(prepped) {
  .ctgp_build_union_index(prepped)
}

ctgp_global_stage <- function(prepped,
                              init_param = NULL,
                              range = NULL,
                              nugget = NULL,
                              optimizer_control = list(),
                              bcd_control = list(),
                              imputation_control = list(),
                              union_control = list(),
                              union_mode = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional"),
                              allow_union_imputation = TRUE,
                              preprocessing_tol = 1e-8,
                              backend = c("cpp", "auto", "legacy"),
                              legacy_parallel = FALSE) {
  backend <- match.arg(backend)
  union_mode <- .ctgp_resolve_union_mode(union_mode)
  if (identical(backend, "auto")) {
    backend <- "cpp"
  }
  if (identical(backend, "legacy")) {
    return(.ctgp_global_stage_legacy(
      prepped = prepped,
      init_param = init_param,
      range = range,
      nugget = nugget,
      optimizer_control = optimizer_control,
      bcd_control = bcd_control,
      imputation_control = imputation_control,
      allow_union_imputation = allow_union_imputation,
      tol = preprocessing_tol,
      legacy_parallel = legacy_parallel
    ))
  }
  (.ctgp_global_stage(
    prepped = prepped,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = bcd_control,
    imputation_control = imputation_control,
    union_control = union_control,
    union_mode = union_mode,
    allow_union_imputation = allow_union_imputation,
    tol = preprocessing_tol
  ))
}

ctgp_bcd <- function(prepped,
                     regime = NULL,
                     common_index = NULL,
                     union_index = NULL,
                     init_param = NULL,
                     range = NULL,
                     nugget = NULL,
                     optimizer_control = list(),
                     bcd_control = list(),
                     imputation_control = list(),
                     preprocessing_tol = 1e-8,
                     backend = c("cpp", "auto", "legacy"),
                     legacy_parallel = FALSE) {
  backend <- match.arg(backend)
  if (identical(backend, "auto")) {
    backend <- "cpp"
  }
  if (identical(backend, "legacy")) {
    stage <- .ctgp_global_stage_legacy(
      prepped = prepped,
      init_param = init_param,
      range = range,
      nugget = nugget,
      optimizer_control = optimizer_control,
      bcd_control = bcd_control,
      imputation_control = imputation_control,
      allow_union_imputation = TRUE,
      tol = preprocessing_tol,
      legacy_parallel = legacy_parallel
    )
    return(stage$bcd)
  }
  (.ctgp_bcd(
    prepped = prepped,
    regime = regime,
    common_index = common_index,
    union_index = union_index,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    bcd_control = bcd_control,
    imputation_control = imputation_control,
    tol = preprocessing_tol
  ))
}

ctgp_impute_union <- function(prepped,
                              union_index = NULL,
                              init_param = NULL,
                              range = NULL,
                              nugget = NULL,
                              optimizer_control = list(),
                              imputation_control = list(),
                              union_control = list(),
                              union_mode = c("fullgrid_exported", "conditional_missing_only", "exported", "conditional"),
                              preprocessing_tol = 1e-8) {
  union_mode <- .ctgp_resolve_union_mode(union_mode)
  (.ctgp_impute_union(
    prepped = prepped,
    union_index = union_index,
    init_param = init_param,
    range = range,
    nugget = nugget,
    optimizer_control = optimizer_control,
    imputation_control = imputation_control,
    union_control = union_control,
    union_mode = union_mode,
    tol = preprocessing_tol
  ))
}

ctgp_find_best_split <- function(prepped,
                                 tau_matrix,
                                 node_mask = rep(TRUE, nrow(prepped$data)),
                                 min_rows = 1L,
                                 min_combined = 1L,
                                 use_openmp = TRUE,
                                 num_threads = 0L,
                                 backend = c("cpp", "auto", "legacy"),
                                 use_abs_tau = .ctgp_default_split_use_abs_tau()) {
  backend <- match.arg(backend)
  if (identical(backend, "auto")) {
    backend <- "cpp"
  }
  .ctgp_find_best_split(
    prepped = prepped,
    tau_matrix = tau_matrix,
    node_mask = node_mask,
    min_rows = min_rows,
    min_combined = min_combined,
    use_openmp = use_openmp,
    num_threads = num_threads,
    backend = backend,
    use_abs_tau = use_abs_tau
  )
}

ctgp_grow_tree <- function(prepped,
                           tau_matrix,
                           node_mask = rep(TRUE, nrow(prepped$data)),
                           node_id = 1L,
                           parent_id = NULL,
                           depth = 0L,
                           max_depth = NULL,
                           min_rows = 1L,
                           min_combined = 1L,
                           use_openmp = TRUE,
                           num_threads = 0L,
                           backend = c("cpp", "auto", "legacy"),
                           use_abs_tau = .ctgp_default_split_use_abs_tau(),
                           legacy_tree = NULL) {
  backend <- match.arg(backend)
  if (identical(backend, "auto")) {
    backend <- if (!is.null(legacy_tree)) "legacy" else "cpp"
  }
  if (identical(backend, "legacy") && !is.null(legacy_tree)) {
    tree <- .ctgp_tree_from_legacy_big_tree(prepped = prepped, legacy_tree_big = legacy_tree)
  } else {
    tree <- .ctgp_grow_tree(
      prepped = prepped,
      tau_matrix = tau_matrix,
      node_mask = node_mask,
      node_id = node_id,
      parent_id = parent_id,
      depth = depth,
      max_depth = max_depth,
      min_rows = min_rows,
      min_combined = min_combined,
      use_openmp = use_openmp,
      num_threads = num_threads,
      backend = backend,
      use_abs_tau = use_abs_tau
    )
  }
  attr(tree, "tree_stage") <- "grown"
  attr(tree, "is_pruned") <- FALSE
  attr(tree, "split_rule") <- if (identical(backend, "legacy")) {
    if (isTRUE(use_abs_tau)) {
      "legacy recursive splitting with absolute tau (paper max-min |corr|)"
    } else {
      "legacy recursive splitting (TBGP max-min corr)"
    }
  } else if (isTRUE(use_abs_tau)) {
    if (is.null(max_depth)) {
      "cpp recursive splitting with absolute tau (paper max-min |corr|)"
    } else {
      paste0("cpp recursive splitting with absolute tau (paper max-min |corr|, max_depth = ", as.integer(max_depth), ")")
    }
  } else if (is.null(max_depth)) {
    "cpp recursive splitting with raw tau (TBGP max-min corr)"
  } else {
    paste0("cpp recursive splitting with raw tau (TBGP max-min corr, max_depth = ", as.integer(max_depth), ")")
  }
  attr(tree, "growth_control") <- list(
    max_depth = if (is.null(max_depth)) NULL else as.integer(max_depth),
    min_rows = as.integer(min_rows),
    min_combined = as.integer(min_combined),
    backend = backend,
    use_abs_tau = isTRUE(use_abs_tau)
  )
  attr(tree, "data_summary") <- .ctgp_tree_data_summary(prepped)
  if (!is.null(legacy_tree)) attr(tree, "legacy_tree_big") <- legacy_tree
  class(tree) <- c("ctgp_tree", class(tree))
  tree
}

ctgp_flatten_tree <- function(tree) {
  .ctgp_flatten_tree(tree)
}

