.ctgp_safe_rcond <- function(mat) {
  if (is.null(mat)) return(NA_real_)
  out <- tryCatch(as.numeric(rcond(mat)), error = function(e) NA_real_)
  if (length(out) != 1L || is.na(out) || !is.finite(out)) return(NA_real_)
  out
}

.ctgp_safe_rank <- function(mat) {
  if (is.null(mat)) return(NA_integer_)
  out <- tryCatch(as.integer(qr(mat)$rank), error = function(e) NA_integer_)
  if (length(out) != 1L || is.na(out)) return(NA_integer_)
  out
}

.ctgp_symmetrize <- function(mat) {
  if (is.null(mat)) return(NULL)
  0.5 * (mat + t(mat))
}

.ctgp_safe_eigen_summary <- function(mat, eigen_limit = 250L) {
  if (is.null(mat)) {
    return(list(
      computed = FALSE,
      min = NA_real_,
      max = NA_real_,
      ratio = NA_real_,
      note = "matrix is NULL"
    ))
  }

  nr <- nrow(mat)
  nc <- ncol(mat)
  if (is.null(nr) || is.null(nc) || nr != nc) {
    return(list(
      computed = FALSE,
      min = NA_real_,
      max = NA_real_,
      ratio = NA_real_,
      note = "matrix is not square"
    ))
  }

  if (nr > eigen_limit) {
    return(list(
      computed = FALSE,
      min = NA_real_,
      max = NA_real_,
      ratio = NA_real_,
      note = sprintf("skipped because dimension %d exceeds eigen_limit %d", nr, eigen_limit)
    ))
  }

  vals <- tryCatch(
    eigen(.ctgp_symmetrize(mat), symmetric = TRUE, only.values = TRUE)$values,
    error = function(e) NULL
  )
  if (is.null(vals) || length(vals) < 1L || any(!is.finite(vals))) {
    return(list(
      computed = FALSE,
      min = NA_real_,
      max = NA_real_,
      ratio = NA_real_,
      note = "eigen decomposition failed"
    ))
  }

  eig_min <- min(vals)
  eig_max <- max(vals)
  eig_ratio <- if (isTRUE(eig_min > 0)) eig_max / eig_min else NA_real_

  list(
    computed = TRUE,
    min = as.numeric(eig_min),
    max = as.numeric(eig_max),
    ratio = as.numeric(eig_ratio),
    note = "ok"
  )
}

.ctgp_matrix_diagnostics <- function(mat, label, eigen_limit = 250L) {
  eig <- .ctgp_safe_eigen_summary(mat, eigen_limit = eigen_limit)
  rc <- .ctgp_safe_rcond(mat)
  diag_range <- c(NA_real_, NA_real_)
  if (!is.null(mat) && nrow(mat) == ncol(mat) && nrow(mat) > 0L) {
    dd <- diag(mat)
    diag_range <- c(min(dd), max(dd))
  }

  list(
    label = label,
    nrow = if (is.null(mat)) NA_integer_ else nrow(mat),
    ncol = if (is.null(mat)) NA_integer_ else ncol(mat),
    rcond = rc,
    condition_estimate = if (is.na(rc) || rc <= 0) Inf else 1 / rc,
    diag_min = diag_range[1],
    diag_max = diag_range[2],
    eigen_computed = eig$computed,
    eig_min = eig$min,
    eig_max = eig$max,
    eig_ratio = eig$ratio,
    eigen_note = eig$note
  )
}

.ctgp_chol_solve <- function(L, B) {
  Bm <- as.matrix(B)
  out <- backsolve(t(L), forwardsolve(L, Bm))
  if (is.null(dim(B))) {
    out[, 1L]
  } else {
    out
  }
}

.ctgp_gp_correlation_matrix <- function(design, fi, nugget = 0) {
  design <- as.matrix(design)
  storage.mode(design) <- "double"
  d <- ncol(design)
  n <- nrow(design)
  theta <- 10^as.numeric(fi)

  if (n == 1L) {
    H <- matrix(1, nrow = 1L, ncol = 1L)
  } else {
    scaled <- sweep(design, 2L, sqrt(theta), `*`)
    D <- as.matrix(stats::dist(scaled))
    H <- exp(-(D ^ 2))
    diag(H) <- 1
  }

  if (!is.null(nugget) && is.finite(nugget) && nugget > 0) {
    diag(H) <- diag(H) + nugget
  }

  H
}

.ctgp_qqgp_h_matrix <- function(design, fi) {
  .ctgp_gp_correlation_matrix(design, fi, nugget = 0)
}

.ctgp_qqgp_r_matrix <- function(H, t_matrix, level_index, nugget = 0) {
  level_index <- as.integer(level_index)
  if (any(level_index < 1L) || any(level_index > nrow(t_matrix))) {
    stop("level_index contains values outside 1, ..., nrow(t_matrix).")
  }
  T_lookup <- t_matrix[level_index, level_index, drop = FALSE]
  R <- H * T_lookup
  if (!is.null(nugget) && is.finite(nugget) && nugget > 0) {
    diag(R) <- diag(R) + nugget
  }
  R
}

.ctgp_matrix_diag_lookup <- function(diag_list, name) {
  if (is.null(diag_list) || is.null(diag_list[[name]])) return(NA_real_)
  diag_list[[name]]$rcond
}

.ctgp_is_deterministic_leaf <- function(object) {
  cls <- class(object)[1L]
  identical(cls, "gp_fit") || identical(cls, "qqgp_fit")
}

.ctgp_response_scale_summary <- function(y) {
  y <- as.numeric(y)
  y <- y[is.finite(y)]
  if (length(y) < 1L) {
    return(list(
      mean = NA_real_,
      sd = NA_real_,
      range = NA_real_,
      abs_mean = NA_real_
    ))
  }

  y_sd <- if (length(y) > 1L) stats::sd(y) else 0
  y_range <- diff(range(y))
  y_abs_mean <- mean(abs(y))

  list(
    mean = mean(y),
    sd = as.numeric(y_sd),
    range = as.numeric(y_range),
    abs_mean = as.numeric(y_abs_mean)
  )
}

.ctgp_safe_ratio <- function(num, den) {
  if (length(den) != 1L || is.na(den) || !is.finite(den) || den <= 0) return(NA_real_)
  as.numeric(num) / as.numeric(den)
}

.ctgp_training_prediction_single <- function(object, prediction_control = NULL, mode = NA_character_) {
  cls <- class(object)
  data <- as.matrix(object$data)
  if (is.null(data)) {
    return(list(
      mode = mode,
      success = FALSE,
      message = "fit object does not contain training data.",
      prediction_control = prediction_control
    ))
  }

  if (inherits(object, "gp_fit") && !inherits(object, "gp_regression_fit")) {
    d <- ncol(data) - 1L
    newdata <- data[, seq_len(d), drop = FALSE]
    y_true <- data[, d + 1L]
    if (is.null(prediction_control)) {
      prediction_control <- list(use_nugget = "none", variance_mode = "universal")
    }
    pred <- tryCatch(
      predict_gp(object, newdata, indep = TRUE, prediction_control = prediction_control),
      error = identity
    )
  } else if (inherits(object, "gp_regression_fit")) {
    d <- ncol(data) - 1L
    newdata <- data[, seq_len(d), drop = FALSE]
    y_true <- data[, d + 1L]
    if (is.null(prediction_control)) {
      prediction_control <- list(variance_mode = "universal")
    }
    pred <- tryCatch(
      predict_gp(object, newdata, indep = TRUE, prediction_control = prediction_control),
      error = identity
    )
  } else if (inherits(object, "qqgp_fit") && !inherits(object, "qqgp_regression_fit")) {
    d <- ncol(as.matrix(object$design))
    newdata <- data[, seq_len(d + 1L), drop = FALSE]
    y_true <- data[, d + 2L]
    if (is.null(prediction_control)) {
      prediction_control <- list(use_nugget = "none", variance_mode = "universal")
    }
    pred <- tryCatch(
      predict_qqgp(object, newdata, indep = TRUE, prediction_control = prediction_control),
      error = identity
    )
  } else if (inherits(object, "qqgp_regression_fit")) {
    d <- ncol(as.matrix(object$design))
    newdata <- data[, seq_len(d + 1L), drop = FALSE]
    y_true <- data[, d + 2L]
    if (is.null(prediction_control)) {
      prediction_control <- list(variance_mode = "universal")
    }
    pred <- tryCatch(
      predict_qqgp(object, newdata, indep = TRUE, prediction_control = prediction_control),
      error = identity
    )
  } else {
    return(list(
      mode = mode,
      success = FALSE,
      message = paste("Unsupported class:", paste(cls, collapse = ", ")),
      prediction_control = prediction_control
    ))
  }

  if (inherits(pred, "error")) {
    return(list(
      mode = mode,
      success = FALSE,
      message = conditionMessage(pred),
      prediction_control = prediction_control
    ))
  }

  err <- as.numeric(pred$pred_mean) - as.numeric(y_true)
  pred_var <- as.numeric(pred$pred_var)
  max_abs_error <- max(abs(err))
  rmse <- sqrt(mean(err ^ 2))
  mean_abs_error <- mean(abs(err))
  max_predvar <- max(pred_var)
  mean_predvar <- mean(pred_var)
  y_scale <- .ctgp_response_scale_summary(y_true)

  list(
    mode = mode,
    success = TRUE,
    message = NA_character_,
    prediction_control = pred$prediction_control,
    variance_mode = pred$variance_mode,
    response_mean = y_scale$mean,
    response_sd = y_scale$sd,
    response_range = y_scale$range,
    response_abs_mean = y_scale$abs_mean,
    max_abs_error = max_abs_error,
    rmse = rmse,
    mean_abs_error = mean_abs_error,
    max_predvar = max_predvar,
    mean_predvar = mean_predvar,
    max_abs_error_over_sd = .ctgp_safe_ratio(max_abs_error, y_scale$sd),
    rmse_over_sd = .ctgp_safe_ratio(rmse, y_scale$sd),
    mean_abs_error_over_sd = .ctgp_safe_ratio(mean_abs_error, y_scale$sd),
    max_abs_error_over_range = .ctgp_safe_ratio(max_abs_error, y_scale$range),
    rmse_over_range = .ctgp_safe_ratio(rmse, y_scale$range),
    mean_abs_error_over_range = .ctgp_safe_ratio(mean_abs_error, y_scale$range)
  )
}

.ctgp_training_prediction_suite <- function(object, prediction_control = NULL) {
  if (!is.null(prediction_control)) {
    looks_like_suite <- is.list(prediction_control) &&
      length(prediction_control) > 0L &&
      !is.null(names(prediction_control)) &&
      all(nzchar(names(prediction_control))) &&
      all(vapply(prediction_control, is.list, logical(1)))

    controls <- if (isTRUE(looks_like_suite)) prediction_control else list(user = prediction_control)
  } else if (.ctgp_is_deterministic_leaf(object)) {
    controls <- list(
      strict_no_nugget = list(use_nugget = "none", variance_mode = "universal"),
      effective_system = list(use_nugget = "effective", variance_mode = "universal")
    )
  } else {
    controls <- list(
      fitted_system = list(variance_mode = "universal")
    )
  }

  results <- lapply(names(controls), function(mode_name) {
    .ctgp_training_prediction_single(object, prediction_control = controls[[mode_name]], mode = mode_name)
  })
  names(results) <- names(controls)

  primary_mode <- names(results)[1L]
  primary <- results[[primary_mode]]

  list(
    mode_order = names(results),
    primary_mode = primary_mode,
    modes = results,
    any_success = any(vapply(results, function(x) isTRUE(x$success), logical(1))),
    success = isTRUE(primary$success),
    message = if (isTRUE(primary$success)) NA_character_ else primary$message,
    prediction_control = primary$prediction_control,
    variance_mode = primary$variance_mode,
    max_abs_error = if (isTRUE(primary$success)) primary$max_abs_error else NA_real_,
    rmse = if (isTRUE(primary$success)) primary$rmse else NA_real_,
    mean_abs_error = if (isTRUE(primary$success)) primary$mean_abs_error else NA_real_,
    max_predvar = if (isTRUE(primary$success)) primary$max_predvar else NA_real_,
    mean_predvar = if (isTRUE(primary$success)) primary$mean_predvar else NA_real_
  )
}

.ctgp_training_prediction_mode <- function(tp, mode) {
  if (is.null(tp) || is.null(tp$modes) || is.null(tp$modes[[mode]])) return(NULL)
  tp$modes[[mode]]
}

.ctgp_flatten_matrix_diagnostics <- function(out, prefix, diag_obj) {
  out[[paste0(prefix, "_rcond")]] <- diag_obj$rcond
  out[[paste0(prefix, "_condition_estimate")]] <- diag_obj$condition_estimate
  out[[paste0(prefix, "_diag_min")]] <- diag_obj$diag_min
  out[[paste0(prefix, "_diag_max")]] <- diag_obj$diag_max
  out[[paste0(prefix, "_eig_min")]] <- diag_obj$eig_min
  out[[paste0(prefix, "_eig_max")]] <- diag_obj$eig_max
  out[[paste0(prefix, "_eig_ratio")]] <- diag_obj$eig_ratio
  out[[paste0(prefix, "_eigen_computed")]] <- diag_obj$eigen_computed
  out[[paste0(prefix, "_eigen_note")]] <- diag_obj$eigen_note
  out
}

.ctgp_as_ctgp_diagnostics <- function(out) {
  class(out) <- "ctgp_diagnostics"
  out
}

.ctgp_build_gp_fit_diagnostics <- function(object, family_label, noise_model, eigen_limit = 250L, include_training_prediction = FALSE, prediction_control = NULL) {
  data <- as.matrix(object$data)
  d <- ncol(data) - 1L
  design <- data[, seq_len(d), drop = FALSE]
  f_matrix <- as.matrix(object$f_matrix)
  l_matrix <- as.matrix(object$l_matrix)
  fi <- as.numeric(object$fi)
  H_base <- .ctgp_gp_correlation_matrix(design, fi, nugget = 0)
  H_effective <- .ctgp_gp_correlation_matrix(design, fi, nugget = .ctgp_null_coalesce(object$effective_nugget, 0))

  KiF <- tryCatch(.ctgp_chol_solve(l_matrix, f_matrix), error = function(e) NULL)
  M <- if (!is.null(KiF)) .ctgp_symmetrize(crossprod(f_matrix, KiF)) else NULL

  mean_rank <- .ctgp_safe_rank(f_matrix)
  mean_cols <- ncol(f_matrix)

  matrices <- list(
    H_base = .ctgp_matrix_diagnostics(H_base, "H base", eigen_limit = eigen_limit),
    H_effective = .ctgp_matrix_diagnostics(H_effective, "H effective", eigen_limit = eigen_limit),
    mean_system = .ctgp_matrix_diagnostics(M, "F' H^{-1} F", eigen_limit = eigen_limit)
  )

  out <- list(
    class_of_object = class(object)[1L],
    model_family = family_label,
    noise_model = noise_model,
    solve_path = "Direct Cholesky factorization of the full GP training correlation matrix.",
    uses_full_training_matrix = TRUE,
    uses_kronecker_decomposition = FALSE,
    n = nrow(design),
    d = d,
    level_num = NA_integer_,
    level_counts = NULL,
    mean_cols = mean_cols,
    mean_rank = mean_rank,
    mean_rank_deficient = isTRUE(mean_rank < mean_cols),
    nugget_input = .ctgp_null_coalesce(object$nugget, NA_real_),
    nugget_provided = .ctgp_null_coalesce(object$nugget_provided, NA),
    stabilization_jitter = .ctgp_null_coalesce(object$stabilization_jitter, NA_real_),
    effective_nugget = .ctgp_null_coalesce(object$effective_nugget, NA_real_),
    sigma_sq = .ctgp_null_coalesce(object$sigma_sq, NA_real_),
    matrices = matrices,
    training_prediction = NULL
  )

  out <- .ctgp_flatten_matrix_diagnostics(out, "H_base", matrices$H_base)
  out <- .ctgp_flatten_matrix_diagnostics(out, "H_effective", matrices$H_effective)
  out <- .ctgp_flatten_matrix_diagnostics(out, "mean_system", matrices$mean_system)
  out$rcond_train_base <- out$H_base_rcond
  out$rcond_train_effective <- out$H_effective_rcond
  out$rcond_mean_system <- out$mean_system_rcond

  if (isTRUE(include_training_prediction)) {
    out$training_prediction <- .ctgp_training_prediction_suite(object, prediction_control = prediction_control)
  }

  .ctgp_as_ctgp_diagnostics(out)
}

.ctgp_build_qqgp_fit_diagnostics <- function(object, family_label, noise_model, eigen_limit = 250L, include_training_prediction = FALSE, prediction_control = NULL) {
  design <- as.matrix(object$design)
  data <- as.matrix(object$data)
  d <- ncol(design)
  level_index <- as.integer(round(data[, d + 1L]))
  level_num <- as.integer(object$level_num)
  f_matrix <- as.matrix(object$f_matrix)
  l_matrix <- as.matrix(object$l_matrix)
  fi <- as.numeric(object$fi)
  t_matrix <- as.matrix(object$t_matrix)

  H <- .ctgp_qqgp_h_matrix(design, fi)
  R_base <- .ctgp_qqgp_r_matrix(H, t_matrix, level_index, nugget = 0)
  R_effective <- .ctgp_qqgp_r_matrix(H, t_matrix, level_index, nugget = .ctgp_null_coalesce(object$effective_nugget, 0))

  RiF <- tryCatch(.ctgp_chol_solve(l_matrix, f_matrix), error = function(e) NULL)
  M <- if (!is.null(RiF)) .ctgp_symmetrize(crossprod(f_matrix, RiF)) else NULL

  mean_rank <- .ctgp_safe_rank(f_matrix)
  mean_cols <- ncol(f_matrix)
  level_counts <- as.integer(tabulate(level_index, nbins = level_num))
  names(level_counts) <- if (!is.null(object$level_levels_used)) as.character(object$level_levels_used) else as.character(seq_len(level_num))

  matrices <- list(
    H = .ctgp_matrix_diagnostics(H, "H (continuous)", eigen_limit = eigen_limit),
    T = .ctgp_matrix_diagnostics(t_matrix, "T (qualitative correlation)", eigen_limit = eigen_limit),
    R_base = .ctgp_matrix_diagnostics(R_base, "R base", eigen_limit = eigen_limit),
    R_effective = .ctgp_matrix_diagnostics(R_effective, "R effective", eigen_limit = eigen_limit),
    mean_system = .ctgp_matrix_diagnostics(M, "F' R^{-1} F", eigen_limit = eigen_limit)
  )

  out <- list(
    class_of_object = class(object)[1L],
    model_family = family_label,
    noise_model = noise_model,
    solve_path = paste(
      "Current QQGP fits construct the full training matrix R = H .* T(level_i, level_j)",
      "and apply a direct Cholesky factorization to R (or R + nugget I).",
      "rcond(T) is therefore reported as a supplementary qualitative-correlation diagnostic, not as the matrix inverted separately in the current implementation."
    ),
    uses_full_training_matrix = TRUE,
    uses_kronecker_decomposition = FALSE,
    n = nrow(design),
    d = d,
    level_num = level_num,
    level_counts = level_counts,
    mean_cols = mean_cols,
    mean_rank = mean_rank,
    mean_rank_deficient = isTRUE(mean_rank < mean_cols),
    nugget_input = .ctgp_null_coalesce(object$nugget, NA_real_),
    nugget_provided = .ctgp_null_coalesce(object$nugget_provided, NA),
    stabilization_jitter = .ctgp_null_coalesce(object$stabilization_jitter, NA_real_),
    effective_nugget = .ctgp_null_coalesce(object$effective_nugget, NA_real_),
    sigma_sq = .ctgp_null_coalesce(object$sigma_sq, NA_real_),
    T_source = if (is.null(object$theta)) "fixed" else "estimated",
    theta_dim = if (is.null(object$theta)) 0L else length(object$theta),
    matrices = matrices,
    training_prediction = NULL
  )

  out <- .ctgp_flatten_matrix_diagnostics(out, "H", matrices$H)
  out <- .ctgp_flatten_matrix_diagnostics(out, "T", matrices$T)
  out <- .ctgp_flatten_matrix_diagnostics(out, "R_base", matrices$R_base)
  out <- .ctgp_flatten_matrix_diagnostics(out, "R_effective", matrices$R_effective)
  out <- .ctgp_flatten_matrix_diagnostics(out, "mean_system", matrices$mean_system)
  out$rcond_train_base <- out$R_base_rcond
  out$rcond_train_effective <- out$R_effective_rcond
  out$rcond_mean_system <- out$mean_system_rcond

  if (isTRUE(include_training_prediction)) {
    out$training_prediction <- .ctgp_training_prediction_suite(object, prediction_control = prediction_control)
  }

  .ctgp_as_ctgp_diagnostics(out)
}

#' Diagnostics for ctGP leaf-model fits
#'
#' Returns conditioning and linear-algebra diagnostics for fitted GP, QQGP,
#' GP regression, and QQGP regression objects. For QQGP fits, the diagnostics
#' report both the full training matrix conditioning and the standalone
#' qualitative-correlation matrix `T`; the latter is a supplementary diagnostic
#' because the current implementation factorizes the full `R` matrix directly.
#'
#' @param object A fitted object returned by [fit_gp()], [fit_qqgp()],
#'   [fit_gp_regression()], or [fit_qqgp_regression()].
#' @param include_training_prediction Logical. If `TRUE`, also evaluate the fit
#'   on its training inputs using high-level prediction and report interpolation /
#'   in-sample prediction summaries. Successful mode-wise summaries include
#'   absolute error, RMSE, predictive variance, and response-scale-normalized
#'   error diagnostics.
#' @param prediction_control Optional prediction-control specification used when
#'   `include_training_prediction = TRUE`. Supply either a single prediction-
#'   control list, or a named list of prediction-control lists. If omitted,
#'   deterministic models evaluate both a strict no-nugget path and an
#'   effective-system path; regression models evaluate the fitted system.
#' @param eigen_limit Maximum matrix dimension for which explicit eigenvalue
#'   summaries are attempted.
#' @param ... Unused.
#'
#' @return An object of class `ctgp_diagnostics`.
#' @export
ctgp_diagnostics <- function(object, ...) {
  UseMethod("ctgp_diagnostics")
}

#' @export
ctgp_diagnostics.gp_fit <- function(object, include_training_prediction = FALSE, prediction_control = NULL, eigen_limit = 250L, ...) {
  .ctgp_build_gp_fit_diagnostics(
    object = object,
    family_label = "Deterministic GP",
    noise_model = "deterministic / emulator",
    eigen_limit = eigen_limit,
    include_training_prediction = include_training_prediction,
    prediction_control = prediction_control
  )
}

#' @export
ctgp_diagnostics.gp_regression_fit <- function(object, include_training_prediction = FALSE, prediction_control = NULL, eigen_limit = 250L, ...) {
  .ctgp_build_gp_fit_diagnostics(
    object = object,
    family_label = "GP regression",
    noise_model = "estimated nugget",
    eigen_limit = eigen_limit,
    include_training_prediction = include_training_prediction,
    prediction_control = prediction_control
  )
}

#' @export
ctgp_diagnostics.qqgp_fit <- function(object, include_training_prediction = FALSE, prediction_control = NULL, eigen_limit = 250L, ...) {
  .ctgp_build_qqgp_fit_diagnostics(
    object = object,
    family_label = "Deterministic QQGP",
    noise_model = "deterministic / emulator",
    eigen_limit = eigen_limit,
    include_training_prediction = include_training_prediction,
    prediction_control = prediction_control
  )
}

#' @export
ctgp_diagnostics.qqgp_regression_fit <- function(object, include_training_prediction = FALSE, prediction_control = NULL, eigen_limit = 250L, ...) {
  .ctgp_build_qqgp_fit_diagnostics(
    object = object,
    family_label = "QQGP regression",
    noise_model = "estimated nugget",
    eigen_limit = eigen_limit,
    include_training_prediction = include_training_prediction,
    prediction_control = prediction_control
  )
}

#' @export
ctgp_diagnostics.ctgp_diagnostics <- function(object, ...) {
  object
}

#' @export
ctgp_diagnostics.default <- function(object, ...) {
  stop(
    "ctgp_diagnostics() does not support objects of class: ",
    paste(class(object), collapse = ", "),
    "."
  )
}

.ctgp_format_diagnostic_value <- function(x, digits = max(3L, getOption("digits") - 2L)) {
  if (length(x) != 1L || is.na(x)) return("NA")
  if (is.infinite(x)) return("Inf")
  formatC(as.numeric(x), digits = digits, format = "fg")
}

#' @export
print.ctgp_diagnostics <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat("ctGP diagnostics\n\n")
  cat("Model:\n")
  cat("  Class                  :", x$class_of_object, "\n")
  cat("  Family                 :", x$model_family, "\n")
  cat("  Noise model            :", x$noise_model, "\n")
  cat("  Observations           :", x$n, "\n")
  cat("  Continuous dimension   :", x$d, "\n")
  if (!is.null(x$level_num) && !is.na(x$level_num)) {
    cat("  Number of levels       :", x$level_num, "\n")
  }
  cat("\n")

  cat("Mean design:\n")
  cat("  Columns                :", x$mean_cols, "\n")
  cat("  Rank                   :", x$mean_rank, "\n")
  cat("  Rank deficient         :", x$mean_rank_deficient, "\n\n")

  cat("Nugget / scale:\n")
  cat("  Input nugget           :", .ctgp_format_diagnostic_value(x$nugget_input, digits), "\n")
  if (!is.null(x$nugget_provided) && !is.na(x$nugget_provided)) {
    cat("  Nugget provided        :", x$nugget_provided, "\n")
  }
  cat("  Stabilization jitter   :", .ctgp_format_diagnostic_value(x$stabilization_jitter, digits), "\n")
  cat("  Effective nugget       :", .ctgp_format_diagnostic_value(x$effective_nugget, digits), "\n")
  cat("  sigma_sq                :", .ctgp_format_diagnostic_value(x$sigma_sq, digits), "\n\n")

  cat("Conditioning:\n")
  cat("  rcond(train base)      :", .ctgp_format_diagnostic_value(x$rcond_train_base, digits), "\n")
  cat("  rcond(train effective) :", .ctgp_format_diagnostic_value(x$rcond_train_effective, digits), "\n")
  cat("  rcond(mean system)     :", .ctgp_format_diagnostic_value(x$rcond_mean_system, digits), "\n")
  if (!is.null(x$H_rcond) && !is.na(x$H_rcond)) {
    cat("  rcond(H)               :", .ctgp_format_diagnostic_value(x$H_rcond, digits), "\n")
  }
  if (!is.null(x$T_rcond) && !is.na(x$T_rcond)) {
    cat("  rcond(T)               :", .ctgp_format_diagnostic_value(x$T_rcond, digits), "\n")
  }
  cat("\n")

  if (!is.null(x$level_counts)) {
    cat("Level counts:\n")
    print(data.frame(level = names(x$level_counts), count = as.integer(x$level_counts)), row.names = FALSE)
    cat("\n")
  }

  if (!is.null(x$training_prediction)) {
    cat("Training-prediction checks:\n")
    tp <- x$training_prediction
    cat("  Primary mode            :", tp$primary_mode, "\n")
    cat("  Any mode succeeded      :", tp$any_success, "\n")
    for (mode_name in tp$mode_order) {
      mode_res <- tp$modes[[mode_name]]
      cat("  - Mode                  :", mode_name, "\n")
      cat("    success               :", mode_res$success, "\n")
      if (isTRUE(mode_res$success)) {
        cat("    max abs error         :", .ctgp_format_diagnostic_value(mode_res$max_abs_error, digits), "\n")
        cat("    RMSE                  :", .ctgp_format_diagnostic_value(mode_res$rmse, digits), "\n")
        cat("    max pred_var           :", .ctgp_format_diagnostic_value(mode_res$max_predvar, digits), "\n")
        cat("    mean pred_var          :", .ctgp_format_diagnostic_value(mode_res$mean_predvar, digits), "\n")
      } else {
        cat("    message               :", mode_res$message, "\n")
      }
    }
    cat("\n")
  }

  cat("Implementation note:\n")
  cat("  ", x$solve_path, "\n", sep = "")

  invisible(x)
}
