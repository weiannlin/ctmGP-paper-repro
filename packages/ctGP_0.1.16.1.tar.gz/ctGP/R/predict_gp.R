
.ctgp_resolve_prediction_control <- function(prediction_control, fit, allow_use_nugget = TRUE) {
  opt <- fit$optimizer_control
  defaults <- list(
    use_openmp = if (!is.null(opt$use_openmp)) isTRUE(opt$use_openmp) else TRUE,
    num_threads = if (!is.null(opt$num_threads)) as.integer(opt$num_threads) else 0L,
    block_size = NULL,
    variance_mode = "universal"
  )
  if (allow_use_nugget) {
    defaults$use_nugget <- TRUE
  }

  if (is.null(prediction_control)) {
    prediction_control <- list()
  }
  if (!is.list(prediction_control)) {
    stop("prediction_control must be a list.")
  }

  unknown <- setdiff(names(prediction_control), names(defaults))
  if (length(unknown) > 0L) {
    stop(
      "Unknown entries in prediction_control: ",
      paste(unknown, collapse = ", "),
      "."
    )
  }

  control <- defaults
  if (length(prediction_control) > 0L) {
    control[names(prediction_control)] <- prediction_control
  }

  control$use_openmp <- isTRUE(control$use_openmp)
  control$num_threads <- as.integer(control$num_threads)
  if (!is.null(control$block_size)) {
    control$block_size <- as.integer(control$block_size)
  }
  if (allow_use_nugget) {
    ug <- control$use_nugget
    if (is.logical(ug)) {
      if (length(ug) != 1L || is.na(ug)) {
        stop("prediction_control$use_nugget must be a non-missing logical scalar, a character mode, or a nonnegative numeric scalar.")
      }
      control$use_nugget <- if (isTRUE(ug)) "effective" else "none"
    } else if (is.character(ug)) {
      if (length(ug) != 1L || is.na(ug)) {
        stop("prediction_control$use_nugget must be a length-1 non-missing character string.")
      }
      ug_norm <- tolower(trimws(ug))
      if (ug_norm %in% c("effective", "fit", "true")) {
        control$use_nugget <- "effective"
      } else if (ug_norm %in% c("none", "false", "off", "no")) {
        control$use_nugget <- "none"
      } else if (ug_norm %in% c("given", "input")) {
        control$use_nugget <- "given"
      } else {
        stop("prediction_control$use_nugget must be one of TRUE/FALSE, 'effective', 'none', 'given', or a nonnegative numeric scalar.")
      }
    } else if (is.numeric(ug)) {
      if (length(ug) != 1L || is.na(ug) || !is.finite(ug) || ug < 0) {
        stop("prediction_control$use_nugget as numeric must be a finite nonnegative scalar.")
      }
      control$use_nugget <- as.numeric(ug)
    } else {
      stop("prediction_control$use_nugget must be logical, character, or numeric.")
    }
  }

  if (length(control$num_threads) != 1L || is.na(control$num_threads)) {
    stop("prediction_control$num_threads must be an integer scalar.")
  }
  if (!is.null(control$block_size)) {
    if (length(control$block_size) != 1L || is.na(control$block_size) || control$block_size < 1L) {
      stop("prediction_control$block_size must be NULL or a positive integer scalar.")
    }
  }

  vm <- control$variance_mode
  if (!is.character(vm) || length(vm) != 1L || is.na(vm)) {
    stop("prediction_control$variance_mode must be a non-missing character scalar.")
  }
  vm <- tolower(trimws(vm))
  if (!vm %in% c("universal", "legacy")) {
    stop("prediction_control$variance_mode must be either 'universal' or 'legacy'.")
  }
  control$variance_mode <- vm

  control
}

.ctgp_gp_infer_mean_source <- function(fit) {
  if (!is.null(fit$mean_source)) {
    return(as.character(fit$mean_source))
  }

  if (!is.null(fit$f_matrix) && is.matrix(fit$f_matrix) &&
      ncol(fit$f_matrix) == 1L &&
      all(abs(fit$f_matrix[, 1] - 1) < 1e-12)) {
    return("default")
  }

  "f_matrix"
}

.ctgp_gp_normalize_newdata <- function(newdata, x_colnames_used) {
  d <- length(x_colnames_used)

  if (d == 1L) {
    if (is.vector(newdata) && !is.list(newdata)) {
      x_new <- matrix(as.numeric(newdata), ncol = 1L)
    } else if (is.matrix(newdata)) {
      if (ncol(newdata) != 1L) {
        stop("For 1D input, newdata matrix must have exactly 1 column.")
      }
      x_new <- newdata
    } else if (is.data.frame(newdata)) {
      if (ncol(newdata) != 1L) {
        stop("For 1D input, newdata data.frame must have exactly 1 column.")
      }
      x_new <- as.matrix(newdata)
    } else {
      stop("For 1D input, newdata must be a numeric vector, matrix, or data.frame.")
    }
  } else {
    if (is.vector(newdata) && !is.list(newdata)) {
      if (length(newdata) != d) {
        stop(sprintf("For input dimension >= 2, a plain vector must have length %d.", d))
      }
      x_new <- matrix(as.numeric(newdata), nrow = 1L)
    } else if (is.matrix(newdata)) {
      x_new <- newdata
    } else if (is.data.frame(newdata)) {
      x_new <- as.matrix(newdata)
    } else {
      stop("For input dimension >= 2, newdata must be a matrix, data.frame, or a numeric vector of length d representing one point.")
    }

    if (ncol(x_new) != d) {
      stop(sprintf("newdata must have exactly %d columns.", d))
    }
  }

  storage.mode(x_new) <- "double"
  if (any(!is.finite(x_new))) {
    stop("newdata must contain only finite numeric values.")
  }

  cn <- colnames(x_new)
  if (!is.null(cn)) {
    cn_clean <- make.names(cn, unique = TRUE)
    colnames(x_new) <- cn_clean
    if (all(x_colnames_used %in% cn_clean)) {
      x_new <- x_new[, x_colnames_used, drop = FALSE]
    }
  }

  if (is.null(colnames(x_new))) {
    colnames(x_new) <- x_colnames_used
  }
  if (!identical(colnames(x_new), x_colnames_used)) {
    if (ncol(x_new) != d) {
      stop(sprintf("newdata must have exactly %d columns.", d))
    }
    colnames(x_new) <- x_colnames_used
  }

  mean_df <- as.data.frame(x_new)
  names(mean_df) <- x_colnames_used

  list(matrix = x_new, data = mean_df)
}

.ctgp_gp_build_prediction_f_matrix <- function(fit, newdata_df, f_matrix = NULL) {
  source <- .ctgp_gp_infer_mean_source(fit)

  if (source == "default") {
    FPred <- matrix(1, nrow = nrow(newdata_df), ncol = 1L)
    colnames(FPred) <- if (!is.null(fit$mean_terms)) fit$mean_terms else "(Intercept)"
    return(FPred)
  }

  if (source == "formula") {
    if (is.null(fit$mean_formula)) {
      stop("fit does not contain mean_formula needed for prediction.")
    }
    rhs_formula <- .ctgp_gp_normalize_formula(fit$mean_formula)
    FPred <- stats::model.matrix(rhs_formula, data = newdata_df)
    if (!is.null(fit$mean_terms) && !identical(colnames(FPred), fit$mean_terms)) {
      stop(
        "Prediction mean design matrix generated from fit$mean_formula does not match the training mean terms."
      )
    }
    return(FPred)
  }

  if (source == "f_matrix") {
    if (is.null(f_matrix)) {
      stop(
        "This GP fit was created using a custom f_matrix. For prediction you must provide the prediction f_matrix explicitly. ",
        "If you want automatic prediction mean construction, fit the model with mean_formula instead."
      )
    }
    FPred <- as.matrix(f_matrix)
    storage.mode(FPred) <- "double"
    if (nrow(FPred) != nrow(newdata_df)) {
      stop("Prediction f_matrix must have the same number of rows as newdata.")
    }
    if (!is.null(fit$mean_terms) && ncol(FPred) != length(fit$mean_terms)) {
      stop("Prediction f_matrix must have the same number of columns as the training f_matrix.")
    }
    if (any(!is.finite(FPred))) {
      stop("Prediction f_matrix must contain only finite numeric values.")
    }
    if (!is.null(fit$mean_terms) && is.null(colnames(FPred))) {
      colnames(FPred) <- fit$mean_terms
    }
    return(FPred)
  }

  stop("Unknown GP mean_source in fit object.")
}

predict_gp <- function(fit, newdata, f_matrix = NULL, indep = FALSE, prediction_control = list(), ...) {
  UseMethod("predict_gp")
}

#' @export
predict_gp.gp_fit <- function(object, newdata, f_matrix = NULL, indep = FALSE, prediction_control = list(), ...) {
  if (is.null(object$data)) {
    stop("fit does not look like a valid ctGP GP fit object.")
  }

  x_colnames_used <- object$x_colnames_used
  if (is.null(x_colnames_used)) {
    x_colnames_used <- .ctgp_gp_make_data_names(as.matrix(object$data))$x
  }

  new_info <- .ctgp_gp_normalize_newdata(newdata, x_colnames_used)
  if (!is.null(object$input_normalizer)) {
    x_norm <- .ctgp_apply_fit_input_normalizer(new_info$matrix, object)
    new_info$matrix <- x_norm
    new_info$data[, x_colnames_used] <- as.data.frame(x_norm, stringsAsFactors = FALSE, check.names = FALSE)
  }
  FPred <-  .ctgp_gp_build_prediction_f_matrix(object, new_info$data, f_matrix = f_matrix)
  control <-  .ctgp_resolve_prediction_control(prediction_control, object, allow_use_nugget = TRUE)

  t_start <- proc.time()

  nugget_override <- NULL
  use_nugget_flag <- TRUE

  if (is.character(control$use_nugget)) {
    if (identical(control$use_nugget, "none")) {
      use_nugget_flag <- FALSE
    } else if (identical(control$use_nugget, "effective")) {
      use_nugget_flag <- TRUE
    } else if (identical(control$use_nugget, "given")) {
      if (is.null(object$nugget_provided) || !isTRUE(object$nugget_provided) || is.null(object$nugget) || !is.finite(object$nugget) || object$nugget < 0) {
        stop(
          "prediction_control$use_nugget = 'given' requires a fit created with an explicit nonnegative nugget."
        )
      }
      nugget_override <- as.numeric(object$nugget)
      use_nugget_flag <- TRUE
    }
  } else if (is.numeric(control$use_nugget)) {
    nugget_override <- as.numeric(control$use_nugget)
    use_nugget_flag <- TRUE
  }

  out <- predict_gp_cpp(
    model = object,
    new_point = new_info$matrix,
    f_matrix = FPred,
    indep = indep,
    use_nugget = use_nugget_flag,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    block_size = if (is.null(control$block_size)) 0L else control$block_size,
    nugget_override = nugget_override,
    variance_mode = control$variance_mode
  )

  elapsed <- proc.time() - t_start

  if (!is.null(out$pred_var)) {
    out$pred_var <- pmax(0, as.numeric(out$pred_var))
  } else if (!is.null(out$pred_sigma_sq)) {
    out$pred_var <- pmax(0, diag(out$pred_sigma_sq))
  } else {
    stop("GP prediction did not return pred_var or pred_sigma_sq.")
  }
  out <- .ctgp_inverse_prediction_scale(out, object$response_normalizer)
  out$timing <- list(
    wall_sec  = unname(elapsed["elapsed"]),
    cpu_sec   = unname(elapsed["user.self"] + elapsed["sys.self"]),
    user_sec  = unname(elapsed["user.self"]),
    sys_sec   = unname(elapsed["sys.self"]),
    elapsed   = unname(elapsed["elapsed"]),
    user.self = unname(elapsed["user.self"]),
    sys.self  = unname(elapsed["sys.self"])
  )
  out$prediction_control <- control
  out$variance_mode <- control$variance_mode
  out
}

#' @export
predict_gp.gp_regression_fit <- function(object, newdata, f_matrix = NULL, indep = FALSE, prediction_control = list(), ...) {
  if (is.null(object$data)) {
    stop("fit does not look like a valid ctGP GP regression fit object.")
  }

  x_colnames_used <- object$x_colnames_used
  if (is.null(x_colnames_used)) {
    x_colnames_used <- .ctgp_gp_make_data_names(as.matrix(object$data))$x
  }

  new_info <- .ctgp_gp_normalize_newdata(newdata, x_colnames_used)
  if (!is.null(object$input_normalizer)) {
    x_norm <- .ctgp_apply_fit_input_normalizer(new_info$matrix, object)
    new_info$matrix <- x_norm
    new_info$data[, x_colnames_used] <- as.data.frame(x_norm, stringsAsFactors = FALSE, check.names = FALSE)
  }
  FPred <-  .ctgp_gp_build_prediction_f_matrix(object, new_info$data, f_matrix = f_matrix)
  control <-  .ctgp_resolve_prediction_control(prediction_control, object, allow_use_nugget = FALSE)

  t_start <- proc.time()

  out <- predict_gp_cpp(
    model = object,
    new_point = new_info$matrix,
    f_matrix = FPred,
    indep = indep,
    use_nugget = TRUE,
    use_openmp = control$use_openmp,
    num_threads = control$num_threads,
    block_size = if (is.null(control$block_size)) 0L else control$block_size,
    variance_mode = control$variance_mode
  )

  elapsed <- proc.time() - t_start

  if (!is.null(out$pred_var)) {
    out$pred_var <- pmax(0, as.numeric(out$pred_var))
  } else if (!is.null(out$pred_sigma_sq)) {
    out$pred_var <- pmax(0, diag(out$pred_sigma_sq))
  } else {
    stop("GP prediction did not return pred_var or pred_sigma_sq.")
  }
  out <- .ctgp_inverse_prediction_scale(out, object$response_normalizer)
  out$timing <- list(
    wall_sec  = unname(elapsed["elapsed"]),
    cpu_sec   = unname(elapsed["user.self"] + elapsed["sys.self"]),
    user_sec  = unname(elapsed["user.self"]),
    sys_sec   = unname(elapsed["sys.self"]),
    elapsed   = unname(elapsed["elapsed"]),
    user.self = unname(elapsed["user.self"]),
    sys.self  = unname(elapsed["sys.self"])
  )
  out$prediction_control <- control
  out$variance_mode <- control$variance_mode
  out
}

#' @export
predict_gp.default <- function(fit, ...) {
  stop(
    "predict_gp() does not support objects of class: ",
    paste(class(fit), collapse = ", "),
    "."
  )
}
