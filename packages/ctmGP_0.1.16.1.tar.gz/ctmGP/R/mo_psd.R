# ctmGP — utilities for ensuring per-candidate predictive Σ is PSD.
#
# Numerical kriging on small datasets sometimes returns predictive covariance
# matrices that are non-PSD (negative eigenvalue or zero diagonal) due to
# floating-point drift in the C(Σ_xX) Σ_XX⁻¹ C(Σ_Xx) update.  These break the
# downstream EHVI engine's Cholesky.  We project to nearest PSD by eigen-clip.

#' Project a symmetric matrix onto the PSD cone (eigen-clip).
#'
#' Symmetrizes (Σ + Σᵀ)/2, computes eigendecomposition, clips eigenvalues to
#' a floor `eps`, reassembles.  The result has all eigenvalues ≥ eps.
#'
#' @param Sigma a square matrix (will be symmetrized).
#' @param eps non-negative floor for eigenvalues.  Default 1e-10.
#' @return PSD matrix with the same dimensions.
#' @keywords internal
.psd_project <- function(Sigma, eps = 1e-10) {
  Sigma <- (Sigma + t(Sigma)) / 2
  ev    <- eigen(Sigma, symmetric = TRUE)
  d     <- pmax(ev$values, eps)
  ev$vectors %*% diag(d, length(d), length(d)) %*% t(ev$vectors)
}

#' Apply `.psd_project` to each entry of a list of T×T matrices.
#' @keywords internal
.psd_project_list <- function(sigma_list, eps = 1e-10) {
  lapply(sigma_list, .psd_project, eps = eps)
}
