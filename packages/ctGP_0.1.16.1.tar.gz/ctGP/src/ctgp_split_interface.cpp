#include <RcppArmadillo.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <set>
#include <string>
#include <vector>

#include "optimizer_pso.h"

#ifdef _OPENMP
#include <omp.h>
#endif

// [[Rcpp::depends(RcppArmadillo)]]

namespace {

struct split_candidate {
  bool valid;
  int var_index;
  double score;
  std::size_t order_index;
  std::vector<int> left_codes;
  std::vector<int> right_codes;
  std::vector<int> left_rows;
  std::vector<int> right_rows;
  std::vector<int> left_ids;
  std::vector<int> right_ids;

  split_candidate()
    : valid(false), var_index(-1), score(std::numeric_limits<double>::infinity()), order_index(std::numeric_limits<std::size_t>::max()) {}
};

std::vector<int> unique_sorted_vector(const std::vector<int>& x) {
  std::vector<int> out = x;
  std::sort(out.begin(), out.end());
  out.erase(std::unique(out.begin(), out.end()), out.end());
  return out;
}

bool candidate_better(const split_candidate& a, const split_candidate& b) {
  if (!a.valid) return false;
  if (!b.valid) return true;
  if (a.score < b.score) return true;
  if (a.score > b.score) return false;
  if (a.var_index < b.var_index) return true;
  if (a.var_index > b.var_index) return false;
  return a.order_index < b.order_index;
}

double split_score(
    const arma::mat& tau_matrix,
    const std::vector<int>& left_ids,
    const std::vector<int>& right_ids,
    bool use_abs_tau
) {
  if (left_ids.empty() || right_ids.empty()) {
    return std::numeric_limits<double>::infinity();
  }
  double best = -std::numeric_limits<double>::infinity();
  for (std::size_t i = 0; i < left_ids.size(); ++i) {
    const int li = left_ids[i] - 1;
    if (li < 0 || li >= static_cast<int>(tau_matrix.n_rows)) {
      return std::numeric_limits<double>::infinity();
    }
    for (std::size_t j = 0; j < right_ids.size(); ++j) {
      const int rj = right_ids[j] - 1;
      if (rj < 0 || rj >= static_cast<int>(tau_matrix.n_cols)) {
        return std::numeric_limits<double>::infinity();
      }
      double val = tau_matrix(li, rj);
      if (use_abs_tau) {
        val = std::abs(val);
      }
      if (val > best) {
        best = val;
      }
    }
  }
  return best;
}

void build_combinations_recursive(
    const std::vector<int>& levels,
    std::size_t start,
    std::size_t choose_k,
    std::vector<int>& current,
    std::vector< std::vector<int> >& out
) {
  if (current.size() == choose_k) {
    out.push_back(current);
    return;
  }
  for (std::size_t i = start; i < levels.size(); ++i) {
    current.push_back(levels[i]);
    build_combinations_recursive(levels, i + 1, choose_k, current, out);
    current.pop_back();
  }
}

std::vector< std::vector<int> > build_legacy_combinations(const std::vector<int>& levels) {
  std::vector< std::vector<int> > out;
  if (levels.size() <= 1) return out;
  for (std::size_t choose_k = 1; choose_k < levels.size(); ++choose_k) {
    std::vector<int> current;
    build_combinations_recursive(levels, 0, choose_k, current, out);
  }
  const std::size_t keep_n = (static_cast<std::size_t>(1) << (levels.size() - 1)) - 1;
  if (out.size() > keep_n) out.resize(keep_n);
  return out;
}

split_candidate evaluate_right_codes_candidate(
    const std::vector<int>& right_codes,
    int var_index,
    std::size_t order_index,
    const std::vector<int>& levels,
    const std::vector<int>& node_codes,
    const std::vector<int>& node_rows,
    const std::vector<int>& node_combined,
    const arma::mat& tau_matrix,
    int min_rows,
    int min_combined,
    bool use_abs_tau
) {
  split_candidate cand;
  if (levels.size() <= 1) {
    return cand;
  }

  cand.var_index = var_index;
  cand.order_index = order_index;
  cand.right_codes = right_codes;

  std::set<int> right_code_set(cand.right_codes.begin(), cand.right_codes.end());
  std::set<int> left_ids_set;
  std::set<int> right_ids_set;

  for (std::size_t i = 0; i < node_rows.size(); ++i) {
    const bool go_right = (right_code_set.find(node_codes[i]) != right_code_set.end());
    if (go_right) {
      cand.right_rows.push_back(node_rows[i]);
      right_ids_set.insert(node_combined[i]);
    } else {
      cand.left_rows.push_back(node_rows[i]);
      left_ids_set.insert(node_combined[i]);
    }
  }

  if (static_cast<int>(cand.left_rows.size()) < min_rows || static_cast<int>(cand.right_rows.size()) < min_rows) {
    cand.valid = false;
    return cand;
  }

  cand.left_ids.assign(left_ids_set.begin(), left_ids_set.end());
  cand.right_ids.assign(right_ids_set.begin(), right_ids_set.end());
  if (static_cast<int>(cand.left_ids.size()) < min_combined || static_cast<int>(cand.right_ids.size()) < min_combined) {
    cand.valid = false;
    return cand;
  }

  cand.left_codes.reserve(levels.size() - cand.right_codes.size());
  for (std::size_t k = 0; k < levels.size(); ++k) {
    if (right_code_set.find(levels[k]) == right_code_set.end()) {
      cand.left_codes.push_back(levels[k]);
    }
  }

  cand.score = split_score(tau_matrix, cand.left_ids, cand.right_ids, use_abs_tau);
  cand.valid = std::isfinite(cand.score);
  return cand;
}

} // namespace

// [[Rcpp::export]]
Rcpp::List ctgp_find_best_split_cpp(
    const arma::mat& qualitative_codes,
    const arma::ivec& combined_id,
    const arma::mat& tau_matrix,
    const arma::uvec& node_rows,
    int min_rows = 1,
    int min_combined = 1,
    bool use_openmp = true,
    int num_threads = 0,
    bool use_abs_tau = true
) {
  if (qualitative_codes.n_rows != static_cast<arma::uword>(combined_id.n_elem)) {
    Rcpp::stop("qualitative_codes and combined_id must have the same number of rows.");
  }
  if (node_rows.n_elem == 0) {
    return Rcpp::List::create(
      Rcpp::Named("is_leaf") = true,
      Rcpp::Named("reason") = "empty node"
    );
  }

  std::vector<int> node_id_vec;
  node_id_vec.reserve(node_rows.n_elem);
  for (arma::uword ii = 0; ii < node_rows.n_elem; ++ii) {
    const int row1 = static_cast<int>(node_rows(ii));
    if (row1 < 1 || row1 > static_cast<int>(combined_id.n_elem)) {
      Rcpp::stop("node_rows must be a 1-based integer vector inside the data row range.");
    }
    node_id_vec.push_back(combined_id(row1 - 1));
  }
  const std::vector<int> node_ids = unique_sorted_vector(node_id_vec);
  if (static_cast<int>(node_ids.size()) <= 1) {
    return Rcpp::List::create(
      Rcpp::Named("is_leaf") = true,
      Rcpp::Named("reason") = "single combined category"
    );
  }

  split_candidate best;

  for (arma::uword j = 0; j < qualitative_codes.n_cols; ++j) {
    std::vector<int> node_codes;
    std::vector<int> node_rows_vec;
    std::vector<int> node_combined_vec;
    node_codes.reserve(node_rows.n_elem);
    node_rows_vec.reserve(node_rows.n_elem);
    node_combined_vec.reserve(node_rows.n_elem);

    for (arma::uword ii = 0; ii < node_rows.n_elem; ++ii) {
      const int row1 = static_cast<int>(node_rows(ii));
      node_rows_vec.push_back(row1);
      node_codes.push_back(static_cast<int>(std::llround(qualitative_codes(row1 - 1, j))));
      node_combined_vec.push_back(combined_id(row1 - 1));
    }

    const std::vector<int> levels = unique_sorted_vector(node_codes);
    if (levels.size() <= 1) {
      continue;
    }
    if (levels.size() >= 63) {
      Rcpp::stop("A qualitative factor has too many levels for exhaustive binary split enumeration in the current C++ backend.");
    }

    const std::vector< std::vector<int> > comb_list = build_legacy_combinations(levels);
    if (comb_list.empty()) {
      continue;
    }

    split_candidate best_var;
    const int n_tasks = (comb_list.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
      ? std::numeric_limits<int>::max()
      : static_cast<int>(comb_list.size());
    const int n_threads = ctgp_openmp_resolve_threads(use_openmp, num_threads, n_tasks);
#ifndef _OPENMP
    (void)n_threads;
#endif

#ifdef _OPENMP
    if (n_threads > 1 && n_tasks > 1) {
#pragma omp parallel num_threads(n_threads)
      {
        split_candidate local_best;
#pragma omp for schedule(static)
        for (int comb_idx = 0; comb_idx < static_cast<int>(comb_list.size()); ++comb_idx) {
          split_candidate cand = evaluate_right_codes_candidate(
            comb_list[static_cast<std::size_t>(comb_idx)],
            static_cast<int>(j + 1),
            static_cast<std::size_t>(comb_idx),
            levels,
            node_codes,
            node_rows_vec,
            node_combined_vec,
            tau_matrix,
            min_rows,
            min_combined,
            use_abs_tau
          );
          if (candidate_better(cand, local_best)) {
            local_best = cand;
          }
        }
#pragma omp critical(ctgp_split_best)
        {
          if (candidate_better(local_best, best_var)) {
            best_var = local_best;
          }
        }
      }
    } else
#endif
    {
      for (std::size_t comb_idx = 0; comb_idx < comb_list.size(); ++comb_idx) {
        split_candidate cand = evaluate_right_codes_candidate(
          comb_list[comb_idx],
          static_cast<int>(j + 1),
          comb_idx,
          levels,
          node_codes,
          node_rows_vec,
          node_combined_vec,
          tau_matrix,
          min_rows,
          min_combined,
          use_abs_tau
        );
        if (candidate_better(cand, best_var)) {
          best_var = cand;
        }
      }
    }

    if (candidate_better(best_var, best)) {
      best = best_var;
    }
  }

  if (!best.valid) {
    return Rcpp::List::create(
      Rcpp::Named("is_leaf") = true,
      Rcpp::Named("reason") = "no admissible split"
    );
  }

  return Rcpp::List::create(
    Rcpp::Named("is_leaf") = false,
    Rcpp::Named("split_var_index") = best.var_index,
    Rcpp::Named("left_codes") = best.left_codes,
    Rcpp::Named("right_codes") = best.right_codes,
    Rcpp::Named("score") = best.score,
    Rcpp::Named("left_rows") = best.left_rows,
    Rcpp::Named("right_rows") = best.right_rows,
    Rcpp::Named("left_ids") = best.left_ids,
    Rcpp::Named("right_ids") = best.right_ids,
    Rcpp::Named("node_ids") = node_ids,
    Rcpp::Named("n_left") = static_cast<int>(best.left_rows.size()),
    Rcpp::Named("n_right") = static_cast<int>(best.right_rows.size())
  );
}
