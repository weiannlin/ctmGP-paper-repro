# ctmGP — IGD+ (Inverted Generational Distance Plus) performance metric.
#
# Reference: Ishibuchi et al. 2015 (Modified distance calculation in
# generational distance and inverted generational distance), as adopted in the
# AoAS paper §4.3.2 (eq 4.1).
#
# IGD+(A, PF) = (1/|PF|) * Σ_{p ∈ PF} d+(p, A)
# d+(p, A)    = min_{a ∈ A} sqrt(Σ_i max(a_i - p_i, 0)²)
#
# Smaller IGD+ ⇒ A better approximates the true Pareto frontier PF.  The "+"
# variant penalises only POSITIVE deviations (a_i > p_i meaning a is worse
# than p in the i-th objective under min convention), unlike vanilla IGD which
# uses signed Euclidean distance and can reward "above-front" points.

#' IGD+ (Inverted Generational Distance Plus) — paper §4.3.2 / eq 4.1.
#'
#' For each true PF point p, finds the closest predicted-PF point a (in the
#' positive-deviation Euclidean metric) and averages those distances.
#'
#' @param predicted_pf n_A × T numeric matrix; the predicted/approximate
#'   Pareto frontier (e.g., the non-dominated subset of all evaluated points
#'   so far in a BO loop).
#' @param true_pf n_PF × T numeric matrix; the true Pareto frontier (or the
#'   best known reference if the true one is unavailable).
#' @return non-negative scalar.  0 iff `predicted_pf` componentwise dominates
#'   `true_pf` at every reference point (i.e., perfect or super-optimal cover).
#' @export
igd_plus <- function(predicted_pf, true_pf) {
  if (!is.matrix(predicted_pf)) predicted_pf <- as.matrix(predicted_pf)
  if (!is.matrix(true_pf))      true_pf      <- as.matrix(true_pf)
  storage.mode(predicted_pf) <- "double"
  storage.mode(true_pf)      <- "double"

  if (ncol(predicted_pf) != ncol(true_pf))
    stop("predicted_pf and true_pf must have the same number of columns (T).")
  if (nrow(true_pf) == 0L)
    stop("true_pf must contain at least one point.")
  if (nrow(predicted_pf) == 0L)
    return(Inf)   # no predicted points → infinitely far from any true PF

  ctmgp_igd_plus_cpp(predicted_pf, true_pf)
}
